import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { User } from 'app/model/user';


@Directive({ selector: '[showForUserRole]' })
export class ShowForUserRoleDirective {
    private hasView: boolean = false;
    private hasAccess: boolean = false;

    constructor(private templateRef: TemplateRef<any>, private viewContainer: ViewContainerRef, private user: User) {
        
    }

    @Input() set showForUserRole(allowedRoles: Array<String>) {
        this.hasAccess = this.user.isMemberOf(allowedRoles);
        if (this.hasAccess && !this.hasView) {
            this.viewContainer.createEmbeddedView(this.templateRef);
            this.hasView = true;
        } else if (!this.hasAccess && this.hasView) {
            this.viewContainer.clear();
            this.hasView = false;
        }
    }
}
