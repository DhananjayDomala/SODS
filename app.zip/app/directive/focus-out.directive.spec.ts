import { FocusOutDirective } from './focus-out.directive';

describe('FocusOutDirective', () => {
  it('should create an instance', () => {
    const directive = new FocusOutDirective();
    expect(directive).toBeTruthy();
  });
});
