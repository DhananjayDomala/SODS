import { Directive, Input, Component } from '@angular/core';
import { NG_VALIDATORS, Validator, ValidatorFn, FormControl } from '@angular/forms';

@Directive({
  selector: '[validationType][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: ValidatorDirective,
      multi: true
    }
  ]
})

export class ValidatorDirective implements Validator {
  validator: ValidatorFn;
  pattern: string;

  regex = {
    'integer': {pattern: '^[0-9]{0,}$', errorMessage: 'Please enter a valid number.'},
    'string': {pattern: '^[0-9a-zA-Z*/\.\'_ \b]+$', errorMessage: 'Remove special character.'},
    'email': {pattern: '^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$', errorMessage: 'Please enter a valid email'},
    'alphanumeric': {pattern: '^[a-zA-Z0-9]*$', errorMessage: 'Please enter a valid alphanumeric character.'}
  };

  constructor() {
    
  }

  @Input() set validationType(pattern: string) {
    this.pattern = pattern;
    this.validator = this.validateTextField();
   }

  validate(c: FormControl) {
    return this.validator(c);
  }

  validateTextField(): ValidatorFn {
    return (c: FormControl) => {
      let value = c.value;
      let leadingSpace = true;
      if (value) {
        leadingSpace = value.charAt(0) === ' ';
      }

      let isValid = new RegExp(this.regex[this.pattern].pattern).test(c.value);
      if ((isValid && !leadingSpace) || !value) {
        return null;
      } else {
        // uncomment the line below to remove disallowed character from the textfield
        //c.setValue(c.value.slice(0, -1));
        return {
          validator: {
            valid: false,
            message: this.regex[this.pattern].errorMessage
          }
        };
      }
    }
  }
}
