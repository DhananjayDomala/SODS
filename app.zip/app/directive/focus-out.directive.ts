import { Directive, ElementRef, Renderer, HostListener, Input, ViewContainerRef, TemplateRef } from '@angular/core';

@Directive({
  selector: '[appFocusOut]'
})
export class FocusOutDirective {
  @Input() comp: any;

  constructor(private el: ElementRef, private renderer: Renderer) { }

  ngOnInit() {
    console.log(this.comp); // This will give you the component instance.
  }

  @HostListener('focusout') focusOut() {
    setTimeout(() => {
      if(this.comp.overlayVisible) {
        this.comp.overlayVisible = false;
      } else {
        this.comp.isVisible = false;
      }

    }, 300);

  }

  @HostListener('focus') focus() {
    setTimeout(() => {
      if(this.comp.overlayVisible) {
        this.comp.overlayVisible = true;
      } else {
        this.comp.isVisible = true;
      }

    }, 150);
  }
}
