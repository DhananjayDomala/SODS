import { ValidatorDirective } from 'app/directive/validator.directive';


describe('EmailValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
