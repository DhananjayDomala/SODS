import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-req-details',
  templateUrl: './search-req-details.component.html',
  styleUrls: ['./search-req-details.component.css']
})
export class SearchReqDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
