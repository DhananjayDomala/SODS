import { HeaderComponent } from './../header/header.component';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../../events/action-events';
import { ANALYZE_FOR_ENTRY_COMPONENTS, Component, OnDestroy, OnInit, Query } from '@angular/core';

import {OutOfService} from '../../service/outoffice.service';


@Component({
  selector: 'app-outofoffice',
  templateUrl: './outofoffice.component.html',
  styleUrls: ['./outofoffice.component.scss']
})
export class OutofofficeComponent extends BaseComponent implements OnInit, OnDestroy {
  isShow: boolean = false;
  date_selection_error: boolean = false;
  minDate: Date = new Date();
  value: Date = new Date();
  selectedType: string;
  searchedUsers: any[] = [];
  results: any[] = [];
  searchedforwardTaskUsers: any[] = [];
  forwardTaskUsers: any[] = [];
  isUserError: boolean = false;
  isForwardError: boolean = false;
  
  forwardTask: any = '';
  user: any = '';
  isUpdateSuccess: any = false;
  isUpdateError: any = false;
  networkID:any;
  typeOfSearch:any = '';
  errorMsg: string = '';

  isSuperUser: boolean = false;

  constructor(
        readonly actionDispatcherService: ActionDispatcherService,
        readonly stateRepresentationRendererService: StateRepresentationRendererService,
        public outOfService :OutOfService
    ) {
        super(stateRepresentationRendererService);

        const mapping: any = [];

        //  For loading the divisions in the market dropdown menu
        mapping[ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS] = (data: any) => {
            this.renderTasksTo(data);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.SET_OUT_OF_OFFICE_STATUS_SUCCESS] = (data: any) => {
            this.onSubmitSuccess(data);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.UN_SET_OUT_OF_OFFICE_STATUS_SUCCESS] = (data: any) => {
            this.onSubmitSuccess(data, true);
        };

        mapping[ModelChangeUpdateEvents.GET_SEARCH_USER_FAIL] = (data: any) => {
            this.renderTasksToFail(data);
        };

        mapping[ModelChangeUpdateEvents.SET_OUT_OF_OFFICE_STATUS_FAIL] = (data: any) => {
            this.onSubmitFail(data);
        };
        mapping[ModelChangeUpdateEvents.UN_SET_OUT_OF_OFFICE_STATUS_FAIL] = (data: any) => {
            this.onSubmitFail(data, true);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_SUCCESS] = (data: any) => {
            this.onGetOutofOfficeSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_FAIL] = (data: any) => {
            this.onGetOutofOfficeFail(data);
        };

        this.networkID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        this.getBasicInfo();
        this.checkSuperUser();
        super.registerStateChangeEvents(mapping);
    }

    checkSuperUser(){
      let userRoles = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userRoles;
      userRoles.forEach( (element)  => {
        if(element === 'USF-SODS-SUPERUSER'){
          this.isSuperUser = true;
        }
      });
    }

    getBasicInfo() {
      const event = this.actionDispatcherService.generateEvent(
            ActionEvents.GET_OUT_OF_OFFICE_STATUS, this.networkID
        );
        this.actionDispatcherService.dispatch(event);
    }  

    onGetOutofOfficeSuccess(data) {
      this.user = '';
      this.selectedType = (data.outOfOffice) ? 'outOfOffice' : 'inOffice';
      this.forwardTask = data.designateName;
      this.value = (data.returnDate) ? new Date(data.returnDate) : new Date();
    }
    onGetOutofOfficeFail(err) {

    }

  renderTasksTo(data) {
    if (this.typeOfSearch === 'user') {
      this.searchedUsers = data.users;
      this.results = data.users.map((item) => { if (item.fullName !== this.forwardTask) { return item.fullName; } });
      this.results = this.results.filter((item) => item !== undefined);
    } else {
      this.searchedforwardTaskUsers = data.users;
      this.forwardTaskUsers = data.users.map((item) => { if (item.fullName !== this.user) { return item.fullName; } });
      this.forwardTaskUsers = this.forwardTaskUsers.filter((item) => item !== undefined);
    }
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  renderTasksToFail(err) {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  getTasks(){
    
  }

  onSubmitSuccess(data, isUnset?: any) {
    this.isUpdateSuccess = true;
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  onSubmitFail(data, isUnset?: any) {
    this.isUpdateError = true;
    this.errorMsg = data;
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  submitOutofOffice() {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 
    if (this.user === '' && (this.selectedType === 'setOtherUser')) {
      this.isUserError = true;
    }

    if (this.forwardTask === '' && (this.selectedType === 'outOfOffice' || this.selectedType === 'setOtherUser')) {
      this.isForwardError = true;
    }

    if (this.isUpdateError || this.isForwardError) {
      return;
    }

    this.isUserError = false;
    this.isForwardError = false;
    this.isUpdateSuccess = false;
    this.isUpdateError = false;
    const actionsEventConst = (this.selectedType === 'outOfOffice' || this.selectedType === 'setOtherUser') ? 
      ActionEvents.SET_OUT_OF_OFFICE_STATUS : ActionEvents.UN_SET_OUT_OF_OFFICE_STATUS;
    const userFilter = this.searchedUsers.find((item) => { return item.fullName === this.user; });
    const forwardTaskFilter = this.searchedforwardTaskUsers.find((item) => { return item.fullName === this.forwardTask; });

    
    const event = this.actionDispatcherService.generateEvent(
            actionsEventConst, {
              networkID: this.networkID,
              updateType: this.selectedType,
              otherUser: userFilter,
              forwardTaskUser: forwardTaskFilter,
              val: this.value
            }
        );
        this.actionDispatcherService.dispatch(event);
  }



  ngOnInit() {
  }
  showOutOfOffice() {
    this.isShow = true;
  }
  onDateSelectionDone($event) {
    this.date_selection_error = false;
    this.value = $event;
  }
  onErrorHandler() {
    this.date_selection_error = true;
  }
  onChangeRadio(val) {
    this.selectedType = '';
    this.forwardTask = '';
    this.isUserError = false;
    this.isUpdateError = false;
    this.isForwardError = false;
    this.isUpdateSuccess = false;
    setTimeout(() => {
      this.selectedType = val;
    }, 0)
    
   
  }

  onChange() {
    
  }

  onUserSlection(selectedUser) {
    this.user = selectedUser;
    this.isUserError = false;
  }

  onForwardTaskSelection(selectedTaskTo) {
    this.forwardTask = selectedTaskTo;
    this.isForwardError = false;
  }
  onUserSearch(query) {
    this.typeOfSearch = 'user';
     const event = this.actionDispatcherService.generateEvent(
            ActionEvents.GET_SEARCH_USER, {
              query: query
            }
        );
        this.actionDispatcherService.dispatch(event);
  }

  onForwardTaskTo(query) {
    this.typeOfSearch = 'forwardTaskTo';
     // Dispatch an event to get the default roles
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.GET_SEARCH_USER, {
              query: query
            }
        );
        this.actionDispatcherService.dispatch(event);
  }

  
}
