import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import * as console from 'console';
import { OutofofficeComponent } from './outofoffice.component';
import { SharedModule } from './../../shared/shared.module';
import { Event, ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "./../../events/action-events";
import { FormsModule } from '@angular/forms';

describe('OutofofficeComponent', () => {
  let component: OutofofficeComponent;
  let fixture: ComponentFixture<OutofofficeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutofofficeComponent ],
      imports: [SharedModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutofofficeComponent);
    component = fixture.componentInstance;
    component.actionDispatcherService.dispatch = () => {};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


