import { Component, OnInit, Input, Output, EventEmitter, HostBinding, ViewEncapsulation, ViewChild } from '@angular/core';
import {CalendarModule, Calendar} from 'primeng/primeng';

@Component({
  selector: 'sods-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CalendarComponent implements OnInit {

  isVisible = false;
  @Input() value: Date;
  @Input() maxDate: Date;
  @Input() minDate: Date;
  @Input() width: string;
  @Input() smBtn: boolean;
  @Input() error: boolean;
  @Output() selectionDone = new EventEmitter();
  @Output() onMonthChange = new EventEmitter();
  @Output() errorEmitter = new EventEmitter();

  @ViewChild('child1')
  child1: Calendar;

  @ViewChild('child2')
  child2: Calendar;

  @ViewChild('child3')
  child3: Calendar;

  @ViewChild('child4')
  child4: Calendar;

  constructor() { }

  ngOnInit() {
  }

  select(){ 
    this.selectionDone.emit(this.value);
  }

  monthChange(){
    this.onMonthChange.emit();
  }
  

  checkDate(){

    if(this.checkFilled()){
      this.errorEmitter.emit('');
			return;
    }

    if(this.hasError()) {
      this.errorEmitter.emit('error');
    } else{
      this.errorEmitter.emit(this.value);
    }
  }

private checkChild1Filled(){
    return (!this.smBtn && !this.error && !this.child1.filled) ? true : false;
   }

private checkChild2Filled(){
     return (!this.smBtn && this.error && !this.child2.filled) ? true : false;
   }

private checkChild3Filled(){
     return (this.smBtn && !this.error && !this.child3.filled) ? true : false
  }

private checkChild4Filled(){
    return (this.smBtn && this.error && !this.child4.filled) ? true : false;
  }

private checkFilled(){
    let child1Filled = this.checkChild1Filled();
    let child2Filled = this.checkChild2Filled();
    let child3Filled = this.checkChild3Filled();
    let child4Filled = this.checkChild4Filled();
    return (child1Filled || child2Filled || child3Filled || child4Filled) ? true : false;
  }

private hasError(){
    return (this.value === null || this.value === undefined || this.value < this.minDate) ? true : false;
  }

}
