import { Component, OnInit, Input, Output, EventEmitter, HostBinding, ViewEncapsulation, ViewChild } from '@angular/core';
import {CalendarModule, Calendar} from 'primeng/primeng';

@Component({
  selector: 'sods-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CalendarComponent implements OnInit {

  isVisible: boolean = false;
  @Input() value: Date;
  @Input() maxDate: Date;
  @Input() minDate: Date;
  @Input() width: string;
  @Input() smBtn: boolean;
  @Input() error: boolean;
  @Output() selectionDone = new EventEmitter();
  @Output() onMonthChange = new EventEmitter();
  @Output() errorEmitter = new EventEmitter();

  @ViewChild('child1')
  child1: Calendar;

  @ViewChild('child2')
  child2: Calendar;

  @ViewChild('child3')
  child3: Calendar;

  @ViewChild('child4')
  child4: Calendar;

  constructor() { }

  ngOnInit() {
  }

  select(){ 
    this.selectionDone.emit(this.value);
  }

  monthChange(){
    this.onMonthChange.emit();
  }
  

  checkDate(){
    if(!this.smBtn && !this.error ){
		if(!this.child1.filled){
			this.errorEmitter.emit('');
			return;
		}
    }
    if(!this.smBtn && this.error ){
		if(!this.child2.filled){
			this.errorEmitter.emit('');
			return;
		}     
    }
    if(this.smBtn && !this.error ){
		if(!this.child3.filled){
			this.errorEmitter.emit('');
			return;
		}  
    }
    if(this.smBtn && this.error ){
		if(!this.child4.filled){
			this.errorEmitter.emit('');
			return;
		}      
    }
    // if(!this.child1.filled){
    //   this.errorEmitter.emit('');
    // }
    if(this.value === null || this.value === undefined){
      this.errorEmitter.emit('error');
    }else if(this.value < this.minDate){
      this.errorEmitter.emit('error');
    }else{
      this.errorEmitter.emit(this.value);
    }
  }

}
