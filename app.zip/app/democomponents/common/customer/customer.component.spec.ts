import { SharedModule } from './../../../shared/shared.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerComponent } from './customer.component';
import { FormsModule } from '@angular/forms';
import { EditCustomerComponent } from './edit-customer.component'
import { SAMPLECUSTOMER } from '../../../model/customer';

describe('CustomerComponent', () => {
  let component: CustomerComponent;
  let fixture: ComponentFixture<CustomerComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ],
      imports: [ SharedModule] 
    })
    .compileComponents();
  }));
  beforeEach(() => {
    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': '', 
      applicationMarkets: [{marketName: 'sample', marketNum: 'sample', marketCode: 'sample'}]})}));
    fixture = TestBed.createComponent(CustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
        fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('Intialize component', () => {
    component.ngOnInit();  
    fixture.detectChanges();
    //check valuess 
    expect(component.marketOptions.length).toBe(1);
    expect(component.defaultMarket).toBe('sample');
    expect(component.selectedMarket).toBe('sample');
    //defaultMarket

  });
  it('Render Customer', () => {
    component.ngOnInit();  
    fixture.detectChanges();
    component.renderCustFound(SAMPLECUSTOMER);
  });
  it('retreive Customer', () => {
    component.ngOnInit();  
    fixture.detectChanges();
    // retreive customer
    component.retreiveCustomer();
    // customer not found
    component.renderCustNotFound();
  });

  it('select market dropdown', () => {
    component.onMarketSelection('1234');
    // onMarketSelection
    expect(component.selectedMarket).toBe('1234');
  });

  it('format address', () => {
    expect(component.formatAddress('', '')).toBe('');
    expect(component.formatAddress('', undefined)).toBe('');
    expect(component.formatAddress('d', 's')).toBe('d\ns');
  });
});