import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})

export class EditCustomerComponent implements OnInit {

  marketOptions: any[];
  id: string;
  selectedMarket: string;
  defaultMarket: string;
  width = "240";

  public error: Boolean;

  constructor() { }

  ngOnInit() { 
    try{
      this.defaultMarket = (this.marketOptions[0] || {}).divisionNumber;
    this.selectedMarket = (this.marketOptions[0] || {}).divisionNumber;
    this.error = false;
    }catch(err) {
      
    }
  }

  onMarketSelection($event) { this.selectedMarket = $event; }
}
