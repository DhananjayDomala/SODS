import { RoleManDropdownComponent } from './../../dropdown/roleManager-dropdown/dropdown.component';
import { OverrideShipTo } from './../../../../model/submitRequisition';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from './../../../base-component';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-override-ship-to',
  templateUrl: './override-ship-to.component.html',
  styleUrls: ['./override-ship-to.component.css']
})
export class OverrideShipToComponent extends BaseComponent implements OnInit {

  //Dropdpown Fields
  @ViewChild('stateDropdown') stateDropdown: RoleManDropdownComponent;
  stateOptions: string[];
  public selectedState: string;
  public defaultState: string = "Select";
  public overrideName: string;
  counter = 1;

  //Misc Fields
  public overrideShipTo: OverrideShipTo;
  public textInputLength: number = 25;

  //Validation Error Handling
  public errors_exist: boolean = false;
  name_required_error: boolean = false;
  phone_required_error: boolean = false;
  address1_required_error: boolean = false;
  address2_required_error: boolean = false;
  city_required_error: boolean = false;
  zip_required_error: boolean = false;

  //Required Fields Errors
  name_required: boolean = false;
  phone_required: boolean = false;
  address1_required: boolean = false;
  city_required: boolean = false;
  state_required: boolean = false;
  zip_required: boolean = false;

  overrideShipToSelected: boolean = false;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
}

  ngOnInit() {
    this.overrideShipTo = new OverrideShipTo();
    this.stateDropdown.options = 
      ["Select", "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", 
        "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", 
        "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", 
        "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", 
        "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", 
        "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", 
        "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", 
        "West Virginia", "Wisconsin", "Wyoming"];
    this.stateDropdown.selectedOption = "Select";
  }

  onStateSelection($event) {
    if(this.selectedState === 'Select') {
      this.state_required = true;
      this.errors_exist = true;
    }else{
      this.overrideShipTo.state = this.stateDropdown.selectedOption;
      this.state_required = false;
      this.errors_exist = false;
    }
  }

  keyupCharsOnly(field: string) {
    this.errors_exist = false;
    if(field === 'name') {
      let regex = !/[^ A-Za-z]/g.test((this.overrideShipTo.name).trim());
      if(regex === false) {
        this.name_required_error = true;
        this.errors_exist = true;
      }else{
        this.name_required_error = false;
        this.name_required = false;
      }
    }
    if(field === 'city') {
      let regex = !/[^ A-Za-z]/g.test((this.overrideShipTo.city).trim());
      if(regex === false) {
        this.city_required_error = true;
        this.errors_exist = true;
      }else{
        this.city_required = false;
        this.city_required_error = false;
      }
    }
  }

  keyupNumbersOnly(field: string) {
    this.errors_exist = false;
    if(field === 'phone') {
      if(!this.validatePhone((this.overrideShipTo.phone).trim())) {
        this.phone_required_error = true;
        this.errors_exist = true;
      }else{
        this.phone_required_error = false;
        this.phone_required = false;
      }
    }
    if(field === 'zip') {
      let regex = !/[^0-9]/g.test((this.overrideShipTo.zip).trim().replace(/\s/g, ''));
      if(regex === false) {
        this.zip_required_error = true;
        this.errors_exist = true;
      }else{
        this.zip_required_error = false;
        this.zip_required = false;
      }
    }
  }

  validatePhone(phone: string){
		if(phone === null || phone === undefined || phone.trim() === '') return true;
		let PHONE_REGEXP = /^[0-9]{10,12}$/
		return PHONE_REGEXP.test(phone);
	}

  keyupNumbersChars(field: string) {
    this.errors_exist = false;
    if(field === 'address1') {
      let regex = !/[^ A-Za-z0-9]/g.test((this.overrideShipTo.address1).trim());
      if(regex === false) {
        this.address1_required_error = true;
        this.errors_exist = true;
      }else{
        this.address1_required_error = false;
        this.address1_required = false;
      }
    }
    if(field === 'address2') {
      let regex = !/[^ A-Za-z0-9]/g.test((this.overrideShipTo.address2).trim());
      if(regex === false) {
        this.address2_required_error = true;
        this.errors_exist = true;
      }else{
        this.address2_required_error = false;
      }
    }
  }

  checkIfBlank(value: string) {
    if(value === null || value === undefined || value.trim() === "") {
      this.errors_exist = true;
      return true;
    }else{
      return false;
    }
  }

  resetRequiredFields() {
    this.name_required = false;
    this.city_required = false;
    this.phone_required = false;
    this.zip_required = false;
    this.address1_required = false;
    this.state_required = false;
  }

  requiredFieldsMet() {
    this.errors_exist = false;
    this.resetRequiredFields();
    if(this.checkIfBlank(this.overrideShipTo.name)) {this.name_required = true;}
    if(this.checkIfBlank(this.overrideShipTo.city)) {this.city_required = true;}
    if(this.checkIfBlank(this.overrideShipTo.phone)) {this.phone_required = true;}
    if(this.checkIfBlank(this.overrideShipTo.zip)) {this.zip_required = true;}
    if(this.checkIfBlank(this.overrideShipTo.address1)) {this.address1_required = true;}
    if(this.checkIfBlank(this.overrideShipTo.state)) {this.state_required = true;}
  }

  controlClick() {
    if(this.counter % 2 === 0 && this.stateDropdown.isVisible) {
      this.stateDropdown.isVisible = false;
      this.counter++;
    }else if(this.stateDropdown.isVisible) {
      this.counter++;
    }else if(this.counter % 2 === 0 && !this.stateDropdown.isVisible) {
      this.counter++;
    }
  }
}
