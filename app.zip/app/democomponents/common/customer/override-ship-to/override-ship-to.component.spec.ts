import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverrideShipToComponent } from './override-ship-to.component';

describe('OverrideShipToComponent', () => {
  let component: OverrideShipToComponent;
  let fixture: ComponentFixture<OverrideShipToComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverrideShipToComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverrideShipToComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
