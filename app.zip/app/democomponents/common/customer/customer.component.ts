import { DefaultValue } from 'aws-sdk/clients/elb';
import { concat } from 'rxjs/observable/concat';
import { any } from 'codelyzer/util/function';
import { Component, OnInit, Input, ViewChild } from '@angular/core'; 
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { Requisition } from '../../../model/requisition';
import { Customer } from '../../../model/customer';
import { CustomerDetailsComponent } from './customer-details.component';
import { Modal, ModalModule } from 'ngx-modal';

@Component({
    selector: 'app-customer',
    templateUrl: './customer.component.html',
    styleUrls: ['./customer.component.css']
})

export class CustomerComponent extends BaseComponent implements OnInit {    
    
    errMsg: any[];
    hasReq: any;
    seq: string;
    noCustomer: boolean = false;
    id: string;
    dept: string;
    name: string;
    defaultShipMethod: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
    estimatedOrderAmt: string;
    confidenceCode: string;
    creditCheckStatus: string;
    marketOptions: any = [];
    defaultMarket: string;
    actionCompleted:boolean = true;

    public readOnly = false;
    public retrieveSuccess = false;
    public error: Boolean;
    public selectedMarket: string;
    public selectedReqType: string;

    @ViewChild(CustomerDetailsComponent) 
    customerDetails: CustomerDetailsComponent;

    customerError: boolean = false;
    @Input('division')
    division: string;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }

    ngOnInit(){
        try{
                this.populateMarketDropdown();      
            
            let mapping: any = [];        
            mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(data); }
            mapping[ModelChangeUpdateEvents.CUST_NOT_FOUND] = (error: any) => { this.renderCustNotFound(); }
            super.registerStateChangeEvents(mapping);
        }catch(err) {

        }
        
    }

    renderCustFound(data: Customer){
        this.actionCompleted = true;
        if (data.confidenceCode === "01") {
            this.error = true;
            this.customerError = true;
            this.customerDetails.errorHandle(true);
            this.actionCompleted = true;

//            this.modalMsg = "Order cannot be processed for this customer. Please contact the credit department.";
            
        } else {
            this.customerError = false;
                try{
                let event = this.actionDispatcherService.generateEvent('retrieveTM', data.tmId);
                this.actionDispatcherService.dispatch(event);
            }catch(err){ }    
                this.customerDetails.id = data.id;
                if(data.dept == undefined || data.dept == null){
                    data.dept = '00-NODEPT';
                }else{
                    this.customerDetails.dept = data.dept;
                }
                this.customerDetails.deptOptions = data.deptOptions;
                this.customerDetails.defaultDept = data.deptOptions[0];
                this.customerDetails.name = data.name;
                this.customerDetails.address = this.formatAddress(data.address1, data.address2);
                this.customerDetails.postalInfo = this.formatLocation(data.city, data.state, data.zip);
                this.customerDetails.phone = this.formatPhone(data.phone);
                this.customerDetails.estimatedOrderAmt = data.estimatedOrderAmt;
                this.customerDetails.confidenceCode = data.confidenceCode;
                this.creditCheckStatus = data.creditCheckStatus;
                this.customerDetails.defaultShipMethod = (this.hasReq && this.hasReq.defaultShipMethod) ? this.hasReq.defaultShipMethod : "Next";
                this.customerDetails.selectedShip = this.customerDetails.defaultShipMethod;                
                this.customerDetails.shipElementsHidden = true;
                this.customerDetails.shipElementsHidden = (this.selectedReqType === 'Direct Ship') ? false : true;
                this.customerDetails.division = data.division;
                this.customerDetails.divisionObj = this.marketOptions.find(({divisionNumber}) => { return divisionNumber == data.division; })
                this.customerDetails.originMarket = data.division;
                this.retrieveSuccess = true; //set the flag to true to enable other fields
                this.customerDetails.errorHandle(false);
                this.error = false;
                if (this.hasReq && this.hasReq.defaultShipMethod && this.selectedReqType !== 'Direct Ship') {
                    // this.customerDetails.shipMethodDP.selectedOption = this.hasReq.defaultShipMethod;
                    this.customerDetails.onShipmentSelection(this.hasReq.defaultShipMethod);
                    if (this.customerDetails.selectedShip === 'Seperate' ) {
                        this.customerDetails.shipElementsHidden = false;
                    }
                }

                if (this.hasReq && this.hasReq.defaultSpecialInstructions) {
                    this.customerDetails.specialInstruct = this.hasReq.defaultSpecialInstructions;
                }
                if (this.hasReq) {
                    this.customerDetails.notMet = this.hasReq.returnIfETANotMet;
                    this.customerDetails.onDateSelectionDone(new Date(this.hasReq.ETADate))
                }
                this.customerDetails.customerType = data.custType;
                this.hasReq = ''; //reseting selected values
        }        
    }

    renderCustNotFound() { 
        this.error = true;
        this.customerDetails.errorHandle(true);
        this.actionCompleted = true;
    }
    
    retreiveCustomer(req?: any){
        if (!this.id || (this.id && this.id.toString().trim() === '')) {
            this.noCustomer = true;
            return;
        }

        try{
            this.hasReq = req;
            
            this.noCustomer = false;
            this.actionCompleted = false;
            this.customerError = false;
            
            // copy these two line where ever u have change event. so that, u r button will enabled once after saved is done.
            let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);


            let event = this.actionDispatcherService.generateEvent('retrieveCustomer', {id: this.id, division: this.selectedMarket});
            this.actionDispatcherService.dispatch(event);
        }catch(err){ }
    }

    formatLocation(cty: string, ste: string, zip: string): string { return (cty + ", " + ste + " " + zip); }

    formatPhone(phoneNbr: string): string {
        return ('(' + phoneNbr.substring(0, 3) + ')-' + phoneNbr.substring(3,6) + '-' + phoneNbr.substring(6));
    }

    formatAddress(addr1: string, addr2: string): string {
        if(addr2 == '' || addr2 == "" || addr2 == undefined) { 
            return addr1; 
        } else { 
            return (addr1 + '\n' + addr2); 
        }
    }

    private populateMarketDropdown() {
        let array = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).applicationMarkets;
        
        let marketOptions = [];
        array.forEach(element => {
            let dropdownValue= {}

            dropdownValue['distributionName'] = element.marketName;
            dropdownValue['divisionCode'] = element.marketCode;
            dropdownValue['divisionNumber'] = element.marketNum;
            marketOptions.push(dropdownValue);
        });
        this.marketOptions = marketOptions;
        this.defaultMarket = marketOptions[0].divisionNumber;
        this.selectedMarket = marketOptions[0].divisionNumber;    
    }

    onMarketSelection($event){
        this.selectedMarket = $event;
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);
    }

    checkCustomerEntered() {
        if (!this.id || (this.id && this.id.toString().trim() === '')) {
            this.error = true;
            this.noCustomer = true;
            return 'Customer and Ship to Location Value can not be empty';
        } else if(this.error) {
            this.noCustomer = false;
            return 'Invliad Customer';
        } else {
            this.error = false;
            this.noCustomer = false;
        }
    }
    getValidationRuleBasedOnQuote() {
        if (this.customerDetails.quotePrice && this.customerDetails.quotePrice !== "" && !this.customerDetails.quoteNbr) {
            this.customerDetails.quoteValid = true;
            this.customerDetails.quoteNumValid = false;
            return "Either Quote Number or Quote Price or Quote Attachment is missing";
        }
        else if (!this.customerDetails.quotePrice && this.customerDetails.quoteNbr && this.customerDetails.quoteNbr !== "") {
            this.customerDetails.quoteValid = false;
            this.customerDetails.quoteNumValid = true;
            return "Either Quote Number or Quote Price or Quote Attachment is missing";
        }
        else if(this.customerDetails.quotePrice && this.customerDetails.quoteNbr) {
            return true;
        }
    }
}