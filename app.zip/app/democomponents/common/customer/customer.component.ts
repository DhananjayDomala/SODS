import { DefaultValue } from 'aws-sdk/clients/elb';
import { concat } from 'rxjs/observable/concat';
import { any } from 'codelyzer/util/function';
import { Component, OnInit, Input, ViewChild } from '@angular/core'; 
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { Requisition } from '../../../model/requisition';
import { Customer } from '../../../model/customer';
import { CustomerDetailsComponent } from './customer-details.component';
import { Modal, ModalModule } from 'ngx-modal';

@Component({
    selector: 'app-customer',
    templateUrl: './customer.component.html',
    styleUrls: ['./customer.component.css']
})

export class CustomerComponent extends BaseComponent implements OnInit {    
    
    errMsg: any[];
    hasReq: any;
    seq: string;
    noCustomer: boolean = false;
    id: string;
    dept: string;
    name: string;
    defaultShipMethod: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
    estimatedOrderAmt: string;
    confidenceCode: string;
    creditCheckStatus: string;
    marketOptions: any = [];
    defaultMarket: string;
    actionCompleted:boolean = true;

    public readOnly = false;
    public retrieveSuccess = false;
    public error: Boolean;
    public selectedMarket: string;
    public selectedReqType: string;

    @ViewChild(CustomerDetailsComponent) 
    customerDetails: CustomerDetailsComponent;

    customerError: boolean = false;
    @Input('division')
    division: string;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);

        let mapping: any = [];        
        mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(data); }
        mapping[ModelChangeUpdateEvents.RETRIEVE_CUST_DRAFT_SUCCESS] = (data: Customer) => { this.renderCustFound(data); }
        mapping[ModelChangeUpdateEvents.CUST_NOT_FOUND] = (error: any) => { this.renderCustNotFound(); }
        super.registerStateChangeEvents(mapping);
    }

    ngOnInit(){
        this.populateMarketDropdown();
    }

private mapData(){
        if (this.hasReq && this.hasReq.defaultShipMethod && this.selectedReqType !== 'Direct Ship') {
            this.customerDetails.onShipmentSelection(this.hasReq.defaultShipMethod);
            if (this.customerDetails.selectedShip === 'Seperate' ) {
                this.customerDetails.shipElementsHidden = false;
            }else{
                this.customerDetails.shipElementsHidden = true;
            }
        }

        if (this.hasReq && this.hasReq.defaultSpecialInstructions) {
            this.customerDetails.specialInstruct = this.hasReq.defaultSpecialInstructions;
        }
        if (this.hasReq) {
            this.customerDetails.notMet = this.hasReq.returnIfETANotMet;
            this.customerDetails.onDateSelectionDone(new Date(this.hasReq.ETADate))
        }
    }

 checkNullOrUndefined(data: any){
        return (data === undefined || data === null) ? true : false;
    }


    renderCustFound(data: Customer){
        this.actionCompleted = true;
        if (data.confidenceCode === "01") {
            this.error = true;
            this.customerError = true;
            this.customerDetails.errorHandle(true);
            this.actionCompleted = true;
        } else {
            this.customerError = false;
            this.retrieveTM(data.tmId);
            this.customerDetails.id = data.id;
            if(this.checkNullOrUndefined(data.dept)){
                data.dept = '00-NODEPT';
            }
            this.customerDetails.dept = data.dept;
            this.customerDetails.deptOptions = data.deptOptions;
            this.customerDetails.defaultDept = data.deptOptions[0];
            this.customerDetails.name = data.name;
            this.customerDetails.address = this.formatAddress(data.address1, data.address2);
            this.customerDetails.postalInfo = this.formatLocation(data.city, data.state, data.zip);
            this.customerDetails.phone = data.phone;
            this.customerDetails.estimatedOrderAmt = data.estimatedOrderAmt;
            this.customerDetails.confidenceCode = data.confidenceCode;
            this.creditCheckStatus = data.creditCheckStatus;
            this.customerDetails.defaultShipMethod = (this.hasReq && this.hasReq.defaultShipMethod) ? this.hasReq.defaultShipMethod : "Next";
            if(this.customerDetails.selectedShip === null || this.customerDetails.selectedShip === undefined){
                this.customerDetails.selectedShip = this.customerDetails.defaultShipMethod;   
            }         
            if(this.customerDetails.shipElementsHidden === false){
                this.customerDetails.shipElementsHidden = (this.selectedReqType === 'Direct Ship' || this.customerDetails.selectedShip === 'Separate') ? false : true;
            }
            this.customerDetails.division = data.division;
            this.customerDetails.divisionObj = this.marketOptions.find(({divisionNumber}) => { return divisionNumber === data.division.toString(); })
            this.customerDetails.originMarket = data.division;
            this.retrieveSuccess = true; //set the flag to true to enable other fields
            this.customerDetails.errorHandle(false);
            this.error = false;
            this.mapData();
            this.customerDetails.customerType = data.custType;
            this.hasReq = ''; //reseting selected values
        }
        
        // unset the busy state
            const event1 = this.actionDispatcherService.generateEvent(
                ActionEvents.SET_BUSY_STATUS, false
            );
            this.actionDispatcherService.dispatch(event1);
            
    }

    retrieveTM(tmId: string){
        let event = this.actionDispatcherService.generateEvent('retrieveTM', tmId);
        this.actionDispatcherService.dispatch(event);
    }

    renderCustNotFound() { 
        this.error = true;
        this.customerDetails.errorHandle(true);
        this.actionCompleted = true;
    }
    
    retreiveCustomer(req?: any){
        if (!this.id || (this.id && this.id.toString().trim() === '')) {
            this.noCustomer = true;
            return;
        }

        try{
            this.hasReq = req;
            
            this.noCustomer = false;
            this.actionCompleted = false;
            this.customerError = false;
            
            // copy these two line where ever u have change event. so that, u r button will enabled once after saved is done.
            let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);


            let event = this.actionDispatcherService.generateEvent('retrieveCustomer', {id: this.id, division: this.selectedMarket});
            this.actionDispatcherService.dispatch(event);
        }catch(err){ }
    }

    formatLocation(cty: string, ste: string, zip: string): string { return (cty + ", " + ste + " " + zip); }

    formatAddress(addr1: string, addr2: string): string {
        if(addr2 === '' || addr2 === "" || addr2 === undefined) { 
            return addr1; 
        } else { 
            return (addr1 + '\n' + addr2); 
        }
    }

    private populateMarketDropdown() {
        let array = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).applicationMarkets;
        
        let marketOptions = [];
        array.forEach(element => {
            let dropdownValue= {}

            dropdownValue['distributionName'] = element.marketName;
            dropdownValue['divisionCode'] = element.marketCode;
            dropdownValue['divisionNumber'] = element.marketNum;
            marketOptions.push(dropdownValue);
        });
        this.marketOptions = marketOptions.sort((a, b)=>{
            if (a.distributionName < b.distributionName) return -1;
            else if (a.distributionName > b.distributionName) return 1;
            else return 0;
        });
        this.defaultMarket = this.marketOptions[0].divisionNumber;
        this.selectedMarket = this.marketOptions[0].divisionNumber;    
    }

    onMarketSelection($event){
        this.selectedMarket = $event;
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);
    }

    checkCustomerEntered(): string {
        if (!this.id || (this.id && this.id.toString().trim() === '')) {
            this.error = true;
            this.noCustomer = true;
            return 'Customer and Ship to Location Value can not be empty';
        } else if(this.error) {
            this.noCustomer = false;
            return 'Invliad Customer';
        } else {
            this.error = false;
            this.noCustomer = false;
        }
        return '';
    }
    getValidationRuleBasedOnQuote() {
        if (this.customerDetails.quotePrice && this.customerDetails.quotePrice !== "" && !this.customerDetails.quoteNbr) {
            this.customerDetails.quoteValid = true;
            this.customerDetails.quoteNumValid = false;
            return "Either Quote Number or Quote Price or Quote Attachment is missing";
        }
        else if (!this.customerDetails.quotePrice && this.customerDetails.quoteNbr && this.customerDetails.quoteNbr !== "") {
            this.customerDetails.quoteValid = false;
            this.customerDetails.quoteNumValid = true;
            return "Either Quote Number or Quote Price or Quote Attachment is missing";
        }
        else if(this.customerDetails.quotePrice && this.customerDetails.quoteNbr) {
            return true;
        }
        return '';
    }
}