import { Component, OnInit, Input, Output, OnChanges, SimpleChanges, EventEmitter, HostBinding, HostListener, ElementRef } from '@angular/core';

export interface USFDropdownMenuSettings {
    selectedOption: string;
    options: string[];
    smBtn: boolean;
    width: string;
    height: string;
    invalid: boolean;
}

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class USFDropdownComponent {

  isVisible: boolean = false;
  @Input() settings: USFDropdownMenuSettings;
  @Output() selectionDone = new EventEmitter();
  @Input() comp: any;

  constructor(private el: ElementRef) { }

  @HostListener('click')
  @HostListener('document:click', ['$event'])
    handleClick(ev: Event) {
        if (ev && !this.el.nativeElement.contains(ev.target)) {
            this.isVisible = false;
        }
    }

  @HostListener('window:keyup', ['$event']) 
    handleKeyup(event) {
        if (event.code === 'Tab') {
            this.isVisible = false;
        }
    }

  toggleDropDown(){
      this.isVisible = !this.isVisible;
  }

  select(option: string){;
      this.isVisible = !this.isVisible;
      this.settings.selectedOption = option;
      this.selectionDone.emit(this.settings.selectedOption);
  }

}
