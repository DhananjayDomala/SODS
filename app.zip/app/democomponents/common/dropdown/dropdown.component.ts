import { Component, OnInit, Input, Output, OnChanges, SimpleChanges, EventEmitter, HostBinding, HostListener, ElementRef } from '@angular/core';

@Component({
  selector: 'sods-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent {

  isVisible: boolean = false;
  @Input() selectedOption: string;
  @Input() options: string[];
  @Input() smBtn: boolean;
  @Input() width: string;
  @Input() height: string;
  @Input() marginLeft: string;
  @Input() marginRight: string;
  @Input() invalid: boolean;
  @Output() selectionDone = new EventEmitter();
  @Input() comp: any;

  constructor(private el: ElementRef) { }

  @HostListener('click')
  @HostListener('document:click', ['$event'])
    handleClick(ev: Event) {
        if (ev && !this.el.nativeElement.contains(ev.target)) {
            this.isVisible = false;
        }
    }

  @HostListener('window:keyup', ['$event']) 
    handleKeyup(event) {
        if (event.code === 'Tab') {
            this.isVisible = false;
        }
    }

  toggleDropDown(){
      this.isVisible = !this.isVisible;
  }

  select(option: string){;
      this.isVisible = !this.isVisible;
      this.selectedOption = option;
      this.selectionDone.emit(this.selectedOption);
  }

}
