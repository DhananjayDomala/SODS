import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidatorDirective } from 'app/directive/validator.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TypeaheadComponent } from 'app/democomponents/common/typeahead/typeahead.component';
import { TypeaheadDirective } from 'ngx-bootstrap/typeahead/typeahead.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [ValidatorDirective, TypeaheadDirective, TypeaheadComponent],
  exports: [
      ValidatorDirective,
      TypeaheadDirective,
      TypeaheadComponent
  ]
})
export class TextFieldModule { }
