import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

export interface USFSearchTextField {
  width: string;
  height: string;
  marginLeft: string;
  marginRight: string;
  disabled: boolean;
  error: boolean;
  errorText?: string;
  text: string;
  inputId: string;
  searchId?: string;
  css: string[];
}

@Component({
  selector: 'app-search-textfield',
  templateUrl: './search-textfield.component.html',
  styleUrls: ['./search-textfield.component.css']
})



export class SearchTextfieldComponent implements OnInit {
  @Input() usfSearchTextfieldSettings: USFSearchTextField;
  @Output('search')
  search: EventEmitter<any> = new EventEmitter<any>();
  
  constructor() { }

  ngOnInit() {
  }

  onSearchClick($event) {
    this.search.emit({'query': $event});
  }

}
