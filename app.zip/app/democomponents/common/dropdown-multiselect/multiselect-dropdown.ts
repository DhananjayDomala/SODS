/*
 * Based on Angular 2 Dropdown Multiselect for Bootstrap
 * Current version: 0.3.0
 *
 * Simon Lindh
 * https://github.com/softsimon/angular-2-dropdown-multiselect
 */

import {
    NgModule,
    Component,
    Pipe,
    OnInit,
    DoCheck,
    HostListener,
    Input,
    ElementRef,
    Output,
    EventEmitter,
    forwardRef,
    IterableDiffers,
    AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { FormsModule, NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { PipeTransform } from '@angular/core/src/change_detection/pipe_transform';

const MULTISELECT_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => MultiselectDropdown),
    multi: true
};

export interface IMultiSelectOption {
    id: number;
    name: string;
}

export interface IMultiSelectSettings {
    pullRight?: boolean;
    enableSearch?: boolean;
    checkedStyle?: 'checkboxes' | 'glyphicon';
    buttonClasses?: string;
    selectionLimit?: number;
    closeOnSelect?: boolean;
    showCheckAll?: boolean;
    showUncheckAll?: boolean;
    showToggleCheckAll?: boolean;
    dynamicTitleMaxItems?: number;
    maxHeight?: string;
    width?: string;
    margin?: string;
}

export interface IMultiSelectTexts {
    checkAll?: string;
    uncheckAll?: string;
    toggleCheckAll?: string;
    checked?: string;
    checkedPlural?: string;
    searchPlaceholder?: string;
    defaultTitle?: string;
    allSelected?: string;
}

@Pipe({
    name: 'searchFilter'
})

export class MultiSelectSearchFilter implements PipeTransform {
    transform(options: Array<IMultiSelectOption>, args: string): Array<IMultiSelectOption> {
        return options.filter((option: IMultiSelectOption) => option.name.toLowerCase().indexOf((args || '').toLowerCase()) > -1);
    }
}

@Component({
    selector: 'app-multiselect-dropdown',
    providers: [MULTISELECT_VALUE_ACCESSOR],
    styles: [],
    template: `
        <div class="btn-group">
            <button type="button"
                class="dropdown-toggle"
                [class.invalid-input] = "invalid"
                [ngClass]="settings.buttonClasses"
                (click)="toggleDropdown()"
                [style.width.px]="settings.width"
                [style.marginLeft.px]="settings.margin">
                {{ title }}<span class="caret"></span>
            </button>
            <ul *ngIf="isVisible" class="dropdown-menu" 
                [class.pull-right]="settings.pullRight"
                [style.max-height.px]="settings.maxHeight"
                [style.width.px]="settings.width"
                style="display: block; height: auto; overflow-y: auto;">
                <li style="margin: 0px 5px 5px 5px;" *ngIf="settings.enableSearch">
                    <div class="input-group input-group-sm">
                        <span class="input-group-addon" id="sizing-addon3"><i class="fa fa-search"></i></span>
                        <input 
                            type="text"
                            class="form-control"
                            placeholder="{{ texts.searchPlaceholder }}"
                            aria-describedby="sizing-addon3"
                            [(ngModel)]="searchFilterText">
                        <span class="input-group-btn" *ngIf="searchFilterText.length > 0">
                            <button class="btn btn-default" type="button" (click)="clearSearch()"><i class="fa fa-times"></i></button>
                        </span>
                    </div>
                </li>
                <li *ngIf="settings.enableSearch"></li>
                <li *ngIf="settings.showToggleCheckAll">
                    <a href="javascript:;" role="menuitem" tabindex="-1" (click)="toggleCheckAll()">
                        <input name="option" type="checkbox" [checked]="allChecked" disabled="disabled" />
                        <label for="option"></label>
                        {{ texts.toggleCheckAll }}
                    </a>
                </li>
                <li *ngIf="settings.showCheckAll">
                    <a href="javascript:;" role="menuitem" tabindex="-1" (click)="checkAll()">
                        <span class="glyphicon glyphicon-ok"></span>
                        {{ texts.checkAll }}
                    </a>
                </li>
                <li *ngIf="settings.showUncheckAll">
                    <a href="javascript:;" role="menuitem" tabindex="-1" (click)="uncheckAll()">
                        <span class="glyphicon glyphicon-remove"></span>
                        {{ texts.uncheckAll }}
                    </a>
                </li>

                <li *ngFor="let option of options | searchFilter:searchFilterText">
                    <a href="javascript:;" role="menuitem" tabindex="-1" (click)="setSelected($event, option)">
                        <input *ngIf="settings.checkedStyle == 'checkboxes'" name="option" type="checkbox" [checked]="isSelected(option)" />
                        <label *ngIf="settings.checkedStyle == 'checkboxes'" for="option"></label>
                        <span *ngIf="settings.checkedStyle == 'glyphicon'" 
                            style="width: 16px;"
                            class="glyphicon"
                            [class.glyphicon-ok]="isSelected(option)">
                        </span>
                        <span>{{ option.name }}</span>
                    </a>
                </li>
            </ul>
        </div>
    `
})
export class MultiselectDropdown implements OnInit, DoCheck, ControlValueAccessor  {
    model: number[];
    selectedOption: string;
    title: string;
    differ: any;
    numSelected = 0;
    isVisible = false;
    searchFilterText = '';

    defaultSettings: IMultiSelectSettings = {
        pullRight: false,
        enableSearch: false,
        checkedStyle: 'checkboxes',
        buttonClasses: 'btn btn-default',
        selectionLimit: 0,
        closeOnSelect: false,
        showCheckAll: false,
        showUncheckAll: false,
        showToggleCheckAll: false,
        dynamicTitleMaxItems: 3,
        maxHeight: '300',
        width: '',
        margin: ''
    };
    defaultTexts: IMultiSelectTexts = {
        checkAll: 'Check all',
        uncheckAll: 'Uncheck all',
        toggleCheckAll: 'Check all',
        checked: 'checked',
        checkedPlural: 'checked',
        searchPlaceholder: 'Search...',
        defaultTitle: 'Select',
        allSelected: ''
    };
    @Input() invalid: boolean;
    @Input() options: Array<IMultiSelectOption>;
    @Input() settings: IMultiSelectSettings;
    @Input() texts: IMultiSelectTexts;
    @Input() allChecked: boolean;
    @Output() selectionLimitReached = new EventEmitter();
    @HostListener('document: click', ['$event.target'])
    onClick(target: HTMLElement) {
        let parentFound = false;
        while (target !== null && !parentFound) {
            if (target === this.element.nativeElement) {
                parentFound = true;
            }
            target = target.parentElement;
        }
        if (!parentFound) {
            this.isVisible = false;
        }
    }

    onModelChange: Function = (_: any) => { };
    onModelTouched: Function = () => { };
    
    constructor(
        private element: ElementRef,
        private differs: IterableDiffers
    ) {
        this.differ = differs.find([]).create(null);
    }

    ngOnInit() {
        this.settings = Object.assign(this.defaultSettings, this.settings);
        this.texts = Object.assign(this.defaultTexts, this.texts);
        this.title = this.texts.defaultTitle;
        if (this.allChecked) {
            this.checkAll();
        }
    }

    writeValue(value: any): void {
        if (value !== undefined) {
            this.model = value;
        }
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }

    ngDoCheck() {
        const changes = this.differ.diff(this.model);
        if (changes) {
            this.updateNumSelected();
            this.updateTitle();
        }
    }

    clearSearch() {
        this.searchFilterText = '';
    }

    toggleDropdown() {
        this.isVisible = !this.isVisible;
        this.allChecked = this.isAllSelected();
    }

    isSelected(option: IMultiSelectOption): boolean {
        return this.model && this.model.indexOf(option.id) > -1;
    }

    isAllSelected() {
        let totalSelected = 0;
        this.options.forEach((e) => {
            if(this.isSelected(e)) {
                totalSelected++;
            }
        });
        return (totalSelected === this.options.length && this.options.length > 0);
    }


    setSelected(event: Event, option: IMultiSelectOption) {
        if (!this.model) { this.model = []; }
        const index = this.model.indexOf(option.id);
        this.selectedOption = option.name;
        if (index > -1) {
            this.model.splice(index, 1);
        } else {
            if (this.settings.selectionLimit === 0 || this.model.length < this.settings.selectionLimit) {
                this.model.push(option.id);
            } else {
                this.selectionLimitReached.emit(this.model.length);
                return;
            }
        }
        if (this.settings.closeOnSelect) {
            this.toggleDropdown();
        }
        this.onModelChange(this.model);
        this.allChecked = this.isAllSelected();
    }

    updateNumSelected() {
       this.numSelected = this.model && this.model.length || 0;
    }

    updateTitle() {
        if (this.numSelected === 0) {
            this.title = this.texts.defaultTitle;
        } else if (this.settings.dynamicTitleMaxItems >= this.numSelected) {
            this.title = this.options
                .filter((option: IMultiSelectOption) => this.model && this.model.indexOf(option.id) > -1)
                .map((option: IMultiSelectOption) => option.name)
                .join(', ');
        } else if (this.numSelected === this.options.length) {
            this.title = this.texts.allSelected;
        } else {
            this.title = (this.numSelected === 1 ? this.texts.checked : this.texts.checkedPlural) + ' (' + this.numSelected + ')';
        }
    }

    toggleCheckAll() {
        if (this.allChecked){
            this.uncheckAll();
        } else {
            this.checkAll();
        }
        this.allChecked = !this.allChecked;
    }

    checkAll() {
        this.model = this.options.map(option => option.id);
        this.onModelChange(this.model);
    }

    uncheckAll() {
        this.model = [];
        this.onModelChange(this.model);
    }
}

@NgModule({
    imports: [CommonModule, FormsModule],
    exports: [MultiselectDropdown],
    declarations: [MultiselectDropdown, MultiSelectSearchFilter],
})
export class MultiselectDropdownModule { }
