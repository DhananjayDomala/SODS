import { Router } from '@angular/router';
import { AuthenticationService } from './../../../service/authentication.service';
import { Modal } from 'ngx-modal';
import { Keepalive } from '@ng-idle/keepalive';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-session',
  templateUrl: './session.component.html',
  styleUrls: ['./session.component.css']
})
export class SessionComponent implements OnInit {

  idleState = 'Not started.';
  timedOut = false;
  @ViewChild('timeoutWarningPopup') timeoutWarningModal: Modal;
  @ViewChild('timeoutPopup') timeoutModal: Modal;

  constructor(private idle: Idle, private keepalive: Keepalive, private authService: AuthenticationService,
            public router: Router) { }

  ngOnInit() {

    this.idle.setIdle(3000); //50 minutes for testing
    this.idle.setTimeout(120); // 2 minutes for testing

    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    // this.idle.onTimeoutWarning.subscribe(
    //   countdown =>
    //     (this.idleState = "You will time out in " + countdown + " seconds!")
    // );


    this.idle.onIdleEnd.subscribe(() => {
      console.log('idle end');
      this.idleState = 'No longer idle.';
    });

    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.timeoutWarningModal.close();
      this.timeoutModal.open();
    });

    this.idle.onIdleStart.subscribe(() => {
      this.idleState = 'You\'ve gone idle!';
      this.timeoutWarningModal.open();
    });

    this.keepalive.interval(1200);

    this.keepalive.onPing.subscribe(() => {
      const username = localStorage.getItem('username');
      const password = localStorage.getItem('password');
      this.authService.loginService(username, password).subscribe(response => {
        if (response.json().token !== null && response.json().token !== undefined) {
          this.reset();
          sessionStorage.setItem('token', response.json().token);
          let expiration = new Date().getTime() + 30 * 60 * 1000;
          let record = { value: response.json().token, timestamp: expiration }
          localStorage.setItem('token', JSON.stringify(record));
        }
      });
    });

    this.reset();
  }

  cancel() {
    //logout
    sessionStorage.removeItem('token');
    localStorage.removeItem('token');
    this.timeoutWarningModal.close();
    this.timeoutModal.close();
    this.router.navigateByUrl('/#');
  }

  continueValidity() {
      this.timeoutWarningModal.close();
    }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
}
