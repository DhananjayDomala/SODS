import { Component, OnInit, Input, Output, EventEmitter, HostListener, ViewChild } from '@angular/core';

@Component({
  selector: 'app-tooltip-label',
  templateUrl: './tooltip-label.component.html',
  styleUrls: ['./tooltip-label.component.css']
})
export class ToolTipLabel implements OnInit {
  @ViewChild('inputTxtField') inputTxtField;
  @Input() label: string;
  @Input() tooltipText: string;
  showPopup =  true;
  
  constructor() { }

  ngOnInit() {
  }
}
