import { Component, OnInit, Input } from '@angular/core';
import { BREADCRUMBS } from 'app/democomponents/common/breadcrumb/breadcrumbs';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {

  @Input() heading: string;
  @Input() breadcrumbs: any;

  homeLink = BREADCRUMBS.home.links[0];

  constructor() { }

  ngOnInit() {

  }
}
