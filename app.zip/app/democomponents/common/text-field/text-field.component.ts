import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormGroup, FormControl, ControlValueAccessor, Validators, ValidatorFn } from '@angular/forms';


export interface USFTextField {
  label?: string;
  width: string;
  height: string;
  marginLeft: string;
  marginRight: string;
  disabled?: boolean;
  required: boolean;
  valid: boolean;
  errorText?: string;
  id?: string;
  css?: string[];
  value: string;
  validationType?: string;
}


@Component({
  selector: 'app-text-field',
  templateUrl: './text-field.component.html',
  styleUrls: ['./text-field.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: TextFieldComponent, multi: true }
  ]
})
export class TextFieldComponent implements OnInit, ControlValueAccessor {
  @ViewChild('inputTxtField') inputTxtField;
  @Input() usfTextfieldSettings: USFTextField;
  @Output() validate: EventEmitter<any> = new EventEmitter<any>();
  txtField;
  onChange;
  pattern: RegExp;
  regex = {
    'integer': '^\\d+',
    'string': '^.+',
    'email': '\\S+@\\S+\\.\\S+'
  };
  constructor() { }

  ngOnInit() {
    this.pattern = new RegExp(this.regex[this.usfTextfieldSettings.validationType], "");
    console.log(this.pattern);
    console.log(this.inputTxtField);
  }

  writeValue(value) {
    this.usfTextfieldSettings.value = value;
    if (this.usfTextfieldSettings.value) {

    }
  }

  registerOnChange(fn) { 
    
    this.onChange = fn;
  }

  registerOnTouched(fn) { }

  onKeyUpEvent($event) {
    console.log(this.inputTxtField);
    if (this.inputTxtField.hasError('required') || this.inputTxtField.hasError('pattern')) {
      this.validate.emit({'valid': false});
    }
    else {
      this.validate.emit({'valid': true});
    }
  }

}
