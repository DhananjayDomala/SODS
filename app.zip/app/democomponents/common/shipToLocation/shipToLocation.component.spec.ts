import * as console from 'console';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SharedModule } from './../../../shared/shared.module';
import { Event, ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';
import { ShipToLocationComponent } from './shipToLocation.component';
import {ActionEvents, ModelChangeUpdateEvents} from "../../../events/action-events";
import { Customer, SAMPLECUSTOMER } from '../../../model/customer';
import { FormsModule } from '@angular/forms';

describe('ShipToLocationComponent', () => {
  let component: ShipToLocationComponent;
  let fixture: ComponentFixture<ShipToLocationComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ],
      imports: [SharedModule]
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(ShipToLocationComponent);
    component = fixture.componentInstance;
    component.actionDispatcherService.dispatch = () => {};
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_SUCCESS, customer)
   describe('Retrive Customer', () => {
    it('should call Retrive Customer', () => {

        // Intialize
        component.ngOnInit();
        
        // Execution
        component.renderCustFound(SAMPLECUSTOMER);
        fixture.detectChanges();

        //Expectation
        expect(component.data.length).toBe(1);
        expect(component.data[0].customer).toBe(SAMPLECUSTOMER.id);

    });

    it('should call Retrive Customer When Modal Opened', () => {
        // Intialize
        component.ngOnInit();
        component.addShipToLocationModal.isOpened = true;
        
        //Execution
        component.renderCustFound(SAMPLECUSTOMER);
        fixture.detectChanges();

       //Expectation
       expect(component.addShipToLocationComponent.id).toBe(SAMPLECUSTOMER.id);
      
    });

   });

  describe('ComponentCollapse', () => {
      it('should collapse', () => {
            // Intialize
            let element = fixture.nativeElement;
            
            // Execution
            const collapseBtn = element.querySelector('#shiptolocation-collapse');
            expect(collapseBtn).toBeDefined();
            collapseBtn.click();

            fixture.detectChanges();

            // Expectation
            expect(component.isCollapsed).toBe(false);

            // Execution
            collapseBtn.click();
            fixture.detectChanges();

            // Expectation
            expect(component.isCollapsed).toBe(true);

        });
   });    



  describe('Open Add Modal', () => {
      it('add btn should be enabled', () => {
            //init
            component.ngOnInit();
            let element = fixture.nativeElement; 
            const addBtn = element.querySelector('#addShipToLocationBtn');
            expect(component.addShipToLocationModal.isOpened).toBe(false);
            component.data = [SAMPLECUSTOMER];
            component.selectedReqType = 'Special Order';
            
            // Execution
            expect(addBtn).toBeDefined();
            addBtn.click();
            fixture.detectChanges();

            // Expectation
            expect(component.addShipToLocationModal.isOpened).toBe(true);
            
      });
  });

  describe('Success Callback', () => {
      it('renderShipmentChangeSuccess', () => {
        // init  
        component.data = [{}];
        //Execution 
        component.renderShipmentChangeSuccess({'shipMethod': '123', 'customerPO': 'string', 'specialInstruct': 'string'});
        // Implementation
        expect(component.data[0].ship_method).toBe('123'); 
      });

      it('renderDeptChangeSuccess', () => {
        // init
        component.data = [{}];
        // Execution
        component.renderDeptChangeSuccess('123');
        // Implementation
        expect(component.data[0].department).toBe('123');
      });
  });
    
  
  describe('Open Edit Modal', () => {
      it('edit btn should be enabled', () => {
            // init
            component.data = [SAMPLECUSTOMER];
            component.selectedReqType = 'Special Order';
            // Execution
            component.editShip(component.data[0]);
            fixture.detectChanges();
            // Expectation
            expect(component.editShipToLocationModal.isOpened).toBe(true);
      });
  });

  describe('Remove Operations', () => {
      it('open del popup', () => {
            // init
            component.data = [SAMPLECUSTOMER];
            // Execution
            component.removeShip(component.data[0]);
            fixture.detectChanges();
            expect(component.removeLocationModal.isOpened).toBe(true);
            component.closeRemove();
            fixture.detectChanges();
            // Expectation
            expect(component.removeLocationModal.isOpened).toBe(false);
       });

      it('remove item', () => {
            // Init
            component.data = [{customerNo: 123}, {customerNo: 321}];
            component.selectedReqType = 'Special Order';
            component.delItem = component.data[1];
            // Execution
            component.remove();
            fixture.detectChanges();
            // Expectation
            expect(component.data.length).toBe(1);
       }); 
  });
  
    describe('Operations', () => {
      it('Add', () => {
            // Mock for Close
            component.addShipToLocationModal.close = () => {
                component.addShipToLocationModal.isOpened = false;
            };
            
            // Initializing
            component.data = [{}];
            component.addShipToLocationModal.isOpened = true;
            component.renderCustFound(SAMPLECUSTOMER); 
            component.selectedReqType = 'Special Order';

            // Execution
            component.onAdd();
            component.closeAddModal();
            fixture.detectChanges();
            
            // Expectation
            expect(component.data.length).toBe(2);
       });

      it('Edit item', () => {
            // Mock for close modal
            component.editShipToLocationModal.close = () => {
                component.editShipToLocationModal.isOpened = false;
            }

            // Initialize
            component.data = [{}, SAMPLECUSTOMER];
            component.editShipToLocationModal.isOpened = true;

            // Execution
            component.editShip(component.data[1]);
            component.onAdd();
            component.closeAddModal();
            
            fixture.detectChanges();

            // Expectation
            expect(component.data.length).toBe(2);
       }); 
  });
    describe('other Operations', () => {
      it('Misc', () => {
        // Init
        component.addShipToLocationModal.isOpened = true;
          // Execution
          component.resetAddModal();
          // Expectation
          expect(component.addShipToLocationComponent.id).toBe(null);
          
          // Execution
          component.renderCustNotFound();
          // Expectation
          expect(component.addShipToLocationComponent.error).toBe(true);

          expect(component.formatAddress('addr1', null)).toBe('addr1');
          expect(component.formatAddress('addr1', 'addr2')).toBe('addr1\naddr2');
          
          //Init
          component.data = [{customer: '1234'}];
          component.editShipToLocationModal.isOpened = true;
          
          // Expectation
          expect(component.dataHasDuplicateValue({customer: '1234'})).toBe(true)
         
        });
    });
  
});