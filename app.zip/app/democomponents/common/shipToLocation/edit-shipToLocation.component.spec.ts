import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditShipToLocationComponent } from './edit-shipToLocation.component';
import { Event, ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';

import { FormsModule } from '@angular/forms';
import { DropdownComponent } from '../../common/dropdown/dropdown.component';
describe('EditShipToLocationComponent', () => {
  let component: EditShipToLocationComponent;
  let fixture: ComponentFixture<EditShipToLocationComponent>;
  const options = [{divisionNumber:  '123', distributionName: '', divisionCode: ''}, {divisionNumber:  '1234'}, {divisionNumber:  '1256'}];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditShipToLocationComponent, DropdownComponent ],
      imports: [FormsModule],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService
      ]
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(EditShipToLocationComponent);
    component = fixture.componentInstance;
    component.actionDispatcherService.dispatch = () => {};
    component.options = options;
    component.selectedMarket = '123';
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should return name', () => {
    // Execution
    const mName = component.getMarketName();
    fixture.detectChanges();
    // Expectation
    expect(mName).toBe('(, 123)');
  }); 
  it('Shipto Dropdown Change', () => {
    // Init
    component.ngOnInit();
    // Execution
    component.onShipmentSelection('SAMPLE');

    // Expectation
    expect(component.dataChanged).toBe(true);
    expect(component.duplicate).toBe(false); 
    expect(component.selectedShip).toBe('SAMPLE');
  });

  it('on Dept Dropdown Change', () => {
    // in it
    component.ngOnInit();

    //Execution
    component.onDeptSelection('SAMPLE');

    // Expectation
    expect(component.dataChanged).toBe(true);
    expect(component.duplicate).toBe(false); 
    expect(component.selectedDept).toBe('SAMPLE');
  });
  it('on Input Change invalid case', () => {
    // init
    component.ngOnInit();
    component.id = 'abccd'
    // execution
    component.onIdChange();

     // Expectation
     expect(component.error).toBe(false);
     expect(component.invalidId).toBe(true); 
  });
  it('on Input Change valid case', () => {

    // init
    component.ngOnInit();
    component.id = '12345678';
    // Execution
    component.onIdChange();

    // Expectation
    expect(component.error).toBe(false);
    expect(component.invalidId).toBe(false); 

    //component.retreiveCustomer();
  });
  it('retrieve customer', () => {
    // init
    component.ngOnInit();

    // Execution
    component.retreiveCustomer();

    // Expectation
    expect(component.dataloaded).toBe(false);
    expect(component.duplicate).toBe(false); 
  });
});