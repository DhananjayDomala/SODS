import { DropdownComponent } from 'app/democomponents/common/dropdown/dropdown.component';
import { Observable } from 'rxjs/Rx';
import { ModelChangeUpdateEvents } from './../../../events/action-events';
import { ObjectKey } from './../../../model/objectKey';
import { EditFileComponent } from './edit-file.component';
import { AttachfileComponent } from './attachfile.component';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';

import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents } from "../../../events/action-events";


import { Attachment } from '../../../model/attachment';

@Component({
  selector: 'app-attachment',
  templateUrl: './attachment.component.html',
  styleUrls: ['./attachment.component.css']
})
export class AttachmentComponent extends BaseComponent implements OnInit {

    @ViewChild('AttachFileModal') attachFileModal: Modal;
    @ViewChild('AttachFile') attachFile: AttachfileComponent;
    @ViewChild('EditFileModal') editFileModal: Modal;
    @ViewChild('EditFile') editFile: EditFileComponent;
    @ViewChild('RemoveAttachmentModal') removeAttachmentModal: Modal;
    @ViewChild('AttachFileModalAreYouSure') attachFileModalAreYouSure: Modal;
    attachmentsList = []; //attachmentsList:Array<Attachment> = [];
    isCollapsedAttachment: any = true;
    actionCompleted:boolean = true;
    actionFailed = false;
    public requisitionId: string;
    fileRef: ElementRef;
    objectKey: string;
    fileName: string;
    errorMsg: string;
    checkedAttachments:Array<ObjectKey> = [];
    listOfAttachments = [];
    selectedAll: any;
    userId: string;
    objectArray:Array<ObjectKey> = [];
    checkboxLength:number = 0;
    timer: any;
    public attachmentsExist:boolean;
    fileNames = [];
    userCanRemove:boolean = false;
    canDownload:boolean = false;
    hasFileUploaded:boolean = false

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService);
      let mapping: any = [];
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {this.renderAttachmentDetails(data);}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL] = () => {this.renderNoAttachmentDetails()}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_SUCCESS] = () => {this.renderAttachmentUploaded()};
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL] = (error:any) => {this.renderError(error)}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS] = () => {this.renderAttachmentDownloaded()}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL] = (error: any) => {this.renderError(error)}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_DELETE_SUCCESS] = () => {this.renderAttachmentDeleted()}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_DELETE_FAIL] = (error: any) => {this.renderError(error)}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_SUCCESS] = () => {this.renderAttachmentDeleted()}
      mapping[ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_FAIL] = (error: any) => {this.renderError(error)}
      mapping[ModelChangeUpdateEvents.REQ_ID_GENERATED_SUCCESS] = (reqId: string) => { this.renderReqIdGenerated(reqId); }  
      super.registerStateChangeEvents(mapping);
    }
    ngOnInit() {
      this.actionCompleted = false;
      this.attachmentsExist = false;
      this.attachmentsList = [];
      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId});
      this.actionDispatcherService.dispatch(event);
      this.userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
    }
    renderReqIdGenerated(reqId) {
      this.requisitionId = reqId;
    }
    get attachmentsCount() {
      return (this.attachmentsList).length;
    }
    get getCheckboxLength() {
      return this.checkboxLength;
    }

    /** START: Functionality **/
    downloadAttachmentOnSelect(fileName: string, objectKey: string) {
      this.actionCompleted = false;
      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_DOWNLOAD, {requisitionId: this.requisitionId, objectKey: objectKey, fileName: fileName});
      this.actionDispatcherService.dispatch(event);
    }
    downloadMultipleAttachments() {
      this.objectArray = [];
      for(let i = 0; i < this.attachmentsList.length; i++) {
        if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked === true) {
          let objectKey = (<HTMLInputElement>document.getElementById("objectKey["+i+"]")).value;
          this.objectArray.push({fileName: this.attachmentsList[i].fileName, objectKey: objectKey, requisitionId: this.requisitionId});
        }
      }
      if(this.objectArray.length > 0) {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_MULTI_DOWNLOAD, 
          {requisitionId: this.requisitionId, multiDownloadList: this.objectArray});
        this.actionDispatcherService.dispatch(event);
      }
    }
    deleteAttachments() {
      this.actionCompleted = false;
      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_DELETE, {requisitionId: this.requisitionId, objectKey: this.objectKey});
      this.actionDispatcherService.dispatch(event);
    }
    removeAttachments() {
      this.removeAttachmentModal.close();
      this.userCanRemove = false;
      this.canDownload = false;
      let objectArray:Array<ObjectKey> = [];
      for(let i = 0; i < this.attachmentsList.length; i++) {
        if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked === true) {
          let objectKey = (<HTMLInputElement>document.getElementById("objectKey["+i+"]")).value;
          objectArray.push({fileName: this.attachmentsList[i].fileName, objectKey: objectKey, requisitionId: this.requisitionId});
        }
      }
      if(objectArray.length > 0) {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_MULTI_DELETE, {requisitionId: this.requisitionId, multiDeleteList: objectArray});
        this.actionDispatcherService.dispatch(event);
      }
    }
    /** END: Functionality **/


    /** START: Checkbox selection functions **/
    checkboxSelected(objectKey: string, fileName: string, event) {
      if(this.attachmentsList.length > 0) {
        this.attachmentsExist = true;
      }
      this.attachmentsList.forEach((element, index) => {
        if(event.target.checked) {
          event.target.value = true;
        }else{
          (<HTMLInputElement>document.getElementById("selectedAll")).checked = false;
          event.target.value = false;
        }
      })  
      //Setting userCanRemove boolean to false if any checked record's userID is NOT the same as the logged in user's userID
      //Requirement: Can only delete those attachments that the currently logged in user uploaded
      for(let i = 0; i < this.attachmentsList.length; i++) {
        if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked === true) {
          this.canDownload = true; //If any are checked, enable download
          let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
          if(this.attachmentsList[i].userId !== userId) {
            this.userCanRemove = false;
            return;
          }else{
            this.userCanRemove = true;
          }
        }
      }
      

      for(let i = 0; i < this.attachmentsList.length; i++) {
        if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked === true) {
          this.attachmentsExist = true;
          return;
        }else{
          this.attachmentsExist = false;
        }
      }
    }
    selectAll(event) {
      if(event.target.checked === true) {
        this.attachmentsExist = true;
        this.canDownload = true;
        this.attachmentsList.forEach((element, index) => {
          element.selected = event.target.checked;
        })
        for(let i = 0; i < this.attachmentsList.length; i++) {
          (<HTMLInputElement>document.getElementById("index["+i+"]")).checked = true;
        }
      }else{
        this.attachmentsExist = false;
        this.attachmentsList.forEach((element, index) => {
          element.selected = event.target.checked;
        })
        for(let i = 0; i < this.attachmentsList.length; i++) {
          (<HTMLInputElement>document.getElementById("index["+i+"]")).checked = false;
        }
      }
      //Setting userCanRemove boolean to false if any checked record's userID is NOT the same as the logged in user's userID
      //Requirement: Can only delete those attachments that the currently logged in user uploaded
      this.userCanRemove = false;
      for(let i = 0; i < this.attachmentsList.length; i++) {
        if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked === true) {
          //If checked, see if userId of this element is same as logged in user
          let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
          if(this.attachmentsList[i].userId !== userId) {
            this.userCanRemove = false;
            return;
          }else{
            this.userCanRemove = true;
          }
        }
      }
    }
    /** END: Checkbox selection functions **/


    /** START: Opening and closing of modals **/
    openAreYouSureModal() {
      this.fileNames = [];
      for(let i = 0; i < this.attachmentsList.length; i++) {
        if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked === true) {
          this.fileNames.push(this.attachmentsList[i].fileName);
        }
      }
      this.removeAttachmentModal.open();
    }
    uploadAttachFileModal() {
      this.attachFile.upload();
    }
    openAttachFileModal(){
      this.attachFile.listOfFiles = [];
      this.attachFile.fileTypeDropDown.selectedOption = '';
      this.attachFile.otherFileType = '';
      this.attachFile.other_require_error = false;
      this.attachFile.file_type_error = false;
      this.attachFile.invalid_format = false;
      this.attachFile.valid_format_error = false;
      this.attachFile.error_on_upload = false;
      this.attachFile.fileChosen = false;
      this.attachFile.otherSelected = false;
      this.attachFile.selectFileType = '';
      this.hasFileUploaded = false;
      if(this.attachmentsList.length >= 10) {
        this.attachFile.disableUpload = true;
      }else{
        this.attachFile.disableUpload = false;
      }
      this.attachFile.uploadedFilesNbr = this.attachmentsList.length;
      this.attachFileModal.open();
    }
    openEditFileModal(objectKey: string, fileName: string, fileType: string){
      this.editFile.listOfFiles = [];
      this.editFile.objectKey = objectKey;
      this.editFile.fileName = fileName;
      this.editFile.other_require_error = false;
      this.editFile.file_type_error = false;
      this.editFile.invalid_format = false;
      this.editFile.valid_format_error = false;
      let stringArray = ['Signed Order', 'Customer Quote', 'Order Acknowledgement', 'Vendor Acknowledgement', 'Spec Sheets','Other'];
      let itExists = (stringArray.indexOf(fileType) > -1);
      //If fileType is in array
      if(itExists) {
        this.editFile.fileTypeDropDown.selectedOption = fileType;
        this.editFile.selectFileType = fileType;
        this.editFile.otherSelected = false;
        this.editFile.otherFileType = '';
      }else{ //If other file type
        this.editFile.fileTypeDropDown.selectedOption = 'Other';
        this.editFile.selectFileType = 'Other';
        this.editFile.otherFileType = fileType;
        this.editFile.otherSelected = true;
      }
      this.editFileModal.open();
    }
    closeAttachFileModal($event) {
      if(this.attachFile.listOfFiles.length > 0 || this.attachFile.selectFileType !== '') {
        this.attachFileModalAreYouSure.open();
      }else{
        this.attachFileModal.close();
      } 
    }
    cancel() {
      this.attachFileModal.close();
    }
    closeEditFileModal() {
      this.editFileModal.close();
    }
    onNotify(event) {
      if(event === 'true') {
        this.hasFileUploaded = true;
      }
      if(event === 'false') {
        this.hasFileUploaded = false;
      }
      if(event === 'closeAttachFileModal') {
        this.attachFileModal.close();
      }
    }
    onEditNotify() {
      this.editFileModal.close();
      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId});
      this.actionDispatcherService.dispatch(event);
    }
    closeRemove() {
      this.attachFileModalAreYouSure.close();
    }
    closeAreYouSureRemove() {
      this.removeAttachmentModal.close();
    }
    openRemoveAttachmentModal(event) {
      this.removeAttachmentModal.open();
    }
    softDeleteAttachments() {
      this.attachFileModalAreYouSure.close();
      this.attachFileModal.close();
      this.attachFile.listOfFiles.forEach((element) => {
          let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_SOFT_DELETE, 
            {requisitionId: this.requisitionId, attachmentsList: this.attachFile.listOfFiles});
          this.actionDispatcherService.dispatch(event);
      });
  }
    /** END: Opening and closing of modals **/


    /** START: Rendering of success & failures **/
    renderAttachmentDetails(data: any){
      this.actionCompleted = true;
      this.attachmentsList = [];
      this.attachmentsList = data;
      if(this.attachmentsList.length > 0) {
        this.attachmentsExist = true;
      }else{
        this.attachmentsExist = false;
      }
    }
    renderNoAttachmentDetails() {
      this.actionCompleted = true;
    }
    renderAttachmentUploaded() {
      this.attachmentsList = [];
      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId});
      this.actionDispatcherService.dispatch(event);
      this.actionCompleted = true;
    }
    renderAttachmentDownloaded() {
      this.actionCompleted = true;
    }
    renderAttachmentDeleted() {
      this.actionCompleted = true;
      this.attachmentsList = [];
      let timer = Observable.timer(500);
      timer.subscribe(t=> {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId});
        this.actionDispatcherService.dispatch(event);
      });
    }
    renderError(error: any) {
      this.actionCompleted = true;
      this.errorMsg = error.statusText;
      this.actionFailed = true;
    }
    /** END: Rendering of success & failures **/
    
    cancelAttachmentEdit() {
      this.editFile.cancel();
    }

    saveAttachmentEdit() {
      this.editFile.save();
    }
}
