import { element } from 'protractor';
import { ObjectKey } from './../../../model/objectKey';
import { environment } from './../../../../environments/environment';
import { ModelChangeUpdateEvents, ActionEvents } from './../../../events/action-events';
import { RequestOptions, Http, Response, Headers, ResponseContentType } from '@angular/http';
import { Component, OnInit, ViewChild, Output, Input, ElementRef } from '@angular/core'; 
import { Modal, ModalModule } from 'ngx-modal';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from '../../base-component';
import { Product, Vendor } from '../../../model/product';
import { Comment} from '../../../model/comment';
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";
import { CalendarComponent } from "app/democomponents/common/calendar/calendar.component";

@Component({
  selector: 'sods-edit-new-product',
  templateUrl: './edit-new-product.component.html',
  styleUrls: ['./edit-new-product.component.css']
})
export class EditNewProductComponent extends BaseComponent implements OnInit {

    counter = 1;
    calendar_counter = 1;
    changeMonthFlag = false;
    prodTypeOptions: string[];
    private selectedProdType: string;
    public defaultProdType: string = 'Grocery';
    public minDate: Date = new Date();
    public value: Date;
  
    //Validation Error Handling
    public product_desc_require_error: boolean = false;
    public vendor_require_error: boolean = false;
    public mfr_product_require_error: boolean = false;
    public qty_require_error: boolean = false;
    public qty_number_error: boolean = false;
    public zero_number_error: boolean = false;
    public date_selection_error: boolean = false;
  
    public sellPrice_number_error: boolean = false;
    
    //Other fields
    public product: Product;
    public comment: Comment;

    //Product attachment
    public fileName: string = "";
    public attachmentsList:Array<any> = [];
    public newAttachmentsList:Array<any> = [];
    public tempDelete:Array<any> = [];
    errorMsg: string;
    requisitionId: string;
    attachmentKey : number;
    attachCount : number = 0;
    fileRef: ElementRef;
    objectKey: string;
    public errorOnUpload: boolean = false;
    public textareaLength: number = 1000;
    @ViewChild('fileInput') inputEl: ElementRef;
    @ViewChild('ProdTypeDropdown') prodTypeDropdown: DropdownComponent;
    @ViewChild('sodsCalendar') sodsCalendar: CalendarComponent;
    disableUpload: boolean = false;

    constructor(private http: Http,readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService);
      let mapping: any = [];
      mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => {this.renderAttachmentDetails(data)}
      mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_FAIL] = (error:any) => {this.renderError(error)}
      mapping[ModelChangeUpdateEvents.PROD_ATTACH_DELETE_SUCCESS] = () => {this.renderAttachmentDeleted()}
      mapping[ModelChangeUpdateEvents.REQ_ID_GENERATED_SUCCESS] = (reqId: string) => { this.renderReqIdGenerated(reqId); }  
      super.registerStateChangeEvents(mapping);
    }
  
    ngOnInit() {
      this.prodTypeOptions = ['Grocery', 'Produce', 'COP', 'Non-Food', 'CES'];
      this.minDate = new Date();
      this.product = new Product();
      this.product.vendor = new Vendor();
      this.product.new = true;
      this.comment = new Comment();
      this.product.comments = new Array<Comment>();
      this.attachmentsList = [];
      this.newAttachmentsList = [];
      this.tempDelete = [];
      this.attachmentKey = this.product.attachmentKey;
    }
    renderReqIdGenerated(reqId) {
      this.requisitionId = reqId;
    }
  
    onProdTypeSelection($event){
      this.product.prodType = $event;
    }
  
    onDateSelectionDone($event){
      this.product.eta = $event;
      this.date_selection_error = false;
    }
  
    onErrorHandler($event){
      this.date_selection_error = true;
      if($event !== 'error'){
        this.date_selection_error = false;
    }
    }
  
    checkNumberFormatforQty() {
      this.checkKeyupRequire_qty();
      if(this.validateNumber(this.product.qty)) {
        this.qty_number_error = false;
      } else { 
        this.qty_number_error = true; 
      }
      if(this.product.qty == '0'){
        this.zero_number_error = true;
      }else{
        this.zero_number_error = false;
      }
    }
  
    //Validate Number
    validateNumber(data: string){
      if(data == null || data == undefined || data.trim() == '') {
        this.qty_require_error = true;
        return true;
      }
      this.qty_require_error = false;
      let NUMBER_REGEXP = /^[0-9]{1,5}$/
      return NUMBER_REGEXP.test(data);
    }
    
  
    checkSellPrice() {
      if(this.product.sellPrice == "" || this.product.sellPrice == null || this.product.sellPrice == undefined) {
          this.sellPrice_number_error = false;
          return;   
      }
      
      if(this.validateQuotePrice(this.product.sellPrice)) {
          this.sellPrice_number_error = false;            
          //checks for whole integers (ex. 32) and converts to 32.00
          if(this.product.sellPrice.indexOf('.') == -1 && !(this.product.sellPrice.charAt(0) == '.')){
            this.product.sellPrice = this.product.sellPrice.concat('.00');
          }
          //checks for .xx and converts to 0.xx
          if(this.product.sellPrice.charAt(0) == '.'){
            this.product.sellPrice = '0'.concat(this.product.sellPrice);
          }
      } else { 
          this.sellPrice_number_error = true;     
      } 
    }
  
    validateQuotePrice(quote: string) : boolean {
      if(quote == null || quote == undefined || quote.trim() == ""){
        return true;
      }
      let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
      return QUOTE_REGEXP.test(quote);
    }
  
    checkProdDescRequire(){
      if(this.product.description == null || this.product.description == undefined || this.product.description.trim() == ""){
        this.product_desc_require_error = true;
      }else{
        this.product_desc_require_error = false;
      }
    }
  
    checkKeyupRequire_desc(){
      this.product.description = this.product.description.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
      this.product_desc_require_error = 
      ((this.product.description === null || this.product.description === undefined || this.product.description.trim() === "") ? true : false);
    }
  
    checkKeyupRequire_mfrProd(){
      this.product.mfrId = this.product.mfrId.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
      this.mfr_product_require_error = 
      ((this.product.mfrId === null || this.product.mfrId === undefined || this.product.mfrId.trim() === "") ? true : false);    
    }
  
    checkKeyupRequire_qty(){
      this.qty_require_error = 
      ((this.product.qty === null || this.product.qty === undefined || this.product.qty.trim() === "") ? true : false); 
    }

    renderAttachmentDeleted() {
    }

    deleteAttachments(requisitionId, objectKey) {
      let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_DELETE, {requisitionId: this.requisitionId, objectKey: objectKey});
      this.actionDispatcherService.dispatch(event);
    }
  
    deleteElement(elem, obj){
      this.errorOnUpload = false;
      let elementitem:HTMLElement = document.getElementById('attach'+elem);
      elementitem.parentNode.removeChild(elementitem);
      if (obj === "attachmentsList") {
        this.attachmentsList.splice(elem, 1);
      }
    }

    renderError(error: any) {
      this.errorMsg = error.statusText;
    }

    editAttachFile() {
      if(this.disableUpload) {
        this.errorMsg = 'Cannot uploaded more than 99 files';
        this.errorOnUpload = true;
      }else{
        if(this.attachmentsList.length + 1 > 99) {
          this.errorMsg = 'Cannot uploaded more than 99 files';
          this.errorOnUpload = true;
        }else{
          this.fileName = "";
          let inputEl: HTMLInputElement = this.inputEl.nativeElement;
          let fileCount: number = inputEl.files.length;
          let attachmentKey = this.product.attachmentKey;
          let APIURL = environment.productAttachments +"/"+this.requisitionId + "/upload?" + "sequenceId=" + this.product.attachmentKey; //Put into environments.ts? Have multiple pointing at this API
          let token = JSON.parse(localStorage.getItem('token')).value; 
          let headers = new Headers();
          headers.append('Authorization', `Bearer ${token}`);
          let options = new RequestOptions({headers: headers});
          let fileName: string;
          let attachment = new FormData();
          this.errorOnUpload = false;
    
          if (fileCount > 0) { // a file was selected
              for (let i = 0; i < fileCount; i++) {
                attachment.append("attachment", inputEl.files.item(i));
                fileName = inputEl.files.item(i).name;
                let fileType = inputEl.files.item(i).type;
                let currentDate = new Date();
                let creationDate = currentDate.toJSON();
              }
              return this.http.put(APIURL, attachment, options)
                  .toPromise().then((res: Response)=>{
                      let body = res.json();
                      inputEl.value = "";
                      this.attachmentsList.push({objectKey: body.objectKey, fileName : fileName, requisitionId: this.requisitionId });
                  })
                  .catch(
                    (error: Response) => {
                       let errorBody = error.json();
                       this.errorOnUpload = true;
                       this.errorMsg = errorBody.message;
                    } 
                );
          }
          this.inputEl.nativeElement.value = "";
          return;
        }
      }
  }

  checkPackSize(){
    this.product.packSize = this.product.packSize.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
  }

  checkLabel(){
    this.product.label = this.product.label.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
  }

  checkVendor(){
    this.product.vendor.vendorName = this.product.vendor.vendorName.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    this.vendor_require_error = 
    ((this.product.vendor.vendorName == null || this.product.vendor.vendorName  == undefined || this.product.vendor.vendorName.trim()=="") ? true : false);
  }

  getAttachmentDetails(requisitionId, attachmentKey){
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, {requisitionId: requisitionId, attachmentKey:this.attachmentKey});
    this.actionDispatcherService.dispatch(event);
  }
  softDeleteAttachments() {
    this.newAttachmentsList.forEach(item => {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_DELETE, {requisitionId: this.requisitionId, objectKey: item.objectKey});
        this.actionDispatcherService.dispatch(event);
    });
  } 
  renderAttachmentDetails(data) {
    this.attachmentsList = data;
  }

  get attachmentCount(){
    return this.attachmentsList.length
  }

  pushtoTempDelete(attachment){
    this.tempDelete.push(attachment);
   }
  
   controlClick(){
    if(this.changeMonthFlag){
      this.changeMonthFlag = false;
      return;
    }
    if(this.counter % 2 === 0 && this.prodTypeDropdown.isVisible){
      this.prodTypeDropdown.isVisible = false;
      this.counter ++;
    }else if(this.prodTypeDropdown.isVisible){
      this.counter ++;
    }else if(this.counter % 2 === 0 && !this.prodTypeDropdown.isVisible){
      this.counter ++;
    }

    if(this.sodsCalendar !== null && this.sodsCalendar !== undefined){
      if(this.calendar_counter  % 2 === 0 && this.sodsCalendar.child3.overlayVisible){
        this.sodsCalendar.child3.overlayVisible = false;
        this.calendar_counter  ++;
      }else if(this.sodsCalendar.child3.overlayVisible){
        this.calendar_counter  ++;
      }else if(this.calendar_counter  % 2 === 0 && !this.sodsCalendar.child3.overlayVisible){
        this.calendar_counter  ++;
      }
    }
  }

  changeMonth(){
    this.changeMonthFlag = true;
  }
  
}
