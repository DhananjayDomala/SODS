// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { SharedModule } from './../../../shared/shared.module';
// import { ProductAttachmentComponent } from './product-attachment.component';

// describe('ProductAttachmentComponent', () => {
//   let component: ProductAttachmentComponent;
//   let fixture: ComponentFixture<ProductAttachmentComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [],
//       imports: [SharedModule]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ProductAttachmentComponent);
//     component = fixture.componentInstance;
//     component.actionDispatcherService.dispatch = () => {};
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should renderAttachmentDetails', () => {
//     component.renderAttachmentDetails([{fileName: 'sample.png'}]);
//     expect(component.actionCompleted).toBeTruthy();
//   });

//   it('should renderAttachmentDetails', () => {
//     component.renderAttachmentDetails([{fileName: 'sample.png'}]);
//     expect(component.actionCompleted).toBeTruthy();
//   });

//   it('should renderNoAttachmentDetails', () => {
//     component.renderNoAttachmentDetails();
//     expect(component.actionCompleted).toBeTruthy();
//   });

//   it('should renderAttachmentDownloaded', () => {
//     component.renderAttachmentDownloaded();
//     expect(component.actionCompleted).toBeTruthy();
//   });

//   it('should downloadAttachments', () => {
//     component.downloadAttachments('123', '');
//     expect(component.actionCompleted).toBeFalsy();
//   });

//   it('should renderError', () => {
//     component.renderError({statusText: 'sas'});
//     expect(component.actionCompleted).toBeTruthy();
//     expect(component.errorMsg).toBe('sas');
//     expect(component.actionFailed).toBeTruthy();
//   });

// });
