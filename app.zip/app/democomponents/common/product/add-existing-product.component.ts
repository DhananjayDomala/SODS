import { ANY_STATE } from '@angular/animations/browser/src/dsl/animation_transition_expr';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "../../../events/action-events";
import { Customer } from '../../../model/customer';
import { Product, Vendor } from '../../../model/product';
import { Comment} from '../../../model/comment';
import { Attachment } from '../../../model/attachment';
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";
import { CalendarComponent } from "app/democomponents/common/calendar/calendar.component";
import { VirtualVendor, RetrieveVirtualVendorRespone } from "app/model/virtualVendor";

@Component({
  selector: 'sods-add-existing-product',
  templateUrl: './add-existing-product.component.html',
  styleUrls: ['./add-existing-product.component.css']
})
export class AddExistingProductComponent extends BaseComponent implements OnInit {

  counter = 1;
  calendar_counter = 1;
  changeMonthFlag = false;
  searchTypeOptions: string[];
  errMsg: string = "";
  selectedSearchType: string;
  readonly defaultSearchType: string = 'Product(USF)';
  div: string;
  public productNbr: string;

  public product: Product;
  public vendor: Vendor;

  public minDate: Date = new Date();
  public value: Date;
  selectedReq: any;

  //validation error handling
  public retrieveSuccess: boolean = false;
  public product_not_found_error: boolean = false;
  public duplicated_product_error: boolean = false;
  public sellPrice_number_error: boolean = false;
  public handling_number_error: boolean = false;
  public qty_require_error: boolean = false;
  public qty_number_error: boolean = false;
  public zero_number_error: boolean = false;
  public date_selection_error: boolean = false;
  public error_msg: string = '';

  @ViewChild('ProdTypeDropdown') prodTypeDropdown: DropdownComponent;
  @ViewChild('sodsCalendar') sodsCalendar: CalendarComponent;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
	super(stateRepresentationRendererService);
    let mapping: any = [];        
    mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(data); }
    mapping[ModelChangeUpdateEvents.REQ_CHANGE_EVT_SUCCESS] = (val) => { this.onValChange(val); }
    mapping[ModelChangeUpdateEvents.RETRIEVE_PRODUCT_SUCCESS] = (product: Product) => { this.renderProductFound(product); }
    mapping[ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL] = (error: any) => { this.renderProductNotFound(error);}
    mapping[ModelChangeUpdateEvents.RETRIEVE_VIRTUAL_VENDOR_SUCCESS] = (res: RetrieveVirtualVendorRespone) => { this.rendorRetrieveVirtualVendorSuccess(res);}
    super.registerStateChangeEvents(mapping);
  }

  onValChange(val: any) {
    if (typeof val === "object") {
      this.selectedReq = val.reqType;
    }
    
  }

  ngOnInit() {
    this.searchTypeOptions = ['Product(USF)', 'Manufacturer Product'];
    this.product = new Product();
    this.product.vendor = new Vendor();
    // this.product.eta = this.value;
    this.product.new = false;
    this.product.comments = new Array<Comment>();
    this.selectedSearchType = this.defaultSearchType;
  }

  onSearchTypeSelection($event){
	  this.selectedSearchType = $event;
  }

  retrieveProduct(){
    this.errMsg = "";
    this.duplicated_product_error = false;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_PRODUCT, {searchType: this.selectedSearchType, div: this.div, prodNbr: this.productNbr});
    this.actionDispatcherService.dispatch(event);
  }

  renderCustFound(data: Customer){
	  this.div = data.division;
  }
  
  renderProductFound(product: Product){

    //make another API to check the vendor
    if(product.vendor !== null && product.vendor.vendorId !== null){
      let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_VIRTUAL_VENDOR, {vendorId: product.vendor.vendorId, product: product});
      this.actionDispatcherService.dispatch(event);
    }else{
      this.errMsg = "There is no vendor attached with customer";
    }
  }

  rendorRetrieveVirtualVendorSuccess(res: RetrieveVirtualVendorRespone){
    let virtualVendorList = res.virtualVendorList;
    let product = res.product;
    if(virtualVendorList[0].vendorNumber === ''){
      if(product.ntnlSts !== "") {
        if (product.distSts !== null && product.distSts !== undefined && product.distSts.toString() !== "" && Number(product.distSts) === 0 && this.selectedReq !== 'Direct Ship') {
          this.errMsg = "Product is currently set to Normal status.";
        } else if (Number(product.distSts) === 2  && this.selectedReq !== 'Direct Ship') {
          this.errMsg = "Product is currently set to Active, but Out of Stock status.";
        } else if (Number(product.distSts) === 3  && this.selectedReq !== 'Direct Ship'){
          this.errMsg = "Product is currently set to Temporary status.";
        } else if (Number(product.distSts) === 4  && this.selectedReq !== 'Direct Ship') {
           this.errMsg = "Product is currently set to Seasonal status.";
        }  else if (Number(product.distSts) === 8) {
           this.errMsg = "Product is currently set to DWO status.";
        }  else if (Number(product.distSts) === 9) {
          this.errMsg = "Product is currently set to Discontinued status.";
        }else {
          this.product_not_found_error = false;
          this.product = product;
          this.product.new = false;
          this.product.comments = new Array<Comment>();
          this.product.attachments = new Array<Attachment>();
          this.errMsg = "";
          // this.product.eta = new Date();
        this.retrieveSuccess = true;
        }
      }else{
        this.errMsg = "Product is currently Inactive.";
      }
      this.product_not_found_error = false;
    }else{
      this.errMsg = 'Product belongs to a Presold/Virtual Vendor, please enter a Sales Order instead';
      this.product_not_found_error = false;
      this.product = product;
      this.product.new = false;
      this.product.comments = new Array<Comment>();
      this.product.attachments = new Array<Attachment>();
      this.retrieveSuccess = true;
    }
  }

  renderProductNotFound(error: any){
    this.retrieveSuccess = false;
	this.product_not_found_error = true;
	this.error_msg = error;
  }

  onDateSelectionDone($event){
    this.product.eta = $event;
    this.date_selection_error = false;
  }

  onErrorHandler($event){
    this.date_selection_error = true;
    if($event !== 'error'){
      this.date_selection_error = false;
    }
  }

  checkSellPrice() {
    if(this.product.sellPrice === "" || this.product.sellPrice === null || this.product.sellPrice === undefined) {
        this.sellPrice_number_error = false;
        return;   
    }
    
    if(this.validateQuotePrice(this.product.sellPrice)) {
        this.sellPrice_number_error = false;            
        //checks for whole integers (ex. 32) and converts to 32.00
        if(this.product.sellPrice.indexOf('.') === -1 && !(this.product.sellPrice.charAt(0) === '.')){
          this.product.sellPrice = this.product.sellPrice.concat('.00');
        }
        //checks for .xx and converts to 0.xx
        if(this.product.sellPrice.charAt(0) === '.'){
          this.product.sellPrice = '0'.concat(this.product.sellPrice);
        }
    } else { 
        this.sellPrice_number_error = true;     
    } 
  }

  checkHandlingPrice(){
    if(this.product.handling === "" || this.product.handling === null || this.product.handling === undefined) {
      this.handling_number_error = false;
      return;   
  }
  
  if(this.validateQuotePrice(this.product.handling)) {
      this.handling_number_error = false;            
      //checks for whole integers (ex. 32) and converts to 32.00
      if(this.product.handling.indexOf('.') === -1 && !(this.product.handling.charAt(0) === '.')){
        this.product.handling = this.product.handling.concat('.00');
      }
      //checks for .xx and converts to 0.xx
      if(this.product.handling.charAt(0) === '.'){
        this.product.handling = '0'.concat(this.product.handling);
      }
    }else { 
        this.handling_number_error = true;     
    } 
  }

  validateQuotePrice(quote: string) : boolean {
    if(quote === null || quote === undefined || quote.trim() === ""){
      return true;
    }
    let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
    return QUOTE_REGEXP.test(quote);
  }

  checkNumberFormatforQty() {
    this.checkKeyupRequire_qty();
    if(this.validateNumber(this.product.qty)) {
      this.qty_number_error = false;
    } else { 
      this.qty_number_error = true; 
    }
    if(this.product.qty == '0'){
      this.zero_number_error = true;
    }else{
      this.zero_number_error = false;
    }
  }

  //Validate Number
  validateNumber(data: string){
    if(data === null || data === undefined || data.trim() === '') {
      this.qty_require_error = true;
      return true;
    }
    this.qty_require_error = false;
    let NUMBER_REGEXP = /^[0-9]{1,5}$/
    return NUMBER_REGEXP.test(data);
  }

  checkKeyupRequire_qty(){
    this.qty_require_error = 
    ((this.product.qty === null || this.product.qty === undefined || this.product.qty.trim() === "") ? true : false); 
  }

  controlClick(){
    if(this.changeMonthFlag){
      this.changeMonthFlag = false;
      return;
    }
    if(this.counter % 2 === 0 && this.prodTypeDropdown.isVisible){
      this.prodTypeDropdown.isVisible = false;
      this.counter ++;
    }else if(this.prodTypeDropdown.isVisible){
      this.counter ++;
    }else if(this.counter % 2 === 0 && !this.prodTypeDropdown.isVisible){
      this.counter ++;
    }

    if(this.sodsCalendar !== null && this.sodsCalendar !== undefined){
      if(this.calendar_counter  % 2 === 0 && this.sodsCalendar.child3.overlayVisible){
        this.sodsCalendar.child3.overlayVisible = false;
        this.calendar_counter  ++;
      }else if(this.sodsCalendar.child3.overlayVisible){
        this.calendar_counter  ++;
      }else if(this.calendar_counter  % 2 === 0 && !this.sodsCalendar.child3.overlayVisible){
        this.calendar_counter  ++;
      }
    }
  }

  changeMonth(){
    this.changeMonthFlag = true;
  }

}
