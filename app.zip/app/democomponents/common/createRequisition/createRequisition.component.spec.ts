import { EditCustomerComponent } from './../customer/edit-customer.component';
import { HeaderComponent } from './../../header/header.component';
import { ModalModule } from 'ngx-modal';
import { CalendarComponent } from './../calendar/calendar.component';
import { MarketDropdownComponent } from './../dropdown/market-dropdown/market-dropdown.component';
import { UserComponent } from './../user/user.component';
import { CustomerComponent } from './../customer/customer.component';
import { CustomerDetailsComponent } from './../customer/customer-details.component';
import { Collapse } from './../../../directive/collapse.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateRequisitionComponent } from './createRequisition.component';
import { DropdownComponent } from '../dropdown/dropdown.component';
import { FormsModule } from '@angular/forms';
import {CalendarModule} from 'primeng/primeng';
import { SAMPLEREQUISITION } from '../../../model/requisition';
import { SAMPLECUSTOMER } from '../../../model/customer';
import { RouterModule } from '@angular/router';

fdescribe('CreateRequisitionComponent', () => {
  let component: CreateRequisitionComponent;
  let fixture: ComponentFixture<CreateRequisitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateRequisitionComponent, EditCustomerComponent, CustomerDetailsComponent, HeaderComponent, CalendarComponent, Collapse, DropdownComponent, CustomerComponent, UserComponent, MarketDropdownComponent ],
      imports: [FormsModule, ModalModule, RouterModule, CalendarModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateRequisitionComponent);
    component = fixture.componentInstance;
    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': ''})}));
    component.tm.name = 'Sample';
    component.tm.email = 'Sample';
    component.tm.phone = '12';
    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Misc', () => {
    fixture.detectChanges();
    component.renderReqIdGenerated(''); // render req id generated
    component.retrieveRequestor(); // render retrieve requestor
    component.renderTMFound({displayName: '', email: '', phone: ''}); // render TM Found
    component.onReqTypeSelection({}); // render on Req Type Selection
    component.reqId = '1'; // render req id
    expect(component.requestId).toBe('1'); 
    component.renderReqFound(SAMPLEREQUISITION); // render render req found
    component.renderReqNotFound(); // render req not found
    component.renderCustFound(SAMPLECUSTOMER); // render customer found
    component.handleBlurOfReqId(); // render blur event
    component.renderCustNotFound(); // render cust not found
    component.customerComponent.marketOptions = []; 
    component.customerComponent.selectedMarket = '1'; // dropdown selection
    expect(component.selectedMarketingType).toBe('1');
    expect(component.getMarketOptions.length).toBe(0);
    component.onReqTypeSelection('Direct Ship'); 
});
  
});
