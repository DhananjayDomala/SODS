import { CustomerDetailsComponent } from './../customer/customer-details.component';
import { Observable } from 'rxjs/Rx';
import { AttachmentComponent } from './../attachment/attachment.component';
import { Component, OnInit, ViewChild, ViewEncapsulation, AfterViewInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { Requisition } from '../../../model/requisition';
import { Customer } from '../../../model/customer';
import { CustomerComponent } from '../customer/customer.component';
import { UserComponent } from '../user/user.component';
import { Modal, ModalModule } from 'ngx-modal';
import { DropdownComponent } from '../dropdown/dropdown.component'

import { TandemTM } from '../../../model/tandemTM';
import { ProductCommentComponent } from '../../common/comment/product-comment/product-comment.component';
import { Comment } from '../../../model/comment';

@Component({
    selector: 'so-createRequisition',
    templateUrl: './createRequisition.component.html',
    styleUrls: ['./createRequisition.component.css'],
})

export class CreateRequisitionComponent extends BaseComponent implements OnInit, OnChanges, AfterViewInit {

    @ViewChild('areYouSure') areUsureModal: Modal;
    @ViewChild('sodsDropdown') sodsDropdown: DropdownComponent;

    @ViewChild('viewCommentsTest') viewMsgsToModal: Modal;
    @ViewChild('Comments') commentsComponent: ProductCommentComponent;
    @ViewChild('viewAuditLogs') viewAuditModal: Modal;

    @Input('taskStatus') taskStatus: string;
    @Output('reqTypeChange')
    reqTypeChangeEvent: EventEmitter<any> = new EventEmitter<any>();


    marketStyle: boolean;
    reqTypeOptions: string[];
    marketOptions: string[];
    taksId: any;
    public showReq: boolean = false;
    public copyReqId: string;
    readonly defaultReqType: string = ((!localStorage.getItem("requestType") || 
        localStorage.getItem("requestType") === "null") ? 'Special Order' : localStorage.getItem("requestType")) || "Special Order";
    readonly defaultMarket: string = "1104";

    selectedReqType: string;
    private selectedMarket: string;

    //Data Model
    public reqId: string;
    public inputReqId: string;
    type: string;
    division: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    totalAmount: string;
    etaSelection: string;
    etaDate: string;
    returnIfEtaNotMet: string;
    defaultShipMethod: string;
    defaultCustomerPO: string;
    defaultSpecInstructions: string;
    rejectComment: string;
    mainCustomerID: string;
    mainCustomerName: string;
    mainCustomerDept: string;

    //Error handling & successful upload start
    public errorsExist: boolean = false;
    errorMsg: string;
    successfulUploads: boolean = false;
    //Error handling & successful upload end

    public currentCustomer: Customer;


    @ViewChild(CustomerComponent)
    public customerComponent: CustomerComponent;
    public customerDetailsComponent: CustomerDetailsComponent;

    @ViewChild('attachmentComponent') attachmentComponent: AttachmentComponent;


    @ViewChild('tm')
    public tm: UserComponent;

    @ViewChild('requestor')
    public requestor: UserComponent;
    reqTypeOptionsValue: any;
    reqTypeOptionsByValue: any;
    isCollapsed = false;

    modalTitle: any;
    modalMsg: any;
    reqStatus: any;
    reqComments: any;

    //add audit log
    auditLogs: any;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);

        let mapping: any = [];
        mapping[ModelChangeUpdateEvents.REQ_FOUNT] = (data: Requisition) => { this.renderReqFound(data); }
        mapping[ModelChangeUpdateEvents.REQ_NOT_FOUND] = (error: any) => { }
        mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(data); }
        mapping[ModelChangeUpdateEvents.CUST_NOT_FOUND] = (error: any) => { this.renderCustNotFound(); }
        mapping[ModelChangeUpdateEvents.REQ_ID_GENERATED_SUCCESS] = (reqId: string) => { this.renderReqIdGenerated(reqId); }
        mapping[ModelChangeUpdateEvents.TM_FOUND] = (data: any) => { this.renderTMFound(data); }
        mapping[ModelChangeUpdateEvents.TM_FOUND_2] = (data: any) => { this.renderTMFound2(data); }
        mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_SUCCESS] = (error: any) => { this.renderSuccessUploads() };
        mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL] = (error: any) => { this.renderError(error) }
        mapping[ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_FAIL] = (error: any) => { this.renderError(error) }
        mapping[ModelChangeUpdateEvents.RETRIEVE_TM_FROM_TANDEMID_SUCCESS] = (tandemTM: TandemTM) => { this.renderTandemTMIdFound(tandemTM); }
        mapping[ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_SUCCESS] = (commentsList: any) => { this.renderRetrieveCommentsSuccess(commentsList); }
        
        super.registerStateChangeEvents(mapping);
    }

    ngAfterViewInit() {
        localStorage.setItem('requestType', null);
    }

    ngOnChanges(){
        if(this.inputReqId !== null && this.inputReqId !== undefined){
            this.reqId = this.inputReqId;
        }else{
            this.generateReqId();
        }
    }

    ngOnInit() {
        try {
            this.retrieveRequestor();
            this.tm.isTM = true;
            this.tm.tmTitle = true;

            //Initialize requisition type options
            this.reqTypeOptions = ['Special Order', 'Direct Ship'];
            this.reqTypeOptionsValue = { 'Special Order': 'SODS-SO', "Direct Ship": "SODS-DS" }
            this.reqTypeOptionsByValue = { 'SODS-SO': 'Special Order', "SODS-DS": "Direct Ship" }

            this.selectedReqType = this.defaultReqType;

            //Initialize customer market options
            this.marketOptions = ["1104", "2205"];
            this.marketStyle = true;
            this.selectedMarket = this.defaultMarket;
            this.sodsDropdown.selectedOption = this.selectedReqType;
            this.onReqTypeSelection(this.selectedReqType, true);
            
            //If create requisition is coming from copy on search details
            if(this.showReq) {
                this.attachmentComponent.requisitionId = this.copyReqId;
            }


        } catch (err) {

        }
    }

    getComments(reqNum) {
        let event = this.actionDispatcherService.generateEvent(
        ActionEvents.RETRIEVE_COMMENT_INBOX,
        reqNum
        );
        this.actionDispatcherService.dispatch(event);
    }

    renderRetrieveCommentsSuccess(commentsList: any) {
        this.reqComments = commentsList;
        this.commentsComponent.comments = commentsList;

        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    }

    closeMsgModal() {
        this.viewMsgsToModal.close();
    }

    renderSuccessUploads() {
        this.successfulUploads = true;
        this.errorsExist = false;
    }

    renderError(error: string) {
        this.errorsExist = true;
        this.errorMsg = error;
    }

    closeSuccessBar() {
        this.successfulUploads = false;
    }

    /*Generate Requisition ID */
    generateReqId() {
        try {
            let event = this.actionDispatcherService.generateEvent('generateRequisitionId', {});
            this.actionDispatcherService.dispatch(event);
        } catch (err) {

        }

    }

    renderReqIdGenerated(reqId: string) {

        if(this.inputReqId !== null && this.inputReqId !== undefined){
            this.reqId = this.inputReqId;
        }else{
            this.reqId = reqId;
        }
        localStorage.setItem('reqId', this.reqId);
        // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
    }

    get requestId() {
        return this.reqId
    }

    set requestId(requestId: string) {
        this.requestId = requestId;
    }

    //Retrieve Requestor Info
    retrieveRequestor() {
        try {
            //Requestor Id and name retrieved from user info
            const data = localStorage.getItem('user');
            this.requestor.name = JSON.parse(JSON.parse(data)._body).displayName;
            this.requestor.networkID = JSON.parse(JSON.parse(data)._body).userId;
            this.requestor.email = JSON.parse(JSON.parse(data)._body).email;
            this.requestor.phone = JSON.parse(JSON.parse(data)._body).phoneNumber;

            if (this.requestor.email === null || this.requestor.email === "") { this.requestor.email = '---'; }
            if (this.requestor.phone === null || this.requestor.phone === "") { this.requestor.phone = '---'; }
            this.requestor.retrieveSuccess = true;


        } catch (err) {

        }

    }

    openViewComments() {
        if (!this.commentsComponent.comments) {
            return;
        }
        this.makeProductCommentsMultiLine(this.commentsComponent.comments);
        this.viewMsgsToModal.open();
    }

    makeProductCommentsMultiLine(comments: Comment[]) {
        comments.forEach((comment: Comment, i) => {
            let text = '';
            if (comment.commentsText.indexOf('productNbr') >= 0) {
                let commentArray = comment.commentsText.split(']');
                text += commentArray[0] + ']\n';
                text += commentArray[1];
                this.commentsComponent.comments[i].commentsText = text;
            }
        });
    }

    makeProductCommentsOneLine(comments: Comment[]) {
        comments.forEach((comment: Comment, i) => {
        let text = '';
        if (comment.commentsText.indexOf('productNbr') >= 0) {
            let text = comment.commentsText.trim().replace(/\n/g, '');
            this.commentsComponent.comments[i].commentsText = text;
        }
        });
    }

    saveComment() {
        //validation first
        if (this.commentsComponent.commentErr === true) {
        return;
        }
        //if user does not hit add, just close it
        if (this.commentsComponent.newAddFlag === false) {
        this.viewMsgsToModal.close();
        } else {
        this.commentsComponent.newAddFlag = false;
        //save to comments array of requisition

        // will need to remove the empty text on the first element
            if (this.commentsComponent.comments[0].commentsText === '') {
                this.commentsComponent.comments.shift();
            }

            this.makeProductCommentsOneLine(this.commentsComponent.comments);
            // Dispatch an event to add a new requisition level comment.
            //this.comments = this.commentsComponent.comments;
        //     this.productCommentAdded[this.selectedIndex] = true;
        //     this.addComment.emit({'product': this.products[this.selectedIndex]});
        //   }
        // });
        // this.addComment({'comment': this.commentsComponent.comments[0]});
        this.viewMsgsToModal.close();
        }
    }


    renderTMFound(data: any) {

        this.tm.isTM = false;
        this.tm.name = data.responseBody.displayName;
        this.tm.email = data.responseBody.email;
        this.tm.phone = data.responseBody.phone;
        this.tm.networkID = data.searchId;

        //if tm name is null, we need to do another check on Tandem
        if (this.tm.name === null || this.tm.name === '') {
            let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_TM_FROM_TANDEMID, data.searchId);
            this.actionDispatcherService.dispatch(event);
        }
    }

    renderTMFound2(data: any) {
        this.tm.retrieveSuccess = true;
        this.tm.isTM = false;
        this.tm.name = data.displayName;
        this.tm.email = data.email;
        this.tm.phone = data.phone;
        if (this.tm.name === null || this.tm.name === undefined) {
            this.tm.retrieveSuccess = false;
        }
    }

    renderTandemTMIdFound(tandemTM: TandemTM) {
        if (tandemTM.tmnetworkID !== null && tandemTM.tmnetworkID !== undefined) {
            let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_TM_2, tandemTM.tmnetworkID);
            this.actionDispatcherService.dispatch(event);
        }

    }

    //Retrieve TM info End
    handleBlurOfReqId() {
        try {
            let event = this.actionDispatcherService.generateEvent('sodsRequestToLoadReq', { reqId: this.reqId });
            this.actionDispatcherService.dispatch(event);
        } catch (err) {

        }

    }

    renderReqFound(req: Requisition) {
        this.reqId = req.reqId;
        this.type = req.type;
        this.division = req.division;
        this.defaultSpecInstructions = req.defaultSpecInstructions;
        this.defaultCustomerPO = req.defaultCustomerPO;
        this.defaultShipMethod = req.defaultShipMethod;
        this.mainCustomerDept = req.mainCustomerDept;
        this.mainCustomerID = req.mainCustomerID;
        this.mainCustomerName = req.mainCustomerName;
        this.totalAmount = req.totalAmount;
    }

    renderReqNotFound() { }

    renderCustFound(cust: Customer) {
    }

    renderCustNotFound() { }

    get selectedMarketingType() {
        return this.customerComponent.selectedMarket;
    }

    get getMarketOptions() {
        return this.customerComponent.marketOptions;
    }

    getRequiredErrors(includeNumberValidation: any) {
        let errors = [];
        if (this.customerComponent.checkCustomerEntered()) {
            errors.push(this.customerComponent.checkCustomerEntered());
        }
        return errors;
    }

    getQuoteErrors() {
        let errors = [];
        if (this.customerComponent.getValidationRuleBasedOnQuote() && this.customerComponent.getValidationRuleBasedOnQuote() !== true) {
            errors.push(this.customerComponent.getValidationRuleBasedOnQuote());
        } else if (this.customerComponent.getValidationRuleBasedOnQuote() === true) {
            return true;
        }
        return errors;
    }

    closeModal() {


        if (this.selectedReqType === 'Special Order') {
            this.sodsDropdown.selectedOption = 'Direct Ship';
            this.onReqTypeSelection('Direct Ship', true);
        } else {
            this.sodsDropdown.selectedOption = 'Special Order';
            this.onReqTypeSelection('Special Order', true);
        }

        this.areUsureModal.close();
    }

    setDropdownValues(val: any) {
        this.sodsDropdown.selectedOption = val;
        this.onReqTypeSelection(val, true);

    }

    revertChanges() {
        this.sodsDropdown.selectedOption = this.selectedReqType;
        this.onReqTypeSelection(this.selectedReqType, true);
        this.areUsureModal.close();
    }

    onReqTypeSelection($event: any, fromCloseModal?: boolean) {
        // localStorage.setItem('requestType', null);
        if ($event !== this.selectedReqType && !fromCloseModal && this.taksId && (this.taskStatus || '').trim() !== 'Draft') {
            this.areUsureModal.open();
            return;
        }

        this.reqTypeChangeEvent.emit($event);

        this.selectedReqType = $event;
        this.customerComponent.selectedReqType = $event
        this.customerComponent.customerDetails.selectedReqType = $event

        if (this.selectedReqType === 'Direct Ship') {
            this.customerComponent.customerDetails.selectedShip = "Separate";
            this.customerComponent.customerDetails.changeShipmentMethod();
            this.customerComponent.customerDetails.selectVisable = false;
            this.customerComponent.customerDetails.shipElementsHidden = false;
        } else {
            this.customerComponent.customerDetails.selectVisable = true;
            this.customerComponent.customerDetails.shipElementsHidden = true;
            if (this.customerComponent.customerDetails.selectedShip === 'Next') {
                this.customerComponent.customerDetails.shipElementsHidden = true;
            } else {
                this.customerComponent.customerDetails.shipElementsHidden = false;
            }
        }
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, { reqType: this.selectedReqType });
        this.actionDispatcherService.dispatch(changeEvent);
    }

    openAuditLog() {
        if (!this.auditLogs.length) {
          return;
        }
        this.viewAuditModal.open();
    }

    closeAuditModal() {
        this.viewAuditModal.close();
    }
}