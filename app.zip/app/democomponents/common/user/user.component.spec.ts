import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserComponent } from './user.component';
import { FormsModule } from '@angular/forms';

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserComponent ],
      imports: [FormsModule]
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('check email', () => {
    component.addlEmail = 's@c.com';
    component.checkIfAddlEmailValid();
    expect(component.isEmailValid).toBeTruthy();
    component.addlEmail = 'sc.com';
    component.checkIfAddlEmailValid();
    expect(component.isEmailValid).toBeFalsy();
    
  });
  it('check phone', () => {
    component.addlPhone = '5121232345';
    component.checkIfAddlPhoneValid();
    expect(component.isPhoneValid).toBeTruthy();
    component.addlPhone = 'sc.com';
    component.checkIfAddlPhoneValid();
    expect(component.isPhoneValid).toBeFalsy();
  });

  it('validate email', () => {
    expect(component.validateEmail(null)).toBeTruthy();
    expect(component.validateEmail(undefined)).toBeTruthy();
    expect(component.validateEmail('')).toBeTruthy();
  });
  
  it('validate phone', () => {
    expect(component.validatePhone(null)).toBeTruthy();
    expect(component.validatePhone(undefined)).toBeTruthy();
    expect(component.validatePhone('')).toBeTruthy();
  });
});