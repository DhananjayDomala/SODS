export const ALERTS = {
    'success': {
        'rolesValidated': 'Validation Successful. All Roles are active.',
        'rolesSaved': 'Save Successful. All Roles are active.',
        'requisitionApproval': 'Requisition Approved Successfully.',
        'requisitionReturn': 'Requisition Returned Successfully.',
        'productsValidated': 'Products validated successfully',
        'poValidation': 'PO validation successfully'
    },
    'error': {
        'divisionDownloadFailed': 'An error occurrred downloading the divisions',
        'levelOneRequired': 'Level 1 is required.',
        'invalidNetworkId': 'Please enter a valid user.',
        'genericValidationError': 'Validation Unsuccessful. Please try again.',
        'renderMarketFail': 'An error occurred downloading the market roles',
        'duplicateNetworkId': '"Network ID" is already added',
        'reqDetailsNotFound': 'Could not get the requistion details',
        'missingReqId': 'Invalid request',
        'noRoleSelected': 'Please select a role',
        'productMarkedReturn': 'One or more products are checked to be returned to requestor.  Please uncheck the return product checkbox to approve the requisition.',
        'noCommentsAddedToProduct': 'Please enter a comment for each product you wish to return to the requestor.',
        'noProductMarkedReturn': 'Please select a product to return.',
        'requisitionApproval': 'Failed to complete task.',
        'requisitionReturn': 'Failed to complete task.',
        'acceptTaskFail': 'Failed to accept the task.',
        'releaseTaskFail': 'Failed to release the task.',
        'productsNotAttached':'One or more products are invalid, Please check the product number, the product status (national and division), or the quantity for master case products',
        'missingProductCost':'One or more products is missing Vendor List Cost in PRISM, Please set up the product cost in PRISM and re validate',
        'invalidProduct':'One or More Products are Invalid. Please enter a valid product number.',
        'missingProductNbr': 'One or More Products are missing product number. Please enter product number to be validated.',
        'poValidationErr': 'One or More PO are invalid',
        'normalProduct': 'Product is currently set to Normal status.',
        'outOfStock': 'Product is currently set to Active, but Out of Stock status.',
        'temporary': 'Product is currently set to Temporary status.',
        'seasonal': 'Product is currently set to Seasonal status.',
        'dwo': 'Product is currently set to DWO status.',
        'discontinued': 'Product is currently set to Discontinued status.',
        'missingReturnComment': 'Please enter a Reason for return in the comment box.',
        'poValidationBackendErr' : 'PO Creation Validation Fail due to Backend Connection Error'
    }

};
