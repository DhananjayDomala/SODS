import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ALERTS } from './alerts';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit, OnChanges{

  @Input() alertSettings: any[];
  @Input() showErrorBar: boolean = false;
  @Input() showSuccessBar: boolean = false;

  message: string;
  alert: any[];
  hideErrorBar: boolean = false;
  hideSuccessBar: boolean = false;

  constructor() {
  }

  ngOnInit() {
    this.alert = this.alertSettings;
    this.message = ALERTS[this.alert[0].alertType][this.alert[0].alertMessage];
  }

  ngDoCheck() {

  }

  ngOnChanges(changes: SimpleChanges): void {
    this.hideErrorBar = false;
    this.hideSuccessBar = false;
  }

  closeSuccessBar() {
    this.hideSuccessBar = true;
  }
  closeErrorBar() {
    this.hideErrorBar = true;
  }
}
