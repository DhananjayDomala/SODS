import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filenotfound',
  templateUrl: './filenotfound.component.html',
  styleUrls: ['./filenotfound.component.css']
})
export class FilenotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
