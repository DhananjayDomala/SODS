import { AlertSetting } from './../common/alert/alert.component';
import { Component, OnInit, ViewEncapsulation, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import { Http, Headers } from "@angular/http";
import { contentHeaders } from "../util/headers";
import { AuthenticationService } from "../../service/authentication.service";

import { Modal, ModalModule } from "ngx-modal";
import { User } from "../../model/user";

@Component({
  selector: "login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  public error: Boolean;
  myform: FormGroup;
  username: FormControl;
  password: FormControl;
  actionCompleted: boolean = true;
  loginError:boolean;
  message: string;
  @ViewChild("removeLocation") removeLocationModal: Modal;

  constructor(
    public router: Router,
    public http: Http,
    private authService: AuthenticationService,
    private user: User
  ) {}

  ngOnInit() {
    this.error = false;
    //this.removeLocationModal.open();
    this.username = new FormControl('', Validators.required);
    this.password = new FormControl('', Validators.required);
    let current = document.getElementById('username');
    current.focus();
 
    this.myform = new FormGroup({
      username: this.username,
      password: this.password
    });
  }

  login(event, username, password) {
    this.actionCompleted = false;
    this.loginError = false;
    this.authService.loginService(username, password).subscribe(response => {
      if (
        response.json().token !== null &&
        response.json().token !== undefined
      ) {
        let obj = { token: response.json().token };
        sessionStorage.setItem("token_obj", JSON.stringify(obj));
        sessionStorage.setItem("token", response.json().token);
        let expiration = new Date().getTime() + 30 * 60 * 1000;
        let record = { value: response.json().token, timestamp: expiration };
        localStorage.setItem("token", JSON.stringify(record));

        //Calls JWT parsing API for user info
        this.authService.fetchUser().subscribe(resp => {
          if (resp.json().userRoles.length === 0) {
            this.actionCompleted = true;
            this.error = true;
          } else {
            // Store User's Info
            console.log(JSON.parse(resp._body));
            const loginResponse = JSON.parse(resp._body) || '';
            const firstName = loginResponse.firstName || '';
            const lastName = loginResponse.lastName || '';
            const email = loginResponse.email || '';
            const networkId = loginResponse.userId || '';
            const applicationMarkets = loginResponse.applicationMarkets || '';
            let movedToR4 = loginResponse.movedToR4;
            this.user.setFirstName(firstName);
            this.user.setLastName(lastName);
            this.user.setEmail(email);
            this.user.setNetworkID(networkId);
            this.user.setRoles(loginResponse.userRoles);
            this.user.setMarkets(applicationMarkets);
            this.user.isLoggedIn = true;

            // Save user in local storage
            localStorage.setItem('username', username);
            localStorage.setItem('password', password);
            localStorage.setItem('user', JSON.stringify(resp));
            if(movedToR4) {
              this.router.navigateByUrl('/taskInbox');
            }else{
              //Show alert
              this.actionCompleted = true;
              this.error = true;
              this.loginError = true;
            }
            
          }
        });
      } else {
        this.actionCompleted = true;
        this.error = true;
      }
    },
    error =>{
      this.actionCompleted = true;
      this.error = true;
    });
  }

  cancel() {
    //logout
    sessionStorage.removeItem("token");
    localStorage.removeItem("token");
    this.user.clearRoles();
    this.router.navigateByUrl("/#");
  }
}
