import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../../events/action-events';
import { DivisionUser } from '../../model/divisionrole';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from '../common/dropdown-multiselect/multiselect-dropdown';
import { Approver, Message } from '../../model/approver';
import { Role, RolesForDisplay } from '../../model/role';
import { BREADCRUMBS } from '../common/breadcrumb/breadcrumbs';
import { ALERTS } from '../common/alert/alerts';
import { DivisionsService } from '../../service/divisions.service';

@Component({
    selector: 'app-market-role-manager',
    templateUrl: './marketrolemanager.component.html',
    styleUrls: ['./marketrolemanager.component.css']
})
export class MarketrolemanagerComponent extends BaseComponent implements OnInit, OnDestroy {
    // For Loading Indicator
    public loading = false;

    // For Breadcrumbs
    public breadcrumbs = BREADCRUMBS['market-role-manager'];

    // For Market Dropdown menu
    public markets: string[] = [];
    public selectedMarketNumber = '';
    public marketOptions = [];
    public selectedMarket = '';
    public validDivNum = false;

    // For Role Multiselect Dropdown Component
    public roles: string[];
    public roleOptions: IMultiSelectOption[] = [];
    // Default roleOptions array indexes selected
    public selectedRoleOptions: number[];

    // For Approvers by Role Component
    public rolesForDisplay: Array<Role> = new Array<Role>();
    public validated = false;
    public approversToAdd: Array<Approver> = new Array<Approver>();
    public approversToDelete: Array<Approver> = new Array<Approver>();

    // For Alert Text Bar
    public showAlert = false;
    public alertType = '';
    public alertMessage = '';
    public alertSettings = [{ 'alertType': '', 'alertMessage': '' }];

    constructor(
        readonly actionDispatcherService: ActionDispatcherService,
        readonly stateRepresentationRendererService: StateRepresentationRendererService,
        private divisionsService: DivisionsService
    ) {
        super(stateRepresentationRendererService);

        const mapping: any = [];

        //  For loading the divisions in the market dropdown menu
        mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (data: any) => {
            this.renderDivisionsForRoleSearch(data);
        };

        mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL] = (data: any) => {
            this.renderDivisionsForRoleSearchFail(data);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_SUCCESS] = (data: any) => {
            this.renderRolesForMarket(data);
        };

        mapping[ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_FAIL] = (data: any) => {
            this.renderRolesForMarketFail(data);
        };

        mapping[ModelChangeUpdateEvents.VALIDATE_APPROVERS_SUCCESS] = (data: any) => {
            this.renderValidationSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.VALIDATE_APPROVERS_FAIL] = (data: any) => {
            this.renderValidationFail(data);
        };

        mapping[ModelChangeUpdateEvents.ADD_APPROVER_SUCCESS] = (data: any) => {
            this.renderAddSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.ADD_APPROVER_FAIL] = (data: any) => {
            this.renderAddFail(data);
        };        

        mapping[ModelChangeUpdateEvents.ADD_LEVEL_TO_ROLE_SUCCESS] = (data: any) => {
            this.renderAddLevelSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.DELETE_APPROVER_SUCCESS] = (data: any) => {
            this.renderRemoveSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.DELETE_LEVEL_FROM_ROLE_SUCCESS] = (data: any) => {
            this.renderDeleteLevelSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.TRIM_EMPTY_LEVELS_SUCCESS] = (data: any) => {
            this.renderTrimEmptyLevelSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.NORMALIZE_LEVELS_SUCCESS_NO_SAVE] = (data: any) => {
            this.renderNormalizeLevelsSuccessNoSave(data);
        };

        mapping[ModelChangeUpdateEvents.NORMALIZE_LEVELS_SUCCESS] = (data: any) => {
            this.renderNormalizeLevelsSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_ADD_SUCCESS] = (data: any) => {
            this.renderSaveSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_ADD_FAIL] = (data: any) => {
            this.renderSaveFail(data);
        };
        
        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_DELETE_SUCCESS] = (data: any) => {
            this.renderSaveDeleteSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_DELETE_FAIL] = (data: any) => {
            //this.renderSaveFail(data);
        };

        super.registerStateChangeEvents(mapping);
    }

    ngOnInit() {
        this.initdata();
    }

    public initdata() {
        // Load Multiselect dropdown menu options
        this.roleOptions = Role.getRoleMenuOptions();
        this.selectedRoleOptions = Role.getDefaultSelectedRoleOptions();

        // Make an api call to get the divisions for the market dropdown menu
        const getDivisionsEvent = this.actionDispatcherService.generateEvent(ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH, { 'data': '' });
        this.actionDispatcherService.dispatch(getDivisionsEvent);
        this.alertSettings = [];
    }

    /* SEARCH BAR FUNCTIONS */
    roleSelect(event) {
        this.selectedRoleOptions = event;
    }

    public onChangeRoleSelection(roles): void {
        // Function is called when user checks an option
        // Input:  array of the selected option array indexes. ex) [0,1,2,3]

        // Set the selected roles array
        this.selectedRoleOptions = roles;

        /* Show/Hide Role based on the selected options
        // We are getting all roles back from the api call
        // no matter how many roles are selected from the dropdown
        // menu */

        // this.rolesForDisplay.forEach((role, index) => {
        //     role.isSelected = this.selectedRoleOptions.includes(index) ? true : false;
        // });
    }

    search(event) {
        this.rolesForDisplay = [];
        this.selectedMarketNumber = event.market;
        this.selectedRoleOptions = event.selectedRoles;
        this.approversToDelete = new Array<Approver>();
        this.approversToAdd = new Array<Approver>();
        if (this.selectedRoleOptions.length > 0) {
            this.getRolesForMarket();
        } else {
            this.showAlertMessage('error', 'noRoleSelected');
        }
    }

    isValidDivNum(valid) {
        if (!valid) {
            this.rolesForDisplay = [];
            this.approversToAdd = [];
            this.approversToDelete = [];
        }
    }

    renderDivisionsForRoleSearch(divResponse) {
        this.markets = divResponse;
        this.divisionsService.setDivisions(divResponse);
        this.markets.forEach((market) => {
            const option = market['divisionName'] + '/' + market['divisionCode'];
            this.marketOptions.push(option);
        });

        this.selectedMarketNumber = this.markets[0]['divisionNumber'];
        this.selectedMarket = this.markets[0]['divisionName'] + '/' + this.markets[0]['divisionCode'];
    }

    renderDivisionsForRoleSearchFail(response) {
        this.rolesForDisplay = [];
        this.alertSettings = [];
        this.showAlertMessage('error', 'divisionDownloadFailed');
    }
    /* END OF SEARCH BAR FUNCTIONS */

    /* START OF INITIAL ROLES FUNCTIONS */
    public getRolesForMarket() {

        this.loading = true;
        this.alertMessage = '';
        this.showAlert = false;
        this.rolesForDisplay = [];

        // Dispatch an event to get the default roles
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.GET_APPROVERS_FOR_MARKET,
            { 'divisionNumber': this.selectedMarketNumber }
        );
        this.actionDispatcherService.dispatch(event);
    }

    renderRolesForMarket(response) {
        this.rolesForDisplay = [];
        if (response.approvers) {
            this.showAlert = false;
            const roles = new RolesForDisplay();
            this.rolesForDisplay = [];
            // Instantiate new roles for display array
            this.rolesForDisplay = roles.getRoles();
            // Group approver response by Role
            let formattedData = RolesForDisplay.groupBy(response.approvers, 'roleId');
            // Format the Data for Display
            formattedData = RolesForDisplay.formatDataForDisplay(formattedData);

            // Replace rolesForDisplay with actual approver values if they exist
            const matches = formattedData.filter((o1) => {
                return this.rolesForDisplay.some((o2) => {
                    return o1['roleId'] === o2['roleId'];
                });
            });

            matches.forEach((row) => {
                const index = this.rolesForDisplay.findIndex(x => x.roleId === row.roleId);
                this.rolesForDisplay[index] = row;
            });

            this.rolesForDisplay.forEach((role, i) => {
                role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
            });

            // Mark the invalid Approvers
            this.markInvalidApprovers(this.rolesForDisplay);
            this.loading = false;
        }
    }

    renderRolesForMarketFail(response) {
        this.loading = false;
        this.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.rolesForDisplay = roles.getRoles();
        this.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });
        this.showAlertMessage('error', 'renderMarketFail');
    }

    /* START OF ADD APPROVER FUNCTIONS */
    add(data) {
        this.markInvalidApprovers(this.rolesForDisplay);
        // Dispatch event to add a new approver
        const addApproverEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.ADD_APPROVER, {
                'rolesForDisplay': this.rolesForDisplay,
                'approverToAdd': data.approver,
                'roleIndex': data.roleIndex
            });
        this.actionDispatcherService.dispatch(addApproverEvent);
    }

    renderAddSuccess(response) {
        this.rolesForDisplay = response.rolesForDisplay;
        let approver = response.approver;
        approver.action = 'Add';
        approver.roleID = approver.roleId;
        approver.flag = true;
        //this.approversToAdd.push(response.approver);
        this.approversToAdd.push(approver);
    }

    renderAddFail(response) {
        this.rolesForDisplay = response.rolesForDisplay;
    }

    addLevel(data) {
        // Dispatch event to add a new level to role
        const roleIndex = data.roleIndex;
        const addLevelEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.ADD_LEVEL_TO_ROLE, {
                'rolesForDisplay': this.rolesForDisplay,
                'roleIndex': roleIndex
            });
        this.actionDispatcherService.dispatch(addLevelEvent);
    }

    renderAddLevelSuccess(data) {
        this.rolesForDisplay = data.rolesForDisplay;
    }

    /* START OF DELETE APPROVER FUNCTIONS */
    delete(data) {
        // Dispatch event to delete approver
        const deleteApproverEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.DELETE_APPROVER, {
                'roleIndex': data.roleIndex,
                'levelIndex': data.levelIndex,
                'approverIndex': data.approverIndex,
                'rolesForDisplay': this.rolesForDisplay
            });
        this.actionDispatcherService.dispatch(deleteApproverEvent);
    }

    deleteLevel(data) {
        // Dispatch event to delete a level from a role
        const roleIndex = data.roleIndex;
        const levelIndex = data.levelIndex;
        const deleteLevelEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.DELETE_LEVEL_FROM_ROLE, {
                'rolesForDisplay': this.rolesForDisplay,
                'roleIndex': roleIndex,
                'levelIndex': levelIndex
            });
        this.actionDispatcherService.dispatch(deleteLevelEvent);
    }

    renderRemoveSuccess(data) {
        const approverToDelete: Approver = data.approver;
        if (!approverToDelete.action) {
            approverToDelete.action = 'Remove';
            approverToDelete.roleID = approverToDelete.roleId;
            this.approversToDelete.push(approverToDelete);
        }
        let idx = Approver.findIndexInArray(this.approversToAdd, 'roleId', approverToDelete.roleID, 'level', approverToDelete.level, 'userId', approverToDelete.userId);
        if (idx >= 0) {
            this.approversToAdd.splice(idx, 1);
        }

        this.rolesForDisplay = data.rolesForDisplay;
        this.markInvalidApprovers(this.rolesForDisplay);
    }

    renderDeleteLevelSuccess(data) {
        this.rolesForDisplay = data.rolesForDisplay;

        const addApprovers = data.approversToAdd;
        const removeApprovers = data.approversToDelete;

        addApprovers.forEach((approver) => {
            this.approversToAdd.push(approver);
        });

        removeApprovers.forEach((approver) => {
            this.approversToDelete.push(approver);
            let idx = Approver.findIndexInArray(this.approversToAdd, 'roleId', approver.roleID, 'level', approver.level, 'userId', approver.userId);
            if (idx >= 0) {
                if (this.approversToAdd[idx].flag !== true) {
                    this.approversToAdd.splice(idx, 1);
                }

            }
        });

        this.markInvalidApprovers(this.rolesForDisplay);

        // dispatch to normalize levels
        this.normalizeLevels(this.rolesForDisplay, false);
    }

    /* START OF VALIDATION FUNCTIONS */
    markInvalidApprovers(rolesForDisplay): boolean {
        this.rolesForDisplay = rolesForDisplay;
        this.showAlert = false;
        this.rolesForDisplay.forEach((role, i) => {
            this.rolesForDisplay[i].invalidLevels = [];
            role.levels.forEach((level, j) => {
                level.forEach((approver, k) => {
                    // log the indexes of approvers that are invalid so that the validations css will appear in UI.
                    if (approver.messages.length > 0) {
                        if (approver.messages[0].type !== '' && approver.action !== 'Remove') {
                            this.validated = false;
                            this.rolesForDisplay[i].invalidLevels.push(j);
                            const idx = Approver.findIndexInArray(this.approversToAdd, 'roleId', approver.roleId, 'level', approver.level, 'userId', approver.userId);
                            this.approversToAdd.splice(idx, 1);
                        }
                    }
                });
                if (this.rolesForDisplay[i].isSelected && this.rolesForDisplay[i].invalidLevels.length > 0) {
                    this.showAlertMessage('error', 'invalidNetworkId');
                }
            });
        });
        return !this.showAlert;
    }

    validateApprovers(data) {
        this.showAlert = false;
        this.loading = true;
        const isSave = data.isSave;

        // Format request
        const requestBody = {
            'approvers': [
                {
                    'status': 'string',
                    'statusDesc': 'string',
                    'allOOO': 'string',
                    'approver': this.approversToAdd
                }
            ]
        };

        // Dispatch an event to validate the approvers
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.VALIDATE_APPROVERS,
            { 'body': requestBody, 'isSave': isSave, 'rolesForDisplay': this.rolesForDisplay }
        );
        this.actionDispatcherService.dispatch(event);
    }

    trimEmptyLevels(approvers: Approver[]) {
        const trimEmptyLevelsEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.TRIM_EMPTY_LEVELS, {
                'rolesForDisplay': this.rolesForDisplay,
                'approvers': approvers,
                'selectedRoleOptions': this.selectedRoleOptions
            });
        this.actionDispatcherService.dispatch(trimEmptyLevelsEvent);
    }

    trimEmptyLevelsSuccess(response) {
        this.rolesForDisplay = response.rolesForDisplay;
    }

    renderValidationSuccess(response) {
        const isSave = response.isSave;
        this.rolesForDisplay = response.rolesForDisplay;

        // mark invalid levels
        const isValid = this.markInvalidApprovers(this.rolesForDisplay);

        // Save Data if valid and Save button is clicked
        if (isValid) {
            // set all approversToAdd as valid
            this.approversToAdd.forEach((approver) => {
                approver.valid = 'true';
            });

            if (isSave) {
                this.saveApprovers(this.rolesForDisplay);
            } else {
                this.showAlertMessage('success', 'rolesValidated');
            }
        } else {
            this.showAlertMessage('error', 'invalidNetworkId');
        }
    }

    renderValidationFail(response) {
        this.loading = false;
        this.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.rolesForDisplay = roles.getRoles();
        this.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });
        this.showAlertMessage('error', 'genericValidationError');
    }

    renderTrimEmptyLevelSuccess(data) {
        this.rolesForDisplay = data.rolesForDisplay;
        // normalize approvers
        this.normalizeLevels(this.rolesForDisplay, true);
    }

    normalizeLevels(rolesForDisplay, isSave) {
        this.rolesForDisplay = rolesForDisplay;
        const normalizeLevelsEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.NORMALIZE_LEVELS, {
                'rolesForDisplay': this.rolesForDisplay,
                'isSave': isSave
            });
        this.actionDispatcherService.dispatch(normalizeLevelsEvent);
    }

    renderNormalizeLevelsSuccess(data) {
        this.rolesForDisplay = data.rolesForDisplay;
        // Validate Approvers
        this.validateApprovers({ 'rolesForDisplay': this.rolesForDisplay, 'isSave': true });
    }

    renderNormalizeLevelsSuccessNoSave(data) {
        this.rolesForDisplay = data.rolesForDisplay;
    }

    /* START OF SAVE FUNCTIONS */
    saveApprovers(rolesForDisplay) {
        this.rolesForDisplay = rolesForDisplay;
        const approversToSave = new Array<Approver>();
        this.approversToDelete.forEach((approver) => {
            approversToSave.push(approver);
        });
        // this.approversToAdd.forEach((approver) => {
        //     approversToSave.push(approver);
        // });

        if (approversToSave.length > 0) {
            const requestBody = {
                'approvers': {
                    'role': approversToSave
                }
            };
            // Dispatch an event to save the approvers
            const saveEvent = this.actionDispatcherService.generateEvent(
                ActionEvents.SAVE_APPROVERS_DELETE, { 'body': requestBody, 'rolesForDisplay': this.rolesForDisplay });
            this.actionDispatcherService.dispatch(saveEvent);
        } else {
                this.rolesForDisplay = rolesForDisplay;
                const approversToSave = new Array<Approver>();
                // this.approversToDelete.forEach((approver) => {
                //     approversToSave.push(approver);
                // });
                this.approversToAdd.forEach((approver) => {
                    approversToSave.push(approver);
                });
        
                if (approversToSave.length > 0) {
                    const requestBody = {
                        'approvers': {
                            'role': approversToSave
                        }
                    };
                    
                    // Dispatch an event to save the approvers
                    const saveEvent = this.actionDispatcherService.generateEvent(
                        ActionEvents.SAVE_APPROVERS_ADD, { 'body': requestBody, 'rolesForDisplay': this.rolesForDisplay });
                    this.actionDispatcherService.dispatch(saveEvent);
                //this.showAlertMessage('success', 'rolesSaved');
            }
        }

    }

    save(data: any): void {
        if (this.approversToAdd.length > 0 || this.approversToDelete.length > 0) {
            let approvers = RolesForDisplay.extractApprovers(this.rolesForDisplay);
            // trim any empty levels
            this.trimEmptyLevels(approvers);
        }
    }

    renderSaveSuccess(data: any): void {
        this.rolesForDisplay = data.rolesForDisplay;
        this.showAlertMessage('success', 'rolesSaved');
        this.approversToDelete = new Array<Approver>();
        this.approversToAdd = new Array<Approver>();
    }

    renderSaveFail(data: any) {
        this.loading = false;
        this.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.rolesForDisplay = roles.getRoles();
        this.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });
        this.showAlertMessage('error', 'invalidNetworkId');
    }

    /* START OF UTILITY FUNCTIONS */
    expandAll() {
        this.rolesForDisplay.forEach((role) => {
            role.isCollapsed = false;
        });
    }

    collapseAll() {
        this.rolesForDisplay.forEach((role) => {
            role.isCollapsed = true;
        });
    }

    toggleCollapse(rowId) {
    }

    handleAlert(alertSettings: any) {
        // this.showAlert = false;
        this.alertSettings = alertSettings;
        this.showAlert = true;
        this.goTo('top');
    }

    showAlertMessage(alertType: string, alertText: string) {
        this.alertSettings = [];
        this.alertMessage = ALERTS[alertType][alertText];
        const alert = { 'alertType': alertType, 'alertMessage': this.alertMessage };
        this.alertSettings.push(alert);
        this.showAlert = true;
        this.loading = false;
        this.goTo('top');
    }

    cancel(rolesForDisplay: any) {
        this.rolesForDisplay = [];
        this.showAlert = false;
        this.loading = false;
        this.goTo('top');
    }

    ngOnDestroy() {
        super.ngOnDestroy();
    }

    renderSaveDeleteSuccess(data: any){
        this.rolesForDisplay = data.rolesForDisplay;
        const approversToSave = new Array<Approver>();

        this.approversToAdd.forEach((approver) => {
            approversToSave.push(approver);
        });

        if (approversToSave.length > 0) {
            const requestBody = {
                'approvers': {
                    'role': approversToSave
                }
            };
            // Dispatch an event to save the approvers
            const saveEvent = this.actionDispatcherService.generateEvent(
                ActionEvents.SAVE_APPROVERS_ADD, { 'body': requestBody, 'rolesForDisplay': this.rolesForDisplay });
            this.actionDispatcherService.dispatch(saveEvent);
        } else {
            this.showAlertMessage('success', 'rolesSaved');
        }
    }

    goTo(location: string): void {
        window.location.hash = '';
        window.location.hash = location;
    }
}
