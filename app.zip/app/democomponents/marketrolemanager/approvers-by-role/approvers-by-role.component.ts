import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { Role } from '../../../model/role';
import { Approver } from '../../../model/approver';
import { Modal } from 'ngx-modal';
import { ALERTS } from '../../common/alert/alerts';

@Component({
  selector: 'app-approvers-by-role',
  templateUrl: './approvers-by-role.component.html',
  styleUrls: ['./approvers-by-role.component.css']
})
export class ApproversByRoleComponent implements OnInit {
  // Input
  @Input() rolesForDisplay: Array<Role>;
  @Input() selectedMarketNumber: string;
  @Input() error: string;
  @Input() validated: boolean;

  // Outputs
  @Output('alert')
  alert: EventEmitter<any> = new EventEmitter<any>();
  
  @Output('delete')
  delete: EventEmitter<any> = new EventEmitter<any>();
  
  @Output('add')
  add: EventEmitter<any> = new EventEmitter<any>();
  
  @Output('addLevel')
  addLevel: EventEmitter<any> = new EventEmitter<any>();
  
  @Output('deleteLevel')
  deleteLevel: EventEmitter<any> = new EventEmitter<any>();
  
  @Output('validate')
  validate: EventEmitter<any> = new EventEmitter<any>();
  
  @Output('save')
  save: EventEmitter<any> = new EventEmitter<any>();

  @Output('cancel')
  cancel: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('confirmDelete') confirmDeleteLevelModal: Modal;

  deletedRoleId: number;
  deletedLevelId: number;
  deletedRoleName: string;
  deletedLevel: any;
  errorString: string;
  roles: Array<Role>;
  isValidated: boolean;

  constructor() {
  }

  ngOnInit() {
    this.errorString = this.error;
    this.roles = this.rolesForDisplay;
    this.isValidated = this.validated;
  }

  addLevelToRole(roleIndex) {
    // Adds an additional approver level to the selected role
    // Max # of levels is 5
    if (this.rolesForDisplay[roleIndex].levels.length < 5) {
      // this.rolesForDisplay[roleId].levels.push([]);
      this.addLevel.emit({'roleIndex': roleIndex});
    }
  }

  deleteApproverLevel(roleIndex, levelIndex) {

    if (this.rolesForDisplay[roleIndex].levels.length > 1 || this.rolesForDisplay[roleIndex].roleId === 'NIA') {

      this.deleteLevel.emit({'roleIndex': roleIndex, 'levelIndex': levelIndex});
    } else {
      this.rolesForDisplay[roleIndex].invalidLevels.push(levelIndex);
      this.alert.emit([{ 'alertType': 'error', 'alertMessage': ALERTS.error.levelOneRequired }]);
      //this.handleError(roleId, levelId);
    }
  }

  handleError(roleId, levelId) {
    // this will close the alert message and un-hightlight txt field after 4 seconds.
    setTimeout(() => {
      this.rolesForDisplay[roleId].invalidLevels = [];
    }, 4000);
  }

  isError(roleId, levelId, level) {
    return this.rolesForDisplay[roleId].invalidLevels.indexOf(levelId) >= 0;
  }

  addApprover(networkID, roleIndex, levelIndex, event) {
    const userId = networkID.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    if (event.keyCode === '32' || event.keyCode === '13') {
      if (userId.length >= 3) {
        const approver = new Approver();
        approver.division = this.selectedMarketNumber.toString();
        approver.userId = userId.toUpperCase().trim();
        approver.level = (levelIndex + 1).toString();
        approver.roleId = this.rolesForDisplay[roleIndex].roleId;
        approver.roleName = this.rolesForDisplay[roleIndex].roleName;
        approver.action = 'Add';
        event.target.value = '';
        this.add.emit({ 'approver': approver, 'roleIndex': roleIndex });
      }
    }

  }

  deleteApprover(roleIndex, levelIndex, approverIndex) {
    this.delete.emit({ 'roleIndex': roleIndex, 'levelIndex': levelIndex, 'approverIndex': approverIndex});
  }

  isInvalidUser(roleId, levelId, userId) {
    // check to see if the approver object is flagged with a message
    // message indicates either invalid network id, or a user that 
    // does not have access to SODS.
    const user = this.rolesForDisplay[roleId].levels[levelId][userId];
    const messages = user.messages || [];
    if (messages.length > 0) {
      return messages[0].type !== '';
    }
    return false;
  }

  expandAll() {
    // expands all of the roles sections
    this.rolesForDisplay.forEach((role) => {
      role.isCollapsed = false;
    });
  }

  collapseAll() {
    // collapses all of the roles sections
    this.rolesForDisplay.forEach((role) => {
      role.isCollapsed = true;
    });
  }

  toggleCollapse(rowId) {
  }

  openDeleteModal(roleId, roleName, levelId, level) {
    // Check to see if there are existing users in the level
    // If so, open the confirm delete modal
    this.deletedLevelId = levelId;
    this.deletedRoleId = roleId;

    if (level.length > 0) {
      this.confirmDeleteLevelModal.open();
    } else {
      // If no users exist in the level, delete it without opening the confirm modal
      this.deleteApproverLevel(roleId, levelId);
    }
  }

  onDeleteLevel() {
    // Confirm button was clicked from modal
    // so, close the modal
    this.confirmDeleteLevelModal.close();
    // Call function to delete the level
    // this.deleteLevel(this.deletedRoleId, this.deletedRoleName, this.deletedLevelId);
    this.deleteApproverLevel(this.deletedRoleId, this.deletedLevelId);
  }

  closeDeleteModal() {
    // close button or x icon was clicked in the confirm delete modal
    this.confirmDeleteLevelModal.close();
  }

  saveApprovers() {
    this.save.emit({ 'rolesForDisplay': this.rolesForDisplay });
  }

  validateApprovers() {
    this.validate.emit({ 'rolesForDisplay': this.rolesForDisplay, 'save': false });
  }

  export() {

  }

  cancelBtnClick() {
    this.cancel.emit({ 'rolesForDisplay': this.rolesForDisplay});
  }

  // Start of Utility Functions
  filterArray(array, property, value) {
    return array.filter((obj) => {
      return obj[property] !== value;
    });
  }

  checkAndAdd(arr, key, objToAdd) {
    const found = arr.some(function (el) {
      return el[key] === objToAdd[key];
    });
    if (!found) {
      arr.push(objToAdd);
    }
  }

}
