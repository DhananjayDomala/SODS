import { RouterModule } from '@angular/router';
import { SODSNewSoComponent } from './sodsnewso.component';
import { AuthGuard } from '../util/auth.guard';

export const sodsNewSoRoutes=[
    // { path: '', component: SODSNewSoComponent, canActivate: [AuthGuard] }
    { path: '', component: SODSNewSoComponent },
    { path: 'approver', component: SODSNewSoComponent}
];

export const routing = RouterModule.forChild(sodsNewSoRoutes);