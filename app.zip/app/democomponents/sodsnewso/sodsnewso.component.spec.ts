import { MockSamService } from './../../service/mocksam.service';
import { NO_ERRORS_SCHEMA } from '@angular/core/src/metadata/ng_module';
import { ModelChangeUpdateEvents } from 'app/events/action-events';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { RoleManDropdownComponent } from './../common/dropdown/roleManager-dropdown/dropdown.component';
import { SearchTextfieldComponent } from './../common/search-textfield/search-textfield.component';
import { USFDropdownComponent } from 'app/democomponents/common/dropdown/usf-dropdown/dropdown.component';
import { MarketDropdownComponent } from './../common/dropdown/market-dropdown/market-dropdown.component';
import { EditCustomerComponent } from './../common/customer/edit-customer.component';
import { CalendarComponent } from 'app/democomponents/common/calendar/calendar.component';
import { PhoneNumberPipe } from './../util/phoneNumberPipe';
import { EditShipToLocationComponent } from './../common/shipToLocation/edit-shipToLocation.component';
import { AddShipToLocationComponent } from './../common/shipToLocation/add-shipToLocation.component';
import { EditExistingProductComponent } from './../common/product/edit-existing-product.component';
import { EditNewProductComponent } from './../common/product/edit-new-product.component';
import { ProductAttachmentComponent } from './../common/product/product-attachment.component';
import { AddExistingProductComponent } from './../common/product/add-existing-product.component';
import { AddNewProductComponent } from './../common/product/add-new-product.component';
import { ShipToDropdownComponent } from './../common/dropdown/shipTo-dropdown/ship-to-dropdown.component';
import { EditFileComponent } from './../common/attachment/edit-file.component';
import { AttachfileComponent } from './../common/attachment/attachfile.component';
import { CustomerComponent } from './../common/customer/customer.component';
import { ProductCommentComponent } from 'app/democomponents/common/comment/product-comment/product-comment.component';
import { UserComponent } from './../common/user/user.component';
import { DropdownComponent } from 'app/democomponents/common/dropdown/dropdown.component';
import { Collapse } from './../../directive/collapse.component';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './../common/footer/footer.component';
import { AlertComponent } from './../common/alert/alert.component';
import { Modal, ModalContent, ModalHeader, ModalFooter } from 'ngx-modal';
import { ShowForUserRoleDirective } from './../../directive/showForUserRole.directive';
import { CustomerDetailsComponent } from './../common/customer/customer-details.component';
import { AttachmentComponent } from './../common/attachment/attachment.component';
import { ShipToLocationComponent } from './../common/shipToLocation/shipToLocation.component';
import { ProductComponent } from './../common/product/product.component';
import { CreateRequisitionComponent } from './../common/createRequisition/createRequisition.component';
import { BreadcrumbComponent } from './../common/breadcrumb/breadcrumb.component';
import { MockComponent } from 'app/model/mock';
import { HeaderComponent } from './../header/header.component';
import { SamService } from 'app/service/sam.service';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { SODSNewSoComponent } from './sodsnewso.component';
import { ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';
import { FormsModule } from '@angular/forms';
import { OverrideShipToComponent } from 'app/democomponents/common/customer/override-ship-to/override-ship-to.component';
import { dateFormatPipe } from 'app/democomponents/util/dateFormatPipe';
import { SharedModule } from 'app/shared/shared.module';
import { User } from 'app/model/user';
import { Component, OnInit, OnChanges, ViewChild, ViewEncapsulation, AfterViewInit, AfterContentChecked, SimpleChanges } from "@angular/core";
import { DOMTestComponentRenderer } from '@angular/platform-browser-dynamic/testing/src/dom_test_component_renderer';

describe('Sodsnewso1Component', () => {
  let component: SODSNewSoComponent;
  let header: HeaderComponent;
  let fixture: ComponentFixture<SODSNewSoComponent>;

  let actionDispatcher: ActionDispatcherService;
  let state: StateRepresentationRendererService;
  let route: ActivatedRoute;
  let router: Router;
  let user: User;

  const reqId = {
    requestId: "1234"
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        SODSNewSoComponent
      ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SamService,
        User,
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              queryParams: 
              {
                'taskId': '1234'
              }
            }
          }
        }
      ],
      imports: [
        RouterModule,
        FormsModule,
        SharedModule,
        RouterTestingModule
      ]
    })
    .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SODSNewSoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.errorsQueue = [];

  });
  

  const mockFun = {
    dataObject: () => {
      let json = {
        "draftTaskId": "31828",
        "overideSavedByID": "",
        "overideSavedByName": "",
        "requisition": {
          "requisitionNumber": "31828",
          "requisitionType": "SODS-SO",
          "division": "1104",
          "status": "new",
          "createdAt": "2018-01-8 14:18:56",
          "updatedAt": "2018-01-8 14:18:56",
          "totalAmount": 100,
          "ETASelection": false,
          "ETADate": "2018-01-8 14:18:42",
          "returnIfETANotMet": false,
          "defaultShipMethod": "Next",
          "mainCustomerID": 60528643,
          "mainCustomerName": "DBL TREE CLEVE DT/LAKESD*",
          "mainCustomerDept": "10-FOOD",
          "mainCustomerType": "NA",
          "attachmentsCount": false
        },
        "requestor": {
          "name": "sodsus01, SharedAcct",
          "networkID": "sodsus01",
          "email": "SODSUser.Shared@usfoods.com",
          "additionalPhone": "",
          "additionalEmail": ""
        },
        "territoryManager": {
          "name": "sodsus02, SharedAcct",
          "networkID": "QFS6026",
          "email": "SODSUser.Shared@usfoods.com"
        },
        "customers": [
          {
            "seq": 1,
            "id": 60528643,
            "dept": "10-FOOD",
            "defaultShipMethod": "Next",
            "name": "DBL TREE CLEVE DT/LAKESD*",
            "address1": "1111 LAKESIDE AVENUE",
            "address2": "",
            "city": "CLEVELAND",
            "state": "OH",
            "zip": "441140000",
            "phone": "2162415100",
            "useOverrideShipto": false,
            "estimatedOrderAmt": "321.12",
            "confidenceCode": "09",
            "creditCheckStatus": "true"
          }
        ],
        "products": [
          {
            "isCollapse": true,
            "copyError": false,
            "vendor": null,
            "prodType": "Grocery",
            "new": true,
            "comments": [],
            "attachments": [],
            "seq": 1,
            "attachmentKey": 1,
            "description": "Eggs",
            "mfrId": "1234",
            "qty": "3",
            "attachCount": 0,
            "shipTodistribution": [
              {
                "departmentId": "10-FOOD",
                "customer": {
                  "id": 60528643,
                  "name": "DBL TREE CLEVE DT/LAKESD*",
                  "address1": "1111 LAKESIDE AVENUE",
                  "address2": "",
                  "zip": "441140000",
                  "city": "CLEVELAND",
                  "state": "OH",
                  "dept": "10-FOOD"
                },
                "shipMethod": "Next",
                "qty": "3",
                "disableInput": true,
                "customerId": 60528643
              }
            ],
            "requested": {
              "description": "Eggs",
              "vendor": "Amber",
              "mfrId": "1234",
              "type": "Grocery"
            },
            "type": "Grocery",
            "manufacturerId": "1234",
            "meetsETA": true
          }
        ],
        "auditLogs": [],
        "tasks": []
      }
    },
    requestId: () => {
      return "1234";
    },
    returnFakeData: () => {
      return "Success";
    }
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /* Test Cases for checkErrorQueue */
  it('should check error queue if no errors exist', () => { 
    component.reqId = "1234";
    component.errorsQueue.length = 0;
    spyOn(component, 'setSubmitBody').and.callFake(mockFun.dataObject);
    spyOn(component, 'callSamService').and.callFake(mockFun.returnFakeData);
    component.checkErrorQueueOnSubmit();
    expect(component.setSubmitBody).toHaveBeenCalled();
    expect(component.callSamService).toHaveBeenCalled();
  });

  it('should check error queue and scroll up if errors exist', () => {
    component.errorsQueue.length = 1;
    spyOn(component, 'scrollWindowUp').and.returnValue('0');
    component.checkErrorQueueOnSubmit();
    expect(component.scrollWindowUp).toHaveBeenCalled();
  });

});