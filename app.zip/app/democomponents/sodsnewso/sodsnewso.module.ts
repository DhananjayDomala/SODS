import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from  '../../shared/shared.module';
import { RouterModule } from '@angular/router';
import { SODSNewSoComponent } from '../sodsnewso/sodsnewso.component';

import { routing } from './sodsnewso.routes';
import { ModalModule } from 'ngx-modal';
import { SamService } from 'app/service/sam.service';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ModalModule,
    routing
  ],
  declarations: [
    SODSNewSoComponent
  ],
  providers : [
    SamService
  ] 
})
export class SodsnewsoModule { }
