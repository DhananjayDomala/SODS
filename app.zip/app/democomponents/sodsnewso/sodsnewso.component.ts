import { CustomerDetailsComponent } from './../common/customer/customer-details.component';
import * as Debugger from '_debugger';
import { ShipTodistribution } from './../../model/submitRequisition';
import * as console from 'console';
import { Product } from './../../model/product';
import { ProductComponent } from './../common/product/product.component';
import { Component, OnInit, OnChanges, ViewChild, ViewEncapsulation, AfterViewInit, AfterContentChecked, SimpleChanges } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { Requisition } from '../../model/requisition';
import { Customer } from '../../model/customer';
import { CustomerComponent } from '../common/customer/customer.component';
import { UserComponent } from '../common/user/user.component';
import { Modal, ModalModule } from 'ngx-modal';
import { CreateRequisitionComponent } from '../common/createRequisition/createRequisition.component';
import { ShipToLocationComponent } from '../common/shipToLocation/shipToLocation.component'
import { AttachmentComponent } from '../common/attachment/attachment.component';
import { Router, ActivatedRoute, ParamMap, Params } from '@angular/router';
import { BREADCRUMBS } from 'app/democomponents/common/breadcrumb/breadcrumbs';
import { SubmitResponseMapper } from '../../democomponents/util/submitRequest-mapper';
import { VALUEMAP } from "app/democomponents/common/options/options";
import { ShipToDistribution } from "app/model/shipToDistribution";

@Component({
    selector: 'so-new',
    templateUrl: './sodsnewso.component.html',
    styleUrls: ['./sodsnewso.component.css'],
})

export class SODSNewSoComponent extends BaseComponent implements OnInit, OnChanges, AfterViewInit, AfterContentChecked {
    @ViewChild('createRequisition') createRequisitionComponent: CreateRequisitionComponent
    @ViewChild('requisitionAttachments') attachmentComponent: AttachmentComponent;
    @ViewChild('sodsProduct') productComponent: ProductComponent;
    @ViewChild('shipToLocation') shipToLocation: ShipToLocationComponent;
    @ViewChild('warningError') warningErrorModal: Modal;
    @ViewChild('cancelPopup') cancelModal: Modal;
    @ViewChild('deleteReq') deleteReqModal: Modal;
    @ViewChild('customerDetails') customerDetailsComponent: CustomerDetailsComponent;

    public elements: any[];
    reqId: string;
    shipCount: any = 0;
    closeErrorPopup: any = false;
    selectedReqType: any;
    errorsQueue: any[];
    successPost: boolean = false;
    successDraft: boolean = false;
    successDelete: boolean = false;
    taskId: any;
    taskName: any;
    comments: any;
    searchReqId: string;
    // For Breadcrumbs
    public breadcrumbs = BREADCRUMBS['create-requisition'];
    public custFound: boolean = true;
    setOverrideShipToFlag: boolean = false;
    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService,
        private route: ActivatedRoute,
        private router: Router,
    ) {
        super(stateRepresentationRendererService);
    }

    ngOnInit() {
        this.errorsQueue = [];
        this.elements = [
            {
                title: 'Requisition # :',
                isCollapsedReq: false
            },
            {
                title: 'Attachments',
                isCollapsedReq: true
            },
            {
                title: 'Ship To Locations',
                isCollapsedReq: true
            },
            {
                title: 'Product Information',
                isCollapsedReq: true
            }
        ];

        let mapping: any = [];
        mapping[ModelChangeUpdateEvents.POST_REQUISITION_SUCCESS] = (data: any) => { this.onPostSuccess(data); }
        mapping[ModelChangeUpdateEvents.POST_REQUISITION_FAIL] = (error: any) => { this.onPostFail(error); }
        mapping[ModelChangeUpdateEvents.DRAFT_REQUISITION_SUCCESS] = (data: any) => { this.onDraftSuccess(data); }
        mapping[ModelChangeUpdateEvents.DRAFT_REQUISITION_FAIL] = (error: any) => { this.onDraftFail(error); }
        mapping[ModelChangeUpdateEvents.REQ_CHANGE_EVT_SUCCESS] = () => { this.onValChange(); }
        mapping[ModelChangeUpdateEvents.DELETE_REQ_SUCCESS] = (error: any) => { this.deleteReqSuccess(); }
        mapping[ModelChangeUpdateEvents.DELETE_REQ_FAIL] = (error: any) => { this.deleteReqFail(error); }

        mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_SUCCESS] = (data: any) => { this.renderReqDetailsForApprovalsSuccess(data); };
        mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_FAIL] = (data: any) => { this.renderReqDetailsForApprovalsFail(data); };

        mapping[ModelChangeUpdateEvents.CUST_FOUND] = () => { this.pdfButton('enable'); }
        mapping[ModelChangeUpdateEvents.CUST_NOT_FOUND] = () => { this.pdfButton('disable'); }

        mapping[ModelChangeUpdateEvents.COPY_REQUISITION_SUCCESS] = (data: any) => { this.renderReqDetailsForApprovalsSuccess(data); };
        mapping[ModelChangeUpdateEvents.COPY_REQUISITION_FAIL] = (data: any) => { this.renderReqDetailsForApprovalsFail(data); };

        super.registerStateChangeEvents(mapping);
        this.taskId = this.route.snapshot.queryParams['taskId'] && this.route.snapshot.queryParams['taskId'].trim() || '';
        if (this.taskId !== undefined && this.taskId !== '') {
            const getReqDetails = this.actionDispatcherService.generateEvent(ActionEvents.GET_REQ_DETAILS_FOR_APPROVALS, { 'taskId': this.taskId });
            this.actionDispatcherService.dispatch(getReqDetails);
        }

        //Call copy API when 'Copy' clicked on search details
        this.searchReqId =this.route.snapshot.queryParams["searchReqId"] && this.route.snapshot.queryParams["searchReqId"].trim() || '';
        if(this.searchReqId !== undefined && this.searchReqId !== '') {
            this.createRequisitionComponent.showReq = true;
            this.createRequisitionComponent.taskStatus = 'Draft';
            this.createRequisitionComponent.inputReqId = this.searchReqId;
            this.createRequisitionComponent.copyReqId = this.searchReqId;
            let requestBody = {
                "requestor" : {
                    "name":  JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName,
                    "networkID": JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId,
                    "phone": JSON.parse(JSON.parse(localStorage.getItem('user'))._body).phoneNumber,
                    "email": JSON.parse(JSON.parse(localStorage.getItem('user'))._body).email,
                    "additionalPhone": "",
                    "additionalEmail": ""
                }
            }
            const getCopyDetails = this.actionDispatcherService.generateEvent(ActionEvents.COPY_REQUISITION, { body: requestBody, reqId: this.searchReqId});
            this.actionDispatcherService.dispatch(getCopyDetails);
        }

        // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

    }

    pdfButton(pdfBtnStatus: string) {
        if(pdfBtnStatus === 'enable') {
            this.custFound = false;
        }
        if(pdfBtnStatus === 'disable') {
            this.custFound = true;
        }
    }

    renderReqDetailsForApprovalsSuccess(data: any) {
        //Map to createRequisition
        this.createRequisitionComponent.taksId = this.taskId;
        if (data.requisition.requisitionType === 'SODS-SO') {
            this.createRequisitionComponent.selectedReqType = 'Special Order';
        } else if (data.requisition.requisitionType === 'SODS-DS') {
            this.createRequisitionComponent.selectedReqType = 'Direct Ship';
        } else {
            this.createRequisitionComponent.selectedReqType = data.requisition.requisitionType; //Not getting currently
        }

        // this.comments = data.requisition.comments;
        //this.createRequisitionComponent.reqComments = data.requisition.comments;
        //this.createRequisitionComponent.commentsComponent.comments = data.requisition.comments;
        this.createRequisitionComponent.getComments(data.requisition.requisitionNumber);

        this.createRequisitionComponent.customerComponent.customerDetails.reqStatus = data.taskName;

        this.taskName = data.taskName;

        this.createRequisitionComponent.setDropdownValues(this.createRequisitionComponent.selectedReqType);

        this.createRequisitionComponent.reqStatus = data.taskName;
        this.createRequisitionComponent.inputReqId = data.requisition.requisitionNumber;
        this.createRequisitionComponent.requestor.name = data.requestor.name;
        this.createRequisitionComponent.requestor.networkID = data.requestor.networkID;
        this.createRequisitionComponent.requestor.email = data.requestor.email;
        this.createRequisitionComponent.requestor.phone = data.requestor.phone;
        this.createRequisitionComponent.requestor.addlPhone = data.requestor.additionalPhone;
        this.createRequisitionComponent.requestor.addlEmail = data.requestor.additionalEmail;

        this.createRequisitionComponent.tm.name = data.territoryManager.name;
        this.createRequisitionComponent.tm.networkID = data.territoryManager.networkID;
        this.createRequisitionComponent.tm.email = data.territoryManager.email;
        this.createRequisitionComponent.tm.phone = data.territoryManager.phone;
        this.createRequisitionComponent.tm.addlPhone = data.territoryManager.additionalPhone;
        this.createRequisitionComponent.tm.addlEmail = data.territoryManager.additionalEmail;

        let address1: any = '';
        let address2: any = '';
        let city: any = '';
        let state: any = '';

        this.createRequisitionComponent.customerComponent.id = (data.customers[0] || {}).id;
        this.createRequisitionComponent.customerComponent.selectedMarket = data.requisition.division
        //this.createRequisitionComponent.customerComponent.retreiveCustomer(data.requisition);
        this.custFound = false;
        let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_CUST_DRAFT, {id: data.requisition.mainCustomerID, division: data.requisition.division});
        this.actionDispatcherService.dispatch(event);

        this.attachmentComponent.requisitionId = data.requisition.requisitionNumber;
        this.attachmentComponent.attachFile.requisitionId = data.requisition.requisitionNumber;
        this.attachmentComponent.editFile.requisitionId = data.requisition.requisitionNumber;

        this.attachmentComponent.ngOnInit();
        // this.attachmentComponent.requisitionId = data.requisition.requisitionNumber;

        //Override Ship To mapping


        for (let i = 0; i < data.customers.length; i++) {
            this.createRequisitionComponent.customerComponent.retrieveSuccess = true;
            //this.createRequisitionComponent.customerComponent.customerDetails.seq = data.customers[i].seq;

            this.createRequisitionComponent.customerComponent.customerDetails.id = data.customers[0].id;
            this.createRequisitionComponent.customerComponent.customerDetails.dept = data.customers[0].dept;
            this.createRequisitionComponent.customerComponent.customerDetails.defaultShipMethod = data.customers[0].defaultShipMethod;
            this.createRequisitionComponent.customerComponent.customerDetails.selectedShip = data.customers[0].defaultShipMethod;
            this.createRequisitionComponent.customerComponent.customerDetails.selectedETA = 'Custom Date';
            this.createRequisitionComponent.customerComponent.customerDetails.shipElementsHidden = (data.customers[0].defaultShipMethod === 'Next') ? true : false;
            this.createRequisitionComponent.customerComponent.customerDetails.name = data.customers[0].name;
            this.createRequisitionComponent.customerComponent.customerDetails.address = 
                data.customers[0].address1 + data.customers[0].address2 + data.customers[0].city + data.customers[0].state;
            this.createRequisitionComponent.customerComponent.customerDetails.comments = (data.requisition.comments[0] || {}).commentsText;

            address1 = data.customers[0].address1;
            address2 = data.customers[0].address2;
            city = data.customers[0].city;
            this.createRequisitionComponent.customerComponent.customerDetails.postalInfo = data.customers[0].zip;
            this.createRequisitionComponent.customerComponent.customerDetails.phone = data.customers[0].phone;
            this.createRequisitionComponent.customerComponent.customerDetails.quotePrice = data.requisition.quotePrice;
            this.createRequisitionComponent.customerComponent.customerDetails.quoteNbr = data.requisition.quoteNumber;
            //Department
            this.createRequisitionComponent.customerComponent.customerDetails.customerPO = data.requisition.defaultCustomerPO;
            this.createRequisitionComponent.customerComponent.customerDetails.specialInstruct = data.requisition.defaultSpecialInstructions;
            //Requested ETA to Customer dropdown
            //Eta checkbox

        }

        //Map to attachment
        this.attachmentComponent.attachmentsList = [];
        //Map to shipToLocation
        this.shipToLocation.selectedReqType = this.createRequisitionComponent.selectedReqType;
        this.shipToLocation.data = data.customers.map((item, index) => {
            return this.shipToLocation.getShipmentObject({
                ...item,
                selectedDept: item.dept,
                selectedShip: item.defaultShipMethod
            }, index + 1);
        });

        //Map to product
        this.productComponent.retrieveCustSuccss = true;
        this.productComponent.renderCustFound();
        this.productComponent.products = data.products.map((item) => {
            const shipTo = item.shipTodistribution.map((ship) => {
                return {
                    qty: ship.qty,
                    customerPO : ship.customerPO,
                    specialInstructions : ship.specialInstructions,
                    shipMethod: VALUEMAP.SHIPMETHOD[ship.shipMethod],
                    sellPrice: ship.sellPrice,
                    disableInput: ship.shipMethod === 'N' ? true : false,
                    customerId: ship.customerId,
                    departmentId: ship.departmentId,
                    customer: {
                        id: ship.customerId,
                        name: data.requisition.mainCustomerName,
                        division: (data.requisiton || {}).division,
                        dept: ship.departmentId,
                        defaultShipMethod: ship.department,
                        address1: address1,
                        address2: address2,
                        city: city,
                        confidenceCode: (data.customers[0].confidenceCode || {}),
                        tmId: data.territoryManager.networkd,
                        tmName: data.territoryManager.name,
                        tmEmail: data.territoryManager.email,
                        custType: data.requisition.mainCustomerType
                    }
                }
            });
            return {
                ...item,
                eta: new Date(item.ETA),
                new: item.new === 'true',
                returned: item.returned,
                mfrId: (item.requested === null || item.requested === undefined) ? item.manufacturerId : item.requested.mfrId,
                prodType: (item.requested === null || item.requested === undefined) ? item.type : item.requested.type,
                vendor : (item.requested === null || item.requested === undefined) ? item.vendor : {
                    vendorName : item.requested.vendor
                },
                shipTodistribution: shipTo
            };
        });
        this.productComponent.shipToArray = this.renderShipToChange(data.customers);
        this.productComponent.productCount = data.products.length + 1;
        // --- End of Data binding for geting requisition details based on id

        // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
    }

    renderShipToChange(data: any){
        //clean out the array firstly
        let shipToArray = new Array<ShipToDistribution>();
        data.forEach((element, index)=> {
          let shipToDistribution = new ShipToDistribution();
          shipToDistribution.id = data.id;
          shipToDistribution.departmentId = element.dept;
          shipToDistribution.customer = new Customer();
          shipToDistribution.customer.id = element.id;
          shipToDistribution.customer.name = element.name;
          shipToDistribution.customer.address1 = element.address1;
          shipToDistribution.customer.address2 = element.address2;
          shipToDistribution.customer.zip = element.zip;
          shipToDistribution.customer.city = element.city;
          shipToDistribution.customer.state = element.state;
          shipToDistribution.customer.dept = element.dept;
          shipToDistribution.departmentId = element.dept;
          shipToDistribution.shipMethod = element.defaultShipMethod;
          shipToArray.push(shipToDistribution);
        });
        return shipToArray;
    }

    renderReqDetailsForApprovalsFail(data: any) {
    }


    onValChange() {
        this.successPost = false;
        this.successDraft = false;
    }

    ngOnChanges(changes: SimpleChanges) {
        this.successPost = false;
        this.successDraft = false;
    }

    onPostSuccess(data: any) {

        localStorage.setItem('requestType', null);
        this.successPost = true;
        window.scrollTo(0, 0);
        if(this.createRequisitionComponent.showReq) {
            localStorage.setItem('saveId', this.createRequisitionComponent.inputReqId);
        }else{
            localStorage.setItem('saveId', this.createRequisitionComponent.requestId);
        }
        this.router.navigate(['taskInbox'])

        // window.location.reload();
    }

    onPostFail(error: any) {
        this.successPost = false;
        this.errorsQueue = [];
        if (error._body) {
            this.errorsQueue.push(error.statusText);
            this.errorsQueue.push(JSON.parse(error._body).message);
        } else {
            this.errorsQueue.push(error);
        }
        window.scrollTo(0, 0);
    }

    onDraftSuccess(data: any) {
        localStorage.setItem('requestType', null);
        this.closeWarning();
        this.successDraft = true;
        window.scrollTo(0, 0);
        localStorage.setItem('draftId', this.createRequisitionComponent.requestId);
        this.router.navigate(['taskInbox']);
    }

    onDraftFail(error: any) {
        this.closeWarning();
        this.successDraft = false;
        this.errorsQueue = [];
        if (error._body) {
            this.errorsQueue.push(error.statusText);
            this.errorsQueue.push(JSON.parse(error._body).message);
        } else {
            this.errorsQueue.push(error);
        }

        window.scrollTo(0, 0);
    }

    ngAfterViewInit() {
    }

    ngAfterContentChecked() {
        this.reqId = this.createRequisitionComponent && this.createRequisitionComponent.reqId || '0000000'
        this.selectedReqType = this.createRequisitionComponent && this.createRequisitionComponent.selectedReqType;
        this.shipCount = this.shipToLocation && this.shipToLocation.shipmentCount;
        if (this.shipToLocation) {
            this.shipToLocation.selectedReqType = this.selectedReqType;
            this.shipToLocation.selectedMarket = this.createRequisitionComponent && this.createRequisitionComponent.selectedMarketingType
            this.shipToLocation.marketingOptions = this.createRequisitionComponent.getMarketOptions
        }

    }

    getDateFormat(date: Date) {
        let d = '';
        d += date.getFullYear();
        d += '-' + (((date.getMonth() + 1) <= 9) ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1));
        d += '-' + date.getDate();
        d += ' ' + ((date.getHours() <= 9) ? '0' + date.getHours() : date.getHours());
        d += ':' + ((date.getMinutes() <= 9) ? '0' + date.getMinutes() : date.getMinutes());
        d += ':' + ((date.getSeconds() <= 9) ? '0' + date.getSeconds() : date.getSeconds());
        return d;
    }

    getDataObject() {

        let overrideShipToData;
        if(this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToSelected === true) {
            this.setOverrideShipToFlag = true;
            overrideShipToData = {
                "name":  this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.name,
                "address1": this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.address1,
                "address2": this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.address2,
                "city": this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.city,
                "state": this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.state,
                "zip": this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.zip,
                "phone": this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipTo.phone
            }
        }else{
            this.setOverrideShipToFlag = false;
        }
        

        const customersData = this.shipToLocation.data.map((item) => {
            return (
                {
                    "seq": item.customerNo,
                    "id": item.customer,
                    "dept": item.department,
                    "defaultShipMethod": item.ship_method,
                    "name": item.customerName,
                    "address1": item.address1,
                    "address2": item.address2,
                    "city": item.city,
                    "state": item.state,
                    "zip": item.zip,
                    "phone": item.phone,
                    "useOverrideShipto": this.setOverrideShipToFlag,
                    "overrideShipto": overrideShipToData,
                    estimatedOrderAmt: item.estimatedOrderAmt,
                    confidenceCode: item.confidenceCode,
                    creditCheckStatus: item.creditCheckStatus
                }
            );
            // "estimatedOrderAmt":321.12,
            // "confidenceCode":"09",
            // "creditCheckStatus":true
        });
        let json = {
            "requisition":
            {
                "requisitionNumber": this.getReqId(),
                "requisitionType": this.createRequisitionComponent.reqTypeOptionsValue[this.createRequisitionComponent.selectedReqType],
                //"requisitionType": "SODS-SO",
                "division": this.createRequisitionComponent.selectedMarketingType,
                "status": "new",
                "createdAt": this.getDateFormat(new Date()),
                "updatedAt": this.getDateFormat(new Date()),
                "totalAmount": 100.00,
                "ETASelection": this.createRequisitionComponent.customerComponent.customerDetails.selectedETA !== 'Select Date',
                "ETADate": this.getDateFormat(this.createRequisitionComponent.customerComponent.customerDetails.value),
                "returnIfETANotMet": this.createRequisitionComponent.customerComponent.customerDetails.notMet,
                "defaultShipMethod": this.createRequisitionComponent.customerComponent.customerDetails.selectedShip,
                "defaultCustomerPO": this.createRequisitionComponent.customerComponent.customerDetails.customerPO,
                "defaultSpecialInstructions": this.createRequisitionComponent.customerComponent.customerDetails.specialInstruct,
                "mainCustomerID": this.createRequisitionComponent.customerComponent.customerDetails.id,
                "mainCustomerName": this.createRequisitionComponent.customerComponent.customerDetails.name,
                "mainCustomerDept": this.createRequisitionComponent.customerComponent.customerDetails.selectedDept || 
                    this.createRequisitionComponent.customerComponent.customerDetails.defaultDept,
                "mainCustomerType": this.createRequisitionComponent.customerComponent.customerDetails.customerType,
                "quotePrice": this.createRequisitionComponent.customerComponent.customerDetails.quotePrice,
                "quoteNumber": this.createRequisitionComponent.customerComponent.customerDetails.quoteNbr,
                "comments": undefined,
                //"comments": this.createRequisitionComponent.customerComponent.customerDetails.comments,
                "attachmentsCount": this.attachmentCount()
            },
            "requestor":
            {
                "name": this.createRequisitionComponent.requestor.name,
                "networkID": this.createRequisitionComponent.requestor.networkID,
                "email": this.createRequisitionComponent.requestor.email,
                "additionalPhone": this.createRequisitionComponent.requestor.addlPhone || '',
                "additionalEmail": this.createRequisitionComponent.requestor.addlEmail || ''
            },
            "territoryManager":
            {
                "name": this.createRequisitionComponent.tm.name,
                "networkID": this.createRequisitionComponent.tm.networkID,
                "email": this.createRequisitionComponent.tm.email,
                "additionalPhone": this.createRequisitionComponent.tm.addlPhone,
                "additionalEmail": this.createRequisitionComponent.tm.addlEmail
            },
            "customers": customersData,
            "products": this.productComponent.getProductsData()
        }
            ;

        if (this.createRequisitionComponent.customerComponent.customerDetails.comments) {
            json.requisition.comments =
                [
                    {
                        "commentsText": this.createRequisitionComponent.customerComponent.customerDetails.comments,
                        "timestamp": this.getDateFormat(new Date((new Date()).getUTCFullYear(), 
                        (new Date()).getUTCMonth(), (new Date()).getUTCDate(), (new Date()).getUTCHours(), 
                        (new Date()).getUTCMinutes(), (new Date()).getUTCSeconds())),
                        "networkID": JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId,
                        "name": JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName
                    }
                ];
        }
        return json;
    }

    getReqId() {
        if(this.createRequisitionComponent.showReq) {
            return this.createRequisitionComponent.inputReqId;
        }else{
            return this.createRequisitionComponent.requestId;
        }
    }

    attachmentCount() {
        if (this.attachmentComponent.attachmentsExist === true) {
            return true;
        } else {
            return false;
        }
    }
    
    checkALLSignedDocs() {
        const filterSingedDocs = this.attachmentComponent.attachmentsList.filter((item) => item.fileType === "Signed Order");
        return filterSingedDocs.length > 0
    }

    checkShipToLocation(){
        if (this.shipToLocation.data && this.shipToLocation.data.length === 0) {
            this.errorsQueue.push("Request must at least have 1 product.");
        }
        else if (this.shipToLocation.selectedReqType === 'Direct Ship' && this.shipToLocation.data.length !== 1) {
            this.errorsQueue.push("Please remove additional Ship to Location, Direct Ship requests can only be shipped to 1 location.");
        }
        if (this.shipToLocation.hasDuplicateValues()) {
            this.errorsQueue.push("Ship to should not have duplicates");
        }
    }

    checkProductCount(){
        if (this.productComponent.products.length) {
            const productErrors = this.productComponent.checkCountOnProduct();
            if (productErrors.length > 0) {
                this.errorsQueue = this.errorsQueue.concat(productErrors);
            }
        } else {
            this.errorsQueue.push("Request must at least have 1 product.");
        }       
    }

    checkErrorQueue(){
        if (this.errorsQueue.length === 0) {
            let body: any = this.getDataObject(); //define body here.. 
            body.draftTaskId = this.createRequisitionComponent.requestId;
            let event = this.actionDispatcherService.generateEvent(ActionEvents.POST_REQUISITION, body);
            this.actionDispatcherService.dispatch(event);
        } else {
            window.scrollTo(0, 0);
        }
    }
    onSubmitRequest() {
        this.successPost = false;
        this.closeErrorPopup = false;
        this.errorsQueue = [];
        const validationErrors = this.createRequisitionComponent.getRequiredErrors(true);
        const quoteErrors: any = this.createRequisitionComponent.getQuoteErrors();
        if (validationErrors && validationErrors.length) {
            this.errorsQueue = this.errorsQueue.concat(validationErrors);
        }
        if (Array.isArray(quoteErrors) && quoteErrors.length > 0) {
            this.errorsQueue = this.errorsQueue.concat(quoteErrors)
        }
        if (!Array.isArray(quoteErrors) && (!this.attachmentComponent.attachmentsCount || !this.checkALLSignedDocs())) {
            this.errorsQueue.push("Please attach a Signed Order under Attachments");
        }

        this.checkShipToLocation();

        this.checkProductCount();

        this.checkErrorQueue();
    }

    onSaveDraft() {
        this.successPost = false;
        this.closeErrorPopup = false;
        this.errorsQueue = [];
        const validationErrors = this.createRequisitionComponent.getRequiredErrors(false);
        if (validationErrors && validationErrors.length) {
            this.errorsQueue = this.errorsQueue.concat(validationErrors);
        }
        if (this.errorsQueue.length === 0) {
            this.cancelModal.close();
            this.warningErrorModal.open();
        } else {
            window.scrollTo(0, 0);
        }
    }
    saveDaft() {
        let body: any = this.getDataObject(); //define body here..
        body.requisition.status = "Draft";
        body.overideSavedByID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        body.overideSavedByName = localStorage.getItem('username');
        let event = this.actionDispatcherService.generateEvent(ActionEvents.DRAFT_REQUISITION, body);
        this.actionDispatcherService.dispatch(event);
    }
    closeWarning() {
        this.warningErrorModal.close();
    }
    onCancel() {
        this.cancelModal.open();
    }
    openCancelPopup() {
        this.cancelModal.close();
        window.location.reload();
    }
    closeCancelPopup() {
        this.cancelModal.close();
    }

    onDelete() {
        this.deleteReqModal.open();
    }

    closeDeleteRequisition() {
        this.deleteReqModal.close();
    }

    confirmDeleteReq() {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.DELETE_REQ, this.createRequisitionComponent.reqId);
        this.actionDispatcherService.dispatch(event);
        this.deleteReqModal.close();
    }

    deleteReqSuccess() {
        this.successDelete = true;
        window.scrollTo(0, 0);
        localStorage.setItem('deleteId', this.createRequisitionComponent.requestId);
        this.router.navigate(['taskInbox']);
    }

    deleteReqFail(error: any) {
        this.successDelete = false;
        this.errorsQueue = [];
        if (error._body) {
            this.errorsQueue.push(error.statusText);
            this.errorsQueue.push(JSON.parse(error._body).message);
        } else {
            this.errorsQueue.push(error);
        }
        window.scrollTo(0, 0);
    }

    generatePdf() {
        let body: any = this.getDataObject();
        let reqMapper = new SubmitResponseMapper();
        let pBody = reqMapper.mapSubmitReqMapper(body);
        let event = this.actionDispatcherService.generateEvent(ActionEvents.GENERATE_PDF, pBody);
        this.actionDispatcherService.dispatch(event);
    }
}