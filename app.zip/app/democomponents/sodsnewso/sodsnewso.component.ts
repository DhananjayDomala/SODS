import { ReqDetails } from 'app/model/submitRequisition';
import { CustomerDetailsComponent } from "./../common/customer/customer-details.component";
import { ShipTodistribution } from "./../../model/submitRequisition";
import * as console from "console";
import { Product } from "./../../model/product";
import { ProductComponent } from "./../common/product/product.component";
import { Component, OnInit, OnChanges, ViewChild, ViewEncapsulation, AfterViewInit, AfterContentChecked, SimpleChanges } from "@angular/core";
import { BaseComponent } from "../base-component";
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam";
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { Requisition } from "../../model/requisition";
import { Customer } from "../../model/customer";
import { CustomerComponent } from "../common/customer/customer.component";
import { UserComponent } from "../common/user/user.component";
import { Modal, ModalModule } from "ngx-modal";
import { CreateRequisitionComponent } from "../common/createRequisition/createRequisition.component";
import { ShipToLocationComponent } from "../common/shipToLocation/shipToLocation.component";
import { AttachmentComponent } from "../common/attachment/attachment.component";
import { Router, ActivatedRoute, ParamMap, Params } from "@angular/router";
import { BREADCRUMBS } from "app/democomponents/common/breadcrumb/breadcrumbs";
import { SubmitResponseMapper } from "../../democomponents/util/submitRequest-mapper";
import { VALUEMAP } from "app/democomponents/common/options/options";
import { ShipToDistribution } from "app/model/shipToDistribution";
import { User } from "app/model/user";
import { ALERTS } from "../common/alert/alerts";
import { AlertSetting } from "../common/alert/alert.component";
import { SamService } from "app/service/sam.service";

@Component({
  selector: "so-new",
  templateUrl: "./sodsnewso.component.html",
  styleUrls: ["./sodsnewso.component.css"]
})
export class SODSNewSoComponent extends BaseComponent
  implements OnInit, OnChanges, AfterViewInit, AfterContentChecked {
  @ViewChild("createRequisition") createRequisitionComponent: CreateRequisitionComponent;
  @ViewChild("requisitionAttachments") attachmentComponent: AttachmentComponent;
  @ViewChild("sodsProduct") productComponent: ProductComponent;
  @ViewChild("shipToLocation") shipToLocation: ShipToLocationComponent;
  @ViewChild("warningError") warningErrorModal: Modal;
  @ViewChild("cancelPopup") cancelModal: Modal;
  @ViewChild("deleteReq") deleteReqModal: Modal;
  @ViewChild("customerDetails")
  customerDetailsComponent: CustomerDetailsComponent;
  // For Security
  public noAccess = true;
  public copyReq = false;
  currentAlert = [];
  public elements: any[];
  reqId: string;
  shipCount: any = 0;
  closeErrorPopup: any = false;
  selectedReqType: any;
  errorsQueue: any[];
  validationErrors: any[];
  successPost: boolean = false;
  successDraft: boolean = false;
  successDelete: boolean = false;
  taskId: any;
  taskName: any;
  comments: any;
  searchReqId: string;
  isRecallOrReturned: boolean = false;
  // For Breadcrumbs
  public breadcrumbs = BREADCRUMBS["create-requisition"];
  copyErrorMsgs: any[];
  // For Alert Text Bar
  public showAlert = false;
  showModalAlert = false;
  public alertType = "";
  public alertMessage = "";
  public alertSettings: AlertSetting[] = [{ alertType: "", alertMessage: "" }];
  copyErrorsExist: boolean = false;
  public custFound: boolean = false;
  setOverrideShipToFlag: boolean = false;
  generatingPdf: boolean = false;
  json: any;

  constructor(private samService: SamService, readonly stateRepresentationRendererService: StateRepresentationRendererService, private route: ActivatedRoute, private router: Router, private user: User) {
    super(stateRepresentationRendererService);
  }

  ngOnInit() {
    this.checkIfSodsUser();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.successPost = false;
    this.successDraft = false;
  }
  ngAfterContentChecked() {
    this.reqId = (this.createRequisitionComponent && this.createRequisitionComponent.reqId) || "0000000";
    this.selectedReqType = this.createRequisitionComponent && this.createRequisitionComponent.selectedReqType;
    this.shipCount = this.shipToLocation && this.shipToLocation.shipmentCount;
    if (this.shipToLocation) {
      this.shipToLocation.selectedReqType = this.selectedReqType;
      this.shipToLocation.selectedMarket = this.createRequisitionComponent && this.createRequisitionComponent.selectedMarketingType;
      this.shipToLocation.marketingOptions = this.createRequisitionComponent.getMarketOptions;
    }
  }

  ngAfterViewInit() {

  }

  modeChangeUpdateEventsMapping() {
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.POST_REQUISITION_SUCCESS] = () => { this.onPostSuccess(); };
    mapping[ModelChangeUpdateEvents.POST_REQUISITION_FAIL] = (error: any) => { this.onPostFail(error); };
    mapping[ModelChangeUpdateEvents.DRAFT_REQUISITION_SUCCESS] = (data: any) => { this.onDraftSuccess(data); };
    mapping[ModelChangeUpdateEvents.DRAFT_REQUISITION_FAIL] = (error: any) => { this.onDraftFail(error); };
    mapping[ModelChangeUpdateEvents.REQ_CHANGE_EVT_SUCCESS] = () => { this.onReqChangeSuccess();};
    mapping[ModelChangeUpdateEvents.DELETE_REQ_SUCCESS] = (error: any) => { this.deleteReqSuccess(); };
    mapping[ModelChangeUpdateEvents.DELETE_REQ_FAIL] = (error: any) => { this.deleteReqFail(error); };
    mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_SUCCESS] = (data: ReqDetails) => { this.renderReqDetailsSuccess(data); };
    mapping[ModelChangeUpdateEvents.CUST_FOUND] = () => { this.custFound = true };
    mapping[ModelChangeUpdateEvents.CUST_NOT_FOUND] = () => { this.custFound = false };
    mapping[ModelChangeUpdateEvents.COPY_REQUISITION_SUCCESS] = (data: any) => { this.copySuccess(data) };
    super.registerStateChangeEvents(mapping);
  }
 
  /* On Load of Page Functions */
  checkIfSodsUser() {
    if(this.user.isMemberOf(["SODS-USER"])) {
      this.modeChangeUpdateEventsMapping();
      this.noAccess = false;
      this.resetErrorsQueue();
      this.setElements();
      this.checkIfParamInUrl();
    }else{
      this.noAccess = true;
      this.showAlertMessage("error", "noAccess");
    }
  }
  setElements() {
    this.elements = [
      {title: "Requisition # :", isCollapsedReq: false},
      {title: "Attachments", isCollapsedReq: true},
      {title: "Ship To Locations", isCollapsedReq: true},
      {title: "Product Information", isCollapsedReq: true}
    ];
  }
  checkIfParamInUrl() {
    this.taskId = (this.route.snapshot.queryParams["taskId"] && this.route.snapshot.queryParams["taskId"].trim()) || "";
    if (this.ifNotNull(this.taskId)) {
      this.callSamService(ActionEvents.GET_REQ_DETAILS_FOR_APPROVALS, {taskId: this.taskId});
    }

    this.searchReqId = (this.route.snapshot.queryParams["searchReqId"] && this.route.snapshot.queryParams["searchReqId"].trim()) || "";
    if (this.ifNotNull(this.searchReqId)) {
      this.copyErrorMsgs = [];
      let requestBody = this.getRequestBodyForCopy();
      this.callSamService(ActionEvents.COPY_REQUISITION, { body: requestBody, reqId: this.searchReqId });
      this.setBusy(true);
    }
  }

  /* Get Body Functions */
  getRequestBodyForCopy() {
    return {
      requestor: {
        name: JSON.parse(JSON.parse(localStorage.getItem("user"))._body).displayName,
        networkID: JSON.parse(JSON.parse(localStorage.getItem("user"))._body).userId,
        phone: JSON.parse(JSON.parse(localStorage.getItem("user"))._body).phoneNumber,
        email: JSON.parse(JSON.parse(localStorage.getItem("user"))._body).email,
        additionalPhone: "",
        additionalEmail: ""
      }
    };
  }
  getDataObject() {
    this.json = {
      requisition: {
        requisitionNumber: this.getReqIdForSubmit(),
        requisitionType: this.createRequisitionComponent.reqTypeOptionsValue[this.createRequisitionComponent.selectedReqType],
        division: this.createRequisitionComponent.selectedMarketingType,
        status: "new",
        createdAt: this.getDateFormat(new Date()),
        updatedAt: this.getDateFormat(new Date()),
        totalAmount: 100.0,
        ETASelection:
          this.createRequisitionComponent.customerComponent.customerDetails
            .selectedETA !== "Select Date",
        ETADate: this.createRequisitionComponent.customerComponent.customerDetails.selectedETA !== "Select Date" ? this.getDateFormat(this.createRequisitionComponent.customerComponent.customerDetails.calendarSettings.value) : null,
        returnIfETANotMet: this.createRequisitionComponent.customerComponent
          .customerDetails.notMet,
        defaultShipMethod: this.createRequisitionComponent.customerComponent
          .customerDetails.selectedShip,
        defaultCustomerPO: this.createRequisitionComponent.customerComponent
          .customerDetails.customerPO,
        defaultSpecialInstructions: this.createRequisitionComponent
          .customerComponent.customerDetails.specialInstruct,
        mainCustomerID: this.createRequisitionComponent.customerComponent
          .customerDetails.id,
        mainCustomerName: this.createRequisitionComponent.customerComponent
          .customerDetails.name,
        mainCustomerDept:
          this.createRequisitionComponent.customerComponent.customerDetails
            .selectedDept ||
          this.createRequisitionComponent.customerComponent.customerDetails
            .defaultDept,
        mainCustomerType: this.createRequisitionComponent.customerComponent
          .customerDetails.customerType,
        quotePrice: this.createRequisitionComponent.customerComponent
          .customerDetails.quotePrice,
        quoteNumber: this.createRequisitionComponent.customerComponent
          .customerDetails.quoteNbr,
        comments: undefined,
        attachmentsCount: this.attachmentComponent.attachmentsList.length > 0 ? true : false
      },
      requestor: this.getRequestorDataForSubmit(),
      territoryManager: this.getTmDataForSubmit(),
      customers: this.getCustomerDataForSubmit(),
      products: this.productComponent.getProductsData()
    };
    return this.json;
  }
  setSubmitBody() {
    let body: any = this.getDataObject();
    body.draftTaskId = this.getRequestId();
    return body;
  }
  setDraftBody() {
    let body: any = this.getDataObject();
    body.requisition.status = "Draft";
    body.overideSavedByID = JSON.parse(JSON.parse(localStorage.getItem("user"))._body).userId;
    body.overideSavedByName = localStorage.getItem("username");
    return body;
  }

  /* Render Functions */
  renderRequestorInfo(data: any) {
    this.createRequisitionComponent.requestor.name = data.requestor.name;
    this.createRequisitionComponent.requestor.networkID = data.requestor.networkID;
    this.createRequisitionComponent.requestor.email = data.requestor.email;
    this.createRequisitionComponent.requestor.phone = data.requestor.phone;
    this.createRequisitionComponent.requestor.addlPhone = data.requestor.additionalPhone;
    this.createRequisitionComponent.requestor.addlEmail = data.requestor.additionalEmail;
  }
  renderTmInfo(data: any) {
    this.createRequisitionComponent.tm.name = data.territoryManager.name;
    this.createRequisitionComponent.tm.networkID = data.territoryManager.networkID;
    this.createRequisitionComponent.tm.email = data.territoryManager.email;
    this.createRequisitionComponent.tm.phone = data.territoryManager.phone;
    this.createRequisitionComponent.tm.addlPhone = data.territoryManager.additionalPhone;
    this.createRequisitionComponent.tm.addlEmail = data.territoryManager.additionalEmail;
  }
  renderSetTaskName(data: any) {
    if(data.taskName === 'Recalled' || data.taskName === 'Returned') {
      this.taskName = data.taskName;
      this.isRecallOrReturned = true;
    }else{
        this.taskName = data.taskName;
    }
  }
  renderAttachmentInfo(data: any) {
    this.attachmentComponent.requisitionId = data.requisition.requisitionNumber;
    this.attachmentComponent.attachFile.requisitionId = data.requisition.requisitionNumber;
    this.attachmentComponent.editFile.requisitionId = data.requisition.requisitionNumber;
    this.attachmentComponent.ngOnInit();
    this.attachmentComponent.attachmentsList = [];
  }
  renderCustomerInfo(data: any) {
    for (let i = 0; i < data.customers.length; i++) {
      this.createRequisitionComponent.customerComponent.retrieveSuccess = true;
      this.createRequisitionComponent.customerComponent.customerDetails.id = data.customers[0].id;
      this.createRequisitionComponent.customerComponent.customerDetails.dept = data.customers[0].dept;
      this.createRequisitionComponent.customerComponent.customerDetails.defaultShipMethod = data.customers[0].defaultShipMethod;
      this.createRequisitionComponent.customerComponent.customerDetails.selectedShip = data.customers[0].defaultShipMethod;
      
      if(this.ifNotNull(data.requisition.ETASelection)) {
        this.createRequisitionComponent.customerComponent.customerDetails.selectedETA = "Select Date"
      }else{
        this.createRequisitionComponent.customerComponent.customerDetails.selectedETA = "Custom Date";
        let dateString = data.requisition.ETADate;
        let etaDate = new Date(dateString);
        this.createRequisitionComponent.customerComponent.customerDetails.calendarSettings.value = etaDate;
      }
      this.createRequisitionComponent.customerComponent.customerDetails.shipElementsHidden = data.customers[0].defaultShipMethod === "Next" ? true : false;
      this.createRequisitionComponent.customerComponent.customerDetails.name = data.customers[0].name;
      this.createRequisitionComponent.customerComponent.customerDetails.address = data.customers[0].address1 + data.customers[0].address2 + data.customers[0].city + data.customers[0].state;
      this.createRequisitionComponent.customerComponent.customerDetails.comments = (data.requisition.comments[0] || {}).commentsText;
      this.createRequisitionComponent.customerComponent.customerDetails.postalInfo = data.customers[0].zip;
      this.createRequisitionComponent.customerComponent.customerDetails.phone = data.customers[0].phone;
      this.createRequisitionComponent.customerComponent.customerDetails.quotePrice = data.requisition.quotePrice;
      this.createRequisitionComponent.customerComponent.customerDetails.quoteNbr = data.requisition.quoteNumber;
      this.createRequisitionComponent.customerComponent.customerDetails.customerPO = data.requisition.defaultCustomerPO;
      this.createRequisitionComponent.customerComponent.customerDetails.specialInstruct = data.requisition.defaultSpecialInstructions;
      this.createRequisitionComponent.customerComponent.customerDetails.notMet = data.requisition.ETASelection;
    }
  }
  renderOverrideShipToInfo(data: any) {
    this.createRequisitionComponent.customerComponent.customerDetails.showOverrideInfo = true;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.name = data.customers[0].overrideShipto.name;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.address1 = data.customers[0].overrideShipto.address1;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.address2 = data.customers[0].overrideShipto.address2;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.city = data.customers[0].overrideShipto.city;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.state = data.customers[0].overrideShipto.state;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.zip = data.customers[0].overrideShipto.zip;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.phone = data.customers[0].overrideShipto.phone;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.name = data.customers[0].overrideShipto.name;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.address1 = data.customers[0].overrideShipto.address1;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.address2 = data.customers[0].overrideShipto.address2;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.city = data.customers[0].overrideShipto.city;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.state = data.customers[0].overrideShipto.state;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.zip = data.customers[0].overrideShipto.zip;
    this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToComponent.overrideShipToModel.phone = data.customers[0].overrideShipto.phone;
  }
  renderShipToLocation(data: any) {
    this.shipToLocation.selectedReqType = this.createRequisitionComponent.selectedReqType;
    this.shipToLocation.data = data.customers.map((item, index) => {
      return this.shipToLocation.getShipmentObject({...item, selectedDept: item.dept, selectedShip: item.defaultShipMethod}, index + 1);
    });
  }
  renderProductInfo(data: any) {
    this.productComponent.retrieveCustSuccss = true;
    this.productComponent.renderCustFound();
    this.productComponent.products = data.products.map(item => {
      const shipTo = item.shipTodistribution.map(ship => {
        return {
          qty: ship.qty,
          customerPO: ship.customerPO,
          specialInstructions: ship.specialInstructions,
          shipMethod: VALUEMAP.SHIPMETHOD[ship.shipMethod],
          sellPrice: ship.sellPrice,
          disableInput: ship.shipMethod === "N" ? true : false,
          customerId: ship.customerId,
          departmentId: ship.departmentId,
          customer: {
            id: ship.customerId,
            name: data.requisition.mainCustomerName,
            division: (data.requisiton || {}).division,
            dept: ship.departmentId,
            defaultShipMethod: ship.department,
            address1: data.customers[0].address1,
            address2: data.customers[0].address2,
            city: data.customers[0].city,
            confidenceCode: data.customers[0].confidenceCode || {},
            tmId: data.territoryManager.networkd,
            tmName: data.territoryManager.name,
            tmEmail: data.territoryManager.email,
            custType: data.requisition.mainCustomerType
          }
        };
      });
      return {
        ...item,
        eta: new Date(item.ETA),
        new: item.new === "true",
        returned: item.returned,
        mfrId: item.requested === null || item.requested === undefined ? item.manufacturerId : item.requested.mfrId,
        prodType: item.requested === null || item.requested === undefined ? item.type : item.requested.type,
        vendor: item.requested === null || item.requested === undefined ? item.vendor : {vendorName: item.requested.vendor},
        shipTodistribution: shipTo
      };
    });
    this.productComponent.shipToArray = this.renderShipToChange(data.customers);
    this.productComponent.productCount = data.products.length + 1;
  }
  renderShipToChange(data: any) {
    //clean out the array firstly
    let shipToArray = new Array<ShipToDistribution>();
    data.forEach((element, index) => {
      let shipToDistribution = new ShipToDistribution();
      shipToDistribution.id = data.id;
      shipToDistribution.departmentId = element.dept;
      shipToDistribution.customer = new Customer();
      shipToDistribution.customer.id = element.id;
      shipToDistribution.customer.name = element.name;
      shipToDistribution.customer.address1 = element.address1;
      shipToDistribution.customer.address2 = element.address2;
      shipToDistribution.customer.zip = element.zip;
      shipToDistribution.customer.city = element.city;
      shipToDistribution.customer.state = element.state;
      shipToDistribution.customer.dept = element.dept;
      shipToDistribution.departmentId = element.dept;
      shipToDistribution.shipMethod = element.defaultShipMethod;
      shipToArray.push(shipToDistribution);
    });
    return shipToArray;
  }
  ifShowReq(data) {
    if(this.createRequisitionComponent.showReq) {
      this.createRequisitionComponent.reqId = data.requisition.requisitionNumber;
      this.createRequisitionComponent.taskStatus = "Draft";
    }
  }
  checkReqType(data: any) {
    if (data.requisition.requisitionType === "SODS-SO") {
      this.createRequisitionComponent.selectedReqType = "Special Order";
    } else if (data.requisition.requisitionType === "SODS-DS") {
      this.createRequisitionComponent.selectedReqType = "Direct Ship";
    } else {
      this.createRequisitionComponent.selectedReqType = data.requisition.requisitionType;
    }
  }
  mapCopyErrors(allData: any, reqErrors: Array<any>, customerErrors: Array<any>, productErrors: Array<any>) {
    for (let j = 0; j < reqErrors.length; j++) {
      this.mapReqErrors(reqErrors[j].errors);
    }
    for (let k = 0; k < customerErrors.length; k++) {
      this.mapCustomerErrors(allData.customers[0].id, customerErrors[k].customerNumber, customerErrors[k].errors);
    }
    for (let m = 0; m < productErrors.length; m++) {
      this.mapProductErrors(productErrors[m].productNumber, productErrors[m].errors);
    }
  }
  mapReqErrors(reqError: string) {
    this.copyErrorsExist = true;
      if(this.ifNotNull(reqError)) {
        this.copyErrorMsgs.push(reqError);
      }
  }
  mapCustomerErrors(custId: string, custNbr: string, error: string) {
    this.copyErrorsExist = true;
      if(this.ifNotNull(custNbr) && this.ifNotNull(error)) {
        if(custId == custNbr) {
          this.createRequisitionComponent.customerComponent.customerDetails.copyError = true;
          this.copyErrorMsgs.push("Customer " + custNbr + " - " + error);
        }else{
          for(let n = 1; n < this.shipToLocation.data.length; n++) {
            if(this.shipToLocation.data[n].customer == custNbr) {
              this.shipToLocation.data[n].copyError = true;
              this.copyErrorMsgs.push("Ship To Customer " + custNbr + " - " + error);
            }
          }
        }
      }
  }
  mapProductErrors(prodNbr: string, error: string){
    this.copyErrorsExist = true;
      if(this.ifNotNull(prodNbr)) {
        this.copyErrorMsgs.push("Product " + prodNbr + " - " + error );
        for(let p = 0; p < this.productComponent.products.length; p++) {
          if(prodNbr == this.productComponent.products[p].productId) {
            this.productComponent.products[p].copyError = true;
          }
        }
      }
  }
  getOverrideShipToDataForSubmit() {
    let overrideShipToData;
    if(this.createRequisitionComponent.selectedReqType == "Direct Ship") {
      if(this.createRequisitionComponent.customerComponent.customerDetails.useOverrideShipto) {
        this.setOverrideShipToFlag = true;
        return overrideShipToData = 
          { 
            name: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.name,
            address1: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.address1,
            address2: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.address2,
            city: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.city,
            state: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.state,
            zip: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.zip,
            phone: this.createRequisitionComponent.customerComponent.customerDetails.overrideShipToModel.phone
        };
      } else {
        this.setOverrideShipToFlag = false;
      }
    }else{
      this.setOverrideShipToFlag = false;
    }
  }
  getCustomerDataForSubmit() {
    return this.shipToLocation.data.map(item => {
      return {
        seq: item.customerNo,
        id: item.customer,
        dept: item.department,
        defaultShipMethod: item.ship_method,
        name: item.customerName,
        address1: item.address1,
        address2: item.address2,
        city: item.city,
        state: item.state,
        zip: item.zip,
        phone: this.getPhoneNbr(item.phone),
        overrideShipto: this.getOverrideShipToDataForSubmit(),
        useOverrideShipto: this.setOverrideShipToFlag,
        estimatedOrderAmt: item.estimatedOrderAmt,
        confidenceCode: item.confidenceCode,
        creditCheckStatus: item.creditCheckStatus
      };
    });
  }
  getRequestorDataForSubmit() {
    return {
      name: this.createRequisitionComponent.requestor.name,
      networkID: this.createRequisitionComponent.requestor.networkID,
      email: this.createRequisitionComponent.requestor.email,
      additionalPhone: this.createRequisitionComponent.requestor.addlPhone || "",
      additionalEmail: this.createRequisitionComponent.requestor.addlEmail || ""
    }
  }
  getTmDataForSubmit() {
    return {
      name: this.createRequisitionComponent.tm.name,
      networkID: this.createRequisitionComponent.tm.networkID,
      email: this.createRequisitionComponent.tm.email,
      additionalPhone: this.createRequisitionComponent.tm.addlPhone,
      additionalEmail: this.createRequisitionComponent.tm.addlEmail
    }
  }
  getCommentsDataForSubmit() {
    if (this.createRequisitionComponent.customerComponent.customerDetails.comments) {
        return [{
          commentsText: this.createRequisitionComponent.customerComponent.customerDetails.comments,
          timestamp: this.getDateFormat(
            new Date(
              new Date().getUTCFullYear(),
              new Date().getUTCMonth(),
              new Date().getUTCDate(),
              new Date().getUTCHours(),
              new Date().getUTCMinutes(),
              new Date().getUTCSeconds()
            )
          ),
          networkID: JSON.parse(JSON.parse(localStorage.getItem("user"))._body).userId,
          name: JSON.parse(JSON.parse(localStorage.getItem("user"))._body).displayName
        }]
    }
  }
  getRequisitionDataForSubmit() {
    this.getCustomerDetailsDataForSubmit();
    return {
      requisitionNumber: this.getReqIdForSubmit(),
      requisitionType: this.createRequisitionComponent.reqTypeOptionsValue[this.createRequisitionComponent.selectedReqType],
      division: this.createRequisitionComponent.selectedMarketingType,
      status: "new",
      createdAt: this.getDateFormat(new Date()),
      updatedAt: this.getDateFormat(new Date()),
      totalAmount: 100.0,
      comments: this.getCommentsDataForSubmit(),
      attachmentsCount: this.attachmentComponent.attachmentsList.length > 0 ? true : false
    }
  }
  getCustomerDetailsDataForSubmit() {
      this.json.requisition.ETASelection = this.createRequisitionComponent.customerComponent.customerDetails.selectedETA !== "Select Date";
      this.json.requisition.ETADate = this.createRequisitionComponent.customerComponent.customerDetails.selectedETA !== "Select Date" ? this.getDateFormat(this.createRequisitionComponent.customerComponent.customerDetails.calendarSettings.value) : null;
      this.json.requisition.returnIfETANotMet = this.createRequisitionComponent.customerComponent.customerDetails.notMet;
      this.json.requisition.defaultShipMethod = this.createRequisitionComponent.customerComponent.customerDetails.selectedShip;
      this.json.requisition.defaultCustomerPO = this.createRequisitionComponent.customerComponent.customerDetails.customerPO;
      this.json.requisition.defaultSpecialInstructions = this.createRequisitionComponent.customerComponent.customerDetails.specialInstruct;
      this.json.requisition.mainCustomerID = this.createRequisitionComponent.customerComponent.customerDetails.id;
      this.json.requisition.mainCustomerName = this.createRequisitionComponent.customerComponent.customerDetails.name;
      this.json.requisition.mainCustomerDept = this.createRequisitionComponent.customerComponent.customerDetails.selectedDept ||
      this.createRequisitionComponent.customerComponent.customerDetails.defaultDept;
      this.json.requisition.mainCustomerType = this.createRequisitionComponent.customerComponent.customerDetails.customerType;
      this.json.requisition.quotePrice = this.createRequisitionComponent.customerComponent.customerDetails.quotePrice;
      this.json.requisition.quoteNumber = this.createRequisitionComponent.customerComponent.customerDetails.quoteNbr;
  }
  getPhoneNbr(phone: string) {
    if(this.generatingPdf) {
      return this.formatPhoneNum(phone);
    } else {
      return phone;
    }
  }
  getReqIdForSubmit() {
    if(this.isRecallOrReturned) {
        return "00000";
    }else if(this.createRequisitionComponent.showReq) { //If copied, send NEW requisition number
        return this.createRequisitionComponent.inputReqId;
    }else{
        return this.createRequisitionComponent.requestId
    }
  }
  checkAllSignedDocs() {
    const filterSignedDocs = this.attachmentComponent.attachmentsList.filter(
      item => item.fileType === "Signed Order"
    );
    return filterSignedDocs.length > 0;
  }

  checkShipToLocation() {
    if (this.shipToLocation.data && this.shipToLocation.data.length === 0) {
      this.errorsQueue.push("Request must at least have one ship to location.");
    } else if (
      this.shipToLocation.selectedReqType === "Direct Ship" &&
      this.shipToLocation.data.length !== 1
    ) {
      this.errorsQueue.push("Please remove additional Ship to Location, Direct Ship requests can only be shipped to 1 location.");
    }
    if (this.shipToLocation.hasDuplicateValues()) {
      this.errorsQueue.push("Ship to should not have duplicates");
    }
  }
  
  /* Success Handlers */
  deleteReqSuccess() {
    this.successDelete = true;
    this.scrollWindowUp();
    localStorage.setItem("deleteId", this.createRequisitionComponent.requestId);
    this.router.navigate(["taskInbox"]);
  }
  onDraftSuccess(data: any) {
    localStorage.setItem("requestType", null);
    this.closeWarning();
    this.successDraft = true;
    this.scrollWindowUp();
    localStorage.setItem("draftId", this.createRequisitionComponent.requestId);
    this.router.navigate(["taskInbox"]);
  }
  onPostSuccess() {
    localStorage.setItem("requestType", null);
    this.successPost = true;
    this.scrollWindowUp();
    if (this.createRequisitionComponent.showReq) {
      localStorage.setItem("saveId", this.createRequisitionComponent.inputReqId);
    } else {
      localStorage.setItem("saveId", this.createRequisitionComponent.requestId);
    }
    this.router.navigate(["taskInbox"]);
  }
  copySuccess(data: any) {
    this.createRequisitionComponent.showReq = true;
    this.createRequisitionComponent.taskStatus = "Draft";
    this.copyReq = true;
    this.renderReqDetailsSuccess(data);
  }
  renderReqDetailsSuccess(data: any) {
    this.createRequisitionComponent.taksId = this.taskId;
    this.checkReqType(data);

    if(!this.copyReq) {
      this.createRequisitionComponent.getComments(data.requisition.requisitionNumber);
      this.createRequisitionComponent.customerComponent.customerDetails.useOverrideShipto = data.customers[0].useOverrideShipto === "true" ? true : false;
      if(this.createRequisitionComponent.customerComponent.customerDetails.useOverrideShipto) {
        this.renderOverrideShipToInfo(data);
      }
    }else{
      this.mapCopyErrors(data, data.reqErrors, data.customerErrors, data.productErrors);
    }
    
    this.ifShowReq(data);
    this.createRequisitionComponent.customerComponent.customerDetails.reqStatus = data.taskName;
    this.createRequisitionComponent.auditLogs = data.auditLogs;
    this.renderSetTaskName(data);
    this.createRequisitionComponent.setDropdownValues(this.createRequisitionComponent.selectedReqType);
    this.createRequisitionComponent.reqStatus = data.taskName;
    this.renderRequestorInfo(data);
    this.createRequisitionComponent.inputReqId = data.requisition.requisitionNumber;
    this.renderTmInfo(data);
    this.createRequisitionComponent.customerComponent.id = (data.customers[0] || {}).id;
    this.createRequisitionComponent.customerComponent.selectedMarket = data.requisition.division;
    //this.custFound = false;
    this.callSamService(ActionEvents.RETRIEVE_CUST_DRAFT, {id: data.requisition.mainCustomerID, division: data.requisition.division});
    this.renderAttachmentInfo(data);
    this.renderCustomerInfo(data);
    this.renderShipToLocation(data);
    this.renderProductInfo(data);
    this.setBusy(false);
  }
  onReqChangeSuccess() {
    this.successPost = false;
    this.successDraft = false;
  }


  /* Fail Handlers */
  deleteReqFail(error: any) {
    this.successDelete = false;
    this.resetErrorsQueue();
    if (this.ifNotNull(error._body)) {
      this.pushToErrorsQueue(error.statusText);
      this.pushToErrorsQueue(JSON.parse(error._body).message);
    } else {
      this.pushToErrorsQueue(error);
    }
    this.scrollWindowUp();
  }
  onDraftFail(error: any) {
    this.closeWarning();
    this.successDraft = false;
    this.resetErrorsQueue();
    if (error._body) {
      this.pushToErrorsQueue(error.statusText);
      this.pushToErrorsQueue(JSON.parse(error._body).message);
    } else {
      this.pushToErrorsQueue(error);
    }
    this.scrollWindowUp();
  }
  onPostFail(error: any) {
    this.successPost = false;
    this.resetErrorsQueue();
    if (this.ifNotNull(error._body)) {
      this.pushToErrorsQueue(error.statusText);
      this.pushToErrorsQueue(JSON.parse(error._body).message);
    } else {
      this.pushToErrorsQueue(error);
    }
    this.scrollWindowUp();
  }


  /* Utility Functions */
  scrollWindowUp() {
    window.scrollTo(0, 0);
  }
  setBusy(status: boolean) {
    this.callSamService(ActionEvents.SET_BUSY_STATUS, status);
  }
  callSamService(eventTypeName: string, data: any) {
    this.samService.callAction(eventTypeName, data);
  }
  getRequestId() {
    return this.createRequisitionComponent.requestId;
  }
  formatPhoneNum(phone): string {
    return phone.replace(/(\d{3})(\d{3})(\d{3})/, '($1) $2-$3');
  }  
  showAlertMessage(alertType: string, alertText: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert: AlertSetting = {alertType: alertType, alertMessage: this.alertMessage};
    this.alertSettings.push(alert);
    this.showAlert = true;
  }

  getAlertArray(array = [], key){
    array = array.filter((item) => {
      return (this.currentAlert[0] || {}).alertMessage !== item;
    });
    this[key] = array;
    let _alertSettings = [];
    array.forEach((message) => {
      const __alert = [];
      const alert: AlertSetting = {alertType: 'error', alertMessage: message};
      __alert.push(alert);
      _alertSettings.push(__alert);
    });
    return _alertSettings;
  }

  getDateFormat(date: Date) {
    let d = "";
    d += date.getFullYear();
    d += "-" + (date.getMonth() + 1 <= 9 ? "0" + (date.getMonth() + 1): date.getMonth() + 1);
    d += "-" + date.getDate();
    d += " " + (date.getHours() <= 9 ? "0" + date.getHours() : date.getHours());
    d += ":" + (date.getMinutes() <= 9 ? "0" + date.getMinutes() : date.getMinutes());
    d += ":" + (date.getSeconds() <= 9 ? "0" + date.getSeconds() : date.getSeconds());
    return d;
  }
  ifNotNull(data: any) {
    if(data != "" && data != undefined && data != null) {
      return true;
    }
  }


  /* Error Handling */
  pushToErrorsQueue(errors: any) {
    this.errorsQueue.push(errors);
  }
  resetErrorsQueue() {
    this.errorsQueue = [];
  }
  checkForErrors() {
    this.checkForValidationErrors();
    this.checkForQuoteErrors();
    this.checkForShipToErrors();
    this.checkForProductErrors();
  }
  checkErrorQueueOnSubmit() {
    if(this.errorsQueue.length === 0) {
      let body = this.setSubmitBody(); 
      this.callSamService(ActionEvents.POST_REQUISITION, body);
      this.setBusy(false);
    }else{
      this.scrollWindowUp();
    }
  }
  checkForQuoteErrors() {
    const quoteErrors: any = this.createRequisitionComponent.getQuoteErrors();
    if (Array.isArray(quoteErrors) && quoteErrors.length > 0) {
      this.errorsQueue = this.errorsQueue.concat(quoteErrors);
    }
    if (!Array.isArray(quoteErrors) &&(!this.attachmentComponent.attachmentsCount || !this.checkAllSignedDocs())) {
      this.pushToErrorsQueue("Please attach a Signed Order under Attachments");
    }
  }
  checkForValidationErrors() {
    this.validationErrors = this.createRequisitionComponent.getRequiredErrors(true);
    if (this.validationErrors && this.validationErrors.length) {
      this.errorsQueue = this.errorsQueue.concat(this.validationErrors);
    }
  }
  checkForShipToErrors() {
    if (this.shipToLocation.data && this.shipToLocation.data.length === 0) {
      this.pushToErrorsQueue("Request must at least have One Ship To Location.");
    } else if (
      this.shipToLocation.selectedReqType === "Direct Ship" &&
      this.shipToLocation.data.length !== 1
    ) {
      this.pushToErrorsQueue("Please remove additional Ship to Location, Direct Ship requests can only be shipped to 1 location.");
    }
    if (this.shipToLocation.hasDuplicateValues()) {
      this.pushToErrorsQueue("Ship to should not have duplicates");
    }
  }
  checkForProductErrors() {
    if (this.productComponent.products.length) {
      const productErrors = this.productComponent.checkCountOnProduct();
      if (productErrors.length > 0) {
        this.errorsQueue = this.errorsQueue.concat(productErrors);
      }
    } else {
      this.pushToErrorsQueue("Request must at least have One Product.");
    }
  }  


  /* Button Actions */
  onSubmitRequest() {
    this.successPost = false;
    this.closeErrorPopup = false;
    this.currentAlert = [];
    this.resetErrorsQueue();
    this.checkForErrors();
    this.checkErrorQueueOnSubmit();
  }
  onSaveDraft() {
    this.successPost = false;
    this.closeErrorPopup = false;
    this.resetErrorsQueue();
    this.validationErrors = this.createRequisitionComponent.getRequiredErrors(false);
    if (this.validationErrors && this.validationErrors.length) {
      this.errorsQueue = this.errorsQueue.concat(this.validationErrors);
    }
    if (this.errorsQueue.length === 0) {
      this.cancelModal.close();
      this.warningErrorModal.open();
    } else {
      this.scrollWindowUp();
    }
  }
  onCancel() {
    this.cancelModal.open();
  }
  onDelete() {
    this.deleteReqModal.open();
  }
  generatePdf() {
    this.generatingPdf = true;
    let body: any = this.getDataObject();
    let reqMapper = new SubmitResponseMapper();
    let pBody = reqMapper.mapSubmitReqMapper(body);
    this.callSamService(ActionEvents.GENERATE_PDF, pBody);
    this.setBusy(false);
  }
  saveDraft() {
    let body: any = this.setDraftBody();
    this.callSamService(ActionEvents.DRAFT_REQUISITION, body);
  }



  /* Open/Close Modals */
  closeDeleteRequisition() {
    this.deleteReqModal.close();
  }
  confirmDeleteReq() {
    this.callSamService(ActionEvents.DELETE_REQ, this.createRequisitionComponent.reqId);
    this.deleteReqModal.close();
  }
  closeWarning() {
    this.warningErrorModal.close();
  }
  openCancelPopup() {
    this.cancelModal.close();
    //window.location.reload();
    window.location.reload();
  }
  closeCancelPopup() {
    this.cancelModal.close();
  }
  
  changeReqType($event){
    if($event === 'Direct Ship'){
      this.shipToLocation.defaultShipMethod = 'Separate';
      this.productComponent.shipMethodsOptions = ['Separate'];
    }else{
      this.shipToLocation.defaultShipMethod = 'Next';
      this.productComponent.shipMethodsOptions = ['Next','Separate'];
    }
  }

  onCloseBar(item) {
    this.currentAlert = item;
  }

}
