import { StateRepresentationRendererService } from 'usf-sam';
import { Subscription } from "rxjs";
import { OnDestroy } from '@angular/core';

export class BaseComponent implements OnDestroy {

    subscriptions: any = [];

    constructor(readonly renderer: StateRepresentationRendererService) {
    }

    registerStateChangeEvents(stateChangeHandlerMap: any) {
        for (let eventType in stateChangeHandlerMap) {
            let subscription = this.renderer.register(eventType, stateChangeHandlerMap[eventType]);
            this.subscriptions.push(subscription);
        }
    }

    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => {
            subscription.unsubscribe();
        });
    }
}