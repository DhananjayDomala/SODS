import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchOlderRequestComponent } from './search-older-request.component';

describe('SearchOlderRequestComponent', () => {
  let component: SearchOlderRequestComponent;
  let fixture: ComponentFixture<SearchOlderRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchOlderRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchOlderRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
