import {
  Component,
  OnInit,
  EventEmitter,
  Output,
  OnDestroy
} from '@angular/core';
import {
  OPERATOROPTIONS,
  VALUEOPTIONS,
  SORTBYOPTIONS,
  PAGEOPTIONS,
  DEFAULTSORTBYOPTION,
  DEFAULTPAGEOPTION,
  VALUEMAP
} from '../../../common/options/options';
import { SearchRequest, Parameter } from '../../../../model/searchRequisition';
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from 'usf-sam/dist/usf-sam';
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from 'app/events/action-events';
import { BaseComponent } from 'app/democomponents/base-component';
import { Input, ViewChild } from '@angular/core';
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";
import { USFCalendarSettings } from '../../../common/calendar/calendar.component';
import { USFTextField } from 'app/democomponents/common/text-field/text-field.component';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-search-custom-filter',
  templateUrl: './search-custom-filter.component.html',
  styleUrls: ['./search-custom-filter.component.css']
})
export class SearchCustomFilterComponent extends BaseComponent
  implements OnInit, OnDestroy {
  @Output() searchRequisitions = new EventEmitter<any>();
  @ViewChild('testing') testing;
  // expand/collapse
  isCollapsed = false;
  menuHeight = '350';

  //sorting
  sortByOptions: string[];
  selectedSortByOption: string;
  defaultSortByOption: string;
  isAscending: boolean;

  //pagination
  pageOptions: string[];
  selectedPage: string;
  defaultPage: string;

  // for validation
  invalidFilters: number[] = new Array<number>();

  @Input() requestOption: string;
  @Output() changePageOption = new EventEmitter();
  @Output() changeSortByOption = new EventEmitter();
  @Output() changeAscendingOption = new EventEmitter();
  @Output() searchRequisition = new EventEmitter();

  request: SearchRequest;
  filters: Filter[] = [];
  excludeComplete = true;

  // validation
  public dateValid = true;
  public date_selection_error: boolean = false;

  // for calendar
  public calendarSettings: USFCalendarSettings = {
    value: new Date(),
    // minDate: new Date(-8640000000000000),
    // maxDate: new Date(),
    width: '170',
    smBtn: false,
    error: false,
    inputStyleClass: ['calendar-input-170'],
    styleClass: ['calendar-component']
  };

  // public selectedDate: Date = new Date();
  // public minDate: Date = new Date(-8640000000000000);
  // public maxDate: Date;
  // public calendarInputWidth: '170';

  //view child
  @ViewChild('SORTBY') sortByDropdown: DropdownComponent;
  @ViewChild('PAGE') pageDropdown: DropdownComponent;

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService
  ) {
    super(stateRepresentationRendererService);
    const mapping: any = [];
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    const filter = new Filter();
    this.filters.push(filter);

    this.onFieldOptionSelected(Object.keys(VALUEOPTIONS)[0], 0);
    //poplate the sort dropdown
    this.initSortByDropDown();

    // Get the Requistion Details For Approvals
    let searchRequest: SearchRequest = new SearchRequest();
    searchRequest.parameters = new Array<Parameter>();
  }

  addFilter() {
    if (this.filters.length < 11) {
      const filter = new Filter();
      filter.fieldOptions = Object.keys(OPERATOROPTIONS).sort();
      this.filters.push(filter);
      this.onFieldOptionSelected(
        Object.keys(OPERATOROPTIONS).sort()[0],
        this.filters.length - 1
      );
    }
  }

  removeFilter(index: number) {
    this.filters.splice(index, 1);
  }

  onFieldOptionSelected($event: string, index: number) {
    this.filters[index] = new Filter();
    this.filters[index].operatorOptions = OPERATOROPTIONS[$event].sort();
    this.filters[index].valueOptions = VALUEOPTIONS[$event];
    this.filters[index].parameters.field = $event;
    this.filters[index].parameters.operator = OPERATOROPTIONS[$event][0];
    this.filters[index].parameters.value = this.getValueOptions(
      VALUEOPTIONS[$event][0]
    );
    this.filters[index].txtFieldSetting.validationType = this.filters[index].parameters.value;
    this.filters[index].type = (this.filters[index].parameters.value === 'integer' || this.filters[index].parameters.value === 'string') ? 'textField' : 'nonTextField';
  }

  getSelectedOperator(index: number) {
    return (
      this.filters[index].parameters.operator ||
      this.filters[index].operatorOptions[0]
    );
  }

  getValueOptions(options) {

    return options === 'date'
      ? Filter.getDateFormat(new Date())
      : options;
  }

  getDefaultSelectedValue(index: number) {
    return this.filters[index].valueOptions[0];
  }

  isTextFieldInput(index: number) {
    return (
      this.filters[index].valueOptions[0] === 'integer' || this.filters[index].valueOptions[0] === 'string'
    );
  }

  isDropDownInput(index: number) {
    return (
      this.filters[index].valueOptions.length > 0 &&
      this.filters[index].valueOptions[0] !== 'date'
      && this.filters[index].valueOptions[0] !== 'integer'
      && this.filters[index].valueOptions[0] !== 'string'
    );
  }

  isDateInput(index: number) {
    return (
      this.filters[index].valueOptions.length > 0 &&
      this.filters[index].valueOptions[0] === 'date'
    );
  }

  onDateSelectionDone($event, index: number): void {
    this.calendarSettings.value = $event;
    this.date_selection_error = false;
    this.filters[index].add(
      this.filters[index].parameters.field,
      this.filters[index].parameters.operator,
      Filter.getDateFormat(this.calendarSettings.value)
    );
    this.filters[index].valid = true;
  }

  onOperatorSelectionDone($event, index: number): void {
    console.log($event);
    this.filters[index].parameters.operator = $event;
    this.filters[index].parameters.value = VALUEOPTIONS[0];
  }

  onMenuValueSelectionDone($event, index: number): void {
    console.log($event);
    this.filters[index].add(
      this.filters[index].parameters.field,
      this.filters[index].parameters.operator,
      $event
    );
    this.filters[index].valid = true;
  }

  onErrorHandler($event) {
    this.date_selection_error = true;
    if ($event !== 'error') {
      this.date_selection_error = false;
    }
  }

  formatRequest(): any {
    this.request = new SearchRequest();
    this.request.parameters = new Array<Parameter>();
    this.filters.forEach(filter => {
      let parameters = new Parameter();
      parameters.field = filter.parameters.field;
      parameters.operator = filter.operatorMap[filter.parameters.operator];
      parameters.value =
        filter.parameters.value === 'Special Order' ||
        filter.parameters.value === 'Direct Ship Order'
          ? filter.requisitionTypeMap[filter.parameters.value]
          : filter.parameters.value;
      console.log(parameters.value);
      if (!parameters.value || parameters.value === 'integer' || parameters.value === 'string') {
        parameters.value = filter.txtFieldSetting.value;
      }

      if(!parameters.value) {
        parameters.value = Filter.getDateFormat(new Date());
      }
      this.request.parameters.push(parameters);
    });
    //need to add a logic to filter out the requisition with delete status
    this.filterOutDeleteReq();
    this.request.operand = this.filters.length > 1 ? 'AND' : '';
    this.request.networkID = localStorage.username;
    this.request.division = '';
    this.request.excludeComplete = this.excludeComplete ? 'Y' : 'N';
    return this.request;
  }

  filterOutDeleteReq(){
    let parameter = new Parameter();
    parameter.field = 'Requisition Status';
    parameter.operator = '!=';
    parameter.value = 'Delete';
    this.request.parameters.push(parameter);
  }

  onExcludeCompleteClick() {
    this.excludeComplete = !this.excludeComplete;
  }

  onBlurValueField($event, i) {
    let value = $event.target.value;
    this.filters[i].valid = value.length > 0;
  }

  onSearchBtnClick() {

    // validate filters
    if (this.isValidFilters()) {
      // collapse filters
      this.collapse();
      // reset the sort by option
      this.resetFilter();
      // Create search request object
      const requestBody = this.formatRequest();
      this.searchRequisition.emit({ body: requestBody });
    } else {
      alert(this.isValidFilters());
    }

  }

  resetFilter(){
    this.sortByDropdown.selectedOption = DEFAULTSORTBYOPTION;
    this.pageDropdown.selectedOption = '10';
    this.isAscending = false;
  }

  isValidFilters() {
    let invalidFilters = this.filters.filter((e) => e.type === 'textField' ? e.valid === false || e.txtFieldSetting.value === '' : e.valid === false);
    return invalidFilters.length === 0;
  }

  onSortBySelection(event) {
    //need to do mapping for the option and value
    this.selectedSortByOption = event;
    let sortByOption = VALUEMAP.SORTBY[event];
    this.changeSortByOption.emit(sortByOption);
  }

  onPageSelection(event) {
    this.changePageOption.emit(event);
  }

  initSortByDropDown() {
    this.isAscending = false;
    this.defaultPage = DEFAULTPAGEOPTION;
    this.selectedSortByOption = DEFAULTSORTBYOPTION;
    this.defaultSortByOption = DEFAULTSORTBYOPTION;
    this.sortByOptions = SORTBYOPTIONS;
    this.pageOptions = PAGEOPTIONS;
  }

  changeAscending() {
    this.isAscending = !this.isAscending;
    let sortByOption = VALUEMAP.SORTBY[this.selectedSortByOption];
    this.changeAscendingOption.emit({
      isAscending: this.isAscending,
      selectedSortOption: sortByOption
    });
  }

  expand() {
    this.isCollapsed = false;
  }

  collapse() {
    this.isCollapsed = true;
  }

  validateTextField($event, index) {
    this.filters[index].valid = $event.valid;
    this.filters[index].txtFieldSetting.valid = $event.valid;
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}

export class Filter {
  fieldOptions: string[] = Object.keys(OPERATOROPTIONS).sort();
  operatorOptions: string[] = [];
  valueOptions: string[] = [];
  type: string;
  txtFieldSetting: USFTextField;
  valid = true;
  parameters: Parameter = new Parameter();

  operatorMap: any = {
    Equals: '=',
    'Not Equal': '!=',
    Contains: 'LIKE',
    'Greater than': '>',
    'Less than': '<',
    'Greater than equal to': '>=',
    'Less than equal to': '<='
  };

  requisitionTypeMap: any = {
    'Special Order': 'SODS-SO',
    'Direct Ship Order': 'SODS-DS'
  };

  static getDateFormat(date: Date) {
    let d = '';
    d +=
      date.getMonth() + 1 <= 9
        ? '0' + (date.getMonth() + 1)
        : date.getMonth() + 1;
    d += '/' + date.getDate();
    d += '/';
    d += date.getFullYear();
    return d;
  }

  static createTextField(type: string): USFTextField {
    return {
      width: '170',
      height: '36',
      marginLeft: '0',
      marginRight: '0',
      required: true,
      valid: true,
      validationType: type,
      errorText: 'Please enter a valid number.',
      value: '',
      id: '',
      disabled: true
    };
  }

  constructor() {
    this.parameters.field = Object.keys(VALUEOPTIONS).sort()[0];
    this.parameters.operator = OPERATOROPTIONS[0];
    this.parameters.value = '';
    this.txtFieldSetting = Filter.createTextField('integer');
    this.valid = true;
    this.type = 'textField';
  }

  add(field: string, operator: string, value: string) {
    console.log(value);
    this.parameters.field = field;
    this.parameters.operator = operator;
    this.parameters.value =
      value === 'date' ? Filter.getDateFormat(new Date()) : value;
    this.valid = true;
  }
}
