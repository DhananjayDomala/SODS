import {
  Component,
  OnInit,
  EventEmitter,
  Output,
  OnDestroy
} from '@angular/core';
import {
  OPERATOROPTIONS,
  VALUEOPTIONS,
  SORTBYOPTIONS,
  PAGEOPTIONS,
  DEFAULTSORTBYOPTION,
  DEFAULTPAGEOPTION,
  VALUEMAP
} from '../../../common/options/options';
import { SearchRequest, Parameter } from '../../../../model/searchRequisition';
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from 'usf-sam/dist/usf-sam';
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from 'app/events/action-events';
import { BaseComponent } from 'app/democomponents/base-component';
import { Input } from '@angular/core';

@Component({
  selector: 'app-search-custom-filter',
  templateUrl: './search-custom-filter.component.html',
  styleUrls: ['./search-custom-filter.component.css']
})
export class SearchCustomFilterComponent extends BaseComponent
  implements OnInit, OnDestroy {
  @Output() searchRequisitions = new EventEmitter<any>();
  // expand/collapse
  isCollapsed = false;
  menuHeight = '350';

  //sorting
  sortByOptions: string[];
  selectedSortByOption: string;
  defaultSortByOption: string;
  isAscending: boolean;

  //pagination
  pageOptions: string[];
  selectedPage: string;
  defaultPage: string;

  @Input() requestOption: string;
  @Output() changePageOption = new EventEmitter();
  @Output() changeSortByOption = new EventEmitter();
  @Output() changeAscendingOption = new EventEmitter();
  @Output() searchRequisition = new EventEmitter();

  request: SearchRequest;
  filters: Filter[] = [];
  excludeComplete = true;

  // validation
  public dateValid = true;
  public date_selection_error: boolean = false;

  // for calendar
  public selectedDate: Date = new Date();
  public minDate: Date = new Date();
  public maxDate: Date;
  public calendarInputWidth: '170';

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService
  ) {
    super(stateRepresentationRendererService);
    const mapping: any = [];
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    const filter = new Filter();
    this.filters.push(filter);

    this.onFieldOptionSelected(Object.keys(VALUEOPTIONS)[0], 0);
    //poplate the sort dropdown
    this.initSortByDropDown();

    // Get the Requistion Details For Approvals
    let searchRequest: SearchRequest = new SearchRequest();
    searchRequest.parameters = new Array<Parameter>();
  }

  addFilter() {
    if (this.filters.length < 11) {
      const filter = new Filter();
      filter.fieldOptions = Object.keys(OPERATOROPTIONS).sort();
      this.filters.push(filter);
      this.onFieldOptionSelected(
        Object.keys(OPERATOROPTIONS).sort()[0],
        this.filters.length - 1
      );
    }
  }

  removeFilter(index: number) {
    this.filters.splice(index, 1);
  }

  onFieldOptionSelected($event: string, index: number) {
    this.filters[index] = new Filter();
    this.filters[index].operatorOptions = OPERATOROPTIONS[$event].sort();
    this.filters[index].valueOptions = VALUEOPTIONS[$event];
    this.filters[index].parameters.field = $event;
    this.filters[index].parameters.operator = OPERATOROPTIONS[$event][0];
    this.filters[index].parameters.value = this.getValueOptions(
      VALUEOPTIONS[$event][0]
    );
  }

  getSelectedOperator(index: number) {
    return (
      this.filters[index].parameters.operator ||
      this.filters[index].operatorOptions[0]
    );
  }

  getValueOptions(options) {
    return options === 'date'
      ? Filter.getDateFormat(new Date())
      : options;
  }

  getDefaultSelectedValue(index: number) {
    return this.filters[index].valueOptions[0];
  }

  isTextFieldInput(index: number) {
    return (
      this.filters[index].valueOptions.length === 0 &&
      this.filters[index].valueOptions[0] !== 'date'
    );
  }

  isDropDownInput(index: number) {
    return (
      this.filters[index].valueOptions.length > 0 &&
      this.filters[index].valueOptions[0] !== 'date'
    );
  }

  isDateInput(index: number) {
    return (
      this.filters[index].valueOptions.length > 0 &&
      this.filters[index].valueOptions[0] === 'date'
    );
  }

  onDateSelectionDone($event, index: number): void {
    this.selectedDate = $event;
    this.date_selection_error = false;
    this.filters[index].add(
      this.filters[index].parameters.field,
      this.filters[index].parameters.operator,
      Filter.getDateFormat(this.selectedDate)
    );
  }

  onTextInputDone($event, index: number): void {
    this.filters[index].add(
      this.filters[index].parameters.field,
      this.filters[index].parameters.operator,
      $event
    );
  }

  onOperatorSelectionDone($event, index: number): void {
    console.log($event);
    this.filters[index].parameters.operator = $event;
    this.filters[index].parameters.value = VALUEOPTIONS[0];
  }

  onMenuValueSelectionDone($event, index: number): void {
    console.log($event);
    this.filters[index].add(
      this.filters[index].parameters.field,
      this.filters[index].parameters.operator,
      $event
    );
  }

  onErrorHandler($event) {
    this.date_selection_error = true;
    if ($event !== 'error') {
      this.date_selection_error = false;
    }
  }

  formatRequest(): any {
    this.request = new SearchRequest();
    this.request.parameters = new Array<Parameter>();
    this.filters.forEach(filter => {
      let parameters = new Parameter();
      parameters.field = filter.parameters.field;
      parameters.operator = filter.operatorMap[filter.parameters.operator];
      parameters.value =
        filter.parameters.value === 'Special Order' ||
        filter.parameters.value === 'Direct Ship Order'
          ? filter.requisitionTypeMap[filter.parameters.value]
          : filter.parameters.value;
      console.log(parameters.value);
      this.request.parameters.push(parameters);
    });
    this.request.operand = this.filters.length > 1 ? 'AND' : '';
    this.request.networkID = localStorage.username;
    this.request.division = '';
    this.request.excludeComplete = this.excludeComplete ? 'Y' : 'N';
    return this.request;
  }

  onExcludeCompleteClick() {
    this.excludeComplete = !this.excludeComplete;
  }

  onBlurValueField($event, i) {
    let value = $event.target.value;
    this.filters[i].valid = value.length > 0;
  }

  onSearchBtnClick() {

    // validate filters
    let valid = this.isValidFilters();
    if (valid) {
      // collapse filters
      this.collapse();
      // Create search request object
      const requestBody = this.formatRequest();
      this.searchRequisition.emit({ body: requestBody });
    }
  }

  isValidFilters() {
    let isValid = true;
    let i = 0;
    while(i < this.filters.length && isValid) {
      isValid = this.filters[i].valid;
      i++;
    }

    return isValid;
  }

  onSortBySelection(event) {
    //need to do mapping for the option and value
    this.selectedSortByOption = event;
    let sortByOption = VALUEMAP.SORTBY[event];
    this.changeSortByOption.emit(sortByOption);
  }

  onPageSelection(event) {
    this.changePageOption.emit(event);
  }

  initSortByDropDown() {
    this.isAscending = false;
    this.defaultPage = DEFAULTPAGEOPTION;
    this.selectedSortByOption = DEFAULTSORTBYOPTION;
    this.defaultSortByOption = DEFAULTSORTBYOPTION;
    this.sortByOptions = SORTBYOPTIONS;
    this.pageOptions = PAGEOPTIONS;
  }

  changeAscending() {
    this.isAscending = !this.isAscending;
    let sortByOption = VALUEMAP.SORTBY[this.selectedSortByOption];
    this.changeAscendingOption.emit({
      isAscending: this.isAscending,
      selectedSortOption: sortByOption
    });
  }

  expand() {
    this.isCollapsed = false;
  }

  collapse() {
    this.isCollapsed = true;
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}

export class Filter {
  fieldOptions: string[] = Object.keys(OPERATOROPTIONS).sort();
  operatorOptions: string[] = [];
  valueOptions: string[] = [];
  valid = false;;
  parameters: Parameter = new Parameter();

  operatorMap: any = {
    Equals: '=',
    'Not Equal': '!=',
    Contains: 'LIKE',
    'Greater than': '>',
    'Less than': '<',
    'Greater than equal to': '>=',
    'Less than equal to': '<='
  };

  requisitionTypeMap: any = {
    'Special Order': 'SODS-SO',
    'Direct Ship Order': 'SODS-DS'
  };

  static getDateFormat(date: Date) {
    let d = '';
    d +=
      date.getMonth() + 1 <= 9
        ? '0' + (date.getMonth() + 1)
        : date.getMonth() + 1;
    d += '/' + date.getDate();
    d += '/';
    d += date.getFullYear();
    return d;
  }

  constructor() {
    this.parameters.field = Object.keys(VALUEOPTIONS).sort()[0];
    this.parameters.operator = OPERATOROPTIONS[0];
    this.parameters.value = '';
    this.valid = true;
  }

  add(field: string, operator: string, value: string) {
    this.parameters.field = field;
    this.parameters.operator = operator;
    this.parameters.value =
      value === 'date' ? Filter.getDateFormat(new Date()) : value;
    this.valid = false;
  }
}
