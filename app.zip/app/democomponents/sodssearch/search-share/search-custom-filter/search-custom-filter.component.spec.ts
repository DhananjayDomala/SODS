import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchCustomFilterComponent } from './search-custom-filter.component';

describe('SearchCustomFilterComponent', () => {
  let component: SearchCustomFilterComponent;
  let fixture: ComponentFixture<SearchCustomFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchCustomFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchCustomFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
