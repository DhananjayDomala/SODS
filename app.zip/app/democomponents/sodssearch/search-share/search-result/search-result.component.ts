import { setTimeout } from 'timers';
import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { BaseComponent } from "app/democomponents/base-component";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { SearchRequisitions, SearchRequisition } from "app/model/searchRequisition";
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam/dist/usf-sam";
import { ModelChangeUpdateEvents, ActionEvents } from "app/events/action-events";
import { PaginationInstance } from "ngx-pagination/dist/ngx-pagination";
import { DEFAULTPAGEOPTION } from "app/democomponents/common/options/options";
import { debug } from 'util';
import { SamService } from "app/service/sam.service";

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent extends BaseComponent implements OnInit, OnChanges {

  // For Loading Indicator
  public loading = false;

  sortByOption: string;

  public searchRequisitions: Array<SearchRequisition>;
  //pagination
  p: number = 1;
  public config: PaginationInstance = {
    id: 'custom',
    itemsPerPage: parseInt(DEFAULTPAGEOPTION),
    currentPage: 1
  };

  //sorting
  isDesc = true;
  column = 'reqID';
  direction: number;
  isAscending: boolean;
  public searchType: string;

  // flag for searchResults
  hasSearchResults = false;
  
  constructor(readonly actionDispatcherService: ActionDispatcherService,
    private samService: SamService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService, public activeRoute:ActivatedRoute, public router:Router) {
      super(stateRepresentationRendererService); 
      const mapping: any = [];
      mapping[ModelChangeUpdateEvents.SEARCH_REQUISITION_SUCCESS] = (
        searchRequisitions: SearchRequisitions
      ) => {
        
        this.renderSearchRequisitionSuccess(searchRequisitions);
      };
      super.registerStateChangeEvents(mapping);
      this.getSearchType();
    }

  ngOnInit() {
    this.searchRequisitions = new Array<SearchRequisition>();
  }

  getSearchType() {
    let url = this.router.url;
    if(url === '/search' || url === '/search/myOpenRequest') {
      this.searchType = 'Open Requests';
    }
    if(url === '/search/olderRequest') {
      this.searchType = 'Open 30';
    }
    if(url === '/search/customSearch') {
      this.searchType = 'Custom Search';
    }
  }

  ngOnChanges() {
  }

  renderSearchRequisitionSuccess(searchRequisitions: SearchRequisitions){
    this.searchRequisitions = searchRequisitions.requisitions;
    this.sort('reqID');
    this.loading = false;
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  sort(property) {
    this.isDesc = !this.isDesc; //change the direction    
    this.column = property;
    this.direction = this.isAscending? 1: -1;
  };

  exportSearchResults() { 
    this.setBusy(true);
    let exportSearch = this.actionDispatcherService.generateEvent(ActionEvents.SEARCH_EXPORT_EXCEL, {searchResult: this.searchRequisitions, searchType: this.searchType});
    this.actionDispatcherService.dispatch(exportSearch);
    setTimeout(() => { this.setBusy(false); }, 1000);
  }

  isSearchResult() {
    return this.searchRequisitions.length > 0;
  }

  noResults() {
    return this.searchRequisitions[0].reqID === '';
  }

  openReqDetails(reqId: any) {
    this.router.navigate(["/search/request-details", reqId]);
  }
  setBusy(status: boolean) {
    this.callSamService(ActionEvents.SET_BUSY_STATUS, status);
  }
  callSamService(eventTypeName: string, data: any) {
    this.samService.callAction(eventTypeName, data);
  }

}