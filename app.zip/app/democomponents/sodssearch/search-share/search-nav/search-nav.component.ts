import { Component, OnInit } from '@angular/core';
import { BREADCRUMBS } from "app/democomponents/common/breadcrumb/breadcrumbs";

@Component({
  selector: 'app-search-nav',
  templateUrl: './search-nav.component.html',
  styleUrls: ['./search-nav.component.css']
})
export class SearchNavComponent implements OnInit {

  public breadcrumbs = BREADCRUMBS["search"];

  constructor() { }

  ngOnInit() {
  }

}
