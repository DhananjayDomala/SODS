import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDesignateComponent } from './search-designate.component';

describe('SearchDesignateComponent', () => {
  let component: SearchDesignateComponent;
  let fixture: ComponentFixture<SearchDesignateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDesignateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDesignateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
