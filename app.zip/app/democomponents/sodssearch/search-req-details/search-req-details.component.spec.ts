import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchReqDetailsComponent } from './search-req-details.component';

describe('SearchReqDetailsComponent', () => {
  let component: SearchReqDetailsComponent;
  let fixture: ComponentFixture<SearchReqDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchReqDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchReqDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
