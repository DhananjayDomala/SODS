import { ModelChangeUpdateEvents, ActionEvents } from 'app/events/action-events';
import { SubmitResponseMapper } from './../../util/submitRequest-mapper';
import { BREADCRUMBS } from 'app/democomponents/common/breadcrumb/breadcrumbs';
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam";
import { BaseComponent } from 'app/democomponents/base-component';
import { SearchResultComponent } from "app/democomponents/sodssearch/search-share/search-result/search-result.component";
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from "@angular/router";
import { DivisionsService } from "../../../service/divisions.service";
import { ReqDetails } from '../../../model/submitRequisition';
import { Division } from "../../../model/division";
import { User } from '../../../model/user';

@Component({
  selector: 'app-search-req-details',
  templateUrl: './search-req-details.component.html',
  styleUrls: ['./search-req-details.component.css']
})
export class SearchReqDetailsComponent extends BaseComponent implements OnInit {
  public breadcrumbs = {};
  products: any;
  public reqDetails: ReqDetails = new ReqDetails();
  reqId = '';
  public collapsed: boolean[] = new Array<boolean>();
  public allCollapsed = false;
  public reqDetailsArray: any[] = new Array<any>();
  requisitionType: any;
  public market: string;
  public requisitionComments: any[];
  isDataLoading = true;
  searchTaskId: string;
  recallAllowed = false;
  copyRequestAllowed = false;
  viewPdfAllowed = false;

  constructor(readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    private divisionsService: DivisionsService,
  private activatedRoute: ActivatedRoute,
  private user: User,
  private router: Router) {
    super(stateRepresentationRendererService);

    const mapping: any = [];
      mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_BY_ID_SUCCESS] = (
        data: ReqDetails
      ) => {
        this.renderGetReqDetailsSuccess(data);
      };
      mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (
        data: any
      ) => {
        this.renderDivisionsForRoleSearch(data);
      };
      mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL] = (
        data: any
      ) => {
        this.renderDivisionsForRoleSearchFail(data);
      };
      mapping[ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_SUCCESS] = (
      commentsList: any
    ) => {
      this.renderRetrieveCommentsSuccess(commentsList);
    };
    mapping[ModelChangeUpdateEvents.RECALL_REQUISITION_SUCCESS] = () => {this.goToTaskInbox()};
    mapping[ModelChangeUpdateEvents.RECALL_REQUISITION_FAIL] = () => {};
      super.registerStateChangeEvents(mapping);
   }
  

  ngOnInit() {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

    this.breadcrumbs = BREADCRUMBS["specialOrder"];

    this.reqId =
      this.activatedRoute.snapshot.params["id"].trim() || "";
    if (this.reqId) {
      this.isDataLoading = true;
      // Get the Requistion Details For Approvals
      this.getRequisitionDetails();
    }
    this.collapsed = [false, false, false, false, false];
  }

  renderGetReqDetailsSuccess(data: ReqDetails){
    this.reqDetails = data;
    this.reqDetailsArray.push(data);
    this.requisitionType = this.reqDetails.requisition.requisitionType;
    this.requisitionComments = this.reqDetails.requisition.comments;
    this.products = this.reqDetails.products;
    this.getDivisions();
    const key = (this.requisitionType === 'Special Order') ? 'specialOrder' : 'directOrder';
    this.breadcrumbs = BREADCRUMBS[key];
    this.isDataLoading = false;
    this.viewPdfAllowed = true;
    this.recallButtonEnabling();
    this.checkIfCopyAllowed(this.reqDetails.requisition.division);
    this.getComments();
    this.setBusyStatus(false);
  }

  setBusyStatus(status: boolean){
    const event1 = this.actionDispatcherService.generateEvent(
      ActionEvents.SET_BUSY_STATUS, status
  );
    this.actionDispatcherService.dispatch(event1); 
  }

  checkIfCopyAllowed(division: string) {
     let array = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).applicationMarkets;
     let marketOptions = [];
     let divAllowed: boolean = false;
     if(array != null) {
      array.forEach(element => {
        if(element.marketNum == division) {
          divAllowed = true;
          return;
        }
      });
     }
    if(divAllowed) {
      if(this.user.isMemberOf(["SODS-USER"])) {
        this.copyRequestAllowed = true;
      } else {
        this.copyRequestAllowed = false;
      }
    }
  }
   isMemberOf(allowedRole: string) {
     let roles = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userRoles;
     for(let i = 0; i < roles.length; i++) {
       if(roles[i].indexOf('-SODS-USER') !== -1) {
         if(allowedRole.indexOf('-SODS-USER') !== -1) {
           return true;
         }
       }else{
         return false;
       }
     }
   }

  recallButtonEnabling() {
    let loggedInUserId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
    let reqUserId = this.reqDetails.requestor.networkID;
    let status = this.reqDetails.requisition.status;
    if(loggedInUserId === reqUserId && (status === 'Pending Product/Vendor Setup' || status === 'Pending Credit Review' || status === 'Pending Approval' || status === 'Pending Buyer')) {
      this.recallAllowed = true;
    }
  }

  getDivisions() {
    // Make an api call to get the division codes for later screens
    const getDivisionsEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH,
      { data: "" }
    );
    this.actionDispatcherService.dispatch(getDivisionsEvent);
  }

  renderDivisionsForRoleSearch(divResponse) {
    this.divisionsService.setDivisions(divResponse);
    let markets: Division[] = this.findInArray(
      this.divisionsService.getDivisions(),
      "divisionNumber",
      Number(this.reqDetails.requisition.division)
    );
    this.market =
      markets[0].divisionName +
      " (" +
      markets[0].divisionCode +
      ", " +
      markets[0].divisionNumber +
      ")";
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter(obj => {
      return obj[property] === value;
    });
  }

  renderDivisionsForRoleSearchFail(response) {
    // this.showAlertMessage("error", "divisionDownloadFailed");
  }

  getComments() {
    let event = this.actionDispatcherService.generateEvent(
      ActionEvents.RETRIEVE_COMMENT_INBOX,
      this.reqDetails.requisition.requisitionNumber
    );
    this.actionDispatcherService.dispatch(event);
  }

  renderRetrieveCommentsSuccess(commentsList: any) {
    this.requisitionComments = commentsList;
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
  }

  getRequisitionDetails() {
    const getReqDetails = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_REQ_DETAILS_BY_ID,
      { reqId: this.reqId, networkID: localStorage.username }
    );
    this.actionDispatcherService.dispatch(getReqDetails);

  }

  expandAll() {
    this.allCollapsed = false;
    this.collapsed = [false, false, false, false, false];
  }

  collapseAll() {
    this.allCollapsed = true;
    this.collapsed = [true, true, true, true, true];
  }

  toggleSection(index: number) {
    this.collapsed[index] = !this.collapsed[index];
  }

  copyRequisition() {
    this.router.navigate(['/sodsnew'], { queryParams: { searchReqId: this.reqId} })
  }

  recallRequisition() {
    let event = this.actionDispatcherService.generateEvent(ActionEvents.RECALL_RQUISITION, {reqId: this.reqId});
    this.actionDispatcherService.dispatch(event);
  }

  goToTaskInbox() {
    this.router.navigate(['/taskInbox']);
  }

  generatePdf() {
      let body: any = this.reqDetails;
      let reqMapper = new SubmitResponseMapper();
      let pBody = reqMapper.mapSubmitReqMapper(body);
      let event = this.actionDispatcherService.generateEvent(ActionEvents.GENERATE_PDF, pBody);
      this.actionDispatcherService.dispatch(event);
  }
}
