import { BaseComponent } from './../../../../base-component';
import { ModelChangeUpdateEvents, ActionEvents } from './../../../../../events/action-events';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { Component, OnInit, ViewChild, Input, Output, SimpleChanges, EventEmitter } from '@angular/core';
import { TaskInboxProduct } from '../../../../../model/submitRequisition';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails } from '../../../../../model/submitRequisition';
import { Comment, SAMPLECommentA, SAMPLECommentB } from '../../../../../model/comment';


import { ProductCommentComponent } from '../../../../common/comment/product-comment/product-comment.component';

@Component({
  selector: 'sods-so-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class SOProductsComponent extends BaseComponent implements OnInit {

  @ViewChild('viewComments') viewMsgsToModal: Modal;
  @ViewChild('viewProduct') viewProdModal: Modal;
  @ViewChild('ProductComments') productComments: ProductCommentComponent;
  @ViewChild('ProductAttachmentModal') productAttachmentModal: Modal;

  public newAddFlag: boolean = false;
  public productSeq: number;
  public newAddedCount: number = 0;
  public data: any = [];
  public attachmentsList:Array<any> = [];
  private textareaLength: number = 1000;
  maxIncidentDescriptionLength: any = 1000;
  //validation for comment
  public commentErr: boolean = false;
  isAllReturned: boolean;
  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }
  @Input() shipToLocations: any;

  @Input() set allReturned(value: boolean) {
    this.isAllReturned = value;
  }

  @Input() invalidProducts: number[];

  @Input() products: TaskInboxProduct[];
  @Input() reqDetails: ReqDetails;
  requistionDetails: ReqDetails;
  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();
  @Output('return')
  return: EventEmitter<any> = new EventEmitter<any>();
  @Output('returnAll')
  returnAll: EventEmitter<any> = new EventEmitter<any>();
  @Output('addComment')
  addComment: EventEmitter<any> = new EventEmitter<any>();

  isCollapsed: boolean;
  comments: any[] = [];
  selectedIndex: any;
  currentProd: any;
  productCommentAdded: boolean[] = new Array<boolean>();
  isReturnAll: boolean = false;
  allChecked = false;
  public reqNbr: string;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];           
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => { this.renderAttachmentDetails(data) }
    super.registerStateChangeEvents(mapping);
  }
  
  ngOnInit() {
    // this is to keep track of when a new comment is added to a product
    this.products = this.products.map((product) => {
      this.productCommentAdded.push(false);
      product.shipTodistribution = product.shipTodistribution.map((item) => {
        item.customer = this.reqDetails.customers.find((c) => c.id == item.customerId ) || {};
        return item;
      })
      return product;
    });
    console.log(this.products);
    this.productComments.isHide = true;
  }
  

  ngOnChanges(changes: SimpleChanges) {
    if(changes.allReturned) {
      this.allChecked = changes.allReturned.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

  openViewComments(comments, index) {
    this.selectedIndex = index;
    this.comments = [...comments] || [];
    // if (!comments.length) {
    //   return;
    // }

    this.viewMsgsToModal.open();
    this.productComments.newAddedCount = 0;
    this.productComments.comments = this.comments;
    this.productComments.productSeq = index + 1;
  }

  openProd(product) {
    this.currentProd = product;
    this.viewProdModal.open();
  }

  closeMsgModal() {
    if (this.productComments.newAddFlag === true) {
      //cancel without saving so clear out the first item of the comments array
      for (let i = 0; i < this.productComments.newAddedCount; i++) {
        this.productComments.comments.shift();
      }
      //reset the add flag
      this.productComments.newAddFlag = false;
    }
    //clear error
    this.productComments.commentErr = false;
    this.viewMsgsToModal.close();
  }

  closeProdModal() {
    this.viewProdModal.close();
  }

  toggleReturnAll() {
    this.allChecked = !this.allChecked;
    this.returnAll.emit({ 'products': this.products, 'returned': this.allChecked });
  }

  returnProduct(product: TaskInboxProduct) { 
    this.return.emit({ 'product': product });
    let productIndex = this.products.findIndex((x) => x.seq === product.seq);
    // check to see if comment exists for product
    if (this.products[productIndex].returned) {
      if (this.isCommentAddedToProduct(productIndex)) {

      } else {
        // Open a modal to add a new comment to the product
        this.openViewComments(product.comments, productIndex);
      }
    }
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter((obj) => {
      return obj[property] === value;
    });
  }

  isCommentAddedToProduct(productIndex: number) {
    return this.productCommentAdded[productIndex] === true;
  }

  //save Comment
  saveComment() {
    //validation first
    if (this.productComments.commentErr === true) {
      return;
    }
    //if user does not hit add, just close it
    if (this.productComments.newAddFlag === false) {
      this.viewMsgsToModal.close();
    } else {
      this.productComments.newAddFlag = false;
      //save to comments array of product element
      this.products.forEach((product, index) => {
        if (product.seq === this.productComments.productSeq) {
          //will need to remove the empty text on the first element
          if (this.productComments.comments[0].commentsText === '') {
            this.productComments.comments.shift();
          }
          product.comments = this.productComments.comments;
          this.productCommentAdded[this.selectedIndex] = true;
          this.addComment.emit({'product': this.products[this.selectedIndex]});
        }
      });
      this.viewMsgsToModal.close();
    }
  }

  isInvalid(index): boolean {
    let invalidIndex = 0;
    this.invalidProducts.forEach((invalid) => {
      if (index === invalid) {
        invalidIndex++;
      }
    });
    return invalidIndex > 0;
  }

  renderAttachmentDetails(data) {
    this.attachmentsList = data;
  }


  cancelProductAttchment(){
    this.productAttachmentModal.close();
  }

}
