import { DropdownComponent } from 'app/democomponents/common/dropdown/dropdown.component';
import { Observable } from 'rxjs/Rx';
import { ModelChangeUpdateEvents } from './../../../../events/action-events';
import { ObjectKey } from './../../../../model/objectKey';
import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';

import { BaseComponent } from '../../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents } from "../../../../events/action-events";


import { Attachment } from '../../../../model/attachment';

@Component({
  selector: 'app-attachments',
  templateUrl: './attachments.component.html',
  styleUrls: ['./attachments.component.css']
})
export class AttachmentsComponent extends BaseComponent implements OnInit {
  isCollapsed: boolean = true;

  @Input() requisitionId: string;

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

    @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();

  attachmentsList = []; //attachmentsList:Array<Attachment> = [];
  isCollapsedAttachment: any = true;
  // requisitionId: string;
  errorMsg: string;
  listOfAttachments = [];
  selectedAll: any;
  userId: string;
  objectArray:Array<ObjectKey> = [];
  checkboxLength:number = 0;
  timer: any;
  public attachmentsExist:boolean;
  fileNames = [];
  actionCompleted = false;
  actionFailed = false;
  canDownload:boolean = false;
  userCanRemove = false;
  
  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {this.renderAttachmentDetails(data);}
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL] = () => {this.renderNoAttachmentDetails()}
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS] = () => {this.renderAttachmentDownloaded()}
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL] = (error: any) => {this.renderError(error)}
    super.registerStateChangeEvents(mapping);
  }
  ngOnInit() {
    this.actionCompleted = false;
    this.attachmentsExist = false;
    this.attachmentsList = [];
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId});
    this.actionDispatcherService.dispatch(event);
    this.userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
  }
  get attachmentsCount() {
    return (this.attachmentsList).length;
  }
  get getCheckboxLength() {
    return this.checkboxLength;
  }

  /** START: Functionality **/
  downloadAttachmentOnSelect(fileName: string, objectKey: string) {
    this.actionCompleted = false;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_DOWNLOAD, {requisitionId: this.requisitionId, objectKey: objectKey, fileName: fileName});
    this.actionDispatcherService.dispatch(event);
  }
  downloadMultipleAttachments() {
    this.objectArray = [];
    for(let i = 0; i < this.attachmentsList.length; i++) {
      if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked == true) {
        let objectKey = (<HTMLInputElement>document.getElementById("objectKey["+i+"]")).value;
        this.objectArray.push({fileName: this.attachmentsList[i].fileName, objectKey: objectKey, requisitionId: this.requisitionId});
      }
    }
    if(this.objectArray.length > 0) {
      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_MULTI_DOWNLOAD, {requisitionId: this.requisitionId, multiDownloadList: this.objectArray});
      this.actionDispatcherService.dispatch(event);
    }
  }
  
  /** START: Checkbox selection functions **/
  checkboxSelected(objectKey: string, fileName: string, event) {
    if(this.attachmentsList.length > 0) {
      this.attachmentsExist = true;
    }
    this.attachmentsList.forEach((element, index) => {
      if(event.target.checked) {
        event.target.value = true;
      }else{
        (<HTMLInputElement>document.getElementById("selectedAll")).checked = false;
        event.target.value = false;
      }
    })  
    //Setting userCanRemove boolean to false if any checked record's userID is NOT the same as the logged in user's userID
    //Requirement: Can only delete those attachments that the currently logged in user uploaded
    for(let i = 0; i < this.attachmentsList.length; i++) {
      if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked == true) {
        this.canDownload = true; //If any are checked, enable download
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        if(this.attachmentsList[i].userId !== userId) {
          this.userCanRemove = false;
          return;
        }else{
          this.userCanRemove = true;
        }
      }
    }
    

    for(let i = 0; i < this.attachmentsList.length; i++) {
      if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked == true) {
        this.attachmentsExist = true;
        return;
      }else{
        this.attachmentsExist = false;
      }
    }
  }
  selectAll(event) {
    if(event.target.checked == true) {
      this.attachmentsExist = true;
      this.canDownload = true;
      this.attachmentsList.forEach((element, index) => {
        element.selected = event.target.checked;
      })
      for(let i = 0; i < this.attachmentsList.length; i++) {
        (<HTMLInputElement>document.getElementById("index["+i+"]")).checked = true;
      }
    }else{
      this.attachmentsExist = false;
      this.attachmentsList.forEach((element, index) => {
        element.selected = event.target.checked;
      })
      for(let i = 0; i < this.attachmentsList.length; i++) {
        (<HTMLInputElement>document.getElementById("index["+i+"]")).checked = false;
      }
    }
    //Setting userCanRemove boolean to false if any checked record's userID is NOT the same as the logged in user's userID
    //Requirement: Can only delete those attachments that the currently logged in user uploaded
    this.userCanRemove = false;
    for(let i = 0; i < this.attachmentsList.length; i++) {
      if((<HTMLInputElement>document.getElementById("index["+i+"]")).checked == true) {
        //If checked, see if userId of this element is same as logged in user
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        if(this.attachmentsList[i].userId !== userId) {
          this.userCanRemove = false;
          return;
        }else{
          this.userCanRemove = true;
        }
      }
    }
  }
  /** END: Checkbox selection functions **/

  /** START: Rendering of success & failures **/
  renderAttachmentDetails(data: any){
    this.actionCompleted = true;
    this.attachmentsList = [];
    this.attachmentsList = data;
    if(this.attachmentsList.length > 0) {
      this.attachmentsExist = true;
    }else{
      this.attachmentsExist = false;
    }
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
  }
  renderNoAttachmentDetails() {
    this.actionCompleted = true;
  }
  renderAttachmentDownloaded() {
    this.actionCompleted = true;
  }
  renderError(error: any) {
    this.actionCompleted = true;
    this.errorMsg = error.statusText;
    this.actionFailed = true;
  }
  /** END: Rendering of success & failures **/

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

}
