import { BaseComponent } from 'app/democomponents/base-component';
import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { StateRepresentationRendererService } from 'usf-sam';
import { ReqDetails } from '../../../../model/submitRequisition';
import { DivisionsService } from '../../../../service/divisions.service';
import { Division } from '../../../../model/division';
import { ProductCommentComponent } from '../../../common/comment/product-comment/product-comment.component';
import { Comment } from '../../../../model/comment';
import { User } from 'app/model/user';
import { PRIVILEGES } from 'app/model/adRoles';
import { USFDropdownComponent, USFDropdownMenuSettings } from 'app/democomponents/common/dropdown/usf-dropdown/dropdown.component';
import { USFoodsButtonSettings } from 'app/democomponents/common/button/button.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-req-details',
  templateUrl: './req-details.component.html',
  styleUrls: ['./req-details.component.css']
})
export class ReqDetailsComponent extends BaseComponent implements OnInit {
  // For access control
  superUserRole: string[] = PRIVILEGES.superUser;

  // for Task Drop Down Select
  public taskDropDownSettings: USFDropdownMenuSettings = {
    selectedOption: '',
    options: [],
    smBtn: false,
    width: '235',
    height: 'auto',
    invalid: false
  };

  // for Task Select Button
  public taskSelectBtnSettings: USFoodsButtonSettings = {
    width: '80',
    height: '36',
    marginLeft: '20',
    marginRight: '0',
    text: 'Select',
    css: ['add']
  }

  @ViewChild('viewCommentsTest') viewMsgsToModal: Modal;
  @ViewChild('viewAuditLogs') viewAuditModal: Modal;
  @ViewChild('Comments') commentsComponent: ProductCommentComponent;

  data: any = [];
  audits: any = [];
  isCollapsed: boolean = true;
  @Input() comments: Comment[];

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set dropShip(value: boolean) {
    this.isDropShip = value;
  }

  @Input() set market(value: string) {
    this.marketNumber = value;
  }

  @Input() reqDetails: ReqDetails;

  requisitionDetails: ReqDetails;

  marketNumber: string;

  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();

  divisions: Division[];

  isDropShip: boolean;
  public requisitionType: string;
  public selectedIndex: number;

  constructor(readonly stateRepresentationRendererService: StateRepresentationRendererService, private divisionService: DivisionsService, private user: User, private router: Router) {
    super(stateRepresentationRendererService);
   }

  ngOnInit() {
    console.log(this.reqDetails);
    this.requisitionDetails = this.reqDetails;
    this.requisitionType = this.reqDetails.requisition.requisitionType;
    this.divisions = this.divisionService.getDivisions();
    this.commentsComponent.comments = this.comments;
    this.commentsComponent.isHide = true;
    console.log(this.requisitionType);

    this.taskDropDownSettings.options = this.setTaskDropdownOptions();
    this.taskDropDownSettings.selectedOption = this.taskDropDownSettings.options[0];
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.comments) {      
      this.commentsComponent.comments = this.comments;
    }
    if (changes.reqDetails) {
      this.requisitionDetails = changes.reqDetails.currentValue;
    }
  }

  setTaskDropdownOptions(): string[] {
    const taskOptions: string[] = [];
    this.reqDetails.tasks.forEach((task) => {
      task.assignedorAcceptedByList.forEach((user) => {
        taskOptions.push(task.taskID + ' - ' + user);
      });
    });
    return taskOptions;
  }

  onTaskDropdownSelect($event) {
    this.taskDropDownSettings.selectedOption = $event;
  }

  onTaskSelectBtnClick($event) {
    const taskIdArr = this.taskDropDownSettings.selectedOption.split('-');
    const taskId = taskIdArr[0].trim();
    this.router.navigate(['/approver'], { queryParams: { taskId: taskId, back: true} });
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  openViewComments() {
    if (!this.commentsComponent.comments) {
      return;
    }
    this.makeProductCommentsMultiLine(this.commentsComponent.comments);
    this.viewMsgsToModal.open();
  }

  makeProductCommentsMultiLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let commentArray = comment.commentsText.split(']');
        text += commentArray[0] + ']\n';
        text += commentArray[1];
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  makeProductCommentsOneLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let text = comment.commentsText.trim().replace(/\n/g, '');
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  openAuditLog() {
    if (!this.reqDetails.auditLogs.length) {
      return;
    }
    this.viewAuditModal.open();
  }

  closeMsgModal() {
    this.viewMsgsToModal.close();
  }
  closeAuditModal() {
    this.viewAuditModal.close();
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

}
