import { BaseComponent } from 'app/democomponents/base-component';
import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { StateRepresentationRendererService } from 'usf-sam';
import { ReqDetails } from '../../../../model/submitRequisition';
import { DivisionsService } from '../../../../service/divisions.service';
import { Division } from '../../../../model/division';
import { ProductCommentComponent } from '../../../common/comment/product-comment/product-comment.component';
import { Comment } from '../../../../model/comment';
import { User } from 'app/model/user';


@Component({
  selector: 'app-req-details',
  templateUrl: './req-details.component.html',
  styleUrls: ['./req-details.component.css']
})
export class ReqDetailsComponent extends BaseComponent implements OnInit {

  @ViewChild('viewCommentsTest') viewMsgsToModal: Modal;
  @ViewChild('viewAuditLogs') viewAuditModal: Modal;
  @ViewChild('Comments') commentsComponent: ProductCommentComponent;

  data: any = [];
  audits: any = [];
  isCollapsed: boolean = true;
  @Input() comments: Comment[];

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set dropShip(value: boolean) {
    this.isDropShip = value;
  }

  @Input() set market(value: string) {
    this.marketNumber = value;
  }

  @Input() reqDetails: ReqDetails;

  requisitionDetails: ReqDetails;

  marketNumber: string;

  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();

  divisions: Division[];

  isDropShip: boolean;
  public requisitionType: string;
  public selectedIndex: number;

  constructor(readonly stateRepresentationRendererService: StateRepresentationRendererService, private divisionService: DivisionsService, private user: User) {
    super(stateRepresentationRendererService);
   }

  ngOnInit() {
    console.log(this.reqDetails);
    this.requisitionDetails = this.reqDetails;
    this.requisitionType = this.reqDetails.requisition.requisitionType;
    this.divisions = this.divisionService.getDivisions();
    this.commentsComponent.comments = this.comments;
    this.commentsComponent.isHide = true;
    console.log(this.requisitionType);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.comments) {      
      this.commentsComponent.comments = this.comments;
    }
    if (changes.reqDetails) {
      this.requisitionDetails = changes.reqDetails.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  openViewComments() {
    if (!this.commentsComponent.comments) {
      return;
    }
    this.makeProductCommentsMultiLine(this.commentsComponent.comments);
    this.viewMsgsToModal.open();
  }

  makeProductCommentsMultiLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let commentArray = comment.commentsText.split(']');
        text += commentArray[0] + ']\n';
        text += commentArray[1];
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  makeProductCommentsOneLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let text = comment.commentsText.trim().replace(/\n/g, '');
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  openAuditLog() {
    if (!this.reqDetails.auditLogs.length) {
      return;
    }
    this.viewAuditModal.open();
  }

  closeMsgModal() {
    this.viewMsgsToModal.close();
  }
  closeAuditModal() {
    this.viewAuditModal.close();
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

}
