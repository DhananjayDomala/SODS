import { RouterModule } from '@angular/router';
import { AuthGuard } from '../util/auth.guard';
import { SearchMyOpenRequestComponent } from "app/democomponents/sodssearch/search-my-open-request/search-my-open-request.component";
import { SearchOlderRequestComponent } from "app/democomponents/sodssearch/search-older-request/search-older-request.component";
import { SearchCustomComponent } from "app/democomponents/sodssearch/search-custom/search-custom.component";
import { SearchReqDetailsComponent } from "app/democomponents/sodssearch/search-req-details/search-req-details.component";

export const sodsSearchRoutes=[
            { path: '', component: SearchMyOpenRequestComponent, canActivate: [AuthGuard]},
            { path: 'request-details/:id', component: SearchReqDetailsComponent, canActivate: [AuthGuard]},
            { path: 'myOpenRequest', component: SearchMyOpenRequestComponent, canActivate: [AuthGuard] },
            { path: 'olderRequest', component: SearchOlderRequestComponent, canActivate: [AuthGuard] },
   
];

export const routing = RouterModule.forChild(sodsSearchRoutes);