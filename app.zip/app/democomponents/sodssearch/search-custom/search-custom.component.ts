import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { SearchResultComponent } from 'app/democomponents/sodssearch/search-share/search-result/search-result.component';
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam/dist/usf-sam";
import { ModelChangeUpdateEvents, ActionEvents } from "app/events/action-events";
import { BaseComponent } from 'app/democomponents/base-component';

@Component({
  selector: 'app-search-custom',
  templateUrl: './search-custom.component.html',
  styleUrls: ['./search-custom.component.css']
})

export class SearchCustomComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild('searchResult') searchResultComponent: SearchResultComponent;

  constructor(readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService);
  }

  ngOnInit() {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 
  }
    ngAfterViewInit() {
      // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
    }

  changePageOption(event){
    this.searchResultComponent.config.itemsPerPage = parseInt(event);
  }

  changeSortByOption(event){
    this.searchResultComponent.sort(event);
  }

  changeAscendingOption(event){
    this.searchResultComponent.isAscending = event.isAscending;
    this.searchResultComponent.sort(event.selectedSortOption);
  }

  searchRequisition($event) {
    const requestBody = $event.body;
    this.loadingResult();

    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

    // emit search event
    const searchRequisitions = this.actionDispatcherService.generateEvent(ActionEvents.SEARCH_REQUISITION, requestBody);
    this.actionDispatcherService.dispatch(searchRequisitions);
  }

  loadingResult(){
    this.searchResultComponent.loading = true;
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }

}
