import { RouterModule } from '@angular/router';
import { AuthGuard } from '../util/auth.guard';
import { SodstaskinboxComponent } from "app/democomponents/sodstaskinbox/sodstaskinbox.component";

export const sodsTaskInboxRoutes=[
    { path: '', component: SodstaskinboxComponent, canActivate: [AuthGuard] }
];

export const routing = RouterModule.forChild(sodsTaskInboxRoutes);