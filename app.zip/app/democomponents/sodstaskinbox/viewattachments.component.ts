import { Attachment } from './../../model/attachment';
import { BaseComponent } from './../base-component';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";

@Component({
    selector: 'app-view-attachments',
    templateUrl: './viewattachments.component.html',
    styleUrls: ['./viewattachments.component.css']
})
export class ViewAttachmentsComponent extends BaseComponent implements OnInit {
    
    public attachmentsList:Array<Attachment> = [];
    public requisitionId:number;
    public attachmentKey:number;
    public fileName: string;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
        let mapping: any = [];
        mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {this.renderAttachmentDetails(data)};
        mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {this.renderAttachmentDetails(data);}
        super.registerStateChangeEvents(mapping); 
    }
    ngOnInit() {
        this.attachmentsList = [];
    }
    renderAttachmentDetails(data) {
        this.attachmentsList = data;
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    }
    downloadAttachments(objectKey, fileName) {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_DOWNLOAD, {requisitionId: this.requisitionId, objectKey:objectKey, fileName:fileName});
        this.actionDispatcherService.dispatch(event);
    }
}