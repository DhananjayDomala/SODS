import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SodstaskinboxComponent } from './sodstaskinbox.component';
import { InboxCommentComponent } from "app/democomponents/sodstaskinbox/inbox-comment/inbox-comment.component";
import { ViewAttachmentsComponent } from "app/democomponents/sodstaskinbox/viewattachments.component";
import { routing } from "app/democomponents/sodstaskinbox/sodstaskinbox.routes";
import { SodstaskinboxModule } from "app/democomponents/sodstaskinbox/sodstaskinbox.module";
import { RouterTestingModule } from '@angular/router/testing';
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { AppModule } from "app/app.module";
import { SAMPLECommentArr } from "app/model/comment";
import { SAMPLETASKARR } from "app/model/task";
import { ActionEvents } from "app/events/action-events";
import { Idle, NgIdleModule, IdleExpiry } from "@ng-idle/core";

fdescribe('SodstaskinboxComponent', () => {
  let component: SodstaskinboxComponent;
  let fixture: ComponentFixture<SodstaskinboxComponent>;
  let sendEvent = false;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SodstaskinboxModule,
        RouterTestingModule
      ],
      declarations: [],
      providers:
      [ 
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        Idle,
       {provide: IdleExpiry, useClass: MockExpiry}]
    })
    .compileComponents();
  }));

  beforeEach(() => {

    //mock the data
    //create a mock version of localStorage
    let store = {};
    const mockLocalStorage = {
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
    .and.callFake(mockLocalStorage.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockLocalStorage.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockLocalStorage.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockLocalStorage.clear);

    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': '', 
      applicationMarkets: [{marketName: 'sample', marketNum: 'sample', marketCode: 'sample'}]})}));
    fixture = TestBed.createComponent(SodstaskinboxComponent);
    component = fixture.componentInstance;
    this.sendEvent = false;
    component.actionDispatcherService.dispatch = (ev: any) => {this.sendEvent = true};
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should sort as asc order', () => {
    //init
    component.isDesc = true;
    component.column = '';
    component.direction = 0;
    //execute
    component.sort('taskId');
    //validate
    expect(component.isDesc).toBe(false);
    expect(component.column).toBe('taskId');
    expect(component.direction).toBe(-1);
  });

  it('should sort as desc order', () => {
    //init
    component.isDesc = false;
    component.column = '';
    component.direction = 0;
    //execute
    component.sort('taskId');
    //validate
    expect(component.isDesc).toBe(true);
    expect(component.column).toBe('taskId');
    expect(component.direction).toBe(1);
  });

  it('should initialize the comment list array successfully after calling the render function of get comments successfully', 
    () => {
      //init
      let commentsList = SAMPLECommentArr;
      //execute
      component.renderRetrieveCommentsSuccess(commentsList);
      //validate
      expect(component.inboxComments.comments).toBe(commentsList);
      expect(component.inboxCommentModel.isOpened).toBe(true);
    });

  it('should close the inboxComment model after calling the close() method', () => {
    //init
    //no initialization needed here
    //execute
    component.closeComment();
    //validate
    expect(component.inboxCommentModel.isOpened).toBe(false);
  });

  it('should open attachments model after calling the openViewAttachments model', () => {
    //init
    let reqId = 1234;
    //execute
    component.openViewAttachments(reqId);
    //validate
    expect(component.viewAttachmentsComponent.requisitionId).toBe(reqId);
    expect(component.viewAttachmentsModal.isOpened).toBe(true);
  });

  it('should clean out attachment list and close attachment model after calling the closeAttachment model', ()=>{
    //execute
    component.cancelViewAttachments();
    //validate
    expect(component.viewAttachmentsComponent.requisitionId).toBeNull();
    expect(component.viewAttachmentsComponent.attachmentsList).toBeNull();
    expect(component.viewAttachmentsModal.isOpened).toBe(false);
  });

  it('should initialize the task list and sort as desc order after calling the render task list method', ()=>{
    //init
    let taskList = SAMPLETASKARR;
    //execute
    component.renderTasksLoadedSuccess(taskList);
    //validate
    expect(component.taskList).toBe(taskList);
    expect(component.isDesc).toBe(false);
  });

  //TODO: I think we should have some logic to check if the event has registered successfully
  it('should generate the event successfully', () => {
    //execute
    component.export();
    component.downloadAll();
    component.openComments("1234");
  });

  it('should set the out of office successfully', ()=>{
    let data = {
      'outOfOffice': true,
      'designateName': 'test'
    }
    component.onGetOutofOfficeSuccess(data);
    expect(component.selectedType).toBe('outOfOffice');
    expect(component.forwardTask).toBe('test');
  });

  it('should have the correct page selection', ()=>{
    let event = 'View All';
    component.taskList.length = 1;
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(component.taskList.length);
    event = 'View 50';
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(50);
    event = 'View 100';
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(100);
  });
});

export class MockExpiry extends IdleExpiry {
  public lastDate: Date;
  public mockNow: Date;

  last(value?: Date): Date {
    if (value !== void 0) {
      this.lastDate = value;
    }

    return this.lastDate;
  }

  now(): Date {
    return this.mockNow || new Date();
  }
}