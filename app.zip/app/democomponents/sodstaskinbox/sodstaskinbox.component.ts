import { setTimeout } from 'timers';
import { Attachment } from './../../model/attachment';
import { ViewAttachmentsComponent } from './viewattachments.component';
import { BaseComponent } from './../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { Task } from "app/model/task";
import { Modal, ModalModule } from 'ngx-modal';
import { InboxCommentComponent } from "app/democomponents/sodstaskinbox/inbox-comment/inbox-comment.component";
import { PaginationInstance } from "ngx-pagination/dist/ngx-pagination";
import { Router } from '@angular/router';
import { DivisionsService } from '../../service/divisions.service';
import { LoadingService } from '../../service/loading.service'

@Component({
  selector: 'app-sodstaskinbox',
  templateUrl: './sodstaskinbox.component.html',
  styleUrls: ['./sodstaskinbox.component.css']
})

export class SodstaskinboxComponent extends BaseComponent implements OnInit, AfterViewInit {

  public taskList: Array<Task> = [];
  public attachList:Array<Attachment> = [];
  //for pagination
  pageOptions: string[];
  selectedPage: string;
  readonly defaultPage: string = "View 10";

  @ViewChild('ViewAttachments')
  viewAttachmentsComponent: ViewAttachmentsComponent;

  @ViewChild('ViewAttachmentsModal')
  viewAttachmentsModal: Modal;

  @ViewChild('successPopup')
  viewdraftSuccessModal: Modal;

  
  isDesc: boolean = true;
  column: string = 'taskId';
  successId: any;
  saveId: any;
  direction: number;

  transfer_reqId: string;
  transfer_forwardId: string;
  deleteId: string;

  //pagination
  p: number = 1;
  public config: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 10,
    currentPage: 1
  };

  @ViewChild('InboxCommentModel')
  inboxCommentModel: Modal;

  @ViewChild('InboxComments')
  inboxComments: InboxCommentComponent;
  selectedType: any;
  forwardTask: any;
  value: any;
  networkID: any;
  showBusyIcon: boolean = false;

  constructor(readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    private loadingService: LoadingService,
    private router: Router) {
    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.GET_TASK_SUCCESS] = (taskList: Task[]) => { this.renderTasksLoadedSuccess(taskList); }
    mapping[ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_SUCCESS] = (commentsList: any) => { this.renderRetrieveCommentsSuccess(commentsList); }

    // For loading the approvers by role for a given market
    mapping[ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_SUCCESS] = (data: any) => {
        this.onGetOutofOfficeSuccess(data);
    };

    mapping[ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_FAIL] = (data: any) => {
        this.onGetOutofOfficeFail(data);
    };
    
    mapping[ModelChangeUpdateEvents.EXPORT_SUCCESS] = (data: any) => {
      // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    };

    mapping[ModelChangeUpdateEvents.EXPORT_FAIL] = (data: any) => {
      // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    };
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS] = (data: any) => {
      // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
    this.actionDispatcherService.dispatch(event1);
       
    };

    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL] = (data: any) => {
      // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    };




    mapping[ModelChangeUpdateEvents.SEARCH_EXPORT_EXCEL_SUCCESS] = (data: any) => {
      // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    };

    mapping[ModelChangeUpdateEvents.SEARCH_EXPORT_EXCEL_FAIL] = (data: any) => {
      // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    };

    this.loadingService.busy().subscribe((isBusy: any) => {
      if (!isBusy) {
        setTimeout(() => {
          this.showBusyIcon = isBusy;
        }, 1000)
      } else {
        this.showBusyIcon = isBusy;
      }
        
            
    });

    super.registerStateChangeEvents(mapping);
  }

  onGetOutofOfficeSuccess(data) {
    this.selectedType = (data.outOfOffice) ? 'outOfOffice' : 'inOffice';
    this.forwardTask = data.designateName;
    this.value = (data.returnDate) ? new Date(data.returnDate) : new Date();
  }
  onGetOutofOfficeFail(err) {

  }

  getBasicInfo() {
    const event = this.actionDispatcherService.generateEvent(
          ActionEvents.GET_OUT_OF_OFFICE_STATUS, this.networkID
      );
      this.actionDispatcherService.dispatch(event);

    // load busy dialog event
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);  
  }  

  ngOnInit() {
    this.pageOptions = ['View 10', 'View 50', 'View 100', 'View All'];
    this.networkID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
    this.getBasicInfo();
        

    this.getTaskInbox();
  }

  ngAfterViewInit() {
    if (localStorage.getItem('draftId') && localStorage.getItem('draftId') !== 'null') {
      this.successId = localStorage.getItem('draftId');
    }

    if (localStorage.getItem('saveId') && localStorage.getItem('saveId') !== 'null') {
      this.saveId = localStorage.getItem('saveId');
    }
    if(localStorage.getItem('transfer_reqId') && localStorage.getItem('transfer_reqId') !== 'null'){
      this.transfer_reqId = localStorage.getItem('transfer_reqId');
    }
    if(localStorage.getItem('transfer_forwardId') && localStorage.getItem('transfer_forwardId') !== 'null'){
      this.transfer_forwardId = localStorage.getItem('transfer_forwardId');
    }
    if(localStorage.getItem('deleteId') && localStorage.getItem('deleteId') !== 'null'){
      this.deleteId = localStorage.getItem('deleteId');
    }

    localStorage.setItem('transfer_reqId', null);
    localStorage.setItem('transfer_forwardId', null);
    localStorage.setItem('draftId', null);
    localStorage.setItem('saveId', null);
    localStorage.setItem('deleteId', null);
  }

  onPageSelection($event){
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);
    if($event === 'View All'){
      this.config.itemsPerPage = this.taskList.length;
    }else if($event === 'View 50'){
      this.config.itemsPerPage = 50;
    }else if($event === 'View 100'){
      this.config.itemsPerPage = 100;
    }else{
      this.config.itemsPerPage = 10;
    }

    setTimeout(() => {
      const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    }, 500)
  }

  onPageChange($event) {
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);
    this.config.currentPage = $event
      setTimeout(() => {
      const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
    }, 500)

  }

  getTaskInbox() {
    //get the login network id from local storage
    const data = localStorage.getItem('user');
    const networkID = JSON.parse(JSON.parse(data)._body).userId;
    //make an api call from sam
    let event = this.actionDispatcherService.generateEvent(ActionEvents.GET_TASK, networkID);
    this.actionDispatcherService.dispatch(event);
  }

  renderTasksLoadedSuccess(taskList: Task[]) {
    //for testing, print out the task list
    this.taskList = taskList;
    this.sort('taskId');
    // unset the busy state
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
  }

  sort(property) {
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);
    this.isDesc = !this.isDesc; //change the direction    
    this.column = property;
    this.direction = this.isDesc ? 1 : -1;

    const event2 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      setTimeout(() => { this.actionDispatcherService.dispatch(event2); }, 500);  
      
  };

  export() {
    // load busy dialog event
    const event1 = this.actionDispatcherService.generateEvent(
      ActionEvents.SET_BUSY_STATUS, true
    );
    this.actionDispatcherService.dispatch(event1);

    let event = this.actionDispatcherService.generateEvent(ActionEvents.EXPORT_EXCEL, {});
    this.actionDispatcherService.dispatch(event);
  }

  openComments(reqId: string) {
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);

    let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_COMMENT_INBOX, reqId);
    this.actionDispatcherService.dispatch(event);
  }

  renderRetrieveCommentsSuccess(commentsList: any) {
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);

    this.inboxComments.comments = commentsList;
    this.inboxCommentModel.open();
  }

  closeComment() {
    this.inboxCommentModel.close();
  }

  openViewAttachments(reqId: number) {

    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);
    
    
    this.viewAttachmentsComponent.requisitionId = reqId;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, { requisitionId: reqId });
    this.actionDispatcherService.dispatch(event);
    this.viewAttachmentsModal.open();
  }

  cancelViewAttachments() {
    this.viewAttachmentsComponent.requisitionId = null;
    this.viewAttachmentsComponent.attachmentsList = null;
    this.viewAttachmentsModal.close();
  }

  downloadAll() {
    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);
    let reqId = this.viewAttachmentsComponent.requisitionId;
    this.attachList = this.viewAttachmentsComponent.attachmentsList;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_MULTI_DOWNLOAD, 
      { requisitionId: reqId, multiDownloadList: this.attachList });
    this.actionDispatcherService.dispatch(event);
  }

  openReqDetails(id) {
    // let foundItem = this.taskList.find((item) => {
    //   return item.reqId === id;
    // });

    // if (foundItem) {
    //   this.openTaskDetails(foundItem.taskId);
    // }

    this.router.navigateByUrl('/search/request-details/' + id);
  }

  moveToOutOfOffice() {
    this.router.navigateByUrl('outofoffice');
  }

  openTaskDetails(taskId: string, action?: string) {
    if (action === 'Draft' || action === 'Returned' || action === 'Recalled') {
      this.router.navigate(['/sodsnew/approver'], { queryParams: { taskId: taskId} })
    } else {
      this.router.navigate(['/approver'], { queryParams: { taskId: taskId } });
    }
  }
}
