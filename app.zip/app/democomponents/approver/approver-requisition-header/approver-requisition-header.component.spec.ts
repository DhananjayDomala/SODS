import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverRequisitionHeaderComponent } from './approver-requisition-header.component';

describe('ApproverRequisitionHeaderComponent', () => {
  let component: ApproverRequisitionHeaderComponent;
  let fixture: ComponentFixture<ApproverRequisitionHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverRequisitionHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverRequisitionHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
