import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails } from '../../../model/submitRequisition';
import { DivisionsService } from '../../../service/divisions.service';
import { Division } from '../../../model/division';
import { ProductCommentComponent } from '../../common/comment/product-comment/product-comment.component';
import { Comment } from '../../../model/comment';
@Component({
  selector: 'app-approver-requisition-header',
  templateUrl: './approver-requisition-header.component.html',
  styleUrls: ['./approver-requisition-header.component.css']
})
export class ApproverRequisitionHeaderComponent implements OnInit {

  @ViewChild('viewCommentsTest') viewMsgsToModal: Modal;
  @ViewChild('viewAuditLogs') viewAuditModal: Modal;
  @ViewChild('Comments') commentsComponent: ProductCommentComponent;

  data: any = [];
  audits: any = [];
  isCollapsed: boolean;
  @Input() comments: Comment[];

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set dropShip(value: boolean) {
    this.isDropShip = value;
  }

  @Input() set market(value: string) {
    this.marketNumber = value;
  }

  @Input() reqDetails: ReqDetails;

  requisitionDetails: ReqDetails;

  marketNumber: string;

  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();

  @Output('addComment')
  addComment: EventEmitter<any> = new EventEmitter<any>();

  divisions: Division[];

  isDropShip: boolean;
  public requisitionType: string;
  public selectedIndex: number;

  constructor(private divisionService: DivisionsService) { }

  ngOnInit() {
    this.requisitionDetails = this.reqDetails;
    this.requisitionType = this.reqDetails.requisition.requisitionType;
    this.divisions = this.divisionService.getDivisions();
    this.commentsComponent.comments = this.comments;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.comments) {      
      this.commentsComponent.comments = this.comments;
    }
    if (changes.reqDetails) {
      this.requisitionDetails = changes.reqDetails.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  openViewComments() {
    if (!this.commentsComponent.comments) {
      return;
    }
    this.makeProductCommentsMultiLine(this.commentsComponent.comments);
    this.viewMsgsToModal.open();
  }

  makeProductCommentsMultiLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let commentArray = comment.commentsText.split(']');
        text += commentArray[0] + ']\n';
        text += commentArray[1];
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  makeProductCommentsOneLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let text = comment.commentsText.trim().replace(/\n/g, '');
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  saveComment() {
    //validation first
    if (this.commentsComponent.commentErr === true) {
      return;
    }
    //if user does not hit add, just close it
    if (this.commentsComponent.newAddFlag === false) {
      this.viewMsgsToModal.close();
    } else {
      this.commentsComponent.newAddFlag = false;
      //save to comments array of requisition

      // will need to remove the empty text on the first element
          if (this.commentsComponent.comments[0].commentsText === '') {
            this.commentsComponent.comments.shift();
          }

          this.makeProductCommentsOneLine(this.commentsComponent.comments);
          // Dispatch an event to add a new requisition level comment.
          //this.comments = this.commentsComponent.comments;
      //     this.productCommentAdded[this.selectedIndex] = true;
      //     this.addComment.emit({'product': this.products[this.selectedIndex]});
      //   }
      // });
      this.addComment.emit({'comment': this.commentsComponent.comments[0]});
      this.viewMsgsToModal.close();
    }
  }  

  openAuditLog() {
    if (!this.reqDetails.auditLogs.length) {
      return;
    }
    this.viewAuditModal.open();
  }

  closeMsgModal() {
    this.viewMsgsToModal.close();
  }
  closeAuditModal() {
    this.viewAuditModal.close();
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }
}
