import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails, OverrideShipTo } from '../../../model/submitRequisition';
import { DivisionsService } from '../../../service/divisions.service';
import { Division } from '../../../model/division';
import { ProductCommentComponent } from '../../common/comment/product-comment/product-comment.component';
import { Comment } from '../../../model/comment';
import { DropdownComponent } from '../../common/dropdown/dropdown.component'
import { OverrideShipToComponent } from 'app/democomponents/common/customer/override-ship-to/override-ship-to.component';
import { String } from 'aws-sdk/clients/es';


@Component({
  selector: 'app-approver-requisition-header',
  templateUrl: './approver-requisition-header.component.html',
  styleUrls: ['./approver-requisition-header.component.css']
})
export class ApproverRequisitionHeaderComponent implements OnInit {

  @ViewChild('OverrideShipTo') 
    overrideShipToComponent: OverrideShipToComponent;

    @ViewChild('viewCommentsTest') viewMsgsToModal: Modal;

  @ViewChild('overrideModal') overrideModal: Modal;
  @ViewChild('viewAuditLogs') viewAuditModal: Modal;
  
  @ViewChild('editRequestType') editRequestType: Modal;
  @ViewChild('errorChangeReq') errorChangeReq: Modal;
  
  @ViewChild('Comments') commentsComponent: ProductCommentComponent;

  @ViewChild('areYouSure') areUsureModal: Modal;
    @ViewChild('sodsDropdown') sodsDropdown: DropdownComponent;

  readonly defaultReqType: string = 'Special Order'

  selectedReqType: string;
  useOverrideShipto: boolean = false;
  taskName: string;
    

  data: any = [];
  audits: any = [];
  isCollapsed: boolean;
  @Input() comments: Comment[];

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set dropShip(value: boolean) {
    this.isDropShip = value;
  }

  @Input() set market(value: string) {
    this.marketNumber = value;
  }

  @Input() reqDetails: ReqDetails;

  requisitionDetails: ReqDetails;

  marketNumber: string;

  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();

  @Output('addComment')
  addComment: EventEmitter<any> = new EventEmitter<any>();

  // seq: string;
    maxIncidentDescriptionLength = 1000;
    maxSpecialInstructionLength = 100;

  divisions: Division[];
  reqTypeOptions = [];

  isDropShip: boolean;
  public requisitionType: string;
  public selectedIndex: number;

  constructor(private divisionService: DivisionsService) { }

  ngOnInit() {
    this.requisitionDetails = this.reqDetails;
    this.requisitionType = this.reqDetails.requisition.requisitionType;

    this.reqTypeOptions = ['Special Order', 'Direct Ship'];
    this.divisions = this.divisionService.getDivisions();
    this.commentsComponent.comments = this.comments;

    if (this.requisitionDetails.customers[0].useOverrideShipto == true) {
      (<HTMLInputElement>document.getElementById("override-checkbox")).checked = true;
    } else if ((<HTMLInputElement>document.getElementById("override-checkbox"))) {
      (<HTMLInputElement>document.getElementById("override-checkbox")).checked = false;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.comments) {      
      this.commentsComponent.comments = this.comments;
    }
    if (changes.reqDetails) {
      this.requisitionDetails = changes.reqDetails.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  openViewComments() {
    if (!this.commentsComponent.comments) {
      return;
    }
    this.makeProductCommentsMultiLine(this.commentsComponent.comments);
    this.viewMsgsToModal.open();
  }

  isBuyer2(taskName: String) {
    if (taskName) {
      return taskName.startsWith('Enter PO Creation Method');
    } else {
      return false;
    }
  }

  makeProductCommentsMultiLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let commentArray = comment.commentsText.split(']');
        text += commentArray[0] + ']\n';
        text += commentArray[1];
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  makeProductCommentsOneLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let text = comment.commentsText.trim().replace(/\n/g, '');
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  saveComment() {
    //validation first
    if (this.commentsComponent.commentErr === true) {
      return;
    }
    //if user does not hit add, just close it
    if (this.commentsComponent.newAddFlag === false) {
      this.viewMsgsToModal.close();
    } else {
      this.commentsComponent.newAddFlag = false;
      //save to comments array of requisition

      // will need to remove the empty text on the first element
          if (this.commentsComponent.comments[0].commentsText === '') {
            this.commentsComponent.comments.shift();
          }

          this.makeProductCommentsOneLine(this.commentsComponent.comments);

      this.addComment.emit({'comment': this.commentsComponent.comments[0]});
      this.viewMsgsToModal.close();
    }
  }  

  openAuditLog() {
    if (!this.reqDetails.auditLogs.length) {
      return;
    }
    this.viewAuditModal.open();
  }

  closeMsgModal() {
    this.viewMsgsToModal.close();
  }
  closeAuditModal() {
    this.viewAuditModal.close();
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

  openRType() {
    this.editRequestType.open();
    this.selectedReqType = this.requisitionType;
    this.setDropdownValues(this.requisitionType)
    
  }

  updateRType() {
      this.requisitionType = this.selectedReqType;
      this.reqDetails.requisition.requisitionType = this.selectedReqType;
      this.editRequestType.close();
  }

  closeModal() {

    if (this.requisitionDetails.customers.length > 1 && this.selectedReqType === 'Special Order') {
      this.revertChanges();
      this.errorChangeReq.open();
      return null;
    }

      if (this.selectedReqType === 'Special Order') {
          this.sodsDropdown.selectedOption = 'Direct Ship';
          this.requisitionDetails.requisition.defaultShipMethod = 'Separate'
          this.onReqTypeSelection('Direct Ship', true);
      } else {
          this.sodsDropdown.selectedOption = 'Special Order';
          this.requisitionDetails.requisition.defaultShipMethod = 'Next'
          this.onReqTypeSelection('Special Order', true);
      }
      this.updateRType();
      this.areUsureModal.close();
  }

  setDropdownValues(val: any) {
      this.sodsDropdown.selectedOption = val;
      this.onReqTypeSelection(val, true);

  }

  revertChanges() {
      this.sodsDropdown.selectedOption = this.selectedReqType;
      this.onReqTypeSelection(this.selectedReqType, true);
      this.areUsureModal.close();
  }

  onReqTypeSelection($event: any, fromCloseModal?: boolean) {
      // localStorage.setItem('requestType', null);
      if ($event !== this.selectedReqType && !fromCloseModal) {
          this.areUsureModal.open();
          return;
      }

      this.selectedReqType = $event;
  }


  closeRTypeModal() {
    this.editRequestType.close();
  }

  closeChangeReq() {
    this.errorChangeReq.close();
    this.closeRTypeModal();
  }

  closeOverride() {
    (<HTMLInputElement>document.getElementById("override-checkbox")).checked = false;
    this.overrideShipToComponent.overrideShipToSelected = false;
    this.useOverrideShipto = false;
    this.reqDetails.customers[0].useOverrideShipto = false;
    this.overrideModal.close();
  }

  openOverride() {
    if((<HTMLInputElement>document.getElementById("override-checkbox")).checked === true) {
        this.reqDetails.customers[0].useOverrideShipto = true;
        this.overrideShipToComponent.overrideShipToSelected = true;
        this.overrideShipToComponent.defaultState = "Select";
        this.overrideShipToComponent.errors_exist = false;
        this.overrideShipToComponent.name_required_error = false;
        this.overrideShipToComponent.phone_required_error = false;
        this.overrideShipToComponent.address1_required_error = false;
        this.overrideShipToComponent.address2_required_error = false;
        this.overrideShipToComponent.city_required_error = false;
        this.overrideShipToComponent.state_required = false;
        this.overrideShipToComponent.zip_required_error = false;
        this.overrideShipToComponent.name_required = false;
        this.overrideShipToComponent.phone_required = false;
        this.overrideShipToComponent.address1_required = false;
        this.overrideShipToComponent.city_required = false;
        this.overrideShipToComponent.state_required = false;
        this.overrideShipToComponent.zip_required = false;

        if (this.reqDetails.customers[0].overrideShipto) {
          this.overrideShipToComponent.overrideShipTo.name = this.reqDetails.customers[0].overrideShipto.name;
          this.overrideShipToComponent.overrideShipTo.address1 = this.reqDetails.customers[0].overrideShipto.address1,
          this.overrideShipToComponent.overrideShipTo.address2 = this.reqDetails.customers[0].overrideShipto.address2,
          this.overrideShipToComponent.overrideShipTo.city = this.reqDetails.customers[0].overrideShipto.city,
          this.overrideShipToComponent.overrideShipTo.state = this.reqDetails.customers[0].overrideShipto.state,
          this.overrideShipToComponent.overrideShipTo.zip = this.reqDetails.customers[0].overrideShipto.zip,
          this.overrideShipToComponent.overrideShipTo.phone = this.reqDetails.customers[0].overrideShipto.phone  
        }
        


        this.overrideModal.open();
    }else{
        this.overrideShipToComponent.overrideShipToSelected = false;
        this.reqDetails.customers[0].useOverrideShipto = false;
    }
  }

  updateOverrideShipTo() {
    this.overrideShipToComponent.requiredFieldsMet();
    if(!this.overrideShipToComponent.errors_exist) {
      this.reqDetails.customers[0].overrideShipto = new OverrideShipTo();

         this.reqDetails.customers[0].overrideShipto.name = this.overrideShipToComponent.overrideShipTo.name;
         this.reqDetails.customers[0].overrideShipto.address1 = this.overrideShipToComponent.overrideShipTo.address1,
          this.reqDetails.customers[0].overrideShipto.address2 = this.overrideShipToComponent.overrideShipTo.address2,
          this.reqDetails.customers[0].overrideShipto.city = this.overrideShipToComponent.overrideShipTo.city,
          this.reqDetails.customers[0].overrideShipto.state = this.overrideShipToComponent.overrideShipTo.state,
          this.reqDetails.customers[0].overrideShipto.zip = this.overrideShipToComponent.overrideShipTo.zip,
          this.reqDetails.customers[0].overrideShipto.phone = this.overrideShipToComponent.overrideShipTo.phone
        this.overrideModal.close();
    }
  }

}
