import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { RouterModule } from '@angular/router';
import { routing } from "app/democomponents/approver/approver.routes";
import { ApproverProductComponent } from "app/democomponents/approver/approver-product/approver-product.component";
import { ApproverAttachmentComponent } from "app/democomponents/approver/approver-attachment/approver-attachment.component";
import { ApproverShipToComponent } from "app/democomponents/approver/approver-ship-to/approver-ship-to.component";
import { ApproverRequisitionHeaderComponent } from "app/democomponents/approver/approver-requisition-header/approver-requisition-header.component";
import { ApproverComponent } from "app/democomponents/approver/approver.component";
import { ApproverNonMarketProductsComponent } from './approver-non-market-products/approver-non-market-products.component';
import { ApproverEditFileComponent } from './approver-attachment/approver-edit-file/approver-edit-file.component';
import { ApproverAttachFileComponent } from './approver-attachment/approver-attach-file/approver-attach-file.component';
import { ApproverCategoryManagerProductComponent } from './approver-category-manager-product/approver-category-manager-product.component';
import { ApproverViewProductAttachmentsComponent } from './approver-attachment/approver-view-product-attachments/approver-view-product-attachments.component';
import { ApproverProductAttachmentProdInfoComponent } from './approver-product-attachment-prod-info/approver-product-attachment-prod-info.component';
import { ApproverBuyerProductComponent } from './approver-buyer-product/approver-buyer-product.component';
import { ApproverChangeVendorComponent } from './approver-change-vendor/approver-change-vendor.component';
import { ApproverBuyerPoProductComponent } from './approver-buyer-po-product/approver-buyer-po-product.component';


import { ApproverCreditAnalyistShipToComponent } from './approver-credit-analyst/approver-credit-analyst.component';

import { SamService } from 'app/service/sam.service';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing
  ],
  declarations: [
    ApproverComponent,
    ApproverRequisitionHeaderComponent,
    ApproverShipToComponent,
    ApproverAttachmentComponent,
    ApproverProductComponent,
    ApproverNonMarketProductsComponent,
    ApproverEditFileComponent,
    ApproverAttachFileComponent,
    ApproverCategoryManagerProductComponent,
    ApproverViewProductAttachmentsComponent,
    ApproverProductAttachmentProdInfoComponent,
    ApproverBuyerProductComponent,
    ApproverChangeVendorComponent,
    ApproverCreditAnalyistShipToComponent,
    ApproverBuyerPoProductComponent,
  ],
  providers : [
    SamService
  ] 
})
export class ApproverModule { }