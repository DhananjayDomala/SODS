import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverBuyerPoProductComponent } from './approver-buyer-po-product.component';
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { DivisionsService } from "app/service/divisions.service";
import { User } from "app/model/user";
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { ReqDetails, TaskInboxProduct } from "app/model/submitRequisition";

describe('ApproverBuyerPoProductComponent', () => {
  let component: ApproverBuyerPoProductComponent;
  let fixture: ComponentFixture<ApproverBuyerPoProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [ ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        DivisionsService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const mockSAMCall = {
      loadAttachmentDetails: () => {

      }
    }
    fixture = TestBed.createComponent(ApproverBuyerPoProductComponent);
    component = fixture.componentInstance;
    component.products = new Array<TaskInboxProduct>();
    spyOn(component.viewProductsComponent, 'loadAttachmentDetails').and.callFake(mockSAMCall.loadAttachmentDetails);
    component.reqDetails = new ReqDetails();
    component.reqDetails.requisition.requisitionType = 'Direct Ship';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
