import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverComponent } from './approver.component';
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { User } from "app/model/user";
import { RouterTestingModule } from "@angular/router/testing";
import { DivisionsService } from "app/service/divisions.service";
import { Observable } from "rxjs/Rx";
import { ActivatedRoute, Params } from "@angular/router";
import { ReqDetails, TaskInboxProduct, Comment, TaskInboxVendor, Requested } from "app/model/submitRequisition";
import { ApproverBuyerProductComponent } from "app/democomponents/approver/approver-buyer-product/approver-buyer-product.component";
import { MockComponent } from "app/model/mock";
import { Requisition } from "app/model/requisition";
import { Product } from "app/model/product";
import { VALUEMAP } from "app/democomponents/common/options/options";


describe('ApproverComponent', () => {
  let component: ApproverComponent;
  let fixture: ComponentFixture<ApproverComponent>;

  beforeEach(async(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
    TestBed.configureTestingModule({
      imports:[ApproverModule, RouterTestingModule],
      declarations: [
        MockComponent({ selector: 'app-approver-buyer-product' }),
      ],
      providers:
      [ 
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        DivisionsService,
        User,
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              queryParams: 
              {
                'taskId': '1234'
              }
            }
          }
        }

      ]
    })
    .compileComponents();
  }));

  const mockFun = {
    getProductsNotAttached: (products: TaskInboxProduct[]) => {
      let mockProductsResponse = new Array<TaskInboxProduct>();
      let mockProduct = new TaskInboxProduct();
      mockProduct.productId = '1';
      mockProductsResponse.push(mockProduct);
      return mockProductsResponse;
    },
    getNewProducts: (products: TaskInboxProduct[]) => {
      let mockProductsResponse = new Array<TaskInboxProduct>();
      let mockProduct = new TaskInboxProduct();
      mockProduct.productId = '2';
      mockProductsResponse.push(mockProduct);
      return mockProductsResponse;
    },
    alertNoProductMarkedReturn: (taskAlias: string) => {
      return false;
    },
    alertNoCommentsAddedToProduct: (taskAlias: string) => {
      return false;
    },
    alertMissingReturnComment: (taskAlias: string) => {
      return false;
    }
  }


  beforeEach(() => {
    let store = {};
    const mockSAMCall = {
      getRequisitionDetails: (key: string) => {

      },
      getAttachmentDetails: () =>{

      },
      setBusyStatus: () =>{

      },
      getComments: () => {

      },
      getDivisions: () => {

      },
      completeTask: () => {

      },
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
    .and.callFake(mockSAMCall.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockSAMCall.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockSAMCall.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockSAMCall.clear);
    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': '', 
      applicationMarkets: [{marketName: 'sample', marketNum: 'sample', marketCode: 'sample'}]})}));
    fixture = TestBed.createComponent(ApproverComponent);
    component = fixture.componentInstance;
    spyOn(component, 'getRequisitionDetails').and.callFake(mockSAMCall.getRequisitionDetails);
    spyOn(component, 'getAttachmentDetails').and.callFake(mockSAMCall.getAttachmentDetails);
    spyOn(component, 'getComments').and.callFake(mockSAMCall.getComments);
    spyOn(component, 'getDivisions').and.callFake(mockSAMCall.getDivisions);
    spyOn(component, 'completeTask').and.callFake(mockSAMCall.completeTask);
    spyOn(component, 'setBusyStatus').and.callFake(mockSAMCall.setBusyStatus);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  fit('should render correct reqDetails from the response', ()=>{
    let inputReqDetails: ReqDetails  = new ReqDetails();
    //1st test case - if acceptedByList is null, isTaskAccepted flag should be set up as false;
    inputReqDetails.acceptedByList = null;
    component.renderReqDetailsForApprovalsSuccess(inputReqDetails);
    expect(component.isTaskAccepted).toBeFalsy;
    //2nd test case - if acceptedByList is undefined, isTaskAccepted flag should be set up as false;
    inputReqDetails.acceptedByList = undefined;
    component.renderReqDetailsForApprovalsSuccess(inputReqDetails);
    expect(component.isTaskAccepted).toBeFalsy;
    //3rd test case - if acceptedByList is an empty list, isTaskAccepted flag should be set up as false;
    inputReqDetails.acceptedByList = [];
    component.renderReqDetailsForApprovalsSuccess(inputReqDetails);
    expect(component.isTaskAccepted).toBeFalsy;
    //4th test case - if we have element on the acceptedByList, isTaskAccepted flag should be set up as true
    inputReqDetails.acceptedByList = ['sodsus01'];
    inputReqDetails.requisition.requisitionNumber = '1234';
    inputReqDetails.requisition.status = 'returned';
    inputReqDetails.requisition.requisitionType = 'Special Order';
    spyOn(component, 'getProductsNotAttached').and.callFake(mockFun.getProductsNotAttached);
    spyOn(component, 'getNewProducts').and.callFake(mockFun.getNewProducts);
    component.renderReqDetailsForApprovalsSuccess(inputReqDetails);
    expect(component.isTaskAccepted).toBeTruthy;
    expect(component.productsNotAttached[0].productId).toBe("1");
    expect(component.productsNew[0].productId).toBe("2");
    expect(component.reqId).toBe('1234');
    expect(component.reqStatus).toBe('returned');
    expect(component.requisitionType).toBe('Special Order');
  });

  it('should return not-attach-to-market product', ()=>{
    let productInputArray = new Array<TaskInboxProduct>();
    let productNotAttached = new TaskInboxProduct();
    let productAttached = new TaskInboxProduct();
    productNotAttached.attached = 'false';
    productAttached.attached = 'true';
    productInputArray.push(productNotAttached);
    productInputArray.push(productAttached);
    expect(component.getProductsNotAttached(productInputArray).length).toBe(1);
  });

  it('should return new product', ()=>{
    let productInputArray = new Array<TaskInboxProduct>();
    let productNotNew = new TaskInboxProduct();
    let productNew = new TaskInboxProduct();
    productNotNew.new = 'false';
    productNew.new = 'true';
    productInputArray.push(productNotNew);
    productInputArray.push(productNew);
    expect(component.getNewProducts(productInputArray).length).toBe(1);
  });
  
  it('should change vendor successfully', ()=> {
    component.changeVendor();
    expect(component.isTransferDisabled).toBeTruthy;
  });

  it('should handle buyer error properly', ()=> {
    component.handleBuyerError();
    expect(component.isApproveDisabled).toBeTruthy;
  });

  it('should check Requisition Comments', ()=> {
    component.reqDetails.requisition.comments.length = 1;
    component.orginalCommentLength = 1;
    expect(component.requisitionHasComments()).toBeFalsy;
    component.orginalCommentLength = 2;
    expect(component.requisitionHasComments()).toBeTruthy;
  });

  it('should update cost successfully', ()=> {
    let event = {
      cost : 1
    }
    const productBuyerProduct: ApproverBuyerProductComponent = component.productBuyerProduct;
    console.log('productBuyerProduct', productBuyerProduct);
    //we need to mock the productBuyerProduct viewchild object
  });

  fit('should return requisition successfully', ()=>{
    spyOn(component, 'alertNoProductMarkedReturn').and.callFake(mockFun.alertNoProductMarkedReturn);
    spyOn(component, 'alertNoCommentsAddedToProduct').and.callFake(mockFun.alertNoCommentsAddedToProduct);
    spyOn(component, 'alertMissingReturnComment').and.callFake(mockFun.alertMissingReturnComment);
    component.reqDetails.requisition.requisitionType = 'Special Order';
    component.returnRequisition();
    expect(component.requisitionType).toBe('Special Order');
    component.reqDetails.requisition.requisitionType = 'Direct Ship';
    component.returnRequisition();
    expect(component.requisitionType).toBe('Direct Ship');
  });

  it('should display alert for no product market return', ()=>{
    let taskAlias = 'NIA';
    expect(component.alertNoProductMarkedReturn(taskAlias)).toBeTruthy;
    taskAlias = 'catMgr';
    expect(component.alertNoProductMarkedReturn(taskAlias)).toBeTruthy;
    taskAlias = 'buyer2';
    expect(component.alertNoProductMarkedReturn(taskAlias)).toBeTruthy;
  });

  it('should display alert for no comment added to product', ()=>{
    let taskAlias = 'NIA';
    expect(component.alertNoCommentsAddedToProduct(taskAlias)).toBeTruthy;
    taskAlias = 'catMgr';
    expect(component.alertNoCommentsAddedToProduct(taskAlias)).toBeTruthy;
    taskAlias = 'buyer2';
    expect(component.alertNoCommentsAddedToProduct(taskAlias)).toBeTruthy;
  });

  it('should display alert for missing return comment', ()=>{
    let taskAlias = 'creditAnalyst';
    expect(component.alertMissingReturnComment(taskAlias)).toBeTruthy;
    taskAlias = 'approver';
    expect(component.alertMissingReturnComment(taskAlias)).toBeTruthy;
    taskAlias = 'replSpcl';
    expect(component.alertMissingReturnComment(taskAlias)).toBeTruthy;
  });

  it('should release task fail', ()=>{
    let data = '';
    component.releaseTaskFail(data);
    expect(component.isTaskAccepted).toBeTruthy;
  });

  it('should release task success', ()=>{
    let data = '';
    component.releaseTaskSuccess(data);
    expect(component.isTaskAccepted).toBeFalsy;
  });

  it('should complete task success', ()=>{
    let data = {
      taskType: 'approve'
    };
    component.completeTaskSuccess(data);
    expect(component.alertMessage).toBe('Requisition Approved Successfully.');
    data = {
      taskType: 'return'
    }
    component.completeTaskSuccess(data);
    expect(component.alertMessage).toBe('Requisition Returned Successfully.');
    expect(component.buttonsDisabled).toBeTruthy;
    expect(component.isApproveDisabled).toBeTruthy;
  });

  it('should alert normal product successfully', ()=>{
    let productIndex = 1;
    let distSts = '0';
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.normalProductAlert(productIndex, distSts)).toBeTruthy;
    distSts = '1';
    expect(component.normalProductAlert(productIndex, distSts)).toBeFalsy;
  });

  it('should alert out of stock product successfully', ()=>{
    let productIndex = 1;
    let distSts = '2';
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.outOfStockAlert(productIndex, distSts)).toBeTruthy;
    distSts = '1';
    expect(component.outOfStockAlert(productIndex, distSts)).toBeFalsy;
  });

  it('should alert temporary product successfully', ()=>{
    let productIndex = 1;
    let distSts = '3';
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.temporaryAlert(productIndex, distSts)).toBeTruthy;
    distSts = '1';
    expect(component.temporaryAlert(productIndex, distSts)).toBeFalsy;
  });

  it('should alert seasonal product successfully', ()=>{
    let productIndex = 1;
    let distSts = '4';
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.seasonalAlert(productIndex, distSts)).toBeTruthy;
    distSts = '1';
    expect(component.seasonalAlert(productIndex, distSts)).toBeFalsy;
  });

  it('should alert dwoAlert product successfully', ()=>{
    let productIndex = 1;
    let distSts = '8';
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.dwoAlert(productIndex, distSts)).toBeTruthy;
    distSts = '1';
    expect(component.dwoAlert(productIndex, distSts)).toBeFalsy;
  });

  it('should alert discontinued product successfully', ()=>{
    let productIndex = 1;
    let distSts = '9';
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.discontinuedAlert(productIndex, distSts)).toBeTruthy;
    distSts = '1';
    expect(component.discontinuedAlert(productIndex, distSts)).toBeFalsy;
  });

  it('should alert non-market-attached product successfully', ()=>{
    let productIndex = 1;
    let prodAttchd = 'false'
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.notAttachedAlert(productIndex, prodAttchd)).toBeTruthy;
    prodAttchd = 'true';
    expect(component.notAttachedAlert(productIndex, prodAttchd)).toBeFalsy;
  });

  it('should alert missing-cost product successfully', ()=>{
    let productIndex = 1;
    let cost = 0.5;
    component.reqDetails.products[1] = new TaskInboxProduct();
    expect(component.missingCostAlert(productIndex, cost)).toBeTruthy;
    cost = 2;
    expect(component.missingCostAlert(productIndex, cost)).toBeFalsy;
  });

  it('should map vendor successfully', ()=>{
    let vendor = {
      vendorLstPrc: '1',
      vendorId: '1234',
      vendorName: 'Test',
      buyerNetworkId: 'O8N6026',
      buyerEmail: 'a@b.com',
      buyerNumber: '12345'
    };
    let productIndex = 1;
    component.reqDetails.products[productIndex]= new TaskInboxProduct();
    component.reqDetails.products[productIndex].vendor = new TaskInboxVendor();
    component.mapVendor(productIndex, vendor);
    expect(component.reqDetails.products[productIndex].cost).toBe(vendor.vendorLstPrc);
    expect(component.reqDetails.products[productIndex].vendor.vendorId).toBe(vendor.vendorId);
    expect(component.reqDetails.products[productIndex].vendor.vendorName).toBe(vendor.vendorName);
    expect(component.reqDetails.products[productIndex].vendor.buyerNetworkId).toBe(vendor.buyerNetworkId);
    expect(component.reqDetails.products[productIndex].vendor.buyerEmail).toBe(vendor.buyerEmail);
    expect(component.reqDetails.products[productIndex].vendor.buyerNumber).toBe(vendor.buyerNumber);
  });

  it('should expand all properly', ()=>{
    component.allCollapsed = true;
    component.expandAll();
    expect(component.allCollapsed).toBeFalsy;
    expect(component.collapsed[0]).toBeFalsy;
  });

  it('should collapse all properly', ()=>{
    component.allCollapsed = false;
    component.collapseAll();
    expect(component.allCollapsed).toBeTruthy;
    let expectArray = [true, true, true, true, true];
    expect(component.collapsed[0]).toBeTruthy;
  });

  it('should toggle section properly', ()=>{
    let index = 1;
    component.toggleSection(index);
    expect(component.collapsed[index]).toBeTruthy;
  });

  it('should handle accept task successfully', ()=>{
    component.isTaskAccepted = false;
    let data = {};
    component.acceptTaskSuccess(data);
    expect(component.isTaskAccepted).toBeTruthy;
  });

  it('should handle accept task fail', ()=>{
    component.isTaskAccepted = true;
    let data = {};
    component.acceptTaskFail(data);
    expect(component.isTaskAccepted).toBeFalsy;
  });

  it('should map Requested Object successfully', ()=>{
    let product = {
      description: '1',
      label: '1234',
      packSize: 'Test',
      salesUOM: 'O8N6026',
      vendor: {vendorId: 1},
      mfrId: '1234',
      pimClass: 1
    };
    let productIndex = 1;
    component.reqDetails.products[productIndex]= new TaskInboxProduct();
    component.reqDetails.products[productIndex].requested = new Requested();
    component.reqDetails.products[productIndex].new = 'true';
    component.mapRequested(productIndex, product);
    expect(component.reqDetails.products[productIndex].requested.description).toBe(product.description);
    expect(component.reqDetails.products[productIndex].requested.label).toBe(product.label);
    expect(component.reqDetails.products[productIndex].requested.packSize).toBe(product.packSize);
    expect(component.reqDetails.products[productIndex].requested.mfrId).toBe(product.mfrId);
    expect(component.reqDetails.products[productIndex].requested.vendor).toBe(product.vendor.vendorId);
    expect(component.reqDetails.products[productIndex].requested.type).toBe(VALUEMAP.PRODUCTTYPE[product.pimClass]);
  });
});

