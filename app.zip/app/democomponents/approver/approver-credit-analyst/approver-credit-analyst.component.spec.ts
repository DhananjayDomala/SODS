import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ApproverShipToComponent } from "app/democomponents/approver/approver-ship-to/approver-ship-to.component";


describe('ApproverShipToComponent', () => {
  let component: ApproverShipToComponent;
  let fixture: ComponentFixture<ApproverShipToComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverShipToComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverShipToComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
