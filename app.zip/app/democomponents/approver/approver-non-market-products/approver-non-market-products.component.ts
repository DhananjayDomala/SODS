import { ActionEvents } from 'app/events/action-events';
import { BaseComponent } from './../../base-component';
import { ModelChangeUpdateEvents } from './../../../events/action-events';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ApproverViewProductAttachmentsComponent } from './../approver-attachment/approver-view-product-attachments/approver-view-product-attachments.component';
import { Component, OnInit, ViewChild, Input, Output, SimpleChanges, EventEmitter } from '@angular/core';
import { TaskInboxProduct } from '../../../model/submitRequisition';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails } from '../../../model/submitRequisition';
import { Comment, SAMPLECommentA, SAMPLECommentB } from '../../../model/comment';


import { ProductCommentComponent } from '../../common/comment/product-comment/product-comment.component';
@Component({
  selector: 'app-approver-non-market-products',
  templateUrl: './approver-non-market-products.component.html',
  styleUrls: ['./approver-non-market-products.component.css']
})
export class ApproverNonMarketProductsComponent extends BaseComponent implements OnInit {

  @ViewChild('viewComments') viewMsgsToModal: Modal;
  @ViewChild('viewProduct') viewProdModal: Modal;
  @ViewChild('ProductComments') productComments: ProductCommentComponent;
  @ViewChild('ViewProductAttachment') viewProductsComponent: ApproverViewProductAttachmentsComponent;
  @ViewChild('ProductAttachmentModal') productAttachmentModal: Modal;
  
  public newAddFlag: boolean = false;
  public productSeq: number;
  public newAddedCount: number = 0;
  public attachmentsList:Array<any> = [];
  public reqNbr: string;
  private textareaLength: number = 1000;
  maxIncidentDescriptionLength: any = 1000;
  //validation for comment
  public commentErr: boolean = false;
  isAllReturned: boolean;
  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set allReturned(value: boolean) {
    this.isAllReturned = value;
  }

  @Input() invalidProducts: number[];

  @Input() products: TaskInboxProduct[];
  @Input() reqDetails: ReqDetails;
  requistionDetails: ReqDetails;
  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();
  @Output('return')
  return: EventEmitter<any> = new EventEmitter<any>();
  @Output('returnAll')
  returnAll: EventEmitter<any> = new EventEmitter<any>();
  @Output('addComment')
  addComment: EventEmitter<any> = new EventEmitter<any>();

  isCollapsed: boolean;
  allChecked = false;
  comments: any[] = [];
  selectedIndex: any;
  currentProd: any;
  productCommentAdded: boolean[] = new Array<boolean>();

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];           
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => { this.renderAttachmentDetails(data) }
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    // this is to keep track of when a new comment is added to a product
    this.products.forEach((product) => {
      this.productCommentAdded.push(false);
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes.allReturned) {
      this.allChecked = changes.allReturned.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

  openViewComments(comments, index, seq) {
    this.selectedIndex = index;
    this.comments = [...comments] || [];
    // if (!comments.length) {
    //   return;
    // }

    this.viewMsgsToModal.open();
    this.productComments.newAddedCount = 0;
    this.productComments.comments = this.comments;
    this.productComments.productSeq = seq;
  }

  closeMsgModal() {
    if (this.productComments.newAddFlag === true) {
      //cancel without saving so clear out the first item of the comments array
      for (let i = 0; i < this.productComments.newAddedCount; i++) {
        this.productComments.comments.shift();
      }
      //reset the add flag
      this.productComments.newAddFlag = false;
    }
    //clear error
    this.productComments.commentErr = false;
    this.viewMsgsToModal.close();
  }

  closeProdModal() {
    this.viewProdModal.close();
  }

  toggleReturnAll() {
    this.allChecked = !this.allChecked;
    this.returnAll.emit({ 'products': this.products, 'returned': this.allChecked });
  }

  returnProduct(product: TaskInboxProduct) { 
    this.return.emit({ 'product': product });
    let productIndex = this.products.findIndex((x) => x.seq === product.seq);
    // check to see if comment exists for product
    if (this.products[productIndex].returned) {
      if (this.isCommentAddedToProduct(productIndex)) {
        return;
      } else {
        // Open a modal to add a new comment to the product
        this.openViewComments(product.comments, productIndex, product.seq);
      }
    }
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter((obj) => {
      return obj[property] === value;
    });
  }

  isCommentAddedToProduct(productIndex: number) {
    return this.productCommentAdded[productIndex] === true;
  }

  //save Comment
  saveComment() {
    //validation first
    if (this.productComments.commentErr === true) {
      return;
    }
    //if user does not hit add, just close it
    if (this.productComments.newAddFlag === false) {
      this.viewMsgsToModal.close();
    } else {
      this.productComments.newAddFlag = false;
      //save to comments array of product element
      this.products.forEach((product, index) => {
        if (product.seq === this.productComments.productSeq) {
          //will need to remove the empty text on the first element
          if (this.productComments.comments[0].commentsText === '') {
            this.productComments.comments.shift();
          }
          product.comments = this.productComments.comments;
          this.productCommentAdded[this.selectedIndex] = true;
          this.addComment.emit({'product': this.products[this.selectedIndex]});
        }
      });
      this.viewMsgsToModal.close();
    }
  }

  isInvalid(index): boolean {
    let invalidIndex = 0;
    this.invalidProducts.forEach((invalid) => {
      if (index === invalid) {
        invalidIndex++;
      }
    });
    return invalidIndex > 0;
  }

  openViewAttachments(seq) {
    this.viewProductsComponent.attachmentsList = [];
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, 
      {requisitionId: this.reqNbr, attachmentKey:seq});
    this.actionDispatcherService.dispatch(event);
    this.viewProductsComponent.seqId = seq;
    this.productAttachmentModal.open();
  }

  renderAttachmentDetails(data) {
    this.attachmentsList = data;
  }
}
