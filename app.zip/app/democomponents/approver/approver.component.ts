import { ApproverNonMarketProductsComponent } from './approver-non-market-products/approver-non-market-products.component';
import { ApproverProductAttachmentProdInfoComponent } from "./approver-product-attachment-prod-info/approver-product-attachment-prod-info.component";
import { ApproverProductComponent } from "./approver-product/approver-product.component";
import { ApproverCategoryManagerProductComponent } from "./approver-category-manager-product/approver-category-manager-product.component";
import { ViewAttachmentsComponent } from "./../sodstaskinbox/viewattachments.component";
import { Attachment } from "./../../model/attachment";
import { ApproverAttachmentComponent } from "./approver-attachment/approver-attachment.component";
import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  Output
} from "@angular/core";
import { BREADCRUMBS } from "app/democomponents/common/breadcrumb/breadcrumbs";
import {
  ReqDetails,
  TaskInboxProduct,
  TaskInboxVendor
} from "../../model/submitRequisition";
import { BaseComponent } from "../base-component";
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from "usf-sam";
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from "../../events/action-events";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { ALERTS } from "../common/alert/alerts";
import { ApproverRequisitionHeaderComponent } from "./approver-requisition-header/approver-requisition-header.component";
import { DivisionsService } from "../../service/divisions.service";
import { Division } from "../../model/division";
import { Modal } from "ngx-modal";
import { ApproverBuyerProductComponent } from "app/democomponents/approver/approver-buyer-product/approver-buyer-product.component";
import { ApproverBuyerPoProductComponent } from "app/democomponents/approver/approver-buyer-po-product/approver-buyer-po-product.component";
import { Vendor } from "app/model/product";
import { AutoCompleteComponent } from "app/democomponents/common/auto-complete/autoComplete.component";
import { POResponse } from "app/model/poResponse";
import { VALUEMAP } from "app/democomponents/common/options/options";
import { AttachmentComponent } from 'app/democomponents/common/attachment/attachment.component';

import { SamService } from 'app/service/sam.service';
import { TypeaheadSettings } from 'app/democomponents/common/typeahead/typeahead.component';
import { NgModel } from '@angular/forms/src/directives/ng_model';

@Component({
  selector: "app-approver",
  templateUrl: "./approver.component.html",
  styleUrls: ["./approver.component.css"]
})
export class ApproverComponent extends BaseComponent
  implements OnInit, OnDestroy {
  @ViewChild("reqDetailsHeader")
  reqDetailsHeader: ApproverRequisitionHeaderComponent;
  @ViewChild("warningError") warningErrorModal: Modal;
  @ViewChild("transferRequisitionModal") transferRequisitionModal: Modal;
  @ViewChild("autoCompleteComponent") autoCompleteComponent: AutoCompleteComponent;
  @ViewChild("transferToTxtField") transferToTxtField;

  @ViewChild("ApproverAttachment") approverAttachmentComp: Attachment;

  // For Loading Indicator
  public loading = false;

  public breadcrumbs = BREADCRUMBS["approver"];

  //requisition type should be seperate
  public requisitionType: string;

  // For Alerts
  alertSettings: any[] = [];
  alertMessage: string;
  showAlert = false;

  // For Requistion Details
  public taskId = "";
  public reqDetails: ReqDetails = new ReqDetails();
  public reqDetailsArray: any[] = new Array<any>();
  public collapsed: boolean[] = new Array<boolean>();
  public allCollapsed = false;
  public allNewReturned = false;
  public allOutOfMarketReturned = false;
  public market: string;
  public reqStatus: string = "Pending Product/Vendor Setup";
  public buttonsDisabled = false;
  public taskName: string = "";
  public isTaskAccepted = false;
  private productHasNewComment: boolean[] = new Array<boolean>();
  public invalidProducts: number[] = new Array<number>();
  public reqId = "";

  //for checking original comments
  public orginalCommentLength: number;

  // For Requisition Header comments
  public requisitionComments: any[];

  // For New Products Section
  public productsNew: TaskInboxProduct[] = new Array<TaskInboxProduct>();
  public isApproveDisabled: boolean = true;
  // For Products Not Attached Section
  public productsNotAttached: TaskInboxProduct[] = new Array<
    TaskInboxProduct
    >();
  public taskInboxVendorObj: TaskInboxProduct[] = new Array<TaskInboxProduct>();
  public productNbrs = [];
  // For all Products
  public taskInboxProducts: TaskInboxProduct[] = new Array<TaskInboxProduct>();
  public isValidated: boolean = false;
  public errorsExist: boolean = false;

  // For Transfer Requisition modal autocomplete text field
  transferTaskToTypeaheadSettings: TypeaheadSettings = {
    label: 'Transfer Task To',
    selected: '',
    results: [],
    validationType: 'string',
    scrollable: true,
    valid: true,
    placeholderTxt: 'Last Name, First Name',
    css: ['typeahead-240'],
    errorMessageTxt: 'Select a valid user.'
  };
  selectedUserToAdd = [];
  searchedUsers: any[];

  // For Transfer Requisition error
  errMsg = "";
  enableTransfer = false;
  isTransferDisabled = false;

  // For back button when super user is viewing
  backBtnRequired: boolean = false;

  @ViewChild("ApproverAttachment")
  approverAttachment: AttachmentComponent;
  @ViewChild("CategoryManagerProduct")
  categoryManagerProduct: ApproverCategoryManagerProductComponent;
  @ViewChild("NewApproverProduct") newApproverProduct: ApproverProductComponent;
  @ViewChild("ProductAttachmentProdInfo")
  productAttachmentProdInfo: ApproverProductAttachmentProdInfoComponent;
  @ViewChild("ProductBuyerProduct")
  productBuyerProduct: ApproverBuyerProductComponent;
  @ViewChild("ProductBuyerProductPO")
  productBuyerProductPO: ApproverBuyerPoProductComponent;
  @ViewChild("ApproverNonMarketProductsComponent")
  approverNonMarketProductsComponent: ApproverNonMarketProductsComponent;
  @ViewChild("approverHeader")
  approverHeader: ApproverRequisitionHeaderComponent;

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    private activatedRoute: ActivatedRoute,
    private divisionsService: DivisionsService,
    private router: Router,
    private samService: SamService
  ) {
    super(stateRepresentationRendererService);
    const mapping: any = [];
    //  For loading the requistion details
    mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_SUCCESS] = (
      data: any
    ) => {
      this.renderReqDetailsForApprovalsSuccess(data);
    };
    mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_FAIL] = (
      data: any
    ) => {
      this.renderReqDetailsForApprovalsFail(data);
    };
    mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (
      data: any
    ) => {
      this.renderDivisionsForRoleSearch(data);
      
    };
    mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL] = (
      data: any
    ) => {
      this.renderDivisionsForRoleSearchFail(data);
    };
    mapping[ModelChangeUpdateEvents.ACCEPT_TASK_SUCCESS] = (data: any) => {
      this.acceptTaskSuccess(data);
    };
    mapping[ModelChangeUpdateEvents.ACCEPT_TASK_FAIL] = (data: any) => {
      this.acceptTaskFail(data);
    };
    mapping[ModelChangeUpdateEvents.RELEASE_TASK_SUCCESS] = (data: any) => {
      this.releaseTaskSuccess(data);
    };
    mapping[ModelChangeUpdateEvents.RELEASE_TASK_FAIL] = (data: any) => {
      this.releaseTaskFail(data);
    };
    mapping[ModelChangeUpdateEvents.COMPLETE_TASK_SUCCESS] = (data: any) => {
      this.completeTaskSuccess(data);
    };
    mapping[ModelChangeUpdateEvents.COMPLETE_TASK_FAIL] = (data: any) => {
      this.completeTaskFail(data);
    };
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS] = (
      data: string[]
    ) => {
      this.passReqIdToComponents();
    };
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL] = () => {
      this.passReqIdToComponents();
    };
    mapping[ModelChangeUpdateEvents.VALIDATE_PRODUCTS_SUCCESS] = (data: any) => {
      this.renderProductsSection(data);
    };
    mapping[ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_SUCCESS] = (
      commentsList: any
    ) => {
      this.renderRetrieveCommentsSuccess(commentsList);
    };
    mapping[ModelChangeUpdateEvents.VALIDATE_PO_SUCCESS] = (poResponse: POResponse) => {
      this.handleValidatePOSuccess(poResponse);
    }
    mapping[ModelChangeUpdateEvents.VALIDATE_PO_FAIL] = (err: any) => {
      this.handleValidatePOFail(err);
    }
    mapping[ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS] = (data: any) => {
      this.renderFilteredUsers(data);
    };
    mapping[ModelChangeUpdateEvents.TRANSFER_REQUISITION_SUCCESS] = (data: any) => {
      this.renderTransferRequisitionSuccess(data);
    };
    mapping[ModelChangeUpdateEvents.TRANSFER_REQUISITION_FAIL] = (data: any) => {
      this.renderTransferRequisitionFail(data);
    };
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    // load busy dialog event
    this.setBusyStatus(true);
    this.initData();
  }

  ngDoCheck() {
    if(this.approverAttachment != undefined) {
      this.approverAttachment.attachFile.requisitionId = this.reqId;
      this.approverAttachment.editFile.requisitionId = this.reqId;
    }
  }

  setBusyStatus(status: boolean){
    this.setBusy(status);
  }

  initData() {
    // Extract the taskId from the url query param
    this.taskId =
      this.activatedRoute.snapshot.queryParams["taskId"].trim() || "";

    if (this.taskId) {
      // Get the Requistion Details For Approvals
      this.getRequisitionDetails();
    }
    // Set the collapsible panels
    this.collapsed = [false, false, false, false, false, false];
  }

  onBackBtnClick() {
    //this.router.navigate search/request-details/31483
    this.router.navigateByUrl('search/request-details/' + this.approverHeader.requisitionDetails.requisition.requisitionNumber);
  }

  setBusy(status: boolean) {
    this.callSamService(ActionEvents.SET_BUSY_STATUS, status);
  }
  callSamService(eventTypeName: string, data: any) {
    this.samService.callAction(eventTypeName, data);
  }

  getRequisitionDetails() {
    // Get the Requistion Details For Approvals
    const getReqDetails = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_REQ_DETAILS_FOR_APPROVALS,
      { taskId: this.taskId }
    );
    this.actionDispatcherService.dispatch(getReqDetails);
  }

  getAttachmentDetails() {
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, { requisitionId: this.reqId });
    this.actionDispatcherService.dispatch(event);
  }

  renderReqDetailsForApprovalsSuccess(response: ReqDetails) {
    if (response.acceptedByList !== null && response.acceptedByList !== undefined && response.acceptedByList.length !== 0) {
      this.isTaskAccepted = true;
    }
    this.reqDetails = response;
    this.reqDetailsArray.push(this.reqDetails);
    this.productsNotAttached = this.getProductsNotAttached(this.reqDetails.products);
    this.productsNew = this.getNewProducts(this.reqDetails.products);
    this.taskInboxProducts = this.reqDetails.products;
    this.reqStatus = this.reqDetails.requisition.status;
    this.reqId = this.reqDetails.requisition.requisitionNumber;
    this.requisitionType = this.reqDetails.requisition.requisitionType;
    this.getAttachmentDetails();
    
    this.reqDetails.products.forEach(product => {
      this.productHasNewComment.push(false);
      if (product.vendor === null || product.vendor === undefined) {
        product.vendor = new TaskInboxVendor();
      }
      if (this.reqDetails.requisition.requisitionType === 'Special Order') {
        product.vendor.POCreationMethod = "Add To Existing";
      } else {
        product.vendor.POCreationMethod = "New";
      }
      product.errorFlag = false;
    });

    this.getComments();
    this.orginalCommentLength = this.reqDetails.requisition.comments.length;

    this.getDivisions();
    let getTaskName = this.checkTaskNames(this.reqDetails.taskName);
    if (getTaskName !== 'replSpcl' && getTaskName !== 'buyer1' && getTaskName !== 'catMgr' && getTaskName !== 'buyerPO') {
      this.isApproveDisabled = false;
    } else if (getTaskName === 'catMgr' && this.productsNew.length === 0) {
      this.isApproveDisabled = false;
    }

    // load busy dialog event
    this.setBusyStatus(false);
    if (this.activatedRoute.snapshot.queryParams["back"]) {
      let back =
        this.activatedRoute.snapshot.queryParams["back"].trim() || "";
      this.backBtnRequired = back ? true : false;
    }

    if (this.backBtnRequired) {
      this.breadcrumbs = {
        'heading': 'Approver Screen',
        'links': [
          {
            'href': '/search/customSearch?reqStatus=PPVS',
            'name': 'Search',
            'active': false
          },
          {
            'href': '/search/request-details/' + this.reqDetails.requisition.requisitionNumber,
            'name': this.requisitionType + ' Requistion',
            'active': false
          },
          {
            'href': '/approver',
            'name': 'Approver',
            'active': true
          }
        ]
      };
    }
  }

  passReqIdToComponents() {
    let reqDet = JSON.stringify(this.reqDetails);
    let req = JSON.stringify(JSON.parse(reqDet).requisition);
    let reqNbr = JSON.parse(req).requisitionNumber;
    if (this.approverAttachment !== undefined) {
      this.approverAttachment.requisitionId = reqNbr;
    }
    if (this.categoryManagerProduct !== undefined) {
      this.categoryManagerProduct.reqNbr = reqNbr;
    }
    if (this.newApproverProduct !== undefined) {
      this.newApproverProduct.reqNbr = reqNbr;
    }
    if (this.productAttachmentProdInfo !== undefined) {
      this.productAttachmentProdInfo.reqNbr = reqNbr;
    }
    if (this.productBuyerProduct !== undefined) {
      this.productBuyerProduct.reqNbr = reqNbr;
    }
    if (this.productBuyerProductPO !== undefined) {
      this.productBuyerProductPO.reqNbr = reqNbr;
    }
    if (this.approverNonMarketProductsComponent !== undefined) {
      this.approverNonMarketProductsComponent.reqNbr = reqNbr;
    }

    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
  }

  renderReqDetailsForApprovalsFail(response) {
    this.showAlertMessage("error", "reqDetailsNotFound");
  }

  getComments() {
    let event = this.actionDispatcherService.generateEvent(
      ActionEvents.RETRIEVE_COMMENT_INBOX,
      this.reqDetails.requisition.requisitionNumber
    );
    this.actionDispatcherService.dispatch(event);
  }

  renderRetrieveCommentsSuccess(commentsList: any) {
    this.requisitionComments = commentsList;

    const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1);
  }

  getNewProducts(products: TaskInboxProduct[]): TaskInboxProduct[] {
    const productsNew = products.filter(product => {
      return product.new === "true";
    });
    return productsNew;
  }

  getProductsNotAttached(products: TaskInboxProduct[]): TaskInboxProduct[] {
    const productsNotAttached = products.filter(product => {
      if (product.attached !== null && product.attached !== undefined) {
          if(product.attached.toString() === 'false'){
            return true;
          }else if(parseInt(product.cost) < 1){
              return true;
          }else{
            return false;
          }
        }
    });
    return productsNotAttached;
  }

  expandAll() {
    this.allCollapsed = false;
    this.approverAttachment.isCollapsedAttachment = false;
    this.collapsed = [false, false, false, false, false, false];
  }

  collapseAll() {
    this.allCollapsed = true;
    this.approverAttachment.isCollapsedAttachment = true;
    this.collapsed = [true, true, true, true, true, true];
  }

  toggleSection(index: number) {
    this.collapsed[index] = !this.collapsed[index];
  }

  getDivisions() {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

    // Make an api call to get the division codes for later screens
    const getDivisionsEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH,
      { data: "" }
    );
    this.actionDispatcherService.dispatch(getDivisionsEvent);
  }

  renderDivisionsForRoleSearch(divResponse) {
    this.divisionsService.setDivisions(divResponse);
    let markets: Division[] = this.findInArray(
      this.divisionsService.getDivisions(),
      "divisionNumber",
      Number(this.reqDetails.requisition.division)
    );
    this.market =
      markets[0].divisionName +
      " (" +
      markets[0].divisionCode +
      ", " +
      markets[0].divisionNumber +
      ")";

      // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  renderDivisionsForRoleSearchFail(response) {
    this.showAlertMessage("error", "divisionDownloadFailed");

    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  approveRequisition() {
    let request = {};
    // check to make sure there are no products to return
    if (this.isProductsToReturn()) {
      this.showAlertMessage("error", "productMarkedReturn");
    } else {
      // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 
      
      this.validateProducts();
      if (this.reqDetails.requisition.requisitionType === "Special Order") {
        this.reqDetails.requisition.requisitionType = "SODS-SO";
        this.requisitionType = "Special Order";
      }
      if (this.reqDetails.requisition.requisitionType === "Direct Ship") {
        this.reqDetails.requisition.requisitionType = "SODS-DS";
        this.requisitionType = "Direct Ship";
      }
      request = {
        taskId: this.taskId,
        taskName: this.reqDetails.taskName,
        taskAction: "",
        completedByID: localStorage.username,
        completedByName: JSON.parse(
          JSON.parse(localStorage.getItem("user"))._body
        ).displayName,
        appId: "SODS",
        status: "Active",
        requisition: this.reqDetails.requisition,
        requestor: this.reqDetails.requestor,
        territoryManager: this.reqDetails.territoryManager,
        customers: this.reqDetails.customers,
        products: this.reqDetails.products,
        auditLogs: this.reqDetails.auditLogs
      };
      // Make an api call to accept the requisition
      const completeTaskEvent = this.actionDispatcherService.generateEvent(
        ActionEvents.COMPLETE_TASK,
        { body: request, taskType: "approve" }
      );
      this.actionDispatcherService.dispatch(completeTaskEvent);
    }
  }

  isProductsToReturn() {
    const productsToReturn = this.getProductsToReturn();
    return productsToReturn.length > 0;
  }

  getProductsToReturn() {
    return this.findInArray(this.reqDetails.products, "returned", true);
  }

  isAssignedTo(networkID: string, assignedToList: string[]): boolean {
    return assignedToList.findIndex(x => x === networkID) >= 0;
  }

  acceptTask() {
    let request = {
      networkID: localStorage.username,
      taskId: this.taskId
    };
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 
      
    // Make an api call to accept the requisition
    const acceptTaskEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.ACCEPT_TASK,
      { body: request, taskType: "accept" }
    );
    this.actionDispatcherService.dispatch(acceptTaskEvent);
  }

  acceptTaskSuccess(data) {
    this.isTaskAccepted = true;
    this.getRequisitionDetails();
  }

  acceptTaskFail(data) {
    this.isTaskAccepted = false;
    // load busy dialog event
    this.setBusyStatus(false);
    this.showAlertMessage("error", "acceptTaskFail");
  }

  releaseTask() {
    // load busy dialog event
    this.setBusyStatus(true);
    const request = {
      taskId: this.taskId
    };
    // Make an api call to accept the requisition
    const releaseTaskEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.RELEASE_TASK,
      { body: request, taskType: "release" }
    );
    this.actionDispatcherService.dispatch(releaseTaskEvent);
  }

  releaseTaskSuccess(data) {

    // load busy dialog event
    this.setBusyStatus(false);
    this.isTaskAccepted = false;
  }

  releaseTaskFail(data) {

    // load busy dialog event
    this.setBusyStatus(false);
    this.showAlertMessage("error", "releaseTaskFail");
    this.isTaskAccepted = true;
  }

  completeTaskSuccess(data) {
    // load busy dialog event
    this.setBusyStatus(false);
    if (data.taskType === "approve") {
      this.showAlertMessage("success", "requisitionApproval");
    } else {
      this.showAlertMessage("success", "requisitionReturn");
    }

    this.buttonsDisabled = true;
    this.isApproveDisabled = true;
    this.isTransferDisabled = true;
  }

  completeTaskFail(data) {
    // load busy dialog event
    this.setBusyStatus(false);
    this.showMessage('error', data);
  }

  alertNoProductMarkedReturn(taskAlias: string): boolean {
    if ((taskAlias === "NIA" || taskAlias === "catMgr" || taskAlias === 'buyer2') && !this.isProductsToReturn()) {
      this.showAlertMessage("error", "noProductMarkedReturn");
      return true;
    }
    return false;
  }

  alertNoCommentsAddedToProduct(taskAlias: string): boolean {
    if ((taskAlias === "NIA" || taskAlias === "catMgr" || taskAlias === 'buyer2') && !this.productsHaveComments()) {
      this.showAlertMessage("error", "noCommentsAddedToProduct");
      return true;
    }
    return false;
  }

  alertMissingReturnComment(taskAlias: string): boolean {
    if ((taskAlias === 'creditAnalyst' || taskAlias === 'approver' || taskAlias === 'replSpcl')
      && !this.requisitionHasComments()) {
      this.showAlertMessage('error', 'missingReturnComment');
      this.approverHeader.viewMsgsToModal.open();
      return true;
    }
    return false;
  }


  returnRequisition() {
    // close confirm modal
    this.warningErrorModal.close();
    let request = {};
    let taskAlias = this.checkTaskNames(this.reqDetails.taskName);

    // check to make sure there are products to return
    let noProductMarkedReturnAlert = this.alertNoProductMarkedReturn(taskAlias);
    let noCommentsAddedToProductAlert = this.alertNoCommentsAddedToProduct(taskAlias);
    let missingReturnCommentAlert = this.alertMissingReturnComment(taskAlias);

    if(!noProductMarkedReturnAlert && !noCommentsAddedToProductAlert && !missingReturnCommentAlert){

      // load busy dialog event
      this.setBusyStatus(true);

      if (this.reqDetails.requisition.requisitionType === "Special Order") {
        this.reqDetails.requisition.requisitionType = "SODS-SO";
        this.requisitionType = "Special Order";
      }
      if (this.reqDetails.requisition.requisitionType === "Direct Ship") {
        this.reqDetails.requisition.requisitionType = "SODS-DS";
        this.requisitionType = "Direct Ship";
      }

      // format request
      request = {
        taskId: this.taskId,
        taskName: this.reqDetails.taskName,
        taskAction: "Return",
        completedByID: localStorage.username,
        completedByName: JSON.parse(
          JSON.parse(localStorage.getItem("user"))._body
        ).displayName,
        appId: "SODS",
        status: "Active",
        requisition: this.reqDetails.requisition,
        requestor: this.reqDetails.requestor,
        territoryManager: this.reqDetails.territoryManager,
        customers: this.reqDetails.customers,
        products: this.reqDetails.products,
        auditLogs: this.reqDetails.auditLogs
      };
      // Make an api call to return the requisition
      this.completeTask(request);
    }
  }

  onReqTypeUpdate(requisitionType) {
    if (requisitionType === "Special Order") {
        this.reqDetails.requisition.requisitionType = "SODS-SO";
        this.requisitionType = "Special Order";
        this.productBuyerProduct.buyerOptions = ['Add To Existing PO', 'Forecast', 'New PO'];
        this.productBuyerProduct.defaultBuyerOptions = 'Add To Existing PO';
      }
      if (requisitionType === "Direct Ship") {
        this.reqDetails.requisition.requisitionType = "SODS-DS";
        this.requisitionType = "Direct Ship";
        
        this.productBuyerProduct.buyerOptions = ['New PO'];
        this.productBuyerProduct.defaultBuyerOptions = 'New PO';
      }
      this.productBuyerProduct.onBuyerSelection(this.productBuyerProduct.defaultBuyerOptions);
  }

  completeTask(request: any) {
    // Make an api call to return the requisition
    const completeTaskEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.COMPLETE_TASK,
      { body: request, taskType: "return" }
    );
    this.actionDispatcherService.dispatch(completeTaskEvent);
  }

  productsHaveComments(): boolean {
    let totalComments = 0;
    this.reqDetails.products.forEach((product, i) => {
      if (product.returned && this.productHasNewComment[i]) {
        totalComments++;
      } else if (product.returned && !this.productHasNewComment[i]) {
        this.invalidProducts.push(product.seq);
      }
    });
    return totalComments === this.getProductsToReturn().length;
  }

  addComment(event): void {
    const seq = event.product.seq;
    const productIndex = this.reqDetails.products.findIndex(x => x.seq === seq);
    this.productHasNewComment[productIndex] = true;
    let index = this.invalidProducts.findIndex(x => x === seq);
    this.invalidProducts.splice(index, 1);

    if (this.invalidProducts.length > 0) {
      this.showAlert = false;
    }
    this.getComments();
  }

  toggleReturnProduct(event) {
    const product: TaskInboxProduct = event.product;
    const seq = product.seq;
    const productIndex = this.reqDetails.products.findIndex(x => x.seq === seq);
    this.reqDetails.products[productIndex].returned = !this.reqDetails.products[
      productIndex
    ].returned;
    this.productsNew = this.getNewProducts(this.reqDetails.products);
    this.productsNotAttached = this.getProductsNotAttached(
      this.reqDetails.products
    );
    this.allNewReturned = this.isAllReturned(this.productsNew);
    this.allOutOfMarketReturned = this.isAllReturned(this.productsNotAttached);

    // Remove flag for invalid product if the return box is unchecked
    if (!this.reqDetails.products[productIndex].returned) {
      const index = this.invalidProducts.findIndex(x => x === seq);
      this.invalidProducts.splice(index, 1);
      // remove alert if there are no more invalid products
      if (this.invalidProducts.length === 0) {
        this.showAlert = false;
      }
    }
    if (this.isProductsToReturn()) {
      this.isApproveDisabled = true;
    } else {
      this.isApproveDisabled = false;
    }
  }

  toggleAllReturnNewProducts(event) {
    const returned = event.returned;
    this.reqDetails.products.forEach(product => {
      if (product.new === "true") {
        product.returned = returned;
      }
    });
    this.allNewReturned = this.isAllReturned(this.productsNew);
    if (!this.allNewReturned) {
      this.invalidProducts = [];
    }
    if (this.isProductsToReturn()) {
      this.isApproveDisabled = true;
    } else {
      this.isApproveDisabled = false;
    }
  }

  toggleAllReturnProducts(event) {
    const returned = event.returned;
    this.reqDetails.products.forEach(product => {
      product.returned = returned;
    });
    this.allNewReturned = this.isAllReturned(this.productsNew);
    if (!this.allNewReturned) {
      this.invalidProducts = [];
    }
  }

  toggleAllNonMarketProducts(event) {
    const returned = event.returned;
    this.reqDetails.products.forEach(product => {
      if (product.attached.toString() === "false") {
        product.returned = returned;
      }
    });
    this.allOutOfMarketReturned = this.isAllReturned(this.productsNotAttached);
  }

  isAllReturned(products: TaskInboxProduct[]) {
    let totalReturned = 0;
    products.forEach(e => {
      if (e.returned) {
        totalReturned++;
      }
    });

    return totalReturned === products.length && products.length > 0;
  }

  showAlertMessage(alertType: string, alertText: string) {
    this.alertMessage = ALERTS[alertType][alertText];
    this.showMessage(alertType, this.alertMessage);
  }

  showMessage(alertType: string, alertText: string) {
    this.alertSettings = [];
    const alert = { alertType: alertType, alertMessage: alertText };
    this.alertSettings.push(alert);
    this.showAlert = true;
    this.loading = false;
    this.goTo("top");
  }

  goTo(location: string): void {
    window.location.hash = "";
    window.location.hash = location;
  }

  updateProductNumber() {
    this.isApproveDisabled = true;
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter(obj => {
      return obj[property] === value;
    });
  }

  findIndex(array, property, value) {
    return array.findIndex(x => x[property] === value);
  }

  // start of modal functions

  openWarningModal() {
    this.warningErrorModal.open();
  }

  closeWarning() {
    this.warningErrorModal.close();
  }

  cancel() {
    // Route user back inbox page
    this.router.navigate(["/taskInbox"], { queryParams: {} });
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }

  //determine which approver screen should go to
  checkTaskNames(taskName: string) {
    if (taskName === null || taskName === undefined) {
      return "invalid";
    }
    const rules = {
      'Approve Requisition': 'approver',
      "Approve New Item": 'NIA',
      'Approve and Setup Products': 'catMgr',
      'Attach Products and Check Product Status': 'replSpcl',
      'Enter Cost': 'buyer1',
      'Enter PO Creation Method': 'buyer2',
      'Analyze Credit': 'creditAnalyst',
      'Enter PO Number': 'buyerPO',
      'Recalled': 'draft',
      'Draft': 'draft',
      'Returned': 'draft'
    };
    let returnValue = 'invalid';
    let keys = Object.keys(rules);
    keys.forEach((key) => {
      if (taskName.startsWith(key)) {
        returnValue = rules[key];
      }
    });
    return returnValue;
  }

  openTransferRequisition() {
    // this.selected = '';
    this.transferTaskToTypeaheadSettings.selected = '';
    this.transferTaskToTypeaheadSettings.valid = true;
    this.selectedUserToAdd = [];
    this.transferRequisitionModal.open();
  }

  closeTransferRequisition() {
    this.transferRequisitionModal.close();
  }

  changePOCreationMethod($event) {
    this.reqDetails.products.forEach(item => {
      if (item.vendor === null || item.vendor === undefined) {
        item.vendor = new TaskInboxVendor();
      }
      item.vendor.POCreationMethod = $event.poCreationMethod;
    });
  }


  validateProducts() {
    if (!this.reqDetails.taskName.startsWith('Enter PO Number')) {
      this.productNbrs = [];
      let cantValidate: boolean = false;
      this.loadProductNotAttachments();
      cantValidate = this.loadNewProduct();
      this.callValidateProductService(cantValidate);
    }
    else {
      //do po validation for buyer po
      this.reqDetails.products.forEach((product) => {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.VALIDATE_PO,
          {
            requisitionId: this.reqDetails.requisition.requisitionNumber, vendorNumber: product.vendor.vendorId,
            buyerNumber: product.vendor.buyerNumber, poNumber: product.PONumber
          });
        this.actionDispatcherService.dispatch(event);
      });
      this.isApproveDisabled = false;
    }
  }


  handleValidatePOSuccess(poResponse: POResponse) {
    this.taskInboxProducts.forEach((product) => {
      poResponse.poStatus.forEach((item) => {
        if (item.poNumber === product.PONumber && item.status === 'Failure') {
          product.errorFlag = true;
          this.showAlertMessage('error', 'poValidationErr');
        } else if (item.poNumber === product.PONumber && item.status === 'Success') {
          product.errorFlag = false;
          this.isApproveDisabled = false;
          this.showAlertMessage('success', 'poValidation');
        } else {
          product.errorFlag = true;
          this.showAlertMessage('error', 'poValidationErr');
        }
      })
    });

    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  handleValidatePOFail(err: any){
    this.showAlertMessage('error','poValidationBackendErr');
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
  }

  renderProductsSection(data: any) {
    if (
      this.checkTaskNames(this.reqDetails.taskName) === "replSpcl" ||
      this.checkTaskNames(this.reqDetails.taskName) === "buyer1"
    ) {
      this.renderForProdAttachApprover(data);
    }
    if (this.checkTaskNames(this.reqDetails.taskName) === "catMgr") {
      this.renderForCategoryManagerApprover(data);
    }
  }

  mapResultsetToReqDetails(i: number, j: number, data: any) {
    this.reqDetails.products[i].attached = data[j].prodAttchd;
    this.reqDetails.products[i].description = data[j].description;
    this.reqDetails.products[i].label = data[j].label;
    this.reqDetails.products[i].priceUOM = data[j].priceUOM;
    this.reqDetails.products[i].manufacturerId = data[j].mfrId;
    this.reqDetails.products[i].packSize = data[j].packSize;
    this.mapVendor(i, data[j].vendor);
    this.mapRequested(i, data[j]);
    this.reqDetails.products[i].description = data[j].description;
    this.reqDetails.products[i].label = data[j].label;
    this.reqDetails.products[i].packSize = data[j].packSize;
    this.reqDetails.products[i].manufacturerId = data[j].mfrId;
    this.reqDetails.products[i].salesUOM = data[j].salesUOM;
    this.reqDetails.products[i].catchWeightInd = data[j].catchWghtInd;
    this.reqDetails.products[i].netWeight = data[j].netWght;
    this.reqDetails.products[i].type = VALUEMAP.PRODUCTTYPE[data[j].pimClass];
    this.reqDetails.products[i].class = data[j].pimClass;
    this.reqDetails.products[i].errorFlag = false;
    this.errorsExist = false;
  }

  productStatusCheck(i: number, j: number, data: any): boolean {
    let noAlert = true;
    let isNormalProductAlert = this.normalProductAlert(i, data[j].distSts);
    let isOutOfStockAlert = this.outOfStockAlert(i, data[j].distSts);
    let isTemporaryAlert = this.temporaryAlert(i, data[j].distSts);
    let isSeasonalAlert = this.seasonalAlert(i, data[j].distSts);
    let isDWOAlert = this.dwoAlert(i, data[j].distSts);
    let isDiscontinuedAlert = this.discontinuedAlert(i, data[j].distSts);
    let isSpecialOrder = this.specialOrderAlert(i, data[j].distSts);
    return !isNormalProductAlert && !isOutOfStockAlert && !isTemporaryAlert && !isSeasonalAlert && !isDWOAlert && !isDiscontinuedAlert && !isSpecialOrder;
  }

  renderForProdAttachApprover(data: any) {
    if (this.reqDetails.products.length > 0 && this.reqDetails.products !== undefined) {
      for (let i = 0; i < this.reqDetails.products.length; i++) {
        if (data !== undefined && data.length > 0) {
          this.processResultforProdAttach(data, i);
        }
      }
      this.checkIfApproveDisabled();
    }
  }

  processResultforProdAttach(data: any, i: number) {
    for (let j = 0; j < data.length; j++) {
      let activeProduct = (data[j].ntnlSts !== "" && data[j].ntnlSts !== undefined && data[j].ntnlSts !== null);
      if (activeProduct) {
        if (this.reqDetails.products[i].productId === data[j].productId.toString()) {
          let noAlert = true;
          let isNotAttached = this.notAttachedAlert(i, data[j].prodAttchd);
          let isMissingCost = true;
          if(data[j].vendor !== undefined){
            isMissingCost = this.missingCostAlert(i, data[j].vendor.vendorLstPrc);
          }
          let productStatusAlert = this.productStatusCheck(i, j, data);
          noAlert = productStatusAlert && !isNotAttached && !isNotAttached && !isMissingCost;
          if (noAlert) {
            this.mapResultsetToReqDetails(i, j, data);
          } else {
            this.mapResultsetToReqDetails(i, j, data);
            this.reqDetails.products[i].errorFlag = true;
            window.scrollTo(0, 0);
          }
        }
      } else {
        this.showAlertMessage('error', 'invalidProduct');
        this.productsNotAttached[i].errorFlag = true;
        this.errorsExist = true;
        window.scrollTo(0, 0);
      }
    }
  }

  handleAlert(productIndex: number, errKey: string) {
    this.showAlertMessage('error', errKey);
    this.errorsExist = true;
    this.reqDetails.products[productIndex].errorFlag = true;
    window.scrollTo(0, 0);
  }

  normalProductAlert(productIndex: number, distSts: string): boolean {
    if (distSts !== null && distSts !== undefined && Number(distSts) === 0 && this.reqDetails.requisition.requisitionType !== 'Direct Ship') {
      this.handleAlert(productIndex, 'normalProduct');
      return true;
    } else {
      return false;
    }
  }
  specialOrderAlert(productIndex: number, distSts: string): boolean {
    if(distSts.toString() === "" ) {
      this.handleAlert(productIndex, 'specialOrderProduct');
      return true;
    }else{
      return false;
    }
  }

  outOfStockAlert(productIndex: number, distSts: string): boolean {
    if (Number(distSts) === 2 && this.reqDetails.requisition.requisitionType !== 'Direct Ship') {
      this.handleAlert(productIndex, 'outOfStock');
      return true;
    } else {
      return false;
    }
  }

  temporaryAlert(productIndex: number, distSts: string): boolean {
    if (Number(distSts) === 3 && this.reqDetails.requisition.requisitionType !== 'Direct Ship') {
      this.handleAlert(productIndex, 'temporary');
      return true;
    } else {
      return false;
    }
  }

  seasonalAlert(productIndex: number, distSts: string): boolean {
    if (Number(distSts) === 4 && this.reqDetails.requisition.requisitionType !== 'Direct Ship') {
      this.handleAlert(productIndex, 'seasonal');
      return true;
    } else {
      return false;
    }
  }

  dwoAlert(productIndex: number, distSts: string): boolean {
    if (Number(distSts) === 8) {
      this.handleAlert(productIndex, 'dwo');
      return true;
    } else {
      return false;
    }
  }

  discontinuedAlert(productIndex: number, distSts: string): boolean {
    if (Number(distSts) === 9) {
      this.handleAlert(productIndex, 'discontinued');
      return true;
    } else {
      return false;
    }
  }

  notAttachedAlert(productIndex: number, prodAttchd: string): boolean {
    if (prodAttchd === 'false') {
      this.handleAlert(productIndex, 'productsNotAttached');
      return true;
    } else {
      return false;
    }
  }

  missingCostAlert(productIndex: number, cost: Number): boolean {
    if (cost < 1) {
      this.handleAlert(productIndex, 'productsNotAttached');
      return true;
    } else {
      return false;
    }
  }

  preCheckCategoryManager(i: number): boolean {
    if (this.productsNew[i].productId !== null && this.productsNew[i].productId !== '' && this.productsNew[i].productId !== undefined) {
      this.categoryManagerProduct.validateNumber(this.productsNew[i].productId, this.productsNew[i].seq);
      if (!this.categoryManagerProduct.prod_nbr_errors_exist) {
        this.productNbrs.push(this.productsNew[i].productId);
        return false;
      } else {
        this.showAlertMessage('error', 'productsNotAttached');
        this.errorsExist = true;
        window.scrollTo(0, 0);
        return true;
      }
    } else {
      this.showAlertMessage('error', 'missingProductNbr');
      this.productsNew[i].errorFlag = true;
      this.errorsExist = true;
      window.scrollTo(0, 0);
      return true;
    }
  }

  preCheckProductAttachment(i: number): boolean {
    if (this.productsNew[i].productId !== null && this.productsNew[i].productId !== '' && this.productsNew[i].productId !== undefined) {
      this.productAttachmentProdInfo.validateNumber(this.productsNew[i].cost, this.productsNew[i].seq);
      if (!this.productAttachmentProdInfo.cost_errors_exist) {
        this.productNbrs.push(this.productsNew[i].productId);
      } else {
        this.showAlertMessage('error', 'productsNotAttached');
        this.errorsExist = true;
        window.scrollTo(0, 0);
        return true;
      }
    } else {
      this.showAlertMessage('error', 'missingProductNbr');
      this.productsNew[i].errorFlag = true;
      this.errorsExist = true;
      window.scrollTo(0, 0);
      return true;
    }
    return false;
  }

  loadProductNotAttachments() {
    for (let i = 0; i < this.productsNotAttached.length; i++) {
      this.productNbrs.push(this.productsNotAttached[i].productId);
    }
  }

  loadNewProduct(): boolean {
    let cantValidate = false;
    if (this.productsNew !== undefined) {
      for (let i = 0; i < this.productsNew.length; i++) {
        if (this.checkTaskNames(this.reqDetails.taskName) === "catMgr") {
          if (this.preCheckCategoryManager(i)) {
            cantValidate = true;
          }
        }
        if (this.checkTaskNames(this.reqDetails.taskName) === "replSpcl" || this.checkTaskNames(this.reqDetails.taskName) === "buyer1") {
          if (this.preCheckProductAttachment(i)) {
            cantValidate = true;
          }
        }
      }
    }
    return cantValidate;
  }

  callValidateProductService(cantValidate: boolean) {

    let isErrClear = false;
    if (this.checkTaskNames(this.reqDetails.taskName) === "catMgr" &&
      !cantValidate && !this.categoryManagerProduct.prod_nbr_errors_exist) {
      isErrClear = true;

    } else if ((this.checkTaskNames(this.reqDetails.taskName) === "replSpcl" ||
      this.checkTaskNames(this.reqDetails.taskName) === "buyer1") &&
      !cantValidate && !this.productAttachmentProdInfo.cost_errors_exist) {
        isErrClear = true;
        // this.productAttachmentProdInfo.products.forEach((product) => {
        //   this.productAttachmentProdInfo.validateNumber(product.cost, product.seq);
        // });
        // if(!this.productAttachmentProdInfo.cost_errors_exist){
        //   isErrClear = true;
        // }
    }

    if (isErrClear) {
      this.errorsExist = false;
      if (this.productNbrs.length > 0) {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.VALIDATE_PRODUCTS, { productNbrs: this.productNbrs, div: this.reqDetails.requisition.division });
        this.actionDispatcherService.dispatch(event);
      }
    }
  }

  mapVendor(productIndex: number, vendor: any) {
    if (vendor !== undefined) {
      this.reqDetails.products[productIndex].cost = vendor.vendorLstPrc;
      this.reqDetails.products[productIndex].vendor.vendorId = vendor.vendorId;
      this.reqDetails.products[productIndex].vendor.vendorName = vendor.vendorName;
      this.reqDetails.products[productIndex].vendor.buyerNetworkId = vendor.buyerNetworkId;
      this.reqDetails.products[productIndex].vendor.buyerEmail = vendor.buyerEmail;
      this.reqDetails.products[productIndex].vendor.buyerNumber = vendor.buyerNumber;
    }
  }

  mapRequested(productIndex: number, product: any) {
    if (this.reqDetails.products[productIndex].new === 'true') {
      this.reqDetails.products[productIndex].requested.description = product.description;
      this.reqDetails.products[productIndex].requested.label = product.label;
      this.reqDetails.products[productIndex].requested.packSize = product.packSize;
      this.reqDetails.products[productIndex].requested.mfrId = product.mfrId;
      this.reqDetails.products[productIndex].requested.salesUOM = product.salesUOM;
      this.reqDetails.products[productIndex].requested.vendor = product.vendor.vendorId;
      this.reqDetails.products[productIndex].requested.type = VALUEMAP.PRODUCTTYPE[product.pimClass];
    }
  }

  renderForCategoryManagerApprover(data: any) {
    if (this.reqDetails.products.length > 0 && this.reqDetails.products !== undefined) {
      for (let i = 0; i < this.reqDetails.products.length; i++) {
        this.processResultForCategoryManager(data, i);
      }
      this.checkIfApproveDisabled();
    }
  }

  processResultForCategoryManager(data: any, i: number) {
    if (data !== undefined && data.length > 0) {
      for (let j = 0; j < data.length; j++) {
        //need to validate the product code here    
        if (this.reqDetails.products[i].productId === data[j].productId.toString()) {
          let noAlert = this.productStatusCheck(i, j, data);
          if (noAlert && data[j].ntnlSts !== "" && data[j].ntnlSts !== undefined && data[j].ntnlSts !== null) {
            this.mapResultsetToReqDetails(i, j, data);
          } else {
            if (noAlert) {
              this.showAlertMessage('error', 'invalidProduct');
            }
            this.reqDetails.products[i].errorFlag = true;
            window.scrollTo(0, 0);
          }
        }
      }
    }
  }

  checkIfApproveDisabled() {
    if (this.checkTaskNames(this.reqDetails.taskName) === "catMgr") {
      this.productsNew = this.getNewProducts(this.reqDetails.products);
    }

    this.reqDetails.products.forEach((item) => {
      if (item.errorFlag === true) {
        this.errorsExist = true;
      }
    })
    if (!this.errorsExist) {
      this.isApproveDisabled = false;
      this.showAlertMessage('success', 'productsValidated');
    } else {
      this.isApproveDisabled = true;
    }
  }

  addRequisitionComment(event) {
    const comment = event.comment;
    this.reqDetails.requisition.comments.push(comment);
  }

  txtFieldInput($event) {
    const timeout = null;
    clearTimeout(timeout);
    // Make a new timeout set to go off in 800ms
    setTimeout(value => this.onLoadingEvent(value), 800, $event);


  }

  onLoadingEvent(query) {
    // Dispatch an event to get the default roles
    let queryString = this.transferTaskToTypeaheadSettings.selected;
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: queryString
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  onValueSelectEvent($event) {
    if (this.transferTaskToTypeaheadSettings.selected) {
      this.selectedUserToAdd = this.filterArray(
        this.searchedUsers,
        "firstName",
        this.getFirstName(this.transferTaskToTypeaheadSettings.selected),
        "lastName",
        this.getLastName(this.transferTaskToTypeaheadSettings.selected)
      );
      this.transferTaskToTypeaheadSettings.valid = true;
    }
  }  

  getUserName() {
    return JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName + "(" + JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId + ")";
  }

  getLastName(user: string) {
    const userArr = user.split(",");
    return userArr[0];
  }

  getFirstName(user: string) {
    const userArr = user.split(",");
    return userArr[1].trim();
  }

  filterArray(array, property, value, property2, value2) {
    return array.filter(obj => {
      return obj[property] === value && obj[property2] === value2;
    });
  }

  renderFilteredUsers(data) {
    this.searchedUsers = data.users;
    this.transferTaskToTypeaheadSettings.results = this.searchedUsers.map(item => {
      if (item.fullName !== this.transferTaskToTypeaheadSettings.selected) {
        return item.fullName;
      }
    });
    this.transferTaskToTypeaheadSettings.results = this.transferTaskToTypeaheadSettings.results.filter(item => item !== undefined);
  }

  isTransferBtnEnabled() {
    if (this.selectedUserToAdd.length > 0) {
       if (this.selectedUserToAdd[0].fullName.toUpperCase() === this.transferToTxtField.value.toUpperCase()) {
         this.transferTaskToTypeaheadSettings.valid = true;
         return true;
       }
       else {
         this.transferTaskToTypeaheadSettings.valid = false;
         return false;
       }
    } else {
      return false;
    }
  }

  transferRequisition() {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1);

      const request = {
      'taskId': this.taskId,
      'reqId': this.reqDetails.requisition.requisitionNumber,
      'approverId': [
        this.selectedUserToAdd[0].userID
      ],
      'updatedByUserID': this.getUserName(),
      'sodsRequisition': {
        'requisition': this.reqDetails.requisition,
        'requestor': this.reqDetails.requestor,
        'territoryManager': this.reqDetails.territoryManager,
        'customers': this.reqDetails.customers,
        'products': this.reqDetails.products,
        'auditLogs': this.reqDetails.auditLogs
      }
    };

    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.TRANSFER_REQUISITION,
      {
        body: request
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  renderTransferRequisitionSuccess(data) {
    //put the data object into the localstorage
    localStorage.setItem('transfer_reqId', data.reqId);
    localStorage.setItem('transfer_forwardId', data.forwardId);
    this.transferRequisitionModal.close();
    this.router.navigate(['taskInbox']);
  }

  renderTransferRequisitionFail(data) {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 

    this.errMsg = "Backend Issue, transfer requisition fails";
  }

  updateMeetsETA(event) {
    this.reqDetails.products.forEach((product) => {
      if (product.productId === event.productId) {
        product.meetsETA = event.flag;
      }
    });
  }

  updateCost(event) {
    if (!this.productBuyerProduct.cost_errors_exist) {
      this.isApproveDisabled = false;
      this.reqDetails.products.forEach((product) => {
        if (product.productId === event.productId) {
          product.cost = event.cost;
        }
      });
    } else {
      this.isApproveDisabled = true;
    }
  }

  validatePO() {
    let poNumber: string[] = new Array<string>();
    let vendorNumber: string;
    let buyerNumber: string;
    this.reqDetails.products.forEach((product) => {
      poNumber.push(product.PONumber);
      vendorNumber = product.vendor.vendorId;
      buyerNumber = product.vendor.buyerNumber;
    });
    let request = {
      'requisitionId': this.reqDetails.requisition.requisitionNumber,
      'vendorNumber': vendorNumber,
      'buyerNumber': buyerNumber,
      'poNumber': poNumber
    }
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

    this.reqDetails.products.forEach((product) => {
      let event = this.actionDispatcherService.generateEvent(ActionEvents.VALIDATE_PO, request);
      this.actionDispatcherService.dispatch(event);
    });
  }

  requisitionHasComments() {
    if (this.reqDetails.requisition.comments.length === this.orginalCommentLength) {
      return false;
    } else {
      return true;
    }
  }

  changeVendor() {
    this.isTransferDisabled = true;
  }

  handleBuyerError() {
    this.showAlertMessage('error', 'CESError');
    this.isApproveDisabled = true;
  }

  validateTransferTaskToField($event) {
    this.transferTaskToTypeaheadSettings.valid = $event.valid;
  }

}
