import { Component, OnInit, ViewChild } from '@angular/core';
import { Product, Vendor } from "app/model/product";
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";

@Component({
  selector: 'app-approver-change-vendor',
  templateUrl: './approver-change-vendor.component.html',
  styleUrls: ['./approver-change-vendor.component.css']
})
export class ApproverChangeVendorComponent implements OnInit {

  public selectedVendor: string;
  public defaultVendor: string;
  public vendorOptions: string[] = [];
  private vendorList: string[];
  public product: Product;
  public inputProduct: Product;
  public newVendor: Vendor;
  @ViewChild('changeVendorDropdown')
  public changeVendorDropdown: DropdownComponent;

  constructor() { }

  ngOnInit() {
    this.newVendor = new Vendor();
  }

  onVendorSelection(event){
    this.inputProduct.vndrDtlList.forEach((vendor)=>{
      if(vendor.vndrNbr === event){
        this.newVendor.vendorId = vendor.vndrNbr;
        this.newVendor.vendorName = vendor.vndrNm;
        this.newVendor.buyerNumber = vendor.byrNbr;
        this.newVendor.buyerName = vendor.byrNm;
        this.newVendor.buyerNetworkId = vendor.byrUserID;
        this.newVendor.buyerEmail = vendor.byrEmail;
        this.newVendor.vendorLstPrc = vendor.vndrLstPrc;
      }
    });
  }
}
