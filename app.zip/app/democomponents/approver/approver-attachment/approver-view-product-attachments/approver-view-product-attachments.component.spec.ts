import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverViewProductAttachmentsComponent } from './approver-view-product-attachments.component';

describe('ApproverViewProductAttachmentsComponent', () => {
  let component: ApproverViewProductAttachmentsComponent;
  let fixture: ComponentFixture<ApproverViewProductAttachmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverViewProductAttachmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverViewProductAttachmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
