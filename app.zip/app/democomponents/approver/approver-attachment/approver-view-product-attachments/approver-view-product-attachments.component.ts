import { ModelChangeUpdateEvents, ActionEvents } from './../../../../events/action-events';
import { BaseComponent } from './../../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { Attachment } from './../../../../model/attachment';
import { Product } from './../../../../model/product';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approver-view-product-attachments',
  templateUrl: './approver-view-product-attachments.component.html',
  styleUrls: ['./approver-view-product-attachments.component.css']
})
export class ApproverViewProductAttachmentsComponent extends BaseComponent implements OnInit {

  public seqId:number;
  public requisitionId:number;
  public attachmentKey:number;
  actionCompleted:boolean = true;
  public actionFailed = false;
  public product: Product;
  public attachmentsList:Array<Attachment> = [];
  errorMsg: string;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {

    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {    this.renderAttachmentDetails(data);  }
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_FAIL] = () => {this.renderNoAttachmentDetails()}
    super.registerStateChangeEvents(mapping); 
}

ngOnInit() {
  this.attachmentsList = [];
  
  let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId, attachmentKey:this.attachmentKey});
  this.actionDispatcherService.dispatch(event);
}

renderAttachmentDetails(data) {
  this.attachmentsList = data;
}

  renderNoAttachmentDetails() {
    this.actionCompleted = true;
  }

  renderAttachmentDownloaded() {
    this.actionCompleted = true;
  }

  downloadAttachments(requisitionId, fileName, objectKey, attachmentKey) {
    this.actionCompleted = false;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_DOWNLOAD, {requisitionId: requisitionId, objectKey: objectKey, fileName: fileName, attachmentKey: attachmentKey});
    this.actionDispatcherService.dispatch(event);
  }

  renderError(error: any) {
    this.actionCompleted = true;
    this.errorMsg = error.statusText;
    this.actionFailed = true;
  }


}