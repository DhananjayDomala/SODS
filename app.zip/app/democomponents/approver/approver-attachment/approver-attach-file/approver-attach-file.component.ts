import { environment } from './../../../../../environments/environment';
import { ObjectKey } from './../../../../model/objectKey';
import { Modal } from 'ngx-modal';
import { DropdownComponent } from './../../../common/dropdown/dropdown.component';
import { ModelChangeUpdateEvents, ActionEvents } from './../../../../events/action-events';
import { BaseComponent } from './../../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService, Event } from 'usf-sam';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http';
import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { element } from 'protractor';

@Component({
  selector: 'app-approver-attach-file',
  templateUrl: './approver-attach-file.component.html',
  styleUrls: ['./approver-attach-file.component.css']
})
export class ApproverAttachFileComponent extends BaseComponent implements OnInit {

  @Output() uploadFileEvent = new EventEmitter<any>();
  @Output() notify = new EventEmitter();
  @Output() closeAttachFileModal = new EventEmitter();
  @ViewChild('fileInput') inputEl: ElementRef;
  @ViewChild('fileTypeDropdown') fileTypeDropDown: DropdownComponent;
  @ViewChild('AttachFileModalAreYouSure') removeAttachmentModal: Modal;
  public showIcon: boolean = true;
  public fileChosen: boolean = false;
  public filesAr: any[];
  public listOfFiles:Array<ObjectKey> = [];
  public delFile: ObjectKey;
  hide: boolean = false;
  index:number = 0;
  fileTypeOptions: string[];
  readonly defaultFileType: string = "";
  selectFileType: string;
  otherSelected: boolean = false;
  otherFileType: string;
  requisitionId: string;
  public other_require_error: boolean = false;
  public invalid_format:boolean = false;
  public file_type_error: boolean = false;
  public valid_format_error:boolean = false;
  public error_on_upload:boolean = false;
  public errors: string;
  fileSelected: boolean = false;
  fileTypeChosen: boolean = false;
  otherFileInputFilled: boolean = false;
  public file_uploaded:boolean = false;
  disableUpload: boolean = false;
  uploadedFilesNbr:number;

  constructor(private http: Http, readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);     
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_UPLOAD_FAIL] = (error: any) => {this.renderError(error)}
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL] = (error: any) => {this.renderError(error)};
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    this.fileTypeOptions = ['','Signed Order', 'Customer Quote', 'Order Acknowledgement', 'Vendor Acknowledgement', 'Spec Sheets','Other'];
    this.selectFileType = this.defaultFileType;
    this.requisitionId = ''; //Get requisition ID from page load
  }

  onFileTypeSelection($event) {
    this.selectFileType = $event;
    this.other_require_error = false;
    this.invalid_format = false;
    this.valid_format_error = false;
    if(this.selectFileType == 'Other') {
      this.otherSelected = true;
      this.file_type_error = false;
    }else if(this.selectFileType == ''){
      this.file_type_error = true;
      this.otherSelected = false;
    }else{
      this.otherFileType = "";
      this.otherSelected = false;
      this.file_type_error = false;
    }
  }
  removeFile() {
      this.showIcon = true;
      this.inputEl.nativeElement.value = "";
  }

  softDeleteAttachments() {
    this.removeAttachmentModal.close();
    this.notify.emit('closeAttachFileModal');
    this.listOfFiles.forEach((element) => {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_SOFT_DELETE, {requisitionId: this.requisitionId, attachmentsList: this.listOfFiles});
        this.actionDispatcherService.dispatch(event);
    });
  }
  uploadFile(){
      if(this.disableUpload) {
          this.errors = 'Cannot upload more than 10 files';
          this.error_on_upload = true;
      }else {
          if(this.uploadedFilesNbr + this.listOfFiles.length + 1 > 10) {
              this.errors = 'Cannot upload more than 10 files';
              this.error_on_upload = true;
          }else{
              this.fileChosen = true;
              this.error_on_upload = false;
              let resultingEvent: Event<any> = null;
              let token = JSON.parse(localStorage.getItem('token')).value; 
              let fullName = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).firstName + " " + JSON.parse(JSON.parse(localStorage.getItem('user'))._body).lastName;
              let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
              let headers = new Headers();
              headers.append('Authorization', `Bearer ${token}`);
              let options = new RequestOptions({headers: headers});
              let APIURL = environment.requisitionAttachments + "/" + this.requisitionId + "/upload";
              let attachment = new FormData();
              let inputEl: HTMLInputElement = this.inputEl.nativeElement;
              let fileCount: number = inputEl.files.length;
              let fileName: string;
              if (fileCount > 0) { // a file was selected
                  for (let i = 0; i < fileCount; i++) {
                      attachment.append("attachment", inputEl.files.item(i));
                      attachment.append("fullName", fullName);
                      attachment.append("userId", userId);
                      fileName = inputEl.files.item(i).name;
                      let currentDate = new Date();
                      let creationDate = currentDate.toJSON();
                  }
                  this.http.put(APIURL, attachment, options).toPromise().then(
                      (res: Response)=>{
                          let body = res.json();
                          this.listOfFiles.push({objectKey: body.objectKey, fileName: fileName, requisitionId: ""});
                          this.file_uploaded = true;
                          this.notify.emit('true');
                      }
                  ).catch(
                      (error: Response) => {
                          let errorBody = error.json();
                          this.error_on_upload = true;
                          this.errors = errorBody.message;
                      }
                  );
              }
              this.inputEl.nativeElement.value = "";
              return resultingEvent;
          }
      }
  }
  deleteFile(objectKey: ObjectKey) {
      this.delFile = objectKey;
      this.listOfFiles.forEach((objectKey, index) => {
          if(this.delFile && this.delFile.objectKey == objectKey.objectKey) {
              this.listOfFiles.splice(index, 1);
              this.delFile = null;
              let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_DELETE, {requisitionId: this.requisitionId, objectKey: objectKey.objectKey});
              this.actionDispatcherService.dispatch(event);
          }
      });
      if(this.listOfFiles.length < 1) {
          this.file_uploaded = false;
          this.notify.emit('false');
          this.fileChosen = false;
      }
      if(this.uploadedFilesNbr + this.listOfFiles.length > 999) {
          this.errors = 'Cannot upload more than 999 files';
          this.error_on_upload = true;
      }else{
          this.error_on_upload = false;
          this.errors = '';
      }
  }
  
  deleteElement(elementId) {
      let elementitem:HTMLElement = document.getElementById('tdElement['+elementId+']');
      elementitem.parentNode.removeChild(elementitem);
  }
  
  upload() {
      if(this.selectFileType == 'Other') {
          if(this.listOfFiles.length > 0) {
              let isValid = this.validate();
              if(!isValid) {
                this.invalid_format = false;
                this.valid_format_error = false;
                let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_EDIT, {requisitionId: this.requisitionId, fileType: this.otherFileType, attachmentsList: this.listOfFiles});
                this.actionDispatcherService.dispatch(event);
                this.notify.emit('closeAttachFileModal');
              }else{
                this.other_require_error = false;
                this.invalid_format = true;
                this.valid_format_error = true;
              }
          }
      }else{
          if(this.selectFileType !== 'Other') {
              if(this.selectFileType == "") {
                  this.file_type_error =
                  ((this.selectFileType == null || this.selectFileType == undefined || this.selectFileType.trim() == "") ? true: false);
              }else{
                  if(this.listOfFiles.length > 0) {
                      let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_EDIT, {requisitionId: this.requisitionId, fileType: this.selectFileType, attachmentsList: this.listOfFiles});
                      this.actionDispatcherService.dispatch(event);
                      this.notify.emit('closeAttachFileModal'); //Get this working again!
                  }
              }
          }
      }
  }
  checkKeyupRequire_other() {
      this.other_require_error =
      ((this.otherFileType == null || this.otherFileType == undefined || this.otherFileType.trim() == "") ? true: false);
      this.invalid_format = false;
      this.valid_format_error = false;
  }
  validate() {
      return !/^[a-z0-9]+$/i.test((this.otherFileType).trim().replace(/\s/g, ''));     
  }
  renderError(error) {
      this.error_on_upload = true;
  }

}
