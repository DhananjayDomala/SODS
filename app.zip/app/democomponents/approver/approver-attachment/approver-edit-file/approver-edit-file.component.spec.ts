import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverEditFileComponent } from './approver-edit-file.component';

describe('ApproverEditFileComponent', () => {
  let component: ApproverEditFileComponent;
  let fixture: ComponentFixture<ApproverEditFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverEditFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverEditFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
