import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverBuyerProductComponent } from './approver-buyer-product.component';
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { DivisionsService } from "app/service/divisions.service";
import { User } from "app/model/user";
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { TaskInboxProduct, ReqDetails } from "app/model/submitRequisition";

describe('ApproverBuyerProductComponent', () => {
  let component: ApproverBuyerProductComponent;
  let fixture: ComponentFixture<ApproverBuyerProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [ ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        DivisionsService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const mockSAMCall = {
      loadAttachmentDetails: () => {

      }
    }
    fixture = TestBed.createComponent(ApproverBuyerProductComponent);
    component = fixture.componentInstance;
    component.products = new Array<TaskInboxProduct>();
    spyOn(component.viewProductsComponent, 'loadAttachmentDetails').and.callFake(mockSAMCall.loadAttachmentDetails);
    component.reqDetails = new ReqDetails();
    component.reqDetails.requisition.requisitionType = 'Direct Ship';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
