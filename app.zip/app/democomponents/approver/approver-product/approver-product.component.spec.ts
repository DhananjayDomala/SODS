import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverProductComponent } from './approver-product.component';
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { DivisionsService } from "app/service/divisions.service";
import { User } from "app/model/user";
import { TaskInboxProduct } from "app/model/submitRequisition";

describe('ApproverProductComponent', () => {
  let component: ApproverProductComponent;
  let fixture: ComponentFixture<ApproverProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [ ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        DivisionsService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const mockSAMCall = {
      loadAttachmentDetails: () => {

      }
    }
    fixture = TestBed.createComponent(ApproverProductComponent);
    component = fixture.componentInstance;
    component.products = new Array<TaskInboxProduct>();
    spyOn(component.viewProductsComponent, 'loadAttachmentDetails').and.callFake(mockSAMCall.loadAttachmentDetails);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
