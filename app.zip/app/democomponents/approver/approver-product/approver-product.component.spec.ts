import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverProductComponent } from './approver-product.component';

describe('ApproverProductComponent', () => {
  let component: ApproverProductComponent;
  let fixture: ComponentFixture<ApproverProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
