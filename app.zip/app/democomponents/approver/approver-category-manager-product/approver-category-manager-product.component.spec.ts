import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverCategoryManagerProductComponent } from './approver-category-manager-product.component';

describe('ApproverCategoryManagerProductComponent', () => {
  let component: ApproverCategoryManagerProductComponent;
  let fixture: ComponentFixture<ApproverCategoryManagerProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverCategoryManagerProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverCategoryManagerProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
