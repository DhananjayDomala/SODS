import { BaseComponent } from './../../base-component';
import { ModelChangeUpdateEvents, ActionEvents } from './../../../events/action-events';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { TaskInboxProduct, ReqDetails } from './../../../model/submitRequisition';
import { ApproverViewProductAttachmentsComponent } from './../approver-attachment/approver-view-product-attachments/approver-view-product-attachments.component';
import { ProductCommentComponent } from './../../common/comment/product-comment/product-comment.component';
import { Modal } from 'ngx-modal';
import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';

@Component({
  selector: 'app-approver-product-attachment-prod-info',
  templateUrl: './approver-product-attachment-prod-info.component.html',
  styleUrls: ['./approver-product-attachment-prod-info.component.css']
})
export class ApproverProductAttachmentProdInfoComponent extends BaseComponent implements OnInit {
  
  @ViewChild('viewComments') viewMsgsToModal: Modal;
  @ViewChild('viewProduct') viewProduct: Modal;
  @ViewChild('ProductAttachmentModal') productAttachmentModal: Modal;
  @ViewChild('ProductAttachments') productAttachments: ApproverViewProductAttachmentsComponent;
  @ViewChild('ProductComments') productComments: ProductCommentComponent; 
 
  @Output('showHide') showHide: EventEmitter<any> = new EventEmitter<any>();
  @Input() invalidProducts: number[];
  @Input() products: TaskInboxProduct[];
  @Input() reqDetails: ReqDetails;
  @Input() set collapsed(value: boolean) {this.isCollapsed = value;}

  public attachmentsList:Array<any> = [];
  isCollapsed: boolean;
  requistionDetails: ReqDetails;
  comments: any[] = [];
  selectedIndex: any;
  currentProd: any;
  productCommentAdded: boolean[] = new Array<boolean>();
  addComment: EventEmitter<any> = new EventEmitter<any>();
  allChecked = false;
  public reqNbr: string;
  public cost_errors_exist: boolean = false;
  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];           
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => { this.renderAttachmentDetails(data) }
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    this.products.forEach((product) => {
      this.productCommentAdded.push(false);
    });
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

  openViewComments(comments, index) {
    this.selectedIndex = index;
    this.comments = [...comments] || [];

    this.viewMsgsToModal.open();
    this.productComments.newAddedCount = 0;
    this.productComments.comments = this.comments;
    this.productComments.productSeq = index + 1;
  }

  openViewAttachments(seq) {
    this.productAttachments.attachmentsList = [];
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, 
      {requisitionId: this.reqNbr, attachmentKey:seq});
    this.actionDispatcherService.dispatch(event);
    this.productAttachments.seqId = seq;
    this.productAttachmentModal.open();
  }

  openProd(product) {
    this.currentProd = product;
    this.viewProduct.open();
  }

  closeMsgModal() {
    if(this.productComments.newAddFlag === true){
      //cancel without saving so clear out the first item of the comments array
      for(let i = 0; i < this.productComments.newAddedCount; i++){
        this.productComments.comments.shift();
      }
      //reset the add flag
      this.productComments.newAddFlag = false;
    }
    //clear error
    this.productComments.commentErr = false;
    this.viewMsgsToModal.close();
  }

    //save Comment
    saveComment() {
      //validation first
      if (this.productComments.commentErr === true) {
        return;
      }
      //if user does not hit add, just close it
      if (this.productComments.newAddFlag === false) {
        this.viewMsgsToModal.close();
      } else {
        this.productComments.newAddFlag = false;
        //save to comments array of product element
        this.products.forEach((product, index) => {
          if (product.seq === this.productComments.productSeq) {
            //will need to remove the empty text on the first element
            if (this.productComments.comments[0].commentsText === '') {
              this.productComments.comments.shift();
            }
            product.comments = this.productComments.comments;
            this.productCommentAdded[this.selectedIndex] = true;
            this.addComment.emit({'product': this.products[this.selectedIndex]});
          }
        });
        this.viewMsgsToModal.close();
      }
    }

  closeProdModal() {
    this.viewProduct.close();
  }

  isCommentAddedToProduct(productIndex: number) {
    return this.productCommentAdded[productIndex] === true;
  }

  isInvalid(index): boolean {
    let invalidIndex = 0;
    this.invalidProducts.forEach((invalid) => {
      if (index === invalid) {
        invalidIndex++;
      }
    });
    return invalidIndex > 0;
  }

  renderAttachmentDetails(data) {
    this.attachmentsList = data;
  }


  cancelProductAttchment(){
    this.productAttachmentModal.close();
  }

  downloadAll(){
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_MULTI_DOWNLOAD, 
      {requisitionId: this.reqNbr, attachmentsList: this.productAttachments.attachmentsList, 
        attachmentKey: this.productAttachments.seqId });
    this.actionDispatcherService.dispatch(event);
  }

  validateNumber(data: string, seq: string) {
    this.cost_errors_exist = false;
    if(this.validateNbr(data)) {
      for(let i = 0; i < this.products.length; i++) {
        if(this.products[i].seq === seq) {
          this.products[i].nbrError = false;
        }
      }
    }else{
      for(let i = 0; i < this.products.length; i++) {
        if(this.products[i].seq === seq) {
          this.cost_errors_exist = true;
          this.products[i].nbrError = true;
        }
      }
    }
  }

  validateNbr(data: string){
		if(data === null || data === undefined || data === "") {
      return false;
    }
		let NUMBER_REGEXP = /^[1-9]\d*(\.\d+)?$/;
		return NUMBER_REGEXP.test(data);
  }
  
}
