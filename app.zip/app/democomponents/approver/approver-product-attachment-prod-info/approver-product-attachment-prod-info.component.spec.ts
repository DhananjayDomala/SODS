import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { DivisionsService } from "app/service/divisions.service";
import { User } from "app/model/user";

import { ApproverProductAttachmentProdInfoComponent } from './approver-product-attachment-prod-info.component';
import { TaskInboxProduct } from "app/model/submitRequisition";

fdescribe('ApproverProductAttachmentProdInfoComponent', () => {
  let component: ApproverProductAttachmentProdInfoComponent;
  let fixture: ComponentFixture<ApproverProductAttachmentProdInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        DivisionsService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const mockSAMCall = {
      loadAttachmentDetails: () => {

      }
    }
    fixture = TestBed.createComponent(ApproverProductAttachmentProdInfoComponent);
    component = fixture.componentInstance;
    component.products = new Array<TaskInboxProduct>();
    spyOn(component.productAttachments, 'loadAttachmentDetails').and.callFake(mockSAMCall.loadAttachmentDetails);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close product modal successfully', ()=> {
    component.closeProdModal();
    expect(component.viewProduct.isOpened).toBeFalsy;
  });

  it('should render ')

});