import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'phoneNumberPipe',
})
export class PhoneNumberPipe implements PipeTransform {
    transform(value: string) {
        if(value !== null) {
            return this.formatPhoneNum(value);
        }
    }

    formatPhoneNum(phone) {
        return phone.replace(/(\d{3})(\d{3})(\d{3})/, '($1) $2-$3');
    }
}