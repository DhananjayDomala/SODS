import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'phoneNumberPipe',
})
export class PhoneNumberPipe implements PipeTransform {
    transform(value: string): string {
        if(value !== null && value !== undefined) {
            return this.formatPhoneNum(value);
        }
        return '';
    }

    formatPhoneNum(phone): string {
        return phone.replace(/(\d{3})(\d{3})(\d{3})/, '($1) $2-$3');
    }
}