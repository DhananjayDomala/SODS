import { Customer } from '../../model/customer';
import { Product, Vendor, ShipToDist, VndrDtlList } from '../../model/product';
import { TandemTM } from '../../model/tandemTM';
import { ReqDetails, TaskInboxCustomer, TaskInboxProduct, Task } from '../../model/submitRequisition';
import { SuperUser } from '../../model/superuser';

export class ResponseMapper {
    static requistionTypes: any = {
        'SODS-SO': 'Special Order',
        'SODS-DS': 'Direct Ship'
    };

    static mapCustomer(data: any): Customer {
        let customer: Customer = new Customer();
        customer.id = data.custNbr;
        customer.division = data.div;
        customer.name = data.custNm;
        customer.address1 = data.addr.addr1;
        customer.address2 = data.addr.addr2;
        customer.city = data.addr.cty;
        customer.state = data.addr.ste;
        customer.zip = data.addr.zip;
        customer.phone = data.phone.telNbr;
        customer.estimatedOrderAmt = '321.12';
        customer.confidenceCode = data.creditCd;
        customer.creditCheckStatus = 'true';
        customer.tmId = data.rte.tmId;
        customer.tmName = 'sodsus02, SharedAcct';
        customer.tmEmail = 'Shared.sodsus02@foodfite.com';
        customer.deptOptions = this.buildOptions(data.dept || []);
        customer.custType = data.custTyp;
        return customer;
    }

    static mapProduct(data: any): Product{
        let product: Product = new Product();
        let vendor : Vendor = new Vendor();
        product.vendor = vendor;
        product.description = data.desc;
        product.productId = data.prodNbr;
        product.mfrId = data.mfrProdNbr;
        product.distSts = data.distSts;
        product.label = data.label;
        product.priceUOM = data.priceUOM;
        product.packSize = data.slsPkSize;
        product.netWeight = data.netWght;
        product.salesUOM = data.slsUOM;
        product.catchWeightInd = data.catchWghtInd;
        if(data.primVndrDtl !== null && data.primVndrDtl !== undefined){
            product.vendor.vendorId = data.primVndrDtl.vndrNbr;
            product.vendor.vendorName = data.primVndrDtl.vndrNm;
            product.vendor.vendorLstPrc = data.primVndrDtl.vndrLstPrc;
            product.vendor.buyerNumber = data.primVndrDtl.byrNbr;
            product.vendor.buyerEmail = data.primVndrDtl.byrEmail;
            product.vendor.buyerName = data.primVndrDtl.byrNm;
            product.vendor.buyerNetworkId = data.primVndrDtl.byrUsrID;
        }
        product.prodCnt = data.prodCnt;
        //add converter
        product.convFctr = data.convFctr;
        product.ntnlSts = data.ntnlSts;
        product.prodAttchd = data.prodAttchd;
        if(data.prodAttchd === 'T'){
            product.attached = 'true';
        }else if(data.prodAttchd === 'F'){
            product.attached = 'false';
        }else{
            product.attached = data.prodAttchd;
        }
        product.class = data.pimClass;
        product.pimClass = data.pimClass;
        return product;
    }

    static mapValidatedProducts(data: any) {
        let productsList: Array<Product> = [];
        for(let i = 0; i < data.product.length; i++) {
            let entry = data.product[i];
            let product: Product = new Product();
            let vendor : Vendor = new Vendor();
            product.vendor = vendor;
            product.description = entry.desc;
            product.vndrDtlList = Array<VndrDtlList>();
            product.productId = entry.prodNbr;
            product.mfrId = entry.mfrProdNbr;
            product.distSts = entry.distSts;
            product.label = entry.label;
            product.priceUOM = entry.priceUOM;
            product.packSize = entry.slsPkSize;
            product.netWeight = entry.netWght;
            product.salesUOM = entry.slsUOM;
            product.catchWeightInd = entry.catchWghtInd;
            if(entry.primVndrDtl !== undefined && entry.primVndrDtl !== null) {
                product.vendor.vendorId = entry.primVndrDtl.vndrNbr;
                product.vendor.vendorName = entry.primVndrDtl.vndrNm;
                product.vendor.vendorLstPrc = entry.primVndrDtl.vndrLstPrc;
                product.vendor.buyerNumber = entry.primVndrDtl.byrNbr;
                product.vendor.buyerEmail = entry.primVndrDtl.byrEmail;
                product.vendor.buyerName = entry.primVndrDtl.byrNm;
                product.vendor.buyerNetworkId = entry.primVndrDtl.byrUsrID;
            }
            if(entry.vndrDtlList !== undefined && entry.primVndrDtl !== null) {
                for(let j = 0; j < entry.vndrDtlList.length; j++) {
                    let newVndrDtl : VndrDtlList = new VndrDtlList();
                    newVndrDtl.byrEmail = entry.vndrDtlList[j].byrEmail;
                    newVndrDtl.byrNbr = entry.vndrDtlList[j].byrNbr;
                    newVndrDtl.byrNm = entry.vndrDtlList[j].byrNm;
                    newVndrDtl.byrUserID = entry.vndrDtlList[j].byrUserID;
                    newVndrDtl.primVndrNbr = entry.vndrDtlList[j].primVndrNbr;
                    newVndrDtl.vndrLstPrc = entry.vndrDtlList[j].vndrLstPrc;
                    newVndrDtl.vndrNbr = entry.vndrDtlList[j].vndrNbr;
                    newVndrDtl.vndrNm = entry.vndrDtlList[j].vndrNm;
                    product.vndrDtlList.push(newVndrDtl);
                }
            }
            product.prodCnt = entry.prodCnt;
            product.convFctr = entry.convFctr;
            product.ntnlSts = entry.ntnlSts;
            if(entry.prodAttchd === 'T'){
                product.prodAttchd = 'true';
                product.attached = 'true';
            }else{
                product.prodAttchd = 'false';
                product.attached = 'false';
            }
            product.class = entry.pimClass;
            product.pimClass = entry.pimClass;
            productsList.push(product);
        }
        return productsList;
    }

    static mapTMInfo(data: any): TandemTM{
        let tandemTM: TandemTM = new TandemTM();
        tandemTM.routeToDivision = data.routeToDivision;
        tandemTM.routeToDivisionCode = data.routeToDivisionCode;
        tandemTM.routeToDivisionSystem = data.routeToDivisionSystem;
        tandemTM.routeToDivisionTimezone = data.routeToDivisionTimezone;
        tandemTM.routeToDSMID = data.routeToDSMID;
        tandemTM.routeToFMID = data.routeToFMID;
        tandemTM.routeToRSMID = data.routeToRSMID;
        tandemTM.routeToVPID = data.routeToVPID;
        tandemTM.status = data.status;
        tandemTM.statusDescription = data.statusDescription;
        tandemTM.tmnetworkID = data.tmnetworkID;
        tandemTM.tmparentDivision = data.tmparentDivision;
        return tandemTM;
    }

    private static buildOptions(dept: any): string[] {
        let optionList: string[] = [];

        if(dept.length === 0){
            return ['00-NODEPT'];
        }
        
        for(let i = 0; i < dept.length; i++) {
            let entry = dept[i];
            let department = entry.dptNbr.concat('-'.concat(entry.dptNm));
            optionList.push(department);
        }
        return optionList;
    }

    static avoidNull(data: any): any {
        if(typeof(data) === 'string'){
            return data || '';
        }

        if(Array.isArray(data)){
            return data || [];
        }
        return data;
    }

    static mapRequisitionDetails(sodsReq: ReqDetails, tasks: Task[]): ReqDetails {
        const reqDetails: ReqDetails = new ReqDetails();
        console.log(sodsReq);

        reqDetails.draftTaskId = this.avoidNull(sodsReq.draftTaskId);
        reqDetails.overideSavedByID = this.avoidNull(sodsReq.overideSavedByID)
        reqDetails.overideSavedByName = this.avoidNull(sodsReq.overideSavedByName);
        reqDetails.taskId = this.avoidNull(sodsReq.taskId);
        reqDetails.taskName = this.avoidNull(sodsReq.taskName);
        reqDetails.taskStatus = this.avoidNull(sodsReq.taskStatus);
        reqDetails.responseStatus = this.avoidNull(sodsReq.responseStatus);
        reqDetails.assignedToCount = this.avoidNull(sodsReq.assignedToCount);
        reqDetails.assignedToList = this.avoidNull(sodsReq.assignedToList);
        reqDetails.acceptedByList = this.avoidNull(sodsReq.acceptedByList);

        // requisition
        reqDetails.requisition.comments = this.avoidNull(sodsReq.requisition.comments);       
        reqDetails.requisition.createdAt = this.avoidNull(sodsReq.requisition.createdAt);
        reqDetails.requisition.defaultCustomerPO = this.avoidNull(sodsReq.requisition.defaultCustomerPO);
        reqDetails.requisition.defaultShipMethod = this.avoidNull(sodsReq.requisition.defaultShipMethod);
        reqDetails.requisition.defaultSpecialInstructions = this.avoidNull(sodsReq.requisition.defaultSpecialInstructions);
        reqDetails.requisition.mainCustomerType = this.avoidNull(sodsReq.requisition.mainCustomerType);
        reqDetails.requisition.division = this.avoidNull(sodsReq.requisition.division);
        reqDetails.requisition.ETADate = this.avoidNull(sodsReq.requisition.ETADate);
        reqDetails.requisition.ETASelection = sodsReq.requisition.ETASelection || false;
        reqDetails.requisition.mainCustomerDept = this.avoidNull(sodsReq.requisition.mainCustomerDept);
        reqDetails.requisition.mainCustomerID = this.avoidNull(sodsReq.requisition.mainCustomerID);
        reqDetails.requisition.mainCustomerName = this.avoidNull(sodsReq.requisition.mainCustomerName);
        reqDetails.requisition.quoteNumber = this.avoidNull(sodsReq.requisition.quoteNumber);
        reqDetails.requisition.quotePrice = this.avoidNull(sodsReq.requisition.quotePrice);
        reqDetails.requisition.requisitionNumber = this.avoidNull(sodsReq.requisition.requisitionNumber);
        reqDetails.requisition.requisitionType = this.requistionTypes[sodsReq.requisition.requisitionType] || sodsReq.requisition.requisitionType;
        reqDetails.requisition.returnIfETANotMet = sodsReq.requisition.returnIfETANotMet || false;
        reqDetails.requisition.status = this.avoidNull(sodsReq.requisition.status);
        reqDetails.requisition.totalAmount = this.avoidNull(sodsReq.requisition.totalAmount);
        reqDetails.requisition.updatedAt = this.avoidNull(sodsReq.requisition.updatedAt);

        // requestor
        reqDetails.requestor.additionalEmail = this.avoidNull(sodsReq.requestor.additionalEmail);
        reqDetails.requestor.additionalPhone = this.avoidNull(sodsReq.requestor.additionalPhone);
        reqDetails.requestor.email = this.avoidNull(sodsReq.requestor.email);
        reqDetails.requestor.name = this.avoidNull(sodsReq.requestor.name);
        reqDetails.requestor.networkID = this.avoidNull(sodsReq.requestor.networkID);

        // territory manager
        reqDetails.territoryManager.additionalEmail = this.avoidNull(sodsReq.territoryManager.additionalEmail);
        reqDetails.territoryManager.additionalPhone = this.avoidNull(sodsReq.territoryManager.additionalPhone);
        reqDetails.territoryManager.email = this.avoidNull(sodsReq.territoryManager.email);
        reqDetails.territoryManager.name = this.avoidNull(sodsReq.territoryManager.name);
        reqDetails.territoryManager.networkID = this.avoidNull(sodsReq.territoryManager.networkID);    

        // customers
        let customers: TaskInboxCustomer[] = new Array<TaskInboxCustomer>();
        sodsReq.customers.forEach((customer) => {
            customer.defaultShipMethod = customer.defaultShipMethod;
            customers.push(customer);
        });
        reqDetails.customers = customers;

        // products
        let products: TaskInboxProduct[] = new Array<TaskInboxProduct>();
        sodsReq.products.forEach((product: TaskInboxProduct) => {
            if (!product.returned) {
                product.returned = false;
            }
            products.push(product);
        });
        reqDetails.products = products;
        reqDetails.auditLogs = sodsReq.auditLogs;
        reqDetails.tasks = this.avoidNull(tasks);
        return reqDetails;
    }

    static mapSuperUser(res: any) {
        const resSuperUsers = res.superUsers || '';
        const superUsers: SuperUser[] = new Array<SuperUser>();
        if (resSuperUsers) {
            resSuperUsers.forEach((user, i) => {
                const superUser = new SuperUser();
                superUser.firstName = user.firstName;
                superUser.lastName = user.lastName;
                superUser.market = user.market;
                superUser.updatedBy = user.updatedBy;
                superUser.updatedDate = user.updatedDate;
                superUser.userID = user.userID;
                superUsers.push(superUser);
            });
        }
        return superUsers;
    }

}