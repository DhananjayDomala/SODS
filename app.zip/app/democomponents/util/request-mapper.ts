import { SetProductNbrs, SetProductNbrsContent } from './../../model/productNbrs';
import { UnsetOutOfOffice, SetOutOfOffice, UnsetOutOfOfficeContent, SetOutOfOfficeContent } from '../../model/outofoffice';

export class RequestMapper {

    static mapUnsetOutofOffice(data: any): UnsetOutOfOffice {
        
        let unsetOutOfOffice: UnsetOutOfOffice = new UnsetOutOfOffice();
        let unsetOutOfOfficeContent: UnsetOutOfOfficeContent = new UnsetOutOfOfficeContent();

        unsetOutOfOfficeContent.NetworkID = data.networkId;
        unsetOutOfOffice.unsetOoOrequest = unsetOutOfOfficeContent;
        return unsetOutOfOffice;
    }

    
    static mapSetOutofOffice(data: any): SetOutOfOffice {

        const date = data.val;
        let setOutOfOffice: SetOutOfOffice = new SetOutOfOffice();
        let setOutOfOfficeContent: SetOutOfOfficeContent = new SetOutOfOfficeContent();
        setOutOfOfficeContent.outOfOfficeUserID = (data.updateType === 'outOfOffice') ? data.networkId : ((data.updateType === 'setOtherUser') ? (data.otherUser || {}).userID : '');
        setOutOfOfficeContent.updatedByUserID = data.networkId;
        setOutOfOfficeContent.returnDate = date.getFullYear() + "-" + ((date.getMonth() + 1 <= 9) ? '0' : '') + (date.getMonth() + 1) + "-" + ((date.getDate() <= 9) ? '0' : '') + (date.getDate()); 
        setOutOfOfficeContent.designateID = (data.updateType === 'setOtherUser' || data.updateType === 'outOfOffice') ? (data.forwardTaskUser || {}).userID : '';
        setOutOfOfficeContent.superUserID = (data.updateType === 'setOtherUser') ? data.networkId : undefined
        setOutOfOffice.setOoOrequest = setOutOfOfficeContent;
        return setOutOfOffice;
    }

    static mapProductAndManufacturer(data: any): SetProductNbrs {
        let setProductNbrs: SetProductNbrs = new SetProductNbrs();
        let setProductNbrsContent: SetProductNbrsContent = new SetProductNbrsContent();
        setProductNbrsContent.productNbr = data;
        setProductNbrs.setProductNbrs = setProductNbrsContent;
        return setProductNbrs;
    }

}