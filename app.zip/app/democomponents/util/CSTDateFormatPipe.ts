import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
    name: 'CSTdateFormatPipe',
})
export class CSTDateFormatPipe implements PipeTransform {
    transform(value: string) {
        let dateStr = value.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
        dateStr = dateStr.replace('-','/');
        let date = new Date(dateStr + ' CST');
        return date.toLocaleString() + ' ' + date.toString().replace(/.*[(](.*)[)].*/,'$1').replace('Pacific Standard Time','PST').replace('Central Standard Time','CST')
            .replace('Mountain Standard Time', 'MST').replace('Eastern Standard Time', 'EST');
    }
}