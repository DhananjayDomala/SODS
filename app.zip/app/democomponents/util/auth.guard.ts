import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate{

    private useJWT = false;
    constructor(private router: Router){

    }

    canActivate(){
        if(this.useJWT){
            
        }else{
            //TODO: implement the authentication logic
            let record = JSON.parse(localStorage.getItem('token'));
            if(!record){
                this.router.navigate(['/']);
                return false;
            }
            let expiration = record.timestamp;

            if(expiration > new Date().getTime()){
                return true;
            }else{
                this.router.navigate(['/']);
                return false;
            }
        }
        this.router.navigate(['/']);
        return false;
    }
}