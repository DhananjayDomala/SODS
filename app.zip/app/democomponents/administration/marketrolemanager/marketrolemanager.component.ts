import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../../../events/action-events';
import { DivisionUser } from '../../../model/divisionrole';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from '../../common/dropdown-multiselect/multiselect-dropdown';
import { Approver, Message } from '../../../model/approver';
import { Role, RolesForDisplay } from '../../../model/role';
import { BREADCRUMBS } from '../../common/breadcrumb/breadcrumbs';
import { ALERTS } from '../../common/alert/alerts';
import { DivisionsService } from '../../../service/divisions.service';
import { TopNavComponent } from '../shared/top-nav/top-nav.component';
import { AlertSetting } from '../../common/alert/alert.component';
import { User } from '../../../model/user';
import { ApproversByRoleSettings } from 'app/democomponents/administration/marketrolemanager/approvers-by-role/approvers-by-role.component';

@Component({
    selector: 'app-market-role-manager',
    templateUrl: './marketrolemanager.component.html',
    styleUrls: ['./marketrolemanager.component.css']
})
export class MarketrolemanagerComponent extends BaseComponent implements OnInit, OnDestroy {
    // For security
    public noAccess = false;
    
    // For Loading Indicator
    public loading = false;

    // For Breadcrumbs
    public breadcrumbs = BREADCRUMBS['market-role-manager'];

    // For Market Dropdown menu
    public markets: string[] = [];
    public selectedMarketNumber = '';
    public marketOptions = [];
    public marketNameAndCode = [];
    public selectedMarket = '';
    public validDivNum = false;

    // For Role Multiselect Dropdown Component
    public roles: string[];
    public roleOptions: IMultiSelectOption[] = [];
    // Default roleOptions array indexes selected
    public selectedRoleOptions: number[];
    public dataForExcel: any = [];
    public marketNameForExcel: string;
    public enableExcelBtn:boolean;

    // For Approvers by Role Component
    //public rolesForDisplay: Array<Role> = new Array<Role>();
    //public validated = false;
    // public approversToAdd: Array<Approver> = new Array<Approver>();
    //public approversToDelete: Array<Approver> = new Array<Approver>();
    public approversByRoleSettings: ApproversByRoleSettings = {
        selectedMarketNumber: this.selectedMarketNumber,
        rolesForDisplay: new Array<Role>(),
        approversToAdd: new Array<Approver>(),
        approversToDelete: new Array<Approver>(),
        readOnly: !this.user.isMarketRoleManager(),
        error: '',
        validated: true
    };


    // For Alert Text Bar
    public showAlert = false;
    public alertType = '';
    public alertMessage = '';
    public alertSettings: AlertSetting[] = [{ 'alertType': '', 'alertMessage': '' }];

    constructor(
        readonly actionDispatcherService: ActionDispatcherService,
        readonly stateRepresentationRendererService: StateRepresentationRendererService,
        readonly divisionsService: DivisionsService,
        readonly user: User
    ) {
        super(stateRepresentationRendererService);

        const mapping: any = [];

        //  For loading the divisions in the market dropdown menu
        mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (data: any) => {
            this.renderDivisionsForRoleSearch(data);
        };

        mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL] = (data: any) => {
            this.renderDivisionsForRoleSearchFail(data);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_SUCCESS] = (data: any) => {
            this.renderRolesForMarket(data);
        };

        mapping[ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_FAIL] = (data: any) => {
            this.renderRolesForMarketFail(data);
        };

        mapping[ModelChangeUpdateEvents.VALIDATE_APPROVERS_SUCCESS] = (data: any) => {
            this.renderValidationSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.VALIDATE_APPROVERS_FAIL] = (data: any) => {
            this.renderValidationFail(data);
        };

        mapping[ModelChangeUpdateEvents.ADD_APPROVER_SUCCESS] = (data: any) => {
            this.renderAddSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.ADD_APPROVER_FAIL] = (data: any) => {
            this.renderAddFail(data);
        };        

        mapping[ModelChangeUpdateEvents.ADD_LEVEL_TO_ROLE_SUCCESS] = (data: any) => {
            this.renderAddLevelSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.DELETE_APPROVER_SUCCESS] = (data: any) => {
            this.renderRemoveSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.DELETE_LEVEL_FROM_ROLE_SUCCESS] = (data: any) => {
            this.renderDeleteLevelSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.TRIM_EMPTY_LEVELS_SUCCESS] = (data: any) => {
            this.renderTrimEmptyLevelSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.NORMALIZE_LEVELS_SUCCESS_NO_SAVE] = (data: any) => {
            this.renderNormalizeLevelsSuccessNoSave(data);
        };

        mapping[ModelChangeUpdateEvents.NORMALIZE_LEVELS_SUCCESS] = (data: any) => {
            this.renderNormalizeLevelsSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_ADD_SUCCESS] = (data: any) => {
            this.renderSaveSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_ADD_FAIL] = (data: any) => {
            this.renderSaveFail(data);
        };
        
        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_DELETE_SUCCESS] = (data: any) => {
            this.renderSaveDeleteSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.SAVE_APPROVERS_DELETE_FAIL] = (data: any) => {
            //this.renderSaveFail(data);
        };

        super.registerStateChangeEvents(mapping);
    }

 ngOnInit() {
    // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

       this.initdata();
     
  }
    ngAfterViewInit() {
      // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
    }

    public initdata() {
        // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, true
      );
      this.actionDispatcherService.dispatch(event1); 

        // Load Multiselect dropdown menu options
        this.roleOptions = Role.getRoleMenuOptions();
        this.selectedRoleOptions = Role.getDefaultSelectedRoleOptions();

        // Make an api call to get the divisions for the market dropdown menu
        this.getDivisionsForRoleSearch();
        this.alertSettings = [];
    }

    getDivisionsForRoleSearch(){
        // Make an api call to get the divisions for the market dropdown menu
        const getDivisionsEvent = this.actionDispatcherService.generateEvent(ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH, { 'data': '' });
        this.actionDispatcherService.dispatch(getDivisionsEvent);
    }

    /* SEARCH BAR FUNCTIONS */
    roleSelect(event) {
        this.selectedRoleOptions = event;
    }

    public onChangeRoleSelection(roles): void {
        // Function is called when user checks an option
        // Input:  array of the selected option array indexes. ex) [0,1,2,3]

        // Set the selected roles array
        this.selectedRoleOptions = roles;

        /* Show/Hide Role based on the selected options
        // We are getting all roles back from the api call
        // no matter how many roles are selected from the dropdown
        // menu */

        // this.approversByRoleSettings.rolesForDisplay.forEach((role, index) => {
        //     role.isSelected = this.selectedRoleOptions.includes(index) ? true : false;
        // });
    }

    search(event) {
        this.approversByRoleSettings.rolesForDisplay = [];
        this.selectedMarketNumber = event.market;
        this.approversByRoleSettings.selectedMarketNumber = event.market;
        this.selectedRoleOptions = event.selectedRoles;
        this.approversByRoleSettings.approversToDelete = new Array<Approver>();
        this.approversByRoleSettings.approversToAdd = new Array<Approver>();

        if (this.selectedRoleOptions.length > 0) {
            this.getRolesForMarket();
        } else {
            this.showAlertMessage('error', 'noRoleSelected');
        }
    }

    isValidDivNum(valid) {
        if (!valid) {
            this.approversByRoleSettings.rolesForDisplay = [];
            this.approversByRoleSettings.approversToAdd = [];
            this.approversByRoleSettings.approversToDelete = [];
        }
    }

    renderDivisionsForRoleSearch(divResponse) {
        this.markets = divResponse;
        this.divisionsService.setDivisions(divResponse);
        this.markets.forEach((market) => {
            const option = market['divisionName'] + ' (' + market['divisionNumber'] + ' - ' + market['divisionCode'] + ')';
            this.marketNameAndCode.push({divisionName: market['divisionName'], divisionCode: market['divisionCode'], divisionNumber: market['divisionNumber']});
            this.marketOptions.push(option);
        });

        this.selectedMarketNumber = this.markets[0]['divisionNumber'];
        this.approversByRoleSettings.selectedMarketNumber = this.selectedMarketNumber;
        this.selectedMarket = this.markets[0]['divisionName'] + ' (' + this.selectedMarketNumber + ' - ' + this.markets[0]['divisionCode'] + ')';
        // load busy dialog event
        this.setBusyStatus(false);
    }

    renderDivisionsForRoleSearchFail(response) {
        this.approversByRoleSettings.rolesForDisplay = [];
        this.alertSettings = [];
        this.showAlertMessage('error', 'divisionDownloadFailed');

        // load busy dialog event
        this.setBusyStatus(false);
    }
    /* END OF SEARCH BAR FUNCTIONS */

    /* START OF INITIAL ROLES FUNCTIONS */
    public getRolesForMarket(isSaveSuccess?: boolean) {
        // load busy dialog event
        this.setBusyStatus(true);

        this.loading = true;
        this.alertMessage = '';
        this.showAlert = false;
        this.approversByRoleSettings.rolesForDisplay = [];

        // Dispatch an event to get the default roles
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.GET_APPROVERS_FOR_MARKET,
            { 'divisionNumber': this.selectedMarketNumber, 'isSaveSuccess': isSaveSuccess }
        );
        this.actionDispatcherService.dispatch(event);
    }

    exportMarketroleSearchResults() {
        for(let i = 0; i < this.marketNameAndCode.length; i++) {
            if(this.selectedMarketNumber == this.marketNameAndCode[i].divisionNumber) {
                this.marketNameForExcel = this.marketNameAndCode[i].divisionName + " / " + this.marketNameAndCode[i].divisionCode;
            }
        }
        let exportSearch = this.actionDispatcherService.generateEvent(ActionEvents.MARKETROLE_SEARCH_EXPORT_EXCEL, {approvers: this.dataForExcel, marketName: this.marketNameForExcel, marketNbr: this.selectedMarketNumber});
        this.actionDispatcherService.dispatch(exportSearch);
    }

    renderRolesForMarket(response) {
        this.enableExcelBtn = true;
        this.approversByRoleSettings.rolesForDisplay = [];
        if (response.approvers) {
            this.dataForExcel = response.approvers;
            this.showAlert = false;
            const roles = new RolesForDisplay();
            this.approversByRoleSettings.rolesForDisplay = [];
            // Instantiate new roles for display array
            this.approversByRoleSettings.rolesForDisplay = roles.getRoles();
            // Group approver response by Role
            let formattedData = RolesForDisplay.groupBy(response.approvers, 'roleId');
            // Format the Data for Display
            formattedData = RolesForDisplay.formatDataForDisplay(formattedData);

            // Replace rolesForDisplay with actual approver values if they exist
            const matches = formattedData.filter((o1) => {
                return this.approversByRoleSettings.rolesForDisplay.some((o2) => {
                    return o1['roleId'] === o2['roleId'];
                });
            });

            matches.forEach((row) => {
                const index = this.approversByRoleSettings.rolesForDisplay.findIndex(x => x.roleId === row.roleId);
                this.approversByRoleSettings.rolesForDisplay[index] = row;
            });

            this.approversByRoleSettings.rolesForDisplay.forEach((role, i) => {
                role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
            });

            // Mark the invalid Approvers
            this.markInvalidApprovers(this.approversByRoleSettings.rolesForDisplay);
            this.loading = false;
        }

        if (response.isSaveSuccess) {
            // Show Successful Save Alert Message
            this.showAlertMessage('success', 'rolesSaved');
        }

        // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 
    }

    renderRolesForMarketFail(response) {
        this.loading = false;
        this.approversByRoleSettings.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.approversByRoleSettings.rolesForDisplay = roles.getRoles();
        this.approversByRoleSettings.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });
        // load busy dialog event
        const event1 = this.actionDispatcherService.generateEvent(
          ActionEvents.SET_BUSY_STATUS, false
      );
      this.actionDispatcherService.dispatch(event1); 

        this.showAlertMessage('error', 'renderMarketFail');
        
    }

    /* START OF ADD APPROVER FUNCTIONS */
    add(data) {
        // load busy dialog event
        this.setBusyStatus(true);

        this.markInvalidApprovers(this.approversByRoleSettings.rolesForDisplay);
        // Dispatch event to add a new approver
        const addApproverEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.ADD_APPROVER, {
                'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay,
                'approverToAdd': data.approver,
                'roleIndex': data.roleIndex
            });
        this.actionDispatcherService.dispatch(addApproverEvent);
    }

    renderAddSuccess(response) {
        this.approversByRoleSettings.rolesForDisplay = response.rolesForDisplay;
        let approver = response.approver;
        approver.action = 'Add';
        approver.roleID = approver.roleId;
        approver.flag = true;
        //this.approversByRoleSettings.approversToAdd.push(response.approver);
        this.approversByRoleSettings.approversToAdd.push(approver);

        // load busy dialog event
        this.setBusyStatus(false);
    }

    renderAddFail(response) {
        this.approversByRoleSettings.rolesForDisplay = response.rolesForDisplay;

        // load busy dialog event
        this.setBusyStatus(false);
    }

    addLevel(data) {
        // load busy dialog event
        this.setBusyStatus(true);

        // Dispatch event to add a new level to role
        const roleIndex = data.roleIndex;
        const addLevelEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.ADD_LEVEL_TO_ROLE, {
                'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay,
                'roleIndex': roleIndex
            });
        this.actionDispatcherService.dispatch(addLevelEvent);
    }

    renderAddLevelSuccess(data) {
        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;

        // load busy dialog event
        this.setBusyStatus(false);
    }

    /* START OF DELETE APPROVER FUNCTIONS */
    delete(data) {
        // load busy dialog event
        this.setBusyStatus(true);

        // Dispatch event to delete approver
        const deleteApproverEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.DELETE_APPROVER, {
                'roleIndex': data.roleIndex,
                'levelIndex': data.levelIndex,
                'approverIndex': data.approverIndex,
                'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay
            });
        this.actionDispatcherService.dispatch(deleteApproverEvent);
    }

    setBusyStatus(status: boolean){
        const event1 = this.actionDispatcherService.generateEvent(
            ActionEvents.SET_BUSY_STATUS, status
        );
        this.actionDispatcherService.dispatch(event1); 
    }

    deleteLevel(data) {
        // load busy dialog event
        this.setBusyStatus(true);

        // Dispatch event to delete a level from a role
        const roleIndex = data.roleIndex;
        const levelIndex = data.levelIndex;
        const deleteLevelEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.DELETE_LEVEL_FROM_ROLE, {
                'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay,
                'roleIndex': roleIndex,
                'levelIndex': levelIndex
            });
        this.actionDispatcherService.dispatch(deleteLevelEvent);
    }

    renderRemoveSuccess(data) {
        this.setBusyStatus(false);
        const approverToDelete: Approver = data.approver;
        if (!approverToDelete.action) {
            approverToDelete.action = 'Remove';
            approverToDelete.roleID = approverToDelete.roleId;
            this.approversByRoleSettings.approversToDelete.push(approverToDelete);
        }

        let idx = Approver.findIndexInArray(this.approversByRoleSettings.approversToAdd, 'roleId', approverToDelete.roleID, 'level', approverToDelete.level, 'userId', approverToDelete.userId);
        if (idx >= 0) {
            this.approversByRoleSettings.approversToAdd.splice(idx, 1);
        }

        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
        this.markInvalidApprovers(this.approversByRoleSettings.rolesForDisplay);
    }

    renderDeleteLevelSuccess(data) {
        this.setBusyStatus(false);

        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
        const addApprovers = data.approversToAdd;
        const removeApprovers = data.approversToDelete;

        addApprovers.forEach((approver: Approver) => {
            this.approversByRoleSettings.approversToAdd.push(approver);
        });

        removeApprovers.forEach((approver) => {
            this.approversByRoleSettings.approversToDelete.push(approver);
            const idx = Approver.findIndexInArray(this.approversByRoleSettings.approversToAdd, 'roleId', approver.roleID, 'level', approver.level, 'userId', approver.userId);
            if (idx >= 0) {
                this.approversByRoleSettings.approversToAdd.splice(idx, 1);
            }
        });

        this.markInvalidApprovers(this.approversByRoleSettings.rolesForDisplay);

        // dispatch to normalize levels
        this.normalizeLevels(this.approversByRoleSettings.rolesForDisplay, false);

        // load busy dialog event
        this.setBusyStatus(false);
    }

    /* START OF VALIDATION FUNCTIONS */
    markInvalidApprovers(rolesForDisplay): boolean {
        this.approversByRoleSettings.rolesForDisplay = rolesForDisplay;
        this.showAlert = false;
        this.approversByRoleSettings.rolesForDisplay.forEach((role, i) => {
            this.approversByRoleSettings.rolesForDisplay[i].invalidLevels = [];
            role.levels.forEach((level, j) => {
                level.forEach((approver, k) => {
                    // log the indexes of approvers that are invalid so that the validations css will appear in UI.
                    if (approver.messages.length > 0) {
                        if (approver.messages[0].type !== '' && approver.action !== 'Remove') {
                            this.approversByRoleSettings.validated = false;
                            this.approversByRoleSettings.rolesForDisplay[i].invalidLevels.push(j);
                            const idx = Approver.findIndexInArray(this.approversByRoleSettings.approversToAdd, 'roleId', approver.roleId, 'level', approver.level, 'userId', approver.userId);
                            this.approversByRoleSettings.approversToAdd.splice(idx, 1);
                        }
                    }
                });
                if (this.approversByRoleSettings.rolesForDisplay[i].isSelected && this.approversByRoleSettings.rolesForDisplay[i].invalidLevels.length > 0) {
                    this.showAlertMessage('error', 'invalidNetworkId');
                }
            });
        });
        return !this.showAlert;
    }

    validateApprovers(data) {
        // load busy dialog event
        this.setBusyStatus(true);

        this.showAlert = false;
        this.loading = true;
        const isSave = data.isSave;

        // Format request
        const requestBody = {
            'approvers': [
                {
                    'status': 'string',
                    'statusDesc': 'string',
                    'allOOO': 'string',
                    'approver': this.approversByRoleSettings.approversToAdd
                }
            ]
        };

        // Dispatch an event to validate the approvers
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.VALIDATE_APPROVERS,
            { 'body': requestBody, 'isSave': isSave, 'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay }
        );
        this.actionDispatcherService.dispatch(event);
    }

    trimEmptyLevels(approvers: Approver[]) {
        const trimEmptyLevelsEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.TRIM_EMPTY_LEVELS, {
                'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay,
                'approvers': approvers,
                'selectedRoleOptions': this.selectedRoleOptions
            });
        this.actionDispatcherService.dispatch(trimEmptyLevelsEvent);
    }

    trimEmptyLevelsSuccess(response) {
        this.approversByRoleSettings.rolesForDisplay = response.rolesForDisplay;
    }

    renderValidationSuccess(response) {

        // load busy dialog event
        this.setBusyStatus(false);
        const isSave = response.isSave;
        this.approversByRoleSettings.rolesForDisplay = response.rolesForDisplay;

        // mark invalid levels
        const isValid = this.markInvalidApprovers(this.approversByRoleSettings.rolesForDisplay);

        // Save Data if valid and Save button is clicked
        if (isValid) {
            // set all approversToAdd as valid
            this.approversByRoleSettings.approversToAdd.forEach((approver) => {
                approver.valid = 'true';
            });

            if (isSave) {
                this.saveApprovers(this.approversByRoleSettings.rolesForDisplay);
            } else {
                this.showAlertMessage('success', 'rolesValidated');
            }
        } else {
            this.showAlertMessage('error', 'invalidNetworkId');
        }
    }

    renderValidationFail(response) {
        this.loading = false;
        this.approversByRoleSettings.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.approversByRoleSettings.rolesForDisplay = roles.getRoles();
        this.approversByRoleSettings.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });
        // load busy dialog event
        this.setBusyStatus(false);

        this.showAlertMessage('error', 'genericValidationError');
    }

    renderTrimEmptyLevelSuccess(data) {
        // load busy dialog event
        this.setBusyStatus(false);
        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
        // normalize approvers
        this.normalizeLevels(this.approversByRoleSettings.rolesForDisplay, true);
    }

    normalizeLevels(rolesForDisplay, isSave) {
        this.approversByRoleSettings.rolesForDisplay = rolesForDisplay;
        const normalizeLevelsEvent = this.actionDispatcherService
            .generateEvent(ActionEvents.NORMALIZE_LEVELS, {
                'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay,
                'isSave': isSave
            });
        this.actionDispatcherService.dispatch(normalizeLevelsEvent);
    }

    renderNormalizeLevelsSuccess(data) {
        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
        // Validate Approvers
        this.validateApprovers({ 'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay, 'isSave': true });
    }

    renderNormalizeLevelsSuccessNoSave(data) {
        // load busy dialog event
        this.setBusyStatus(false);

        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
    }

    /* START OF SAVE FUNCTIONS */
    saveApprovers(rolesForDisplay) {
        this.approversByRoleSettings.rolesForDisplay = rolesForDisplay;
        const approversToSave = new Array<Approver>();
        this.approversByRoleSettings.approversToDelete.forEach((approver) => {
            approversToSave.push(approver);
        });
        // this.approversByRoleSettings.approversToAdd.forEach((approver) => {
        //     approversToSave.push(approver);
        // });

        if (approversToSave.length > 0) {
            const requestBody = {
                'approvers': {
                    'role': approversToSave
                }
            };
            // Dispatch an event to save the approvers
            const saveEvent = this.actionDispatcherService.generateEvent(
                ActionEvents.SAVE_APPROVERS_DELETE, { 'body': requestBody, 'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay });
            this.actionDispatcherService.dispatch(saveEvent);
        } else {
                this.approversByRoleSettings.rolesForDisplay = rolesForDisplay;
                const approversToSave = new Array<Approver>();
                this.approversByRoleSettings.approversToAdd = this.removeDuplicates(this.approversByRoleSettings.approversToAdd, 'roleId', 'level', 'userId');
                this.approversByRoleSettings.approversToAdd.forEach((approver) => {
                    approversToSave.push(approver);
                });
        
                if (approversToSave.length > 0) {
                    const requestBody = {
                        'approvers': {
                            'role': approversToSave
                        }
                    };
                    
                    // Dispatch an event to save the approvers
                    const saveEvent = this.actionDispatcherService.generateEvent(
                        ActionEvents.SAVE_APPROVERS_ADD, { 'body': requestBody, 'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay });
                    this.actionDispatcherService.dispatch(saveEvent);
                //this.showAlertMessage('success', 'rolesSaved');
            }
        }

    }

    removeDuplicates(myArr, prop, prop1, prop2) {
        return myArr.filter((obj, pos, arr) => {
            return arr.map((mapObj) => {
                mapObj[prop].indexOf(obj[prop]) === pos && mapObj[prop1].indexOf(obj[prop1]) === pos && mapObj[prop2].indexOf(obj[prop2]) === pos;
            });
        });
    }

    save(data: any): void {
        if (this.approversByRoleSettings.approversToAdd.length > 0 || this.approversByRoleSettings.approversToDelete.length > 0) {
            let approvers = RolesForDisplay.extractApprovers(this.approversByRoleSettings.rolesForDisplay);
            // trim any empty levels
            this.trimEmptyLevels(approvers);
        }
    }

    renderSaveSuccess(data: any): void {
        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
        this.approversByRoleSettings.approversToDelete = new Array<Approver>();
        this.approversByRoleSettings.approversToAdd = new Array<Approver>();
        this.getRolesForMarket(true);
    }

    renderSaveFail(data: any) {
        this.loading = false;
        this.approversByRoleSettings.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.approversByRoleSettings.rolesForDisplay = roles.getRoles();
        this.approversByRoleSettings.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });
        this.showAlertMessage('error', 'invalidNetworkId');
    }

    /* START OF UTILITY FUNCTIONS */
    expandAll() {
        this.approversByRoleSettings.rolesForDisplay.forEach((role) => {
            role.isCollapsed = false;
        });
    }

    collapseAll() {
        this.approversByRoleSettings.rolesForDisplay.forEach((role) => {
            role.isCollapsed = true;
        });
    }

    toggleCollapse(rowId) {
    }

    handleAlert(alertSettings: AlertSetting[]) {
        // this.showAlert = false;
        this.alertSettings = alertSettings;
        this.showAlert = true;
        this.goTo('top');
    }

    showAlertMessage(alertType: string, alertText: string) {
        this.alertSettings = [];
        this.alertMessage = ALERTS[alertType][alertText];
        const alert: AlertSetting = { 'alertType': alertType, 'alertMessage': this.alertMessage };
        this.alertSettings.push(alert);
        this.showAlert = true;
        this.loading = false;
        this.goTo('top');
    }

    cancel(rolesForDisplay: any) {
        this.approversByRoleSettings.rolesForDisplay = [];
        this.showAlert = false;
        this.loading = false;
        this.goTo('top');
    }

    ngOnDestroy() {
        super.ngOnDestroy();
    }

    renderSaveDeleteSuccess(data: any){
        this.approversByRoleSettings.rolesForDisplay = data.rolesForDisplay;
        const approversToSave = new Array<Approver>();

        this.approversByRoleSettings.approversToAdd.forEach((approver) => {
            approversToSave.push(approver);
        });

        if (approversToSave.length > 0) {
            const requestBody = {
                'approvers': {
                    'role': approversToSave
                }
            };
            // Dispatch an event to save the approvers
            const saveEvent = this.actionDispatcherService.generateEvent(
                ActionEvents.SAVE_APPROVERS_ADD, { 'body': requestBody, 'rolesForDisplay': this.approversByRoleSettings.rolesForDisplay });
            this.actionDispatcherService.dispatch(saveEvent);
        } else {
            this.showAlertMessage('success', 'rolesSaved');
        }
    }

    goTo(location: string): void {
        window.location.hash = '';
        window.location.hash = location;
    }
}
