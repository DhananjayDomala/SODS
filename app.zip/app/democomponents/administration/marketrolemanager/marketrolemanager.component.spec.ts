import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketrolemanagerComponent } from './marketrolemanager.component';
import { AdministrationModule } from "app/democomponents/administration/administration.module";
import { RouterTestingModule } from "@angular/router/testing";
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { DivisionsService } from "app/service/divisions.service";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { User } from "app/model/user";
import { ALERTS } from "app/democomponents/common/alert/alerts";
import { Approver, Message } from "app/model/approver";

describe('MarketrolemanagerComponent', () => {
  let component: MarketrolemanagerComponent;
  let fixture: ComponentFixture<MarketrolemanagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AdministrationModule, RouterTestingModule],
      declarations: [ ],
      providers: [        
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        DivisionsService,
        SodsModelService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const mockSAMCall = {
      getDivisionsForRoleSearch: () => {

      },
      getRolesForMarket: ()=> {

      },
      markInvalidApprovers:()=>{

      },
      normalizeLevels: ()=>{

      }
    }
    fixture = TestBed.createComponent(MarketrolemanagerComponent);
    component = fixture.componentInstance;
    spyOn(component, 'getDivisionsForRoleSearch').and.callFake(mockSAMCall.getDivisionsForRoleSearch);
    spyOn(component, 'getRolesForMarket').and.callFake(mockSAMCall.getRolesForMarket);
    spyOn(component, 'markInvalidApprovers').and.callFake(mockSAMCall.markInvalidApprovers);
    spyOn(component, 'normalizeLevels').and.callFake(mockSAMCall.normalizeLevels);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should search successfully', ()=> {
    let event = {
      market: '1104',
      selectedRoles: ['NIA', 'CA']
    }
    component.search(event);
    expect(component.selectedMarketNumber).toBe(event.market);
    event.selectedRoles = [];
    component.search(event);
    expect(component.alertMessage).toBe(ALERTS['error']['noRoleSelected']);
  });

  it('should check valid num', ()=>{
    let valid = false;
    component.isValidDivNum(valid);
    expect(component.rolesForDisplay.length).toBe(0);
    expect(component.approversToAdd.length).toBe(0);
    expect(component.approversToDelete.length).toBe(0);
  });

  it('should render divisionsForRoleSearch successfully', ()=>{
    let divResponse = 
      [
        {
          "divisionNumber": 2140,
          "divisionName": "ALBANY",
          "divisionCode": 98,
          "city": "CLIFTON PARK",
          "state": "NY",
          "region": "Northeast",
          "status": "A"
        },
        {
          "divisionNumber": 1104,
          "divisionName": "CLEVELAND",
          "divisionCode": "3Z",
          "city": "CLEVELAND",
          "state": "OH",
          "region": "East",
          "status": "A"
        }
      ]
    component.renderDivisionsForRoleSearch(divResponse);
    expect(component.markets).toBe(divResponse);
    expect(component.selectedMarketNumber).toBe(component.markets[0]['divisionNumber']);
    expect(component.selectedMarket).toBe(component.markets[0]['divisionName'] + ' (' + component.selectedMarketNumber + ' - ' + component.markets[0]['divisionCode'] + ')');
  });

  it('should render DivisionsForRoleSearchFail', ()=>{
    let response = '';
    component.renderDivisionsForRoleSearchFail(response);
    expect(component.rolesForDisplay.length).toBe(0);
    expect(component.alertSettings.length).toBe(1);
    expect(component.alertMessage).toBe(ALERTS['error']['divisionDownloadFailed']);
  });

  it('should render add role successfully', ()=>{
    let response = {
      rolesForDisplay : 'NIA',
      approver: new Approver(),
      roleId: 'NIA'
    };
    response.approver.roleId = 'NIA';
    component.renderAddSuccess(response);
    expect(component.approversToAdd[0].action).toBe('Add');
    expect(component.approversToAdd[0].roleID).toBe('NIA');
    expect(component.approversToAdd[0].flag).toBeTruthy;
  });

  it('should render add level successfully', ()=>{
    let data = {
      rolesForDisplay: ['NIA', 'CA']
    }
    component.renderAddLevelSuccess(data);
    expect(component.rolesForDisplay).toBe(data.rolesForDisplay);
  });

  it('should render remove approver successfully', ()=>{
    let data = {
      rolesForDisplay: ['NIA', 'CA'],
      approver: {
        roleId: 'NIA',
        userId: 'O8N6026',
        level: '1',
        action: ''
      }
    };
    component.approversToAdd = new Array<Approver>();
    component.approversToAdd[0] = new Approver();
    component.approversToAdd[0].roleId = 'NIA';
    component.approversToAdd[0].level = '1';
    component.approversToAdd[0].userId = 'O8N6026';

    component.renderRemoveSuccess(data);
    expect(component.approversToDelete[0].action).toBe('Remove');
    expect(component.approversToDelete[0].roleID).toBe('NIA');
    expect(component.rolesForDisplay).toBe(data.rolesForDisplay);
    //the approvers to add array should be 0 since the role/user has been removed
    expect(component.approversToAdd.length).toBe(0);
  });

  it('should render delete level successfully', ()=>{
    let data = {
      rolesForDisplay: ['NIA', 'CA'],
      approversToAdd: new Array<Approver>(),
      approversToDelete: new Array<Approver>()
    };
    data.approversToAdd[0] = {        
      roleId: 'NIA',
      roleID: 'NIA',
      roleName: '',
      valid: 'true',
      flag: true,
      firstName: 'Wen',
      lastName: 'Liang',
      email: 'test@test.com',
      outofOffice: 'false',
      designatedId: '',
      returnDate: '',
      messages: new Array<Message>(),
      userId: 'O8N6026',
      division: '1104',
      level: '1',
      action: 'Add',
      applicationId: 'SODS'
    }
    data.approversToDelete[0] = {        
      roleId: 'NIA',
      roleID: 'NIA',
      roleName: '',
      valid: 'true',
      flag: true,
      firstName: 'Wen',
      lastName: 'Liang',
      email: 'test@test.com',
      outofOffice: 'false',
      designatedId: '',
      returnDate: '',
      messages: new Array<Message>(),
      userId: 'O8N6026',
      division: '1104',
      level: '1',
      action: 'Remove',
      applicationId: 'SODS'
    }
    component.renderDeleteLevelSuccess(data);
    expect(component.rolesForDisplay).toBe(data.rolesForDisplay);
  });

  it('render roles for market successfully', ()=>{
    let response = {
      approvers: new Array<Approver>()
    }
    component.loading = true;
    component.showAlert = true;
    component.renderRolesForMarket(response);
    expect(component.loading).toBeFalsy;
    expect(component.showAlert).toBeFalsy
  });

  it('it should handle render roles for market failure status', ()=>{
    component.loading = true;
    let response = {error: 'error'};
    component.renderRolesForMarketFail(response);
    expect(component.loading).toBeFalsy;
  });

});