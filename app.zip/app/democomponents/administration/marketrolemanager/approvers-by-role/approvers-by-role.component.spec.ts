import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproversByRoleComponent } from './approvers-by-role.component';

describe('ApproversByRoleComponent', () => {
  let component: ApproversByRoleComponent;
  let fixture: ComponentFixture<ApproversByRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproversByRoleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproversByRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
