import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproversByRoleComponent } from './approvers-by-role.component';
import { AdministrationModule } from "app/democomponents/administration/administration.module";
import { User } from "app/model/user";
import { Role } from "app/model/role";

describe('ApproversByRoleComponent', () => {
  let component: ApproversByRoleComponent;
  let fixture: ComponentFixture<ApproversByRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AdministrationModule],
      declarations: [  ],
      providers: [
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproversByRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add Approver successfully', ()=>{
    let networkID = 'abc6026';
    let roleIndex = 1;
    let levelIndex = 1;
    let event = {
      keyCode : 32,
      target: new Object()
    }
    component.selectedMarketNumber = '1104';
    component.rolesForDisplay = new Array<Role>();
    component.rolesForDisplay[1] = new Role('1234', false, 'NIA');
    expect(component.addApprover(networkID, roleIndex, levelIndex, event).approver.userId).toBe('ABC6026');

  });
});
