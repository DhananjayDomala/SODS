import { Component, OnInit } from '@angular/core';
import { BREADCRUMBS } from '../../common/breadcrumb/breadcrumbs';
import { ALERTS } from '../../common/alert/alerts';
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from 'usf-sam';
import { DivisionsService } from '../../../service/divisions.service';
import { BaseComponent } from 'app/democomponents/base-component';
import { ModelChangeUpdateEvents, ActionEvents } from 'app/events/action-events';
import {
  IMultiSelectOption,
  IMultiSelectSettings,
  IMultiSelectTexts
} from '../../common/dropdown-multiselect/multiselect-dropdown';

@Component({
  selector: 'app-superuser',
  templateUrl: './superuser.component.html',
  styleUrls: ['./superuser.component.css']
})
export class SuperuserComponent extends BaseComponent implements OnInit {
  // For Breadcrumbs
  public breadcrumbs = BREADCRUMBS['super-user'];

  // For Market Multiselect
  public markets: string[];
  public marketOptions: IMultiSelectOption[] = [];
  // Default roleOptions array indexes selected
  public selectedMarketOptions: number[] = [];

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    private divisionsService: DivisionsService
  ) {
    super(stateRepresentationRendererService);

    const mapping: any = [];

    //  For loading the divisions in the market dropdown menu
    mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (
      data: any
    ) => {
      this.renderDivisionsForSearch(data);
    };

    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    // Make an api call to get the divisions for the market dropdown menu
    const getDivisionsEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH,
      { data: '' }
    );
    this.actionDispatcherService.dispatch(getDivisionsEvent);
  }

  onChangeMarketSelection(markets: number[]) {
    // Function is called when user checks an option
    // Input:  array of the selected option array indexes. ex) [0,1,2,3]

    // Set the selected roles array
    this.selectedMarketOptions = markets;
  }

  renderDivisionsForSearch(divResponse) {
    console.log("Division Response:  " + divResponse);
    this.markets = divResponse;
    this.divisionsService.setDivisions(divResponse);
    this.markets.forEach((market, i) => {
      const name = market['divisionName'] + ' (' + market['divisionNumber'] + ' - ' + market['divisionCode'] + ')';
      const option: IMultiSelectOption = {
        id: i,
        name: name
      };
      this.marketOptions.push(option);
      this.selectedMarketOptions.push(i);
    });
  }

  renderDivisionsForRoleSearchFail(response) {

  }
}
