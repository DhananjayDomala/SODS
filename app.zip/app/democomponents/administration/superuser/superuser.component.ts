import { Component, OnInit, ViewChild } from "@angular/core";
import { BREADCRUMBS } from "../../common/breadcrumb/breadcrumbs";
import { ALERTS } from "../../common/alert/alerts";
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from "usf-sam";
import { DivisionsService } from "../../../service/divisions.service";
import { BaseComponent } from "app/democomponents/base-component";
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from "app/events/action-events";
import { Modal } from "ngx-modal";
import {
  IMultiSelectOption,
  IMultiSelectSettings,
  IMultiSelectTexts
} from "../../common/dropdown-multiselect/multiselect-dropdown";
import { Division } from "app/model/division";
import { SuperUser } from "../../../model/superuser";
import { AlertSetting } from "../../common/alert/alert.component";
import { DropdownComponent } from "../../common/dropdown/dropdown.component";
import { SearchBarComponent } from "./search-bar/search-bar.component";
import { USFoodsButtonSettings } from "app/democomponents/common/button/button.component";
import { ButtonComponent } from "../../common/button/button.component";
import { User } from "../../../model/user";
import { PRIVILEGES } from "app/model/adRoles";

@Component({
  selector: "app-superuser",
  templateUrl: "./superuser.component.html",
  styleUrls: ["./superuser.component.css"]
})
export class SuperuserComponent extends BaseComponent implements OnInit {
  // For security
  noAccess = true;

  // For Typeahead test
  selected = "";
  users: string[] = [];
  selectedUserToAdd = {};
  // For Breadcrumbs
  breadcrumbs = BREADCRUMBS["super-user"];

  // For Market Multiselect
  markets: string[];
  marketOptions: IMultiSelectOption[] = [];
  selectedMarketOptions: number[] = new Array<number>();
  selectedMarket = "Select Market";

  // For Markt Dropdown and Add Modal
  selectedModalMarket = "";
  isSubmitBtnPressed = false;
  modalMarketOptions: string[] = new Array<string>();

  // For Search Results
  searchResults: SuperUser[] = new Array<SuperUser>();
  noResultMessage = "";
  usersToDelete: number[] = new Array<number>();

  // For User Autocomplete field
  forwardTaskUsers: any[] = [];
  isForwardError: boolean = false;
  typeOfSearch: any = "";
  searchedUsers: any[] = [];
  results: any[] = [];
  user = "";
  isUserError = false;

  // For Modal User AutoComplete field
  modalUsers: any[] = [];

  // For Spinner
  loading = false;

  // For Add Super User Modal Form Validation
  isValidMarketSelected = false;
  isValidUserSelected = false;

  // For Alert Text Bar
  public showAlert = false;
  showModalAlert = false;
  public alertType = "";
  public alertMessage = "";
  public alertSettings: AlertSetting[] = [{ alertType: "", alertMessage: "" }];

  // For Modals
  @ViewChild("addSuperUserModal") addSuperUserModal: Modal;
  @ViewChild("deleteSuperUserModal") deleteSuperUserModal: Modal;
  @ViewChild("cancelAddModal") cancelAddModal: Modal;
  @ViewChild("dropdown") dropdown: DropdownComponent;
  @ViewChild("searchBar") searchBar: SearchBarComponent;


  // For User Access Security
  allowedRoles = PRIVILEGES.divManager;

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    private divisionsService: DivisionsService,
    private loggedInUser: User
  ) {
    super(stateRepresentationRendererService);

    const mapping: any = [];

    //  For loading the divisions in the market dropdown menu
    mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (
      data: any
    ) => {
      this.renderDivisionsForSearch(data);
    };

    // For doing the search operation
    mapping[ModelChangeUpdateEvents.SUPER_USER_SEARCH_SUCCESS] = (
      data: any
    ) => {
      this.renderSuperUserSearchSuccess(data);
    };

    mapping[ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS] = (data: any) => {
      this.renderFilteredUsers(data);
    };

    mapping[ModelChangeUpdateEvents.SUPER_USER_SEARCH_FAIL] = (data: any) => {
      this.renderSuperUserSearchFail(data);
    };

    mapping[ModelChangeUpdateEvents.ADD_SUPER_USER_SUCCESS] = (data: any) => {
      this.renderAddSuperUserSuccess(data);
    };

    mapping[ModelChangeUpdateEvents.ADD_SUPER_USER_FAIL] = (data: any) => {
      this.renderAddSuperUserFail(data);
    };

    mapping[ModelChangeUpdateEvents.DELETE_SUPER_USER_SUCCESS] = (
      data: any
    ) => {
      this.renderDeleteSuperUserSuccess(data);
    };

    mapping[ModelChangeUpdateEvents.DELETE_SUPER_USER_FAIL] = (data: any) => {
      this.renderDeleteSuperUserFail(data);
    };

    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    if (this.loggedInUser.isMemberOf(["USF-SODS-DIVMGR"])) {
      this.noAccess = false;
      // Make an api call to get the divisions for the market dropdown menu
      const getDivisionsEvent = this.actionDispatcherService.generateEvent(
        ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH,
        { data: "" }
      );
      this.actionDispatcherService.dispatch(getDivisionsEvent);
    } else {
      this.noAccess = true;
      this.showAlertMessage('error', 'noAccess', 'top');
    }
  }

  onChangeMarketSelection(markets: number[]) {
    // Function is called when user checks an option
    // Input:  array of the selected option array indexes. ex) [0,1,2,3]

    // Set the selected roles array
    this.selectedMarketOptions = markets;
  }

  renderDivisionsForSearch(divResponse) {
    console.log("Division Response:  " + divResponse);
    this.markets = divResponse;
    this.divisionsService.setDivisions(divResponse);
    this.markets.forEach((market, i) => {
      const name =
        market["divisionName"] +
        " (" +
        market["divisionNumber"] +
        " - " +
        market["divisionCode"] +
        ")";
      const option: IMultiSelectOption = {
        id: i,
        name: name
      };
      this.marketOptions.push(option);
      this.modalMarketOptions.push(name);
      this.selectedMarketOptions.push(i);
    });
  }

  renderDivisionsForRoleSearchFail(response) { }

  addSuperUser($event) {
    // TODO:  Open Add User Modal
    this.showAlert = false;
    this.isSubmitBtnPressed = false;
    this.selected = "";
    this.selectedModalMarket = "";
    this.isValidMarketSelected = false;
    this.isValidUserSelected = false;
    this.dropdown.selectedOption = "Select Market";
    this.clearDeletedUsers();
    this.addSuperUserModal.open();
  }

  clearDeletedUsers(): void {
    // clear delete settings
    this.usersToDelete = [];
    this.searchResults.forEach((result) => {
      result.delete = false;
    });
  }

  deleteSuperUser($event) {
    this.showAlert = false;
    const superUsersToDelete = this.searchResults.filter(user => {
      return user.delete === true;
    });
    if (superUsersToDelete.length > 0) {

      this.deleteSuperUserModal.open();
    } else {
      this.showAlertMessage("error", "noSuperUserSelected", "page");
    }
  }
  confirmCloseAddSuperUserModal() {

    this.cancelAddModal.open();
  }

  closeAddSuperUserModal() {
    this.selectedMarket = "";
    this.selectedModalMarket = "Select Market";
    this.addSuperUserModal.close();
  }

  closeDeleteSuperUserModal() {
    this.deleteSuperUserModal.close();
  }

  onDeleteSuperUser() {
    this.closeDeleteSuperUserModal();
    this.loading = true;
    const requestBody = {
      superUsers: []
    };

    const superUsersToDelete: SuperUser[] = this.searchResults.filter(user => {
      return user.delete === true;
    });
    superUsersToDelete.forEach(user => {
      requestBody.superUsers.push({ market: user.market, userID: user.userID });
    });
    
    const userInfo = {
      market: superUsersToDelete[0].market,
      firstName: superUsersToDelete[0].firstName,
      lastName: superUsersToDelete[0].lastName
    }
    if (superUsersToDelete.length > 0) {
      
      // Make an api call to delete the selected users
      const deleteSuperUserEvent = this.actionDispatcherService.generateEvent(
        ActionEvents.DELETE_SUPER_USER,
        { body: requestBody, userInfo: userInfo }
      );
      this.actionDispatcherService.dispatch(deleteSuperUserEvent);
    } else {
      this.loading = false;
      this.showAlertMessage("error", "noSuperUserSelected", "page");
    }
  }

  findInArray(array, property, value) {
    return array.filter(obj => {
      return obj[property] === value;
    });
  }

  getDivisions(divisions: number[]) {
    console.log(divisions);
    const divisionsForApiRequest = new Array<String>();
    divisions.forEach((division, i) => {
      divisionsForApiRequest.push(
        this.markets[division]["divisionNumber"].toString()
      );
    });
    return divisionsForApiRequest;
  }

  searchSuperUser($event) {
    this.showAlert = false;
    const firstName = $event.firstName || "";
    const lastName = $event.lastName || "";
    const markets = $event.markets || "";
    this.loading = true;
    const requestBody = {
      firstName: firstName,
      lastName: lastName,
      divisions: this.getDivisions($event.markets)
    };
    // TODO:  Dispatch event to the the search results
    // Make an api call to get the divisions for the market dropdown menu
    const superUserSearchEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.SUPER_USER_SEARCH,
      { body: requestBody }
    );
    this.actionDispatcherService.dispatch(superUserSearchEvent);
  }

  // Delete checkbox checked
  toggleUserToDelete($event) {
    const index = $event.indexToDelete;
    console.log(index);
    this.searchResults[index].delete = !this.searchResults[index].delete;
    this.setDeleteButtonFlag();
  }

  setDeleteButtonFlag() {
    let deletedUsers = this.searchResults.filter(item => item.delete);
    this.searchBar.isDeleteEnabled = deletedUsers.length > 0;
  }

  renderSuperUserSearchSuccess(superUsers: SuperUser[]) {
    console.log(superUsers);
    this.searchResults = superUsers;
    this.searchResults.sort(function (a, b) {
      return (
        a.market.localeCompare(b.market) || a.lastName.localeCompare(b.lastName)
      );
    });
    this.loading = false;
    this.noResultMessage =
      this.searchResults.length > 0
        ? ""
        : "There are no super users maching your search criteria.";
  }

  renderSuperUserSearchFail(data) {
    console.log(data);
  }
  // For Add Super User Modal
  onMarketSelection($event) {
    this.selectedMarket = $event;
  }

  onModalMarketSelection($event) {
    const tempMarketString = $event.option.match(/\(([^)]+)\)/)[1];
    this.selectedModalMarket = tempMarketString.split(" ")[0];
    this.isValidMarketSelected = true;
  }

  onUserSlection(selectedUser) {
    this.user = selectedUser;
    this.isUserError = false;
  }

  onForwardTaskSelection(selectedTaskTo) {
    this.user = selectedTaskTo;
    this.isForwardError = false;
  }

  onUserSearch(query) {
    this.typeOfSearch = "user";
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: query
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  onAutoComplete(query) {
    console.log(query);
    // Dispatch an event to get the default roles
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: this.selected
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  renderFilteredUsers(data) {
    // This is for the modal super user autocomplete text field

    this.searchedUsers = data.users;

    // Filter super users by the selected divisions
    this.searchedUsers = this.searchedUsers.filter(
      item => item.adgroups.indexOf("USF-SODS-SuperUser") > -1
    );
    this.results = this.searchedUsers.map(item => {
      if (item.fullName !== this.user) {
        return item.fullName;
      }
    });
    this.users = this.results.filter(item => item !== undefined);
  }

  getLastName(user: string) {
    const userArr = user.split(",");
    return userArr[0];
  }

  getFirstName(user: string) {
    const userArr = user.split(",");
    return userArr[1].trim();
  }

  txtFieldInput($event) {
    const timeout = null;
    clearTimeout(timeout);
    // Make a new timeout set to go off in 800ms
    setTimeout(value => this.onAutoComplete(value), 800, $event);
  }

  typeaheadOnSelect($event) {
    if (this.selected) {
      this.selectedUserToAdd = this.filterArray(
        this.searchedUsers,
        "firstName",
        this.getFirstName(this.selected),
        "lastName",
        this.getLastName(this.selected)
      );
    }
    this.isValidUserSelected = true;
  }

  isValidUserInput() {
    return this.isValidUserSelected && this.selected.length > 0;
  }

  isValidAddSuperUserData() {
    return this.isValidUserInput() && this.isValidModalMarketSelected();
  }

  isValidModalMarketSelected() {
    console.log(this.selected);
    return this.selectedModalMarket !== "" && this.selectedModalMarket !== " ";
  }

  onModalAddButtonClick($event) {
    this.isSubmitBtnPressed = true;

    if (this.isValidAddSuperUserData()) {
      this.loading = true;
      const reqBody = {
        market: this.selectedModalMarket,
        userID: this.selectedUserToAdd[0].userID,
        firstName: this.selectedUserToAdd[0].firstName,
        lastName: this.selectedUserToAdd[0].lastName,
        insertedByUserID: localStorage.username,
        insertedByUserName: JSON.parse(
          JSON.parse(localStorage.getItem("user"))._body
        ).displayName
      };
      // Make an api call to add the super user
      const addSuperUserEvent = this.actionDispatcherService.generateEvent(
        ActionEvents.ADD_SUPER_USER,
        {
          body: reqBody,
          userInfo: {
            market: this.selectedModalMarket,
            firstName: this.selectedUserToAdd[0].firstName,
            lastName: this.selectedUserToAdd[0].lastName
          }
        }
      );
      this.actionDispatcherService.dispatch(addSuperUserEvent);
    }
  }

  filterArray(array, property, value, property2, value2) {
    return array.filter(obj => {
      return obj[property] === value && obj[property2] === value2;
    });
  }

  // Crud Operation Rendering
  renderAddSuperUserSuccess(data) {
    this.addSuperUserModal.close();
    this.isValidMarketSelected = false;
    this.isValidUserSelected = false;
    this.loading = false;
    let division = this.divisionsService.getMarketNameByDivisionNumber(data.userInfo.market);
    let user = data.userInfo.firstName + ' ' + data.userInfo.lastName;
    this.showCustomAlertMessage('success', user + ' has been successfully added to the ' + division + ' market.', 'page');

    let requestBody = {
      firstName: "",
      lastName: "",
      divisions: this.getDivisions(this.selectedMarketOptions)
    };

    const superUserSearchEvent = this.actionDispatcherService.generateEvent(
      ActionEvents.SUPER_USER_SEARCH,
      { body: requestBody }
    );
    this.actionDispatcherService.dispatch(superUserSearchEvent);
  }

  renderAddSuperUserFail(data) {
    this.loading = false;
    this.isValidMarketSelected = false;
    this.isValidUserSelected = false;
    this.searchBar.isDeleteEnabled = false;
    this.addSuperUser("event");
    this.showAlertMessage("error", "addSuperUserFail", "modal");
  }

  renderDeleteSuperUserSuccess(data) {

    this.loading = false;
    // temp store the deleted users.
    const deletedUsers = this.searchResults.filter((user: SuperUser) => {
      return user.delete === true;
    });
    
    // get the division name;
    const division = this.divisionsService.getMarketNameByDivisionNumber(data.userInfo.market);
    
    if (deletedUsers.length === 1) {
      // format the deleted users first and last name.
      const user = data.userInfo.firstName + ' ' + data.userInfo.lastName;
      // show Alert message
      this.showCustomAlertMessage('success', user + ' has been successfully deleted from the ' + division + ' market.', 'page');
    } else {
      const markets = [];
      deletedUsers.forEach((user) => {
        markets.push(this.divisionsService.getMarketNameByDivisionNumber(user.market));
      });
      
      markets[markets.length -1] = ' and ' + markets[markets.length - 1];
      let marketString = markets.join(', ');
  
      this.showCustomAlertMessage('success', deletedUsers.length + ' users have been successfully deleted from the ' + marketString + ' markets.', 'page');
    }

    // Remove user from search results
    this.searchResults = this.searchResults.filter((user: SuperUser) => {
      return user.delete !== true;
    });
    this.searchBar.isDeleteEnabled = false;
  }

  renderDeleteSuperUserFail(data) {
    console.log(data);
  }
  
  showCustomAlertMessage(alertType: string, alertText: string, location: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert: AlertSetting = {
      alertType: alertType,
      alertMessage: alertText
    };
    this.alertSettings.push(alert);
    this.showAlert = location !== "modal" ? true : false;
    this.showModalAlert = location === "modal" ? true : false;
    this.loading = false;
    this.goTo("top");
  }


  showAlertMessage(alertType: string, alertText: string, location: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert: AlertSetting = {
      alertType: alertType,
      alertMessage: this.alertMessage
    };
    this.alertSettings.push(alert);
    this.showAlert = location !== "modal" ? true : false;
    this.showModalAlert = location === "modal" ? true : false;
    this.loading = false;
    this.goTo("top");
  }

  goTo(location: string): void {
    window.location.hash = "";
    window.location.hash = location;
  }

  isModalMarketValid() {
    return this.selectedModalMarket && this.isSubmitBtnPressed;
  }

  disableSubmitBtn() {
    this.isValidUserSelected = false;
  }

  closeCancelAddModal() {
    this.cancelAddModal.close();
  }

  closeAllModals() {
    this.cancelAddModal.close();
    this.closeAddSuperUserModal();
    this.closeDeleteSuperUserModal();
  }
}
