import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SuperUser } from '../../../../model/superuser';

@Component({
  selector: 'app-search-results-table',
  templateUrl: './search-results-table.component.html',
  styleUrls: ['./search-results-table.component.css']
})
export class SearchResultsTableComponent implements OnInit {
  @Input() searchResults: SuperUser[];
  @Input() noResultsMessage: string;
  @Output('toggleUserToDelete')
  toggleUserToDelete: EventEmitter<any> = new EventEmitter<any>();
  //sorting
  isDesc = true;
  column = 'market';
  direction: number;
  isAscending: boolean;

  constructor() { }

  ngOnInit() {
  }

  markUserToDelete($event, i) {
    this.toggleUserToDelete.emit({'indexToDelete': i});
  }

}
