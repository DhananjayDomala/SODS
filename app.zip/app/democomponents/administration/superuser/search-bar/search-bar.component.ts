import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import {
  IMultiSelectTexts,
  IMultiSelectSettings,
  IMultiSelectOption
} from '../../../common/dropdown-multiselect/multiselect-dropdown';
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from 'usf-sam';
import { OutOfService } from '../../../../service/outoffice.service';
import { BaseComponent } from 'app/democomponents/base-component';
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from 'app/events/action-events';
import { USFoodsButtonSettings, ButtonComponent } from 'app/democomponents/common/button/button.component';
import { TypeaheadSettings } from 'app/democomponents/common/typeahead/typeahead.component';

 @Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css']
})
export class SearchBarComponent extends BaseComponent implements OnInit {
  @Input() marketOptions: IMultiSelectOption[];
  @Input() selectedMarketOptions: number[];

  @Output('marketSelect')
  marketSelect: EventEmitter<any> = new EventEmitter<any>();

  @Output('searchSuperUser')
  searchSuperUser: EventEmitter<any> = new EventEmitter<any>();

  @Output('addSuperUser')
  addSuperUser: EventEmitter<any> = new EventEmitter<any>();

  @Output('deleteSuperUsers')
  deleteSuperUsers: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('SEARCHBTN')
  searchBtn: ButtonComponent;

  disableTypeAhead: boolean;

  public multiSelectSettings: IMultiSelectSettings = {
    pullRight: true,
    enableSearch: false,
    checkedStyle: 'checkboxes',
    selectionLimit: 0,
    closeOnSelect: false,
    showCheckAll: false,
    showUncheckAll: false,
    showToggleCheckAll: true,
    dynamicTitleMaxItems: 1,
    maxHeight: '190',
    width: '340',
    margin: '50'
  };

  public multiSelectTexts: IMultiSelectTexts = {
    checkAll: 'Check All',
    uncheckAll: 'Uncheck All',
    toggleCheckAll: 'All Markets',
    checked: 'Selected',
    checkedPlural: 'Selected',
    searchPlaceholder: 'Search...',
    defaultTitle: 'Select Markets',
    allSelected: 'All Markets'
  };

  // For search button
  searchBtnSettings: USFoodsButtonSettings = {
    width: '80',
    height: '36',
    text: 'Search',
    marginLeft: '0',
    marginRight: '0',
    css: ['yes']
  }

  addBtnSettings: USFoodsButtonSettings = {
    width: '120',
    height: '36',
    text: 'Add Super User',
    marginLeft: '0',
    marginRight: '0',
    css: ['add']
  }

  deleteBtnSettings: USFoodsButtonSettings = {
    width: '80',
    height: '36',
    text: 'Delete',
    marginLeft: '0',
    marginRight: '0',
    css: ['delete']
  }

  deleteDisabledBtnSettings: USFoodsButtonSettings = {
    width: '80',
    height: '36',
    text: 'Delete',
    marginLeft: '0',
    marginRight: '0',
    css: ['delete-disabled']
  }

  // For User Autocomplete field
  forwardTaskUsers: any[] = [];
  isForwardError = false;
  typeOfSearch: any = '';
  searchedUsers: any[] = [];
  results: any[] = [];
  user = '';
  isUserError = false;

  // For Typeahead test
  selected = '';
  users: string[] = [];
  selectedUserToAdd = {};

  superUserSearchTypeaheadSettings: TypeaheadSettings = {
    required: false,
    label: 'Last Name, First Name',
    selected: '',
    results: [],
    validationType: 'string',
    scrollable: true,
    valid: true,
    placeholderTxt: 'Last Name, First Name',
    marginRight: '20',
    css: ['typeahead-255'],
    errorMessageTxt: 'Select a valid user.'
  };
  
  // For Validation
  isSearchClicked = false;
  isDeleteEnabled = false;

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    public outOfService: OutOfService
  ) {
    super(stateRepresentationRendererService);

    const mapping: any = [];

    //  For loading the divisions in the market dropdown menu
    mapping[ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS] = (data: any) => {
      this.renderFilteredUsers(data);
    };

    super.registerStateChangeEvents(mapping);
  }
  ngOnInit() {
  }

  public onChangeMarketSelection(markets: number[]): void {
    // Function is called when user checks an option
    // Input:  array of the selected option array indexes. ex) [0,1,2,3]

    // Set the selected roles array
    this.selectedMarketOptions = markets;
    if(markets.length === 0){
      this.searchBtn.disabled = true;
      this.disableTypeAhead = true;
      this.selected = '';
    }else{
      this.searchBtn.disabled = false;
      this.disableTypeAhead = false;
    }
    this.marketSelect.emit(this.selectedMarketOptions);
  }

  onUserTxtFieldBlur(user) {
  }

  onUserSlection(selectedUser) {
    this.user = selectedUser;
    this.isUserError = false;
  }

  onForwardTaskSelection(selectedTaskTo) {
    this.user = selectedTaskTo;
    this.isForwardError = false;
  }

  onUserSearch(query) {
    this.typeOfSearch = 'user';
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: query
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  renderFilteredUsers(data) {
    this.searchedUsers = data.users;
    // Filter super users by the selected divisions
    this.searchedUsers = this.searchedUsers.filter(
      item => item.adgroups.indexOf("USF-SODS-SuperUser") > -1
    );
    this.superUserSearchTypeaheadSettings.results = this.searchedUsers.map(item => {
      if (item.fullName !== this.superUserSearchTypeaheadSettings.selected) {
        return item.fullName;
      }
    });
    this.superUserSearchTypeaheadSettings.results = this.superUserSearchTypeaheadSettings.results.filter(item => item !== undefined);
  }

  getLastName(user: string) {
    const userArr = user.split(',');
    if (userArr.length > 0) {
      return userArr[0];
    } else {
      return user;
    }
  }

  getFirstName(user: string) {
    const userArr = user.split(',');
    if (userArr.length > 1) {
      return userArr[1].trim();
    } else {
      return user;
    }
  }

  onSearchBtnClick($event) {
    this.isSearchClicked = true;
    const firstName = this.getFirstName(this.superUserSearchTypeaheadSettings.selected);
    const lastName = this.getLastName(this.superUserSearchTypeaheadSettings.selected);
    this.searchSuperUser.emit({
      firstName: firstName,
      lastName: lastName,
      markets: this.selectedMarketOptions
    });
  }

  onAddBtnClick($event) {
    this.isDeleteEnabled = false;
    this.addSuperUser.emit({ action: 'add' });
  }

  onDeleteBtnClick($event) {
    this.deleteSuperUsers.emit({ action: 'delete' });
  }

  // For Auto Complete
  txtFieldInput($event) {
    const timeout = null;
    clearTimeout(timeout);
    // Make a new timeout set to go off in 800ms
    setTimeout(value => this.onAutoComplete(value), 100, $event);
  }

  onAutoComplete(query) {
    // Dispatch an event to get the default roles
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: this.superUserSearchTypeaheadSettings.selected
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  typeaheadOnSelect($event) {
    if (this.superUserSearchTypeaheadSettings.selected) {
      this.selectedUserToAdd = this.filterArray(
        this.searchedUsers,
        'firstName',
        this.getFirstName(this.selected),
        'lastName',
        this.getLastName(this.selected)
      );
    }
  }

  filterArray(array, property, value, property2, value2) {
    return array.filter(obj => {
      return obj[property] === value && obj[property2] === value2;
    });
  }

  validateUserSearchTxtField($event) {
    this.superUserSearchTypeaheadSettings.valid = $event.valid;
  }
}
