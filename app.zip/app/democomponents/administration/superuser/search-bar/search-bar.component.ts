import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import {
  IMultiSelectTexts,
  IMultiSelectSettings,
  IMultiSelectOption
} from "../../../common/dropdown-multiselect/multiselect-dropdown";
import {
  ActionDispatcherService,
  StateRepresentationRendererService
} from "usf-sam";
import { OutOfService } from "../../../../service/outoffice.service";
import { BaseComponent } from "app/democomponents/base-component";
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from "app/events/action-events";

@Component({
  selector: "app-search-bar",
  templateUrl: "./search-bar.component.html",
  styleUrls: ["./search-bar.component.css"]
})
export class SearchBarComponent extends BaseComponent implements OnInit {
  @Input() marketOptions: IMultiSelectOption[];
  @Input() selectedMarketOptions: number[];

  @Output("marketSelect")
  marketSelect: EventEmitter<any> = new EventEmitter<any>();

  public multiSelectSettings: IMultiSelectSettings = {
    pullRight: true,
    enableSearch: false,
    checkedStyle: "checkboxes",
    selectionLimit: 0,
    closeOnSelect: false,
    showCheckAll: false,
    showUncheckAll: false,
    showToggleCheckAll: true,
    dynamicTitleMaxItems: 0,
    maxHeight: "340px",
    width: "340",
    margin: "50"
  };

  public multiSelectTexts: IMultiSelectTexts = {
    checkAll: "Check All",
    uncheckAll: "Uncheck All",
    toggleCheckAll: "All Markets",
    checked: "Selected",
    checkedPlural: "Selected",
    searchPlaceholder: "Search...",
    defaultTitle: "Select Markets",
    allSelected: "All Markets"
  };

  // For User Autocomplete field
  forwardTaskUsers: any[] = [];
  forwardTask: any = "";
  isForwardError: boolean = false;
  typeOfSearch: any = "";
  searchedUsers: any[] = [];
  results: any[] = [];
  user: string = "";
  isUserError: boolean = false;

  constructor(
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
    public outOfService: OutOfService
  ) {
    super(stateRepresentationRendererService);

    const mapping: any = [];

    //  For loading the divisions in the market dropdown menu
    mapping[ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS] = (data: any) => {
      this.renderTasksTo(data);
    };

    super.registerStateChangeEvents(mapping);
  }
  ngOnInit() {
    console.log(this.selectedMarketOptions);
  }

  public onChangeMarketSelection(markets: number[]): void {
    // Function is called when user checks an option
    // Input:  array of the selected option array indexes. ex) [0,1,2,3]

    // Set the selected roles array
    this.selectedMarketOptions = markets;
    this.marketSelect.emit(markets);
  }

  onUserTxtFieldBlur(user) {
    console.log(user);
  }

  onUserSlection(selectedUser) {
    this.user = selectedUser;
    this.isUserError = false;
  }

  onForwardTaskSelection(selectedTaskTo) {
    this.forwardTask = selectedTaskTo;
    this.isForwardError = false;
  }

  onUserSearch(query) {
    this.typeOfSearch = "user";
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: query
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  onForwardTaskTo(query) {
    this.typeOfSearch = "forwardTaskTo";
    // Dispatch an event to get the default roles
    const event = this.actionDispatcherService.generateEvent(
      ActionEvents.GET_SEARCH_USER,
      {
        query: query
      }
    );
    this.actionDispatcherService.dispatch(event);
  }

  renderTasksTo(data) {
    this.searchedUsers = data.users;
    this.results = data.users.map(item => {
      if (item.fullName !== this.forwardTask) {
        return item.fullName;
      }
    });
    this.results = this.results.filter(item => item !== undefined);
    console.log(this.results);
    
  }
}
