import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { RouterModule } from '@angular/router';
import { AdministrationComponent } from './administration.component';
import { routing } from './administration.routes';
import { MarketRoleSearchComponent } from './marketrolemanager/market-role-search/market-role-search.component';
import { ApproversByRoleComponent } from './marketrolemanager/approvers-by-role/approvers-by-role.component';
import { MarketrolemanagerComponent } from './marketrolemanager/marketrolemanager.component';
import { SuperuserComponent } from './superuser/superuser.component';
import { TopNavComponent } from './shared/top-nav/top-nav.component';
import { SearchBarComponent } from './superuser/search-bar/search-bar.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing
  ],
  declarations: [
    AdministrationComponent,
    MarketrolemanagerComponent,
    MarketRoleSearchComponent,
    ApproversByRoleComponent,
    SuperuserComponent,
    TopNavComponent,
    SearchBarComponent
  ]
})
export class AdministrationModule { }