
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './democomponents/login/login.component';
import { LogOffComponent } from './democomponents/login/logoff.component';
import { SodsdetailsComponent } from './democomponents/sodsdetails/sodsdetails.component';
import { MarketrolemanagerComponent } from './democomponents/marketrolemanager/marketrolemanager.component';
import { AuthGuard } from './democomponents/util/auth.guard';
import {OutofofficeComponent} from './democomponents/outofoffice/outofoffice.component';
import { FilenotfoundComponent } from './democomponents/login/filenotfound.component';

const routes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'sodsnew', 
      loadChildren: './democomponents/sodsnewso/sodsnewso.module#SodsnewsoModule'
    },
    { 
      path: 'sodsdetails', 
      loadChildren: './democomponents/sodsdetails/sodsdetails.module#SodsdetailsModule'
    },
    { 
      path: 'search', 
      loadChildren: './democomponents/sodssearch/sodssearch.module#SodssearchModule'
    },
    { 
      path: 'marketrolemanager', 
      loadChildren: './democomponents/marketrolemanager/marketrolemanager.module#MarketrolemanagerModule'
    },
    { 
      path: 'taskInbox', 
      loadChildren: './democomponents/sodstaskinbox/sodstaskinbox.module#SodstaskinboxModule'
    },
    {
      path: 'approver',
      loadChildren: './democomponents/approver/approver.module#ApproverModule'
    },
    {
      path: 'administration',
      loadChildren: './democomponents/administration/administration.module#AdministrationModule'
    },
    { path: 'login', component: LoginComponent },
    { path: 'logoff', component: LogOffComponent },
    { path: 'outofoffice',component: OutofofficeComponent},
    { path: '**', component: FilenotfoundComponent, canActivate: [AuthGuard] }
];

export const appRoutingProviders: any[] = [];

export const routing = RouterModule.forRoot(routes);