import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActionDispatcherService, ModelPresenterService } from 'usf-sam';
import { SodsModelService } from './demomodel/sodsmodel.service';

import { ActionEvents } from './events/action-events';

import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Modal, ModalModule } from 'ngx-modal';
import { Router } from '@angular/router';

import { AuthenticationService } from './service/authentication.service';
import { User } from 'app/model/user';
import { LoadingService } from './service/loading.service'
import { AlertSetting } from './democomponents/common/alert/alert.component';
import { ALERTS } from './democomponents/common/alert/alerts';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {

  title = 'SODS Demo!';

  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  showBusyIcon = false;
  showError = false;
  timeoutIn = 5000;
// For Alert Text Bar
    public showAlert = false;
    public alertType = '';
    public alertMessage = '';
    public alertSettings: AlertSetting[] = [{ 'alertType': '', 'alertMessage': '' }];


  @ViewChild('timeoutWarningPopup') timeoutWarningModal: Modal;
  @ViewChild('timeoutPopup') timeoutModal: Modal;

  constructor(readonly actionDispatcher: ActionDispatcherService, readonly modelPresenter: ModelPresenterService,
    readonly sodsmodel: SodsModelService, 
    private loadingService: LoadingService,
    private idle: Idle, private keepalive: Keepalive, public router: Router, private authService: AuthenticationService, private user: User) {


  }
  
  showAlertMessage(alertType: string, alertText: string) {
        this.alertSettings = [];
        this.alertMessage = ALERTS[alertType][alertText];
        const alert: AlertSetting = { 'alertType': alertType, 'alertMessage': this.alertMessage };
        this.alertSettings.push(alert);
        this.showAlert = true;
        this.goTo('top');
    }

    goTo(location: string): void {
        window.location.hash = '';
        window.location.hash = location;
    }

  ngOnInit() {
    this.modelPresenter.registerEventsForModel(this.sodsmodel);

    this.loadingService.busy().subscribe((isBusy: any) => { this.showBusyIcon = isBusy;
      console.log(this.showBusyIcon);
    });
    this.loadingService.error().subscribe((isError: any) => { 
      this.showAlertMessage('error', 'noSuperUserSelected');
    });
    
    // set roles
    const localUser = JSON.parse(JSON.parse(localStorage.getItem('user'))._body) || '';
    if (localUser) {
      const roles = localUser.userRoles || '';
      const applicationMarkets = localUser.applicationMarkets || [];
      const firstName = localUser.firstName || '';
      const lastName = localUser.lastName || '';
      const networkID = localUser.userId || '';
      this.user.setRoles(roles);
      this.user.setMarkets(applicationMarkets);
      this.user.setFirstName(firstName);
      this.user.setLastName(lastName);
      this.user.setNetworkID(networkID);
    }

    this.idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle.';
    });

    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.timeoutWarningModal.close();
      this.timeoutModal.open();
    });

    this.idle.onIdleStart.subscribe(() => {
      this.idleState = 'You\'ve gone idle!';
      this.timeoutWarningModal.open();
    });
    
    this.keepalive.onPing.subscribe(() => {
      const username = localStorage.getItem('username');
      const password = localStorage.getItem('password');
  
      this.authService.loginService(username, password).subscribe(response => {
        if (response.json().token !== null && response.json().token !== undefined && response.json().login === 'SUCCESS') {
          
            this.reset();
            sessionStorage.setItem('token', response.json().token);
            let expiration = new Date().getTime() + 30 * 60 * 1000;
            let record = { value: response.json().token, timestamp: expiration }
            localStorage.setItem('token', JSON.stringify(record));
          }
        });
    });
  }

  continueValidity() {
    this.timeoutWarningModal.close();
  }

  isLoggined() {
    
  }
  
  cancel() {
    //logout
    sessionStorage.removeItem('token');
    localStorage.removeItem('token');
    this.timeoutWarningModal.close();
    this.timeoutModal.close();
    this.router.navigateByUrl('/#');
  }
  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
}
