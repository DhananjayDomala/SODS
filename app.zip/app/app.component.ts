import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActionDispatcherService, ModelPresenterService } from 'usf-sam';
import { SodsModelService } from './demomodel/sodsmodel.service';

import { ActionEvents } from './events/action-events';

import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Modal, ModalModule } from 'ngx-modal';
import { Router } from '@angular/router';

import { AuthenticationService } from './service/authentication.service';
import { User } from 'app/model/user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {

  title = 'SODS Demo!';

  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;

  @ViewChild('timeoutWarningPopup') timeoutWarningModal: Modal;
  @ViewChild('timeoutPopup') timeoutModal: Modal;

  constructor(readonly actionDispatcher: ActionDispatcherService, readonly modelPresenter: ModelPresenterService,
    readonly sodsmodel: SodsModelService, private idle: Idle, private keepalive: Keepalive, public router: Router, private authService: AuthenticationService, private user: User) {


  }

  ngOnInit() {
    this.modelPresenter.registerEventsForModel(this.sodsmodel);

    // set roles
    let localStorageRoles = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userRoles || '';
    if (localStorageRoles) {
      this.user.setRoles(localStorageRoles);
    }

    this.idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle.';
    });

    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.timeoutWarningModal.close();
      this.timeoutModal.open();
    });

    this.idle.onIdleStart.subscribe(() => {
      this.idleState = 'You\'ve gone idle!';
      this.timeoutWarningModal.open();
    });
    
    this.keepalive.onPing.subscribe(() => {
      const username = localStorage.getItem('username');
      const password = localStorage.getItem('password');
  
      this.authService.loginService(username, password).subscribe(response => {
        if (response.json().token !== null && response.json().token !== undefined && response.json().login === 'SUCCESS') {
          
            this.reset();
            sessionStorage.setItem('token', response.json().token);
            let expiration = new Date().getTime() + 30 * 60 * 1000;
            let record = { value: response.json().token, timestamp: expiration }
            localStorage.setItem('token', JSON.stringify(record));
          }
        });
    });
  }

  continueValidity() {
    this.timeoutWarningModal.close();
  }

  isLoggined() {
    
  }
  
  cancel() {
    //logout
    sessionStorage.removeItem('token');
    localStorage.removeItem('token');
    this.timeoutWarningModal.close();
    this.timeoutModal.close();
    this.router.navigateByUrl('/#');
  }
  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
}
