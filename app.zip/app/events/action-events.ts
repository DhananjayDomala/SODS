export class ActionEvents {

    static FIND_PRODUCT = 'isaRequestToLoadProduct';
    static LOAD_ISA_FOR_PRODUCT = 'loadISAForProduct';
    static CHANGE_ISA_COST_TYPE = 'changeISACostType';
    static UPDATE_ISA_COST_VALUE = 'updateISACostValue';
    static UPDATE_ISA_ADJUSTMENT_TYPE = 'updateISAAdjustmentType';
    static UPDATE_ISA_AMOUNT = 'updateISAAmount';
    static UPDATE_ISA_MARKUP_TYPE = 'updateISAMarkupType';
    static UPDATE_ISA_MARKUP_AMOUNT = 'updateISAMarkupAmount';
    static UPDATE_ISA_SELL_PRICE = 'updateISASellPrice';
    static SAVE_ISA_ITEM = "saveISAItem";

    // Change Event
    static REQ_CHANGE_EVT = 'Req Change Event';
    //SODS Action Events
    static FIND_REQ = 'sodsRequestToLoadReq';
    static RETRIEVE_CUST = 'retrieveCustomer';

    //SODS Retrieve Customer for ShipTo
    static RETRIEVE_CUST_SHIPTO = 'retrieveCustomerShipTo';

    static RETRIEVE_CUST_DRAFT = 'retrieveCustomerDraft';

    //SODS Products Events
    static VALIDATE_PRODUCT = 'validateProduct';
    static LOAD_PRODUCT = 'loadProduct';
    static GENERATE_REQ_ID = 'generateRequisitionId';
    static SEARCH_MARKET_ROLE = 'searchMarketRole';
    static FIND_ATTACHMENT = "findAttachment";

    //Header Event
    static RETRIEVE_USER_INFO = "retrieveUserInfo";

    //Post requisition
    static POST_REQUISITION = "postRequisition";

    //Draft requisition
    static DRAFT_REQUISITION = "draftRequisition";

    //Retrieve TM
    static RETRIEVE_TM = 'retrieveTM';

    //Retrieve TM 2
    static RETRIEVE_TM_2 = 'retrieveTM2';

    //Retrieve Product
    static RETRIEVE_PRODUCT = 'retrieveProduct';

    //Retreive Product for Editing
    static RETRIEVE_PRODUCT_EDIT = 'retrieveProductEdit';

    //Department Change Event
    static DEPARTMENT_CHANGE = 'departmentChange';

    //Shipment Change Event
    static SHIPMENT_CHANGE = 'shipmentChange';
    //Calendar Change Event
    static CALENDAR_CHANGE = 'calendarChange';

    //Requisition Attachment Events
    static REQ_ATTACHMENT_DETAILS = 'reqAttachDetails';
    static REQ_ATTACHMENTS_DOWNLOAD = 'reqAttachDownload';
    static REQ_ATTACHMENTS_MULTI_DOWNLOAD = 'reqAttachMultiDownload';
    static REQ_ATTACHMENTS_UPLOAD = 'reqAttachUpload';
    static REQ_ATTACHMENTS_DELETE = 'reqAttachDelete';
    static REQ_ATTACHMENTS_SOFT_DELETE = 'reqAttachSoftDelete';
    static REQ_ATTACHMENTS_EDIT = 'reqAttachEdit';
    static REQ_ATTACHMENTS_MULTI_DELETE = 'reqAttachMultiDelete';
    //ShipTo Events
    static SHIPTO_CHANGE = 'shipToChange';

    //Product Attachment Events
    static PROD_ATTACHMENT_UPLOAD = 'prodAttachUpload';
    static PROD_ATTACHMENT_DETAILS = 'prodAttachDetails';
    static PROD_ATTACHMENTS_DELETE = 'prodAttachDelete';
    static PROD_ATTACHMENTS_DOWNLOAD = 'prodAttachDownload';
    static PROD_ATTACHMENTS_MULTI_DOWNLOAD = 'prodAttachMultiDownload'
    static PROD_ATTACHMENTS_MULTI_DELETE = 'prodAttachMultiDelete'

    //retrieve usf tm id from Tandem TM ID
    static RETRIEVE_TM_FROM_TANDEMID = 'retrieveTMFromTandemId';

    //delete requisition
    static DELETE_REQ = 'deleteRequisition';

    static TASKS_TO_SEARCH_REQ = 'taskToSearch';

    static OUT_OF_OFFICE_UPDATE = 'updateOutOfOffice';

    // search User
    static GET_REQ_DETAILS_BY_ID = 'getReqDetailsById'
    static GET_SEARCH_USER = 'getSearchUser';
    static SET_OUT_OF_OFFICE_STATUS = 'setOutOfOfficeStatus';
    static UN_SET_OUT_OF_OFFICE_STATUS = 'unsetOutOfOfficeStatus';
    static GET_OUT_OF_OFFICE_STATUS = 'getOutOfOfficeStatus';
    static GENERATE_PDF = 'generatePDF';
    static EXPORT_EXCEL = 'exportExcel';
    // For Task Inbox
    static GET_TASK = 'getTasks';
    static RETRIEVE_COMMENT_INBOX = 'retrieveCommentsforInbox';

    // For Market Role Manager
    static GET_DIVISIONS_FOR_ROLE_SEARCH = 'getDivisionsForApproversSearch';
    static GET_APPROVERS_FOR_MARKET = 'getApproversForMarket';
    static VALIDATE_APPROVERS = 'validateApprovers';
    static SAVE_APPROVERS_DELETE = 'saveApproversDelete';
    static SAVE_APPROVERS_ADD = 'saveApproverAdd'
    static ADD_APPROVER = 'addApprover';
    static ADD_LEVEL_TO_ROLE = 'addApproverLevel';
    static DELETE_LEVEL_FROM_ROLE = 'deleteApproverLevel';
    static DELETE_APPROVER = 'deleteApprover';
    static TRIM_EMPTY_LEVELS = 'trimEmptyLevels';
    static NORMALIZE_LEVELS = 'normalizeLevels';

    // For Approvals
    static GET_REQ_DETAILS_FOR_APPROVALS = 'getReqDetailsForApprovals';
    static ACCEPT_TASK = 'acceptTask';
    static RELEASE_TASK = 'releaseTask';
    static COMPLETE_TASK = 'completeTask';
    static VALIDATE_PRODUCTS = 'validateProducts';
    // For validate po
    static VALIDATE_PO = 'validatePO';
    static TRANSFER_REQUISITION = 'transferRequisition';

    //For retrieve virtual vendor
    static RETRIEVE_VIRTUAL_VENDOR = 'retrieveVirtualVendor';

    //Search API
    static SEARCH_REQUISITION = 'searchRequisition';
    static SEARCH_EXPORT_EXCEL = 'searchExportExcel';
    static COPY_REQUISITION = 'copyRequisition';
    static RECALL_RQUISITION = 'recallRequisition';

    // SuperUser
    static SUPER_USER_SEARCH = 'superUserSearch';
    static ADD_SUPER_USER = 'addSuperUser';
    static DELETE_SUPER_USER = 'deleteSuperUser';
}

export class ModelChangeUpdateEvents {

    static PRODUCT_FOUND = 'productFound';
    static PRODUCT_NOT_FOUND = 'productNotFound';
    static ISA_ITEM_LOADED = 'isaItemLaoded';
    static ISA_ITEM_COST_TYPE_UPDATED = 'isaItemCostTypeUpdated';
    static ISA_ITEM_AMOUNT_UPDATED = 'isaItemAmountUpdated';
    static ISA_ITEM_SELL_PRICE_UPDATED = 'isaItemSellPriceUpdated';
    static ISA_ITEM_MEETS_VALIDITY_REQUIREMENTS = 'isaItemMeetsValidityRequirements';

    static REQ_CHANGE_EVT_SUCCESS = 'Req change Event Success';

    static GET_REQ_DETAILS_BY_ID_SUCCESS = 'getReqDetailsByIdSuccess'
    static GET_REQ_DETAILS_BY_ID_FAIL = 'getReqDetailsByIdFail'

    //Search Tasks To
    static TASKS_TO_SEARCH_SUCCESS = 'tasksToSearchSuccess';
    static TASKS_TO_SEARCH_FAIL = 'tasksToSearchFailed';

    static OUT_OF_OFFICE_UPDATE_SUCCESS = 'outOfOfficeSuccess'
    static OUT_OF_OFFICE_UPDATE_FAIL = 'outOfOfficeFail'

    //POST Requisition Events
    static POST_REQUISITION_SUCCESS = "reqPostSuccess";
    static POST_REQUISITION_FAIL = "reqPostFailed";

    //POST Requisition Events
    static DRAFT_REQUISITION_SUCCESS = "reqDraftSuccess";
    static DRAFT_REQUISITION_FAIL = "reqDraftFailed";


    //SODS Model Change Events
    static REQ_FOUNT = 'reqFound';
    static REQ_NOT_FOUND = 'reqNotFound';
    static CUST_FOUND = 'custFound';
    static CUST_NOT_FOUND = 'custNotFound';

    //SODS Retrieve Customer for Ship To
    static RETRIEVE_CUST_SHIPTO_SUCCESS = 'custShipToFound';
    static RETRIEVE_CUST_SHIPTO_FAIL = 'custShipToNotFound';

    //SODS Model Change Events for Products
    static PRODUCT_VALIDATED = 'productValidated';
    static PRODUCT_NOT_VALIDATED = 'productNotValidated';
    static PRODUCT_LOADED_SUCCESS = 'productLoadedSuccess';
    static PRODUCT_LOADED_FAILED = 'productLoadedFailed';
    static REQ_ID_GENERATED_SUCCESS = 'requisitionIdGeneratedSuccess';
    static REQ_ID_GENERATED_FAILED = 'requisitionIdGeneratedFailed';
    static MARKET_ROLE_FOUND = 'MarketRoleFound';
    static MARKET_ROLE_NOT_FOUND = 'MarketRoleNotFound';

    //SODS Model Change Events
    static ATTACHMENT_FOUND = "attachmentFound";
    static ATTACHMENT_NOT_FOUND = "attachmentNotFound";

    //Header Model Change Events 
    static USER_INFO_FOUND = "userInfoFound";
    static USER_INFO_NOT_FOUND = "userInfoNotFound";

    //TM Model Change Events
    static TM_FOUND = "TMFound";
    static TM_NOT_FOUND = "TMNotFound";

    //TM Second Time Change Events
    static TM_FOUND_2 = "TMFound2";
    static TM_NOT_FOUND_2 = "TMNotFound2";

    //Retrieve Product Status Event
    static RETRIEVE_PRODUCT_SUCCESS = "retrieveProductSuccess";
    static RETRIEVE_PRODUCT_FAIL = "retrieveProductFail";

    //Retrieve Product Edit Status Event
    static RETRIEVE_PRODUCT_EDIT_SUCCESS = 'retrieveProductEditSuccess';
    static RETRIEVE_PRODUCT_EDIT_FAIL = "retrieveProductEditFail";

    //Department Change
    static DEPARTMENT_CHANGE_SUCCESS = "departmentChangeSuccess";

    //Shipment Change
    static SHIPMENT_CHANGE_SUCCESS = "shipmentChangeSuccess";

    //Calendar Change Success
    static CALENDAR_CHANGE_SUCCESS = 'calendarChangeSuccess';

    //Requisition Model Change Update Events
    static REQ_ATTACH_DETAILS_SUCCESS = "reqAttachDetailsSuccess";
    static REQ_ATTACH_DETAILS_FAIL = 'reqAttachDetailsFail';
    static REQ_ATTACH_UPLOAD_SUCCESS = 'reqAttachUploadSuccess';
    static REQ_ATTACH_UPLOAD_FAIL = 'reqAttachUploadFail';
    static REQ_ATTACH_DOWNLOAD_SUCCESS = 'reqAttachDownloadSuccess';
    static REQ_ATTACH_DOWNLOAD_FAIL = 'reqAttachDownloadFail';
    static REQ_ATTACH_DELETE_SUCCESS = 'reqAttachDeleteSuccess';
    static REQ_ATTACH_DELETE_FAIL = 'reqAttachDeleteFail';
    static REQ_ATTACH_SOFT_DELETE_SUCCESS = 'reqAttachSoftDeleteSuccess';
    static REQ_ATTACH_SOFT_DELETE_FAIL = 'reqAttachSoftDeleteFail';
    static REQ_ATTACH_EDIT_SUCCESS = 'reqAttachEditSuccess';
    static REQ_ATTACH_EDIT_FAIL = 'reqAttachEditFail';
    static REQ_ATTACH_MULTI_DELETE_SUCCESS = 'reqAttachMultiDeleteSuccess';
    static REQ_ATTACH_MULTI_DELETE_FAIL = 'reqAttachMultiDeleteFail';

    //ShipTo ModalChange Event
    static SHIPTO_CHANGE_SUCCESS = 'shipToChangeSuccess';
    static SHIPTO_CHANGE_FAILUER = 'shipToChangeFailure';
    //Product Attachment Event
    static PROD_ATTACH_UPLOAD_SUCCESS = 'prodAttachUploadSuccess';
    static PROD_ATTACH_UPLOAD_FAIL = 'prodAttachUploadFail';
    static PROD_ATTACH_DETAILS_SUCCESS = "prodAttachDetailsSuccess";
    static PROD_ATTACH_DETAILS_FAIL = 'prodAttachDetailsFail';
    static PROD_ATTACH_DOWNLOAD_SUCCESS = 'prodAttachDownloadSuccess';
    static PROD_ATTACH_DOWNLOAD_FAIL = 'prodAttachDownloadFail';
    static PROD_ATTACH_DELETE_SUCCESS = 'prodAttachDeleteSuccess';
    static PROD_ATTACH_DELETE_FAIL = 'prodAttachDeleteFail';
    static PROD_ATTACH_MULTI_DOWNLOAD_SUCCESS = 'prodAttachMultiDownloadSuccess';
    static PROD_ATTACH_MULTI_DOWNLOAD_FAIL = 'prodAttachMultiDownloadFail';
    static PROD_ATTACHMENTS_MULTI_DELETE_SUCCESS = 'prodAttachMultiDeleteSuccess';
    static PROD_ATTACHMENTS_MULTI_DELETE_FAIL = 'prodAttachMultiDeleteFail';

    // For Market Role Manager
    static APPROVERS_FOR_MARKET_SUCCESS = 'APPROVERSForMarketSuccess';
    static APPROVERS_FOR_MARKET_FAIL = 'APPROVERSForMarketFail';
    static DIVISIONS_FOR_ROLE_SEARCH_SUCCESS = 'divisionsForRoleManagerSuccess';
    static DIVISIONS_FOR_ROLE_SEARCH_FAIL = 'divisionsForRoleManagerFail';
    static VALIDATE_APPROVERS_SUCCESS = 'validateApproversSuccess';
    static VALIDATE_APPROVERS_FAIL = 'validateApproversFail';
    static SAVE_APPROVERS_DELETE_SUCCESS = 'saveApproversDeleteSuccess';
    static SAVE_APPROVERS_DELETE_FAIL = 'saveApproversDeleteFail';
    static SAVE_APPROVERS_ADD_SUCCESS = 'saveApproversAddSuccess';
    static SAVE_APPROVERS_ADD_FAIL = 'saveApproversAddFail';
    static ADD_APPROVER_SUCCESS = 'addApproverSuccess';
    static ADD_APPROVER_FAIL = 'addApproverFail';
    static ADD_LEVEL_TO_ROLE_SUCCESS = 'addApproverLevelSuccess';
    static ADD_LEVEL_TO_ROLE_FAIL = 'addApproverLevelFail';
    static DELETE_LEVEL_FROM_ROLE_SUCCESS = 'deleteApproverLevelSuccess';
    static DELETE_LEVEL_FROM_ROLE_FAIL = 'deleteApproverLevelFail';
    static DELETE_APPROVER_SUCCESS = 'deleteApproverSuccess';
    static DELETE_APPROVER_FAIL = 'deleteApproverFail';
    static TRIM_EMPTY_LEVELS_SUCCESS = 'trimEmptyLevelsSuccess';
    static TRIM_EMPTY_LEVELS_FAIL = 'trimEmptyLevelsFail';
    static NORMALIZE_LEVELS_SUCCESS = 'normalizeLevelsSuccess';
    static NORMALIZE_LEVELS_SUCCESS_NO_SAVE = 'normalizeLevelsSuccessNoSave';   
    static NORMALIZE_LEVELS_FAIL = 'normalizeLevelsFail';
    // for testing
    static TEST_SUCCESS_EVENT = 'testsuccessevent';

    // retrieve usf tm id from Tandem TM ID successfully
    static RETRIEVE_TM_FROM_TANDEMID_SUCCESS = 'retrieveTMFromTandemIdSuccess';
    static RETRIEVE_TM_FROM_TANDEMID_FAIL = 'retrieveTMFromTandemIdFail';

    //delete successfully
    static DELETE_REQ_SUCCESS = 'deleteRequisitionSuccess';
    static DELETE_REQ_FAIL = 'deleteRequisitionFail';

    //Out of Office
    static GET_SEARCH_USER_SUCCESS = 'getSearchUserSuccess';
    static GET_SEARCH_USER_FAIL = 'getSearchUserFail';
    static SET_OUT_OF_OFFICE_STATUS_SUCCESS = 'setOutOfOfficeStatusSuccess';
    static SET_OUT_OF_OFFICE_STATUS_FAIL = 'setOutOfOfficeStatusFail';
    static UN_SET_OUT_OF_OFFICE_STATUS_SUCCESS = 'unsetOutOfOfficeStatusSuccess';
    static UN_SET_OUT_OF_OFFICE_STATUS_FAIL = 'unsetOutOfOfficeStatusFail';
    static GET_OUT_OF_OFFICE_STATUS_SUCCESS = 'getOutOfOfficeStatusSuccess';
    static GET_OUT_OF_OFFICE_STATUS_FAIL = 'getOutOfOfficeStatusFail';
    static PDF_GENERATE_SUCCESS = 'pdfGenerateSuccess';
    static PDF_GENERATE_FAIL = 'pdfGenerateFail';
    static EXPORT_SUCCESS = 'exportSuccess';
    static EXPORT_FAIL = 'exportFail';
    //get tasks successfully
    static GET_TASK_SUCCESS = 'getTaskSuccess';
    static GET_TASK_FAIL = 'getTaskFail';
    static RETRIEVE_COMMENT_INBOX_SUCCESS = 'retrieveCommentsforinboxSuccess';
    static RETRIEVE_COMMENT_INBOX_FAIL = 'retrieveCommentsforinboxFail';

    // For Approvals
    static GET_REQ_DETAILS_FOR_APPROVALS_SUCCESS = 'getReqDetailsForApproversSuccess';
    static GET_REQ_DETAILS_FOR_APPROVALS_FAIL = 'getReqDetailsForApproversFail';
    static ACCEPT_TASK_SUCCESS = 'acceptTaskSuccess';
    static ACCEPT_TASK_FAIL = 'acceptTaskFail';
    static RELEASE_TASK_SUCCESS = 'releaseTaskSuccess';
    static RELEASE_TASK_FAIL = 'releaseTaskFail';
    static COMPLETE_TASK_SUCCESS = 'completeTaskSuccess';
    static COMPLETE_TASK_FAIL = 'completeTaskFail';
    static VALIDATE_PRODUCTS_SUCCESS = 'validateProductsSuccess';
    static VALIDATE_PRODUCTS_FAIL = 'validateProductsFail';
    // For validating po model change event
    static VALIDATE_PO_SUCCESS = 'validatePOSuccess';
    static VALIDATE_PO_FAIL = 'validatePOFail';
    static TRANSFER_REQUISITION_SUCCESS = 'transferRequisitionSuccess';
    static TRANSFER_REQUISITION_FAIL = 'transferRequisitionFail';

    //retrieve virtual vendor status
    static RETRIEVE_VIRTUAL_VENDOR_SUCCESS = 'retrieveVendorSuccess';
    static RETRIEVE_VIRTUAL_VENDOR_FAIL = 'retrieveVendorFail';

    //search status
    static SEARCH_REQUISITION_SUCCESS = 'searchRequisitionSuccess';
    static SEARCH_REQUISITION_FAIL = 'searchRequisitionFail';

    static SEARCH_EXPORT_EXCEL_SUCCESS = 'searchExportExcelSuccess';
    static SEARCH_EXPORT_EXCEL_FAIL = 'searchExportExcelFail';

    //retrieve customer for draft
    static RETRIEVE_CUST_DRAFT_SUCCESS = 'retrieveCustDraftSuccess';
    static RETRIEVE_CUST_DRAFT_FAIL = 'retrieveCustDraftFail';

    // super user
    static SUPER_USER_SEARCH_SUCCESS = 'superUserSearchSuccess';
    static SUPER_USER_SEARCH_FAIL = 'superUserSearchFail';
    static ADD_SUPER_USER_SUCCESS = 'addSuperUserSuccess';
    static ADD_SUPER_USER_FAIL = 'addSuperUserFail';
    static DELETE_SUPER_USER_SUCCESS = 'deleteSuperUserSuccess';
    static DELETE_SUPER_USER_FAIL = 'deleteSuperUserFail';

    static COPY_REQUISITION_SUCCESS = 'copyRequisitionSuccess';
    static COPY_REQUISITION_FAIL = 'copyRequisitionCopy';
    static RECALL_REQUISITION_SUCCESS = 'recallRequisitionSuccess';
    static RECALL_REQUISITION_FAIL = 'recallRequisitionFail';
}
