import { Injectable } from '@angular/core';
import { Event } from 'usf-sam';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { contentHeaders } from '../democomponents/util/headers';
import { ActionDispatcherService } from 'usf-sam';
import { Observable, Subject} from 'rxjs/Rx';
import { environment } from '../../environments/environment';

@Injectable()
export class LoadingService {
  private busySubject = new Subject<Boolean>();
  private errorSubject = new Subject<Boolean>();  
  constructor() { }
  
  setBusy(status) {
      this.busySubject.next(status)
  }
  
  busy() {
      return this.busySubject.asObservable();
  }

  setError(hasError) {
      this.errorSubject.next(hasError)
  }
  
  error() {
      return this.errorSubject.asObservable();
  }

  
}