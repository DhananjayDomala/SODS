import { ActionEvents } from 'app/events/action-events';
import { BaseComponent } from 'app/democomponents/base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { Injectable } from '@angular/core';

@Injectable()
export class SamService {

    constructor(readonly actionDispatcherService: ActionDispatcherService) {
        
    }

    callAction(eventTypeName: string, data: any) {
        const call = this.actionDispatcherService.generateEvent(eventTypeName, data);
        this.actionDispatcherService.dispatch(call);
    }
}