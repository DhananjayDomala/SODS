import { TestBed, inject, fakeAsync } from '@angular/core/testing';
import { AuthenticationService } from './authentication.service';
import {Http, XHRBackend, HttpModule, ResponseOptions} from '@angular/http';
import { MockBackend, MockConnection} from '@angular/http/testing';
import { ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';

beforeEach(() => {
  TestBed.configureTestingModule({
    imports: [ HttpModule ],
    providers: [
      AuthenticationService,
      ActionDispatcherService,
      ModelPresenterService,
      StateRepresentationRendererService,
      EventTypeRegistryService,
      {
        provide: XHRBackend, useClass: MockBackend
      }
    ]
  });  
});

fdescribe('AuthenticationService', () => {

  it('login should return successful response',
    inject([AuthenticationService, XHRBackend], (authenticationService, mockBackend)=>{

      const mockResponse = {
        data:[
          { login: 'SUCCESS',token: '12345'}
        ]
      }

      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          status : 400,
          body: JSON.stringify(mockResponse)
        })));
      });


      authenticationService.loginService('a','b').subscribe(res => {
      });

    })
  );
});
