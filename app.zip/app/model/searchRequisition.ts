export class SearchRequisitions{
    'requisitions': SearchRequisition[];
}

export class SearchRequisition {
    'reqID': string;
    'reqType': string;
    'appID': string;
    'division': string;
    'lastUpdateDate':  string;
    'status':  string;
    'requestor':  string;
    'seller':  string;
    'requestedDate': string;
    'customerNbr':  string;
    'customerName': string;
    'customerDept':  string;
    'customerPO':  string;
    'products': SearchProduct[];
    'isCollapsed': boolean;
}

export class SearchProduct{
    'productNumber': string;
    'productDesc': string;
    'qty': string;
    'status': string;
    'packSize': string;
    'label': string;
    'vendorNum': string;
    'vendorName': string;
}

export class SearchRequest {
    'parameters': Parameter[];
    'operand': string;
    'networkID': string;
    'division': string;
    'excludeComplete': string;
}

export class Parameter {
    'field': string;
    'operator': string;
    'value': string;

    constructor() {
        this.field = '';
        this.operator = '';
        this.value = '';
    }
}