import { Comment, SAMPLECommentArr } from './comment';
import { Attachment, SAMPLEAttachmentArr } from './attachment';
import { ShipToDistribution, SAMPLEShipToArr } from './shipToDistribution';

export class Vendor{
    vendorId: string;
    vendorName: string;
    buyerNumber: string;
    buyerEmail: string;
    buyerNetworkId: string;
    POCreationMethod: string;
    vendorLstPrc: string;
    buyerName: string;
}

export const SAMPLEVendor : Vendor = {
    vendorId: '4009',
    vendorName: 'ADVANCEPIERRE FOODS',
    buyerNumber: '955',
    buyerEmail: 'SODSUser@usfoods.com',
    buyerNetworkId: 'sodsby01',
    POCreationMethod: 'new',
    vendorLstPrc: '34.9000',
    buyerName: 'Random, User'
}

export class ShipToDist{
    customerId: string;
    departmentId: string;
    qty: string;
    sellPrice: string;
    handling: string;
    shippedMethod: string;
    customerPO: string;
    splInstructions: string;
    shippedQty: string;
    returnedQty: string;
    salesOrderQty: string;
}

export const SAMPLEShipToDist : ShipToDist = {
    customerId: '60528643',
    departmentId: '10-FOOD',
    qty: '4',
    sellPrice: '0',
    handling: '0',
    shippedMethod: 'S',
    customerPO: '124540',
    splInstructions: 'TEST',
    shippedQty: '0',
    returnedQty: '0',
    salesOrderQty: '0'
}

export const SAMPLEShipToDistB : ShipToDist = {
    customerId: '60528643',
    departmentId: '20-FOOD',
    qty: '5',
    sellPrice: '2',
    handling: '2',
    shippedMethod: 'D',
    customerPO: '99999',
    splInstructions: 'TEST_1',
    shippedQty: '0',
    returnedQty: '0',
    salesOrderQty: '0'
}

export const SAMPLERequested : Requested = {
    description: 'SHEET PAN RACK',
    vendor: 'CRESCOR',
    mfrId: '200-1833A',
    label: 'PACKER',
    packSize: 'EA',
    type: 'C E&S',
    salesUOM: '',
    comments: 'Some comments'
}

export const SAMPLEVndrDtlList : VndrDtlList = {
    byrEmail: 'buyer@gmail.com',
    byrNbr: '34343443',
    byrNm: 'Doe, Jane',
    byrUserID: 'JD34343',
    primVndrNbr: '343434',
    vndrLstPrc: '646.45',
    vndrNbr: '6565',
    vndrNm: 'Doe, Jane'
}

export const SAMPLEVndrDtlListArr: VndrDtlList[] = [SAMPLEVndrDtlList];



export class Product{
    seq: number;
    new: boolean;
    productId: string;
    manufacturerId: string;
    mfrId: string;
    prodCnt: number;
    distSts: number;
    description: string;
    desc: string;
    prodType: string;
    qty: string;
    label: string;
    packSize: string;
    catchWeightInd: string;
    netWeight: string;
    sellPrice: string;
    salesUOM: string;
    handling: string;
    meetsETA: boolean;
    type: string;
    attached: string;
    cost: string;
    priceUOM: string;
    returned: boolean;
    eta: Date;
    vendor: Vendor;
    shipTodistribution: ShipToDistribution[];
    comments: Comment[];
    attachments: Attachment[];
    requested: Requested;
    vndrDtlList: VndrDtlList[];
    attachCount: number;
    attachmentKey : number;
    requisitionId: number;
    isCollapse: boolean = true;
    //add converter(master pack size)
    convFctr: string;
    prodAttchd: string;
    ntnlSts: string;
    pimClass: string;
    grossWght: string;
    ETA: string;
    class: string;
}

export class VndrDtlList {
    byrEmail: string;
    byrNbr: string;
    byrNm: string;
    byrUserID: string;
    primVndrNbr: string;
    vndrLstPrc: string;
    vndrNbr: string;
    vndrNm: string;
}

export class Requested {
    description: string;
    vendor: string;
    mfrId: string;
    label: string;
    packSize: string;
    type: string;
    salesUOM: string;
    comments: string;
}

export const SAMPLEProduct : Product = {
    seq: 1,
    new: true,
    productId: '1142936',
    mfrId: '3338',
    manufacturerId: '3338',
    prodCnt: 4,
    distSts: 9,
    description: 'MEATLOAF, BF SLCD W/KETCH CKD',
    desc: 'MEATLOAF, BF SLCD W/KETCH CKD',
    prodType: 'Food',
    qty: '4',
    label: 'CLASSIC',
    packSize: '54/4.5 OZ',
    catchWeightInd: 'N',
    netWeight: '18.00',
    sellPrice: '0',
    salesUOM: 'CS',
    handling: '0',
    meetsETA: true,
    type: 'food',
    attached: 'true',
    cost: '80.28',
    priceUOM: 'CS',
    returned: false,
    eta: new Date(),
    vendor: SAMPLEVendor,
    shipTodistribution: SAMPLEShipToArr,
    comments: SAMPLECommentArr,
    attachments: SAMPLEAttachmentArr,
    requested: SAMPLERequested,
    vndrDtlList: SAMPLEVndrDtlListArr,
    attachCount : 0,
    attachmentKey : 0,
    isCollapse: false,
    requisitionId: 1234,
    convFctr: '1',
    prodAttchd: 'T',
    ntnlSts: 'A',
    pimClass: '13',
    grossWght: '11.900',
    ETA: '',
    class: '05',
}

export const SAMPLEProduct_B : Product = {
    seq: 2,
    new: false,
    productId: '1142937',
    mfrId: '3338',
    manufacturerId: '3338',
    prodCnt: 3,
    distSts: 8,
    description: 'BEEF, BF SLCD W/KETCH CKD',
    desc: 'BEEF, BF SLCD W/KETCH CKD',
    prodType: 'Food',
    qty: '4',
    label: 'CLASSIC',
    packSize: '54/4.5 OZ',
    catchWeightInd: 'N',
    netWeight: '18.00',
    sellPrice: '0',
    salesUOM: 'CS',
    handling: '0',
    meetsETA: true,
    type: 'food',
    attached: 'true',
    cost: '80.28',
    priceUOM: 'CS',
    returned: false,
    eta: new Date(),
    vendor: SAMPLEVendor,
    shipTodistribution: SAMPLEShipToArr,
    comments: SAMPLECommentArr,
    attachments: SAMPLEAttachmentArr,
    requested: SAMPLERequested,
    vndrDtlList: SAMPLEVndrDtlListArr,
    attachCount: 0,
    attachmentKey: 0,
    isCollapse: false,
    requisitionId: 1234,
    convFctr: '1',
    prodAttchd: 'T',
    ntnlSts: 'A',
    pimClass: '13',
    grossWght: '11.900',
    ETA: '',
    class: '04'

}

