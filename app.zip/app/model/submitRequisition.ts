export class ReqDetails {
    'draftTaskId'?: any;
    'overideSavedByID'?: any;
    'overideSavedByName'?: any;
    'requisition': Requisition;
    'requestor': Requestor;
    'territoryManager': TerritoryManager;
    'customers': TaskInboxCustomer[];
    'products': TaskInboxProduct[];
    'auditLogs': AuditLog[];
    'taskId'?: any;
    'taskName'?: string;
    'taskStatus'?: string;
    'responseStatus'?: any;
    'responseStatusDescription'?: any;
    'assignedToCount': string;
    'assignedToList': string[];
    'acceptedByList': string[];
    'tasks'?: Task[];

    constructor() {
        this.draftTaskId = '';
        this.overideSavedByID = '';
        this.overideSavedByName = '';
        this.requisition = {
            'requisitionNumber': '',
            'requisitionType': '',
            'division': '',
            'status': '',
            'createdAt': '',
            'updatedAt':  '',
            'totalAmount':  '',
            'ETASelection': false,
            'ETADate':  '',
            'returnIfETANotMet': false,
            'defaultShipMethod':  '',
            'defaultCustomerPO':  '',
            'defaultSpecialInstructions':  '',
            'mainCustomerID':  '',
            'mainCustomerName':  '',
            'mainCustomerDept':  '',
            'mainCustomerType': '',
            'quotePrice':  '',
            'quoteNumber':  '',
            'comments': []
        };
        this.requestor = {
            'name': '',
            'networkID': '',
            'email': '',
            'phone': 'None',
            'additionalPhone': 'None',
            'additionalEmail': 'None'
        };
        this.territoryManager = {
            'name': '',
            'networkID': '',
            'email': 'None',
            'phone': 'None',
            'additionalPhone': '',
            'additionalEmail': ''
        };
        this.customers = new Array<TaskInboxCustomer>();
        this.products = new Array<TaskInboxProduct>();
        this.auditLogs = [];
        this.tasks = new Array<Task>();
    }

    // comments, shipto goes in products
}
export interface Requisition {
    'requisitionNumber': string;
    'requisitionType': string;
    'division': string;
    'status':  string;
    'createdAt':  string;
    'updatedAt':  string;
    'totalAmount':  any;
    'ETASelection': boolean;
    'ETADate':  string;
    'returnIfETANotMet': boolean;
    'defaultShipMethod':  string;
    'defaultCustomerPO':  string;
    'defaultSpecialInstructions':  string;
    'mainCustomerID':  string;
    'mainCustomerName':  string;
    'mainCustomerDept':  string;
    'mainCustomerType': string;
    'quotePrice':  any;
    'quoteNumber':  string;
    'comments': Comment[];
}

export interface AuditLog {
    'displayText': string;
    'dateTime': string;
    'networkID': string;
    'userName': string;
}

export interface Comment {
    'commentsText': string;
    'timestamp': string;
    'networkID': string;
    'name': string;
}

export class Requestor {
    'name': string;
    'networkID': string;
    'email': string;
    'phone': string;
    'additionalPhone': string;
    'additionalEmail': string;
}

export class TerritoryManager {
    'name': string;
    'networkID': string;
    'email': string;
    'phone': string;
    'additionalPhone': string;
    'additionalEmail': string;
}

export interface TaskInboxCustomer {
    'seq': string;
    'id': string;
    'dept': string;
    'defaultShipMethod': string;
    'name': string;
    'address1': string;
    'city': string;
    'state': string;
    'zip': string;
    'phone': string;
    'estimatedOrderAmt': string;
    'confidenceCode': string;
    'creditCheckStatus': boolean;
    'useOverrideShipto': boolean;
	'overrideShipto': OverrideShipTo;
}

export interface Task {
    "taskID": string;
    "taskName": string;
    "assignedorAcceptedByList": string[];
}

export class OverrideShipTo {
    name?: string;
    address1?: string;
    address2?: string;
    city?: string;
    state?: string;
    zip?: string;
    phone?: string;
}

export class TaskInboxProduct {
    'seq': any;
    'new': string; // boolean value is returned for if product is new or existing
    'productId': string;
    'manufacturerId': string;
    'description':string;
    'qty': any;
    'label': string;
    'packSize': string;
    'catchWeightInd': string;
    'netWeight': string;
    'status': string;
    'sellPrice': any;
    'salesUOM': string;
    'handling': any;
    'ETASelection': boolean;
    'ETA': string;
    'actualETA': string;
    'ETAUpdRC':string;
    'ETAUpdRCDesc':string;
    'meetsETA': boolean;
    'type': string;
    'class': string;
    'attached': string; // I = not attached in market
    'statusCode': string;
    'PONumber': string;
    'PODate': string;
    'cost': string;
    'priceUOM': string;
    'returned': boolean;
    'requested': Requested;
    'vendor': TaskInboxVendor;
    'shipTodistribution': ShipTodistribution[];
    'comments': Comment[];
    'attachmentsFlag': string;
    'errorFlag': boolean;
    'nbrError': boolean;

}

export class Requested {
    'description': string;
    'vendor': string;
    'mfrId': string;
    'label': string;
    'packSize': string;
    'type': string;
    'salesUOM': string;
    'comments': string;
}

export class TaskInboxVendor {
    'vendorId': string;
    'vendorName': string;
    'vendorType': string;
    'buyerNumber': string;
    'buyerEmail': string;
    'buyerName' : string;
    'buyerNetworkId': string;
    'POCreationMethod': string;
}

export interface ShipTodistribution{
    'customerId': string;
    'departmentId': string;
    'qty': any;
    'sellPrice': any;
    'handling': any;
    'shipMethod': string;
    'customerPO': string;
    'specialInstructions': string;
    'status': string;
    'shippedQty': any;
    'returnedQty': any;
    'salesOrderNumber': string;
    'salesOrderDate': string;
    'salesOrderQty': any;
    'deliveryDate': string;
    'invoiceNumber': string;
    'invoiceDate': string;
    'customer'?: any
}