export class Comment{
    commentsText: string;
    timestamp: string;
    networkID: string;
    name: string;
}

export const SAMPLECommentA: Comment = {
    commentsText: 'abcdlajflsjfladsjfalsdjfalsjfdlsajfladsjflasdjflasdjflasjdflasj',
    timestamp: '',
    networkID: 'test',
    name: 'Wen, Liang'
}

export const SAMPLECommentB: Comment = {
    commentsText: 'sjfldsajfldasjfladsjflasdjflsadjlvmfaonvoaijeoincalmclajclasjfaposdjf',
    timestamp: '',
    networkID: 'test',
    name: 'Karthik, Balasubramanian'
}

export const SAMPLECommentArr: Comment[] = [SAMPLECommentA, SAMPLECommentB];