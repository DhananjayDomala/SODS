export class Comment{
    commentsText: string;
    timestamp: string;
    networkId: string;
    name: string;
}

export const SAMPLECommentA: Comment = {
    commentsText: 'abcdlajflsjfladsjfalsdjfalsjfdlsajfladsjflasdjflasdjflasjdflasj',
    timestamp: '',
    networkId: 'test',
    name: 'Wen, Liang'
}

export const SAMPLECommentB: Comment = {
    commentsText: 'sjfldsajfldasjfladsjflasdjflsadjlvmfaonvoaijeoincalmclajclasjfaposdjf',
    timestamp: '',
    networkId: 'test',
    name: 'Karthik, Balasubramanian'
}

export const SAMPLECommentArr: Comment[] = [SAMPLECommentA, SAMPLECommentB];