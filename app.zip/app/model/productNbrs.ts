export class SetProductNbrs {
    setProductNbrs: SetProductNbrsContent;
}

export class SetProductNbrsContent {
    productNbr: string;
}