export class Task {
    taskId: string
    taskType: string
    reqId: string
    custNumber: string
    custName: string
    deptId: string
    commentsFlag: string
    actionRequired: string
    createdDate: string
    lastUpdateDate: string
    division: string
}

export const SAMPLETask_A: Task = {
    taskId: "18694",
    taskType: "SODS-SO",
    reqId: "21191",
    custNumber: "60528643",
    custName: "DBL TREE CLEVE DT/LAKESD*",
    deptId: "10-FOOD",
    commentsFlag: "true",
    actionRequired: "Approve New Item",
    createdDate: "10/01/2017",
    lastUpdateDate: "10/01/2017",
    division: '1104'
}

export const SAMPLETask_B: Task = {
    taskId: "18689",
    taskType: "SODS-SO",
    reqId: "21187",
    custNumber: "60528643",
    custName: "DBL TREE CLEVE DT/LAKESD*",
    deptId: "10-FOOD",
    commentsFlag: "true",
    actionRequired: "Approve New Item",
    createdDate: "10/01/2017",
    lastUpdateDate: "10/01/2017",
    division: '1104'
}

export const SAMPLETASKARR: Task[] = [SAMPLETask_A, SAMPLETask_B];