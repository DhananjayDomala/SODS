export class Customer{
    id: string;
    division: string;
    dept: string;
    defaultShipMethod: string;
    name: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
    estimatedOrderAmt: string;
    confidenceCode: string;
    creditCheckStatus: string;
    tmId: string;
    tmName: string;
    tmEmail: string;
    deptOptions: any;
    custType: any;
}

export const SAMPLECUSTOMER : Customer = {
    id : '60528643',
    division: '1104',
    dept: '10-FOOD',
    defaultShipMethod: 'Separate',
    name: 'DBL TREE CLEVE DT/LAKESD*',
    address1: '1111 LAKESIDE AVENUE',
    address2: '2500 METRO HEALTH DRIVE',
    city: 'CLEVELAND',
    state: 'OH',
    zip: '441140000',
    phone: '2162415100',
    estimatedOrderAmt: '321.12',
    confidenceCode: '09',
    creditCheckStatus: 'true',
    tmId: 'QFS6026',
    tmName: 'sodsus02, SharedAcct',
    tmEmail: 'Shared.sodsus02@foodfite.com',
    custType: 'NA',
    deptOptions:[
        {value: '10-FOOD'},
        {value: '20-NON-FOOD'}
    ]
}