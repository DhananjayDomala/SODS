import { Injectable } from '@angular/core';
import { PRIVILEGES } from 'app/model/adRoles';

@Injectable()
export class User {
  private networkId = '';
  private roles: Array<string> = [];
  private markets: Array<any> = [];
  public firstName = '';
  public lastName = '';
  public email = '';
  public isLoggedIn = false;

  constructor() {
    this.roles = ['none'];
  }

  setMarkets(markets: Array<any>): void {
    this.markets = markets;
  }

  setRoles(roles: Array<string>): void {
    this.roles = roles;
  }

  getRoles(): string[] {
    return this.roles;
  }

  clearRoles(): void {
    this.roles = [];
    this.isLoggedIn = false;
  }

  isMemberOf(allowedRoles: Array<String>): boolean {
    const rolesFound = this.roles.filter(function(e, index) {
      if (e.indexOf('-SODS-USER') !== -1) {
        e = 'SODS-USER';
      }
      return allowedRoles.indexOf(e) > -1;
    });
    return rolesFound.length > 0;
  }

  isMarketRoleManager(): boolean {
    return this.isMemberOf(PRIVILEGES.marketRoleManager);
  }
  
  isInMarket(allowedMarkets: Array<any>) {
    const marketsFound = this.markets.filter(function(e, index) {
      return allowedMarkets.indexOf(e.marketNum) > -1;
    });
    return marketsFound.length > 0;
  }

  canCreateRequisition(): boolean {
    const allRoles = this.roles.filter(role => role.indexOf('SODS-USER') !== -1);
    return allRoles.length > 0;
  }

  setNetworkID(networkId: string): void {
    this.networkId = networkId;
  }

  getNetworkID(): string {
    return this.networkId;
  }

  setFirstName(fname: string): void {
    this.firstName = fname;
  }

  getFirstName(): string {
    return this.firstName;
  }

  setLastName(lname: string): void {
    this.lastName = lname;
  }

  getLastName(): string {
    return this.lastName;
  }

  setEmail(email: string): void {
    this.email = email;
  }

  getEmail(): string {
    return this.email;
  }
}
