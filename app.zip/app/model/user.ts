import { Injectable } from '@angular/core';

@Injectable()
export class User {
  private networkId = '';
  private roles: Array<string> = [];
  private markets: Array<string> = [];
  public firstName = '';
  public lastName = '';
  public email = '';
  public isLoggedIn = false;

  constructor() {
    this.roles = ['none'];
  }

  setMarkets(markets: Array<string>) {
    this.markets = markets;
  }

  setRoles(roles: Array<string>) {
    this.roles = roles;
  }

  getRoles() {
    return this.roles;
  }

  clearRoles() {
    this.roles = [];
    this.isLoggedIn = false;
  }

  isMemberOf(allowedRoles: Array<String>) {
    if (allowedRoles.length > 0) {
      for (let i = 0; i < allowedRoles.length; i++) {
        for (let j = 0; j < this.roles.length; j++) {
          if (allowedRoles[i] === this.roles[j]) {
            return true;
          }
        }
      }
    }
    return false;
  }

  isInMarket(allowedMarkets: Array<String>) {
    if (allowedMarkets.length > 0) {
      for (let i = 0; i < allowedMarkets.length; i++) {
        for (let j = 0; j < this.markets.length; j++) {
          if (allowedMarkets[i] === this.markets[j]) {
            return true;
          }
        }
      }
    }
    return false;
  }

  canCreateRequisition() {
    const allRoles = this.roles.filter(role => role.indexOf('-SODS-USER') !== -1);
    return allRoles.length > 0;
  }

  setNetworkID(networkId: string) {
    this.networkId = networkId;
  }

  getNetworkID() {
    return this.networkId;
  }

  setFirstName(fname: string) {
    this.firstName = fname;
  }

  getFirstName() {
    return this.firstName;
  }

  setLastName(lname: string) {
    this.lastName = lname;
  }

  getLastName() {
    return this.lastName;
  }

  setEmail(email: string) {
    this.email = email;
  }

  getEmail() {
    return this.email;
  }
}
