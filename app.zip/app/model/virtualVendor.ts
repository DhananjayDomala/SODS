import { Product } from "app/model/product";

export class RetrieveVirtualVendorRespone{
    virtualVendorList: VirtualVendor[];
    product: Product;
}

export class VirtualVendor {
    vendorNumber: string;
    vendorName: string;
    noOfProducts: string;
}