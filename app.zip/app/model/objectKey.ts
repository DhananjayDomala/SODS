export class ObjectKey{
    objectKey: any;
    fileName: string;
    requisitionId: string;
}