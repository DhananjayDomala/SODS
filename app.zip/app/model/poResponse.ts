export interface POResponse{
    status: string;
    statusDescription: string;
    poStatus: POStatus[];
}

export interface POStatus{
    poNumber: string;
    status: string;
    statusDescription: string;
}