import { Approver } from './approver';

export class Role {
    static roleMap = {
        'NIA': 'New Product Approver',
        'CMG': 'Category Manager Grocery',
        'CMP': 'Category Manager Produce',
        'CMFC': 'Category Manager COP',
        'CMNF': 'Category Manager Non-Food',
        'CMES': 'Category Manager CES',
        'PAG': 'Product Attachment Grocery',
        'PAP': 'Product Attachment Produce',
        'PAFC': 'Product Attachment COP',
        'PANF': 'Product Attachment Non-Food',
        'PAES': 'Product Attachment CES',
        'CA': 'Credit Analyst',
        'DSM': 'District Sales Manager',
        'RSM': 'Regional Sales Manager',
        'VP': 'VP of Local Sales',
        'BUYER': 'Buyer Backup',
        'DSB': 'Direct Ship Buyer',
        'FM': 'District Sales Support',
        'CESB': 'Direct Ship Buyer CES'
        // 'DSS': 'District Sales Support'
    };

    roleId: string;
    roleName: string;
    isCollapsed: boolean;
    isSelected: boolean;
    invalidLevels: number[] = [];
    levels: [any[]];

    public static getRoleName(roleId: string) {
        return this.roleMap[roleId];
    }

    static getRoleMenuOptions() {

        const options = [];
        Object.keys(this.roleMap).forEach((role, id) => {
            const item = {'id': id, 'name': this.roleMap[role]};
            options.push(item);
        });
        return options;
    }

    static getDefaultSelectedRoleOptions() {
        const options = [];
        Object.keys(this.roleMap).forEach((role, id) => {
            options.push(id);
        });
        return options;
    }

    constructor(roleId: string, isCollapsed: boolean, roleName: string) {
        this.roleId = roleId;
        this.isCollapsed = isCollapsed;
        this.roleName = roleName;
        this.isSelected = false;
        this.levels = [new Array<Approver>()];
        this.invalidLevels = new Array<number>();
    }
}

export class RolesForDisplay {
    roles: Array<Role> = [];

    static formatDataForDisplay(obj) {
        // This will restructure the Approvers
        // in order to allow for dynamic display in template
        // It requires the Approvers array to be grouped by the roleId

        let newObj = {};
        let levelsArray = [];
        const marketRoles = [];

        for (const p in obj) {
            if (obj.hasOwnProperty(p)) {
                const levels = this.groupBy(obj[p], 'level');
                for (const q in levels) {
                    if (levels.hasOwnProperty(q)) {
                        levelsArray = Object.keys(levels).map(function (key) {
                            return levels[key];
                        });
                    }
                }

                newObj = {
                    'invalidLevels': [],
                    'roleId': p,
                    'isCollapsed': false,
                    'isSelected': true,
                    'roleName': Role.getRoleName(p),
                    'levels': levelsArray
                };
                marketRoles.push(newObj);
            }
        }
        return marketRoles;
    }

    static groupBy(arr, property) {
        return arr.reduce(function (all, x) {
            if (!all[x[property]]) { all[x[property]] = []; }
            all[x[property]].push(x);
            return all;
        }, {});
    }

    static extractApprovers(rolesForDisplay): Approver[] {
        const approvers: Approver[] = new Array<Approver>();
        rolesForDisplay.forEach((role, i) => {
            role.levels.forEach((level, j) => {
                level.forEach((approver, k) => {
                    approvers.push(approver);
                });
            });
        });
        return approvers;
    }

    constructor() {
        this.roles = new Array<Role>();
        for (const key in Role.roleMap) {
            if (Role.roleMap.hasOwnProperty(key)) {
                this.roles.push(new Role(key.toString(), true, Role.getRoleName(key.toString())));
            }
        }
    }

    setSelectedRoles(selectedRoles: number[]): Array<Role> {
        selectedRoles.forEach((index) => {
            this.roles[index].isSelected = true;
        });
        return this.roles;
    }

    getRoles() {
        return this.roles;
    }


    filterArray(array, property, value) {
        return array.filter((obj) => {
            return obj[property] !== value;
        });
    }
}
