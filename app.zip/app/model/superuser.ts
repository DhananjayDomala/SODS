export class SuperUser {
    market: string;
    userID: string;
    firstName: string;
    lastName: string;
    updatedBy: string;
    updatedDate: string;
    delete = false;
}
