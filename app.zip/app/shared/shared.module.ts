import { OverrideShipToComponent } from 'app/democomponents/common/customer/override-ship-to/override-ship-to.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { ProductComponent } from '../democomponents/common/product/product.component';
import { ProductAttachmentComponent } from './../democomponents/common/product/product-attachment.component';
import { CustomerComponent } from '../democomponents/common/customer/customer.component';
import { EditCustomerComponent } from '../democomponents/common/customer/edit-customer.component';
import { CustomerDetailsComponent } from '../democomponents/common/customer/customer-details.component';
import { UserComponent } from '../democomponents/common/user/user.component';
import { AttachmentComponent } from '../democomponents/common/attachment/attachment.component';
import { AttachfileComponent } from '../democomponents/common/attachment/attachfile.component';
import { AuditlogComponent } from '../democomponents/common/auditlog/auditlog.component';
import { VendorComponent } from '../democomponents/common/vendor/vendor.component';
import { AddNewProductComponent } from '../democomponents/common/product/add-new-product.component';
import { AddExistingProductComponent } from '../democomponents/common/product/add-existing-product.component';
import { UploadProductComponent } from '../democomponents/common/product/upload-product.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from '../democomponents/header/header.component';
import { DropdownComponent } from '../democomponents/common/dropdown/dropdown.component';
import { MarketDropdownComponent } from '../democomponents/common/dropdown/market-dropdown/market-dropdown.component';
import { ShipToDropdownComponent } from '../democomponents/common/dropdown/shipTo-dropdown/ship-to-dropdown.component';
import { Collapse } from '../directive/collapse.component';
import { ModalModule, Modal } from 'ngx-modal';
import {CalendarModule} from 'primeng/primeng';
import {AutoCompleteModule} from 'primeng/primeng';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { CalendarComponent } from '../democomponents/common/calendar/calendar.component';
import { AutoCompleteComponent } from '../democomponents/common/auto-complete/autoComplete.component';

import { CreateRequisitionComponent } from '../democomponents/common/createRequisition/createRequisition.component';
import { ShipToLocationComponent } from '../democomponents/common/shipToLocation/shipToLocation.component';
import { AddShipToLocationComponent } from '../democomponents/common/shipToLocation/add-shipToLocation.component';
import { EditShipToLocationComponent } from '../democomponents/common/shipToLocation/edit-shipToLocation.component';

import { ProductCommentComponent } from '../democomponents/common/comment/product-comment/product-comment.component';
import { EditNewProductComponent } from '../democomponents/common/product/edit-new-product.component';
import { EditExistingProductComponent } from '../democomponents/common/product/edit-existing-product.component';
import { EditFileComponent } from '../democomponents/common/attachment/edit-file.component';
import { MultiselectDropdownModule } from '../democomponents/common/dropdown-multiselect/multiselect-dropdown';
import { RoleManDropdownComponent } from '../democomponents/common/dropdown/roleManager-dropdown/dropdown.component';
import { BreadcrumbComponent } from '../democomponents/common/breadcrumb/breadcrumb.component';
import { SpinnerComponent } from '../democomponents/common/spinner/spinner.component';
import { AlertComponent } from '../democomponents/common/alert/alert.component';
import { AutocompleteTextfieldComponent } from '../democomponents/common/autocomplete-textfield/autocomplete-textfield.component';
import { FooterComponent } from '../democomponents/common/footer/footer.component';
import { dateFormatPipe } from "app/democomponents/util/dateFormatPipe";
import { CSTDateFormatPipe } from "app/democomponents/util/CSTDateFormatPipe";
import { PhoneNumberPipe } from '../democomponents/util/phoneNumberPipe';
import { ZipCodePipe } from '../democomponents/util/zipCodePipe';
import { OrderrByPipe } from "app/democomponents/util/orderby.pipe";
import { ButtonComponent } from '../democomponents/common/button/button.component';
import { ShowForUserRoleDirective } from '../directive/showForUserRole.directive';

import { BusyLoaderComponent } from 'app/democomponents/common/busyloader/busyLoader.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ModalModule,
    CalendarModule,
    AutoCompleteModule,
    RouterModule,
    MultiselectDropdownModule,
    TypeaheadModule.forRoot()
  ],
  declarations: [
    OrderrByPipe,
    ProductComponent,
    ProductAttachmentComponent,
    CustomerComponent,
    UserComponent,
    AttachmentComponent,
    AttachfileComponent,
    AuditlogComponent,
    VendorComponent,
    EditCustomerComponent,
    AddNewProductComponent,
    AddExistingProductComponent,
    UploadProductComponent,
    HeaderComponent,
    DropdownComponent,
    MarketDropdownComponent,
    ShipToDropdownComponent,
    CustomerDetailsComponent,
    Collapse,
    CalendarComponent,
    AutoCompleteComponent,
    CreateRequisitionComponent,
    ShipToLocationComponent,
    AddShipToLocationComponent,
    EditShipToLocationComponent,
    ProductCommentComponent,
    EditNewProductComponent,
    EditExistingProductComponent,
    EditFileComponent,
    RoleManDropdownComponent,
    BreadcrumbComponent,
    SpinnerComponent,
    AlertComponent,
    AutocompleteTextfieldComponent,
    FooterComponent,
    dateFormatPipe,
    CSTDateFormatPipe,
    PhoneNumberPipe,
    ZipCodePipe,
    OverrideShipToComponent,
    ButtonComponent,
    ShowForUserRoleDirective,
    BusyLoaderComponent
  ],
  exports: [
    CommonModule,
    FormsModule,
    MultiselectDropdownModule,
    TypeaheadModule,
    ProductComponent,
    CustomerComponent,
    UserComponent,
    AttachmentComponent,
    AuditlogComponent,
    VendorComponent,
    HeaderComponent,
    DropdownComponent,
    MarketDropdownComponent,
    ShipToDropdownComponent,
    CustomerDetailsComponent,
    Collapse,
    CalendarComponent,
    AutoCompleteComponent,
    CreateRequisitionComponent,
    ShipToLocationComponent,
    AddShipToLocationComponent,
    EditShipToLocationComponent,
    ProductCommentComponent,
    EditNewProductComponent,
    EditExistingProductComponent,
    RoleManDropdownComponent,
    BreadcrumbComponent,
    SpinnerComponent,
    ModalModule,
    Modal,
    AlertComponent,
    AutocompleteTextfieldComponent,
    FooterComponent,
    dateFormatPipe,
    CSTDateFormatPipe,
    PhoneNumberPipe,
    OrderrByPipe,
    ZipCodePipe,
    ButtonComponent,
    ShowForUserRoleDirective,
    BusyLoaderComponent
  ]
})

export class SharedModule { }