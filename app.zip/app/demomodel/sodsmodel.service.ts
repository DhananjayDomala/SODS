import { ObjectKey } from './../model/objectKey';
import { element } from 'protractor';
import { Injectable, ElementRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http';
import { Event, ActionSubscriber } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../events/action-events';
import { contentHeaders } from '../democomponents/util/headers';
import { environment } from '../../environments/environment';
import { ResponseMapper } from '../democomponents/util/response-mapper';
import { SubmitResponseMapper } from '../democomponents/util/submitRequest-mapper';
import { Observable } from 'rxjs/Rx';

//import model
import { Requisition, SAMPLEREQUISITION } from '../model/requisition';
import { Customer, SAMPLECUSTOMER } from '../model/customer';
import { Product, SAMPLEProduct, SAMPLEProduct_B } from '../model/product';
import { DivisionUser, SAMPLEDivisionUserBuyer, SAMPLEDivisionUserCA } from '../model/divisionrole';
import { Attachment, SAMPLEATTACHMENT_A, SAMPLEATTACHMENT_B } from '../model/attachment';
import { SAMPLETandemTM, TandemTM } from '../model/tandemTM';
import { UsfUser } from '../model/usfuser';
import { Header, SAMPLEHEADER } from '../model/header';
import { fileSaver, saveAs } from 'file-saver';
import { Division } from '../model/division';
import { Approver, Message } from '../model/approver';
import { Role, RolesForDisplay } from '../model/role';
import { Task } from "app/model/task";
import { RequestMapper } from "app/democomponents/util/request-mapper";
import { ReqDetails } from '../model/submitRequisition';
import { RetrieveVirtualVendorRespone } from "app/model/virtualVendor";
import { POResponse } from "app/model/poResponse";
import { SearchRequest, SearchRequisitions } from "app/model/searchRequisition";


@Injectable()
export class SodsModelService {

    //SODS model map
    requisitionMap: any = [];
    sampleRequisition: Requisition = SAMPLEREQUISITION;
    customer: Customer;
    product: Product;
    user: UsfUser;
    reqId: string;

    constructor(private http: Http) {
        this.requisitionMap['9789'] = SAMPLEREQUISITION;
    }

    //SODS Function
    @ActionSubscriber(ActionEvents.FIND_REQ)
    private findReq(data: { reqId: string }): Event<any> | Promise<Event<any>> {

        let resultingEvent: Event<any> = null;

        let reqData = this.requisitionMap[data.reqId];
        if (reqData) {
            resultingEvent = new Event<any>('reqFound', this.sampleRequisition);
        } else {
            resultingEvent = new Event<any>('reqNotFound', {});
        }
        return resultingEvent;

    }

    @ActionSubscriber(ActionEvents.RETRIEVE_CUST)
    private retrieveCust(data: { id: string, division: string }): Event<any> | Promise<Event<any>> {
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = environment.customerInquiryURL
            .concat('custNbr=' + data.id + '&div=' + data.division);

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                let customer: Customer = ResponseMapper.mapCustomer(response.json());
                if (customer === null || customer === undefined){
                    return new Event<any>('custNotFound', {});
                }else{
                    return new Event<any>('custFound', customer);
                }

            }, (err: Error) => {
                return new Event<any>('custNotFound', {});
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_CUST_SHIPTO)
    private retrieveCustforShipTo(data: { id: string, division: string }): Event<any> | Promise<Event<any>> {
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = environment.customerInquiryURL
            .concat('custNbr=' + data.id + '&div=' + data.division);

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                let customer: Customer = ResponseMapper.mapCustomer(response.json());
                if (customer === null || customer === undefined){
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_FAIL, {});
                }else{
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_SUCCESS, customer);
                }
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_FAIL, {});
            }).catch(this.handleError);
    }

    //Product Related
    @ActionSubscriber(ActionEvents.VALIDATE_PRODUCT)
    private validateProduct(data: { productId: string, qty: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;

        this.product = this.searchProduct(data);

        if (this.product) {
            resultingEvent = new Event<any>('productValidated', this.product);
        } else {
            resultingEvent = new Event<any>('productNotValidated', {});
        }
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.LOAD_PRODUCT)
    private loadProduct(req: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let productList: Product[] = [];
        productList.push(SAMPLEProduct);
        productList.push(SAMPLEProduct_B);
        return new Event<any>('productLoadedSuccess', productList);
    }

    //Load Create Requisition Page
    @ActionSubscriber(ActionEvents.GENERATE_REQ_ID)
    private generateReqId(): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(environment.generateReqIdURL, options)
            .toPromise()
            .then((res: Response) => {
                let body = res.json();
                return new Event<any>('requisitionIdGeneratedSuccess', body.reqId);
            })
            .catch(this.handleError);
    }

    //Loda Create Requisition Page - Retrieve TM
    @ActionSubscriber(ActionEvents.RETRIEVE_TM)
    private retrieveTM(searchId: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let username = localStorage.getItem('username');
        let password = localStorage.getItem('password');
        let body = JSON.stringify({ username, password, searchId });

        return this.http.post(environment.retrieveUserURL, body, { headers: contentHeaders })
            .toPromise()
            .then((res: Response) => {
                let responseBody = res.json();

                return new Event<any>(ModelChangeUpdateEvents.TM_FOUND, { responseBody, searchId });
            })
            .catch(this.handleError);
    }

    // Create Requisition Page - Retrieve TM
    @ActionSubscriber(ActionEvents.RETRIEVE_TM_2)
    private retrieveTM2(searchId: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let username = localStorage.getItem('username');
        let password = localStorage.getItem('password');
        let body = JSON.stringify({ username, password, searchId });

        return this.http.post(environment.retrieveUserURL, body, { headers: contentHeaders })
            .toPromise()
            .then((res: Response) => {
                let responseBody = res.json();
                return new Event<any>(ModelChangeUpdateEvents.TM_FOUND_2, responseBody);
            })
            .catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_TM_FROM_TANDEMID)
    private retrieveUSFTMFromTandemTM(tandemTMId: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let url: string = environment.retrieveUSFTMFromTandemIDURL
            .concat('/' + tandemTMId);

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                //we do mapping here to return the response of tm information
                let respBody = response.json();
                let tandemTM: TandemTM = ResponseMapper.mapTMInfo(respBody);
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_TM_FROM_TANDEMID_SUCCESS, tandemTM);
            }, (err: Error) => {
                
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_TM_FROM_TANDEMID_FAIL, {});
            }).catch(this.handleError);


        //return null;
    }

    //Post Create Requisition Page - POST TM
    @ActionSubscriber(ActionEvents.POST_REQUISITION)
    private postRequisition(postBody: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        // headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });
        const reqMapper = new SubmitResponseMapper();
        const pBody = reqMapper.mapSubmitReqMapper(postBody);
        return this.http.post(environment.postReqIdURL + '' + postBody.requisition.requisitionNumber, pBody, options)
            .toPromise()
            .then((res: Response) => {
                let body = res.json();
                return new Event<any>(ModelChangeUpdateEvents.POST_REQUISITION_SUCCESS, body);
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.POST_REQUISITION_FAIL, errorMessage);
            });
    }

    //Draft Create Requisition Page - POST TM
    @ActionSubscriber(ActionEvents.DRAFT_REQUISITION)
    private draftRequisition(postBody: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        // headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });
            const reqMapper = new SubmitResponseMapper();
        const pBody = reqMapper.mapDraftReqMapper(postBody);
        

        return this.http.post(environment.draftReqIdURL + '' + postBody.requisition.requisitionNumber, pBody, options)
            .toPromise()
            .then((res: Response) => {
                let body = res.json();
                return new Event<any>(ModelChangeUpdateEvents.DRAFT_REQUISITION_SUCCESS, body);
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.DRAFT_REQUISITION_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.SEARCH_MARKET_ROLE)
    private searchMarketRole(market: string, role: string): Event<any> | Promise<Event<any>> {
        //place search logic here
        let resultingEvent: Event<any> = null;
        let resultingUsers: DivisionUser[] = [];
        resultingUsers.push(SAMPLEDivisionUserBuyer);
        resultingUsers.push(SAMPLEDivisionUserCA);
        return new Event<any>('MarketRoleFound', resultingUsers);
    }

    //Find Attachment here
    @ActionSubscriber(ActionEvents.FIND_ATTACHMENT)
    private findAttachment(): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let resultingAttachments: Attachment[] = [];
        resultingAttachments.push(SAMPLEATTACHMENT_A);
        resultingAttachments.push(SAMPLEATTACHMENT_B);
        return new Event<any>('attachmentFound', resultingAttachments);
    }

    //Header User Info
    @ActionSubscriber(ActionEvents.RETRIEVE_USER_INFO)
    private retrieveUserInfo(): Event<any> | Promise<Event<any>> {
        let resultingUser: UsfUser = new UsfUser();

        //let user = JSON.parse(JSON.parse(sessionStorage.getItem('user'))._body);
        let jsonResponse = JSON.parse(localStorage.getItem('user'));
        let user = JSON.parse(jsonResponse._body);

        resultingUser.userId = user.userId;
        resultingUser.firstName = user.firstName;
        resultingUser.lastName = user.lastName;
        resultingUser.email = user.email;
        resultingUser.phone = user.phone;

        return new Event<any>('userInfoFound', resultingUser);
    }

    //Retrieve Product Info
    @ActionSubscriber(ActionEvents.RETRIEVE_PRODUCT)
    private retrieveProduct(data: { searchType: string, div: string, prodNbr: string }): Event<any> | Promise<Event<any>> {
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = '';
        url = environment.productRetrivalURL.concat('div=' + data.div);
        
        let prodNbrs: Array<String> = new Array<String>();
        let manufacturerNbrs: Array<String> = new Array<String>();
        if(data.searchType === 'Product(USF)') {
            prodNbrs.push(data.prodNbr);
        }
        if(data.searchType === 'Manufacturer Product') {
            manufacturerNbrs.push(data.prodNbr);
        }

        let body = {productRequest: {productNbrs:prodNbrs,  manufacturerNbrs: manufacturerNbrs}};
        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });
        
        return this.http.post(url, body, options).toPromise()
            .then((response: Response) => {
                let res = response.json();
                let resultProduct: Product = ResponseMapper.mapProduct(res.product[0]);
                if (resultProduct.desc === '') {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL, 'Product is invalid. Please check the product number or product type');
                } else if (resultProduct.prodCnt > 1) {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL, 'More than one product is returned');
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_SUCCESS, resultProduct);
                }
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL, 'Product is invalid. Please check the product number or product type');
            }).catch(this.handleError);
    }
    

    //Retrieve Product Info
    @ActionSubscriber(ActionEvents.RETRIEVE_PRODUCT_EDIT)
    private retrieveProductEdit(data: { searchType: string, div: string, prodNbr: string }): Event<any> | Promise<Event<any>> {

        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = '';
        url = environment.productRetrivalURL.concat('div=' + data.div);
        
        let prodNbrs: Array<String> = new Array<String>();
        let manufacturerNbrs: Array<String> = new Array<String>();
        if(data.searchType === 'Product(USF)') {
            prodNbrs.push(data.prodNbr);
        }
        if(data.searchType === 'Manufacturer Product') {
            manufacturerNbrs.push(data.prodNbr);
        }

        let body = {productNbrs:prodNbrs,  manufacturerNbrs: manufacturerNbrs};
        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.post(url, body, options).toPromise()
            .then((response: Response) => {
                let res = response.json();
                let resultProduct: Product = ResponseMapper.mapProduct(res.product[0]);
                if (resultProduct.description === '') {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL, 'Product is invalid. Please check the product number or product type');
                } else if (resultProduct.prodCnt > 1) {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL, 'More than one product is returned');
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_SUCCESS, resultProduct);
                }
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL, 'Product is invalid. Please check the product number or product type');
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.DEPARTMENT_CHANGE)
    private changeDepartment(deptId: string): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.DEPARTMENT_CHANGE_SUCCESS, deptId);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.REQ_CHANGE_EVT)
    private changeValue(value: any): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_CHANGE_EVT_SUCCESS, value);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.SHIPMENT_CHANGE)
    private changeShipment(data: any): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.SHIPMENT_CHANGE_SUCCESS, data);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.CALENDAR_CHANGE)
    private changeCalendar(date: Date): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.CALENDAR_CHANGE_SUCCESS, date);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.SHIPTO_CHANGE)
    private changeShipTo(data: any): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.SHIPTO_CHANGE_SUCCESS, data);
        return resultingEvent;
    }

    private searchProduct(data: { productId: string, qty: string }): Product {
        if (data.productId === SAMPLEProduct.productId && data.qty === SAMPLEProduct.qty) {
            return SAMPLEProduct;
        } else {
            return null;
        }
    }

    private handleError(error: any) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
    }

    /*
    *
    * Attachment Services
    *
    */

    /* 
        @param {string} requisitionId Requisition ID of current requisition
        @returns {array list} attachmentsList An array list of attachment details
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENT_DETAILS)
    private getAttachmentDetails(data: { requisitionId: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let attachmentsList = [];
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/details";

        return this.http.get(APIURL, options).toPromise().then(
            (res: Response) => {
                if (res[`_body`] === "") {
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS, {});
                } else {
                    let attachments = res.json();
                    attachments.forEach(element => {
                        let theAttachment = {};
                        theAttachment['fileName'] = element.fileName;
                        theAttachment['fileType'] = element.fileType;
                        theAttachment['fullName'] = element.fullName;
                        theAttachment['objectKey'] = element.objectKey;
                        theAttachment['dateUploaded'] = element.dateUploaded;
                        theAttachment['userId'] = element.userId;
                        attachmentsList.push(theAttachment);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS, attachmentsList);
                }
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL, {});
            }
            );
    }

    /*
        @param {string} requisitionId Requisition ID of current requisition
        @param {ElementRef} fileRef Reference to the file element
        @returns {null}
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_UPLOAD)
    private uploadAttachments(requisitionId: string, fileRef: ElementRef, attachedFile: FormData): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let fullName = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).firstName + " " + JSON.parse(JSON.parse(localStorage.getItem('user'))._body).lastName;
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.requisitionAttachments + "/" + requisitionId + "/upload";
        let attachment = new FormData();
        let inputEl: HTMLInputElement = fileRef.nativeElement;
        let fileCount: number = inputEl.files.length;
        if (fileCount > 0) { // a file was selected
            for (let i = 0; i < fileCount; i++) {
                attachment.append("attachment", inputEl.files.item(i));
                attachment.append("fullName", fullName);
                attachment.append("userId", userId);
                let fileName = inputEl.files.item(i).name;
                let currentDate = new Date();
                let creationDate = currentDate.toJSON();
            }
            this.http.put(APIURL, attachment, options).toPromise().then(
                (res: Response) => {
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_UPLOAD_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_UPLOAD_FAIL, "File could not be uploaded");
                }
                );
        }
        return resultingEvent;
    }

    /*
        @param {string} requisitionId Requisition ID of current requisition
        @param {string} objectKey Key of selected object
        @param {string} fileName Name of file
        @returns {null}
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_DOWNLOAD)
    private downloadAttachments(data: { requisitionId: string, objectKey: string, fileName: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + data.objectKey;
        return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                let blob = new Blob([res.blob()]);
                let fileNm = data.fileName;
                saveAs(blob, fileNm);
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL, errorBody.message);
            }
            );

    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_MULTI_DOWNLOAD)
    private downloadMultiAttachments(data: { requisitionId: string, multiDownloadList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        data.multiDownloadList.forEach(element => {
            let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + element.objectKey;
            return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
                (res: Response) => {
                    let blob = new Blob([res.blob()]);
                    let fileNm = element.fileName;
                    saveAs(blob, fileNm);
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL, errorBody.message);
                }
                );
        })
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS, {});
    }

    /*
        @param {string} requisitionId Requisition ID of current requisition
        @param {string} objectKey Key of selected object
        @returns {null}
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_DELETE)
    private deleteAttachments(data: { requisitionId: string, objectKey: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + data.objectKey + "&userId=" + userId;
        this.http.delete(APIURL, options).toPromise().then(
            (res: Response) => {
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DELETE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DELETE_FAIL, errorBody.message);
            }
            );
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_MULTI_DELETE)
    private deleteMultiAttachments(data: { requisitionId: string, multiDeleteList: Array<any> }): Event<any> | Promise<Event<any>> {
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let keys: string;

        data.multiDeleteList.forEach(element => {
            keys = element.objectKey + "," + keys;
        })
        keys = keys.replace(/,\s*$/, "");
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/multiDelete" + "?objectKey=" + keys + "&userId=" + userId;
        this.http.delete(APIURL, options).toPromise().then(
            (res: Response) => {
                //return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_FAIL, "Failed to remove files, please try again");
            }
            );
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_SOFT_DELETE)
    private softDeleteAttachments(data: { requisitionId: string, attachmentsList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        data.attachmentsList.forEach(element => {
            let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + element.objectKey + "&userId=" + userId;
            this.http.delete(APIURL, options).toPromise().then(
                (res: Response) => {
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_SOFT_DELETE_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL, errorBody.message);
                });
        }
        );
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_SOFT_DELETE_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.PROD_ATTACHMENT_DETAILS)
    private getProdAttachmentDetails(data: { requisitionId: string, attachmentKey: number }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let attachmentsList = [];
        let APIURL = environment.productAttachments + "/" + data.requisitionId + "/details?" + "sequenceId=" + data.attachmentKey;
        return this.http.get(APIURL, options).toPromise().then(
            (res: Response) => {
                if (res[`_body`] === "") {
                    return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS, {});
                } else {
                    let attachments = res.json();
                    attachments.forEach(element => {
                        let theAttachment = {};
                        theAttachment['fileName'] = element.fileName;
                        theAttachment['fileType'] = element.fileType;
                        theAttachment['fullName'] = element.fullName;
                        theAttachment['objectKey'] = element.objectKey;
                        theAttachment['dateUploaded'] = element.dateUploaded;
                        theAttachment['requisitionId'] = element.requisitionId;
                        attachmentsList.push(theAttachment);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS, attachmentsList);
                }
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL, {});
            }
            );
    }


    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_DELETE)
    private deleteProdAttachments(data: { requisitionId: string, objectKey: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.productAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + data.objectKey + "&userId = " + userId;

        this.http.delete(APIURL, options).toPromise().then(
            (res: Response) => {
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DELETE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DELETE_FAIL, errorBody.message);
            }
            );
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_DOWNLOAD)
    private downloadProdAttachments(data: { requisitionId: string, objectKey: string, fileName: string, attachmentKey: number }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.productAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + data.objectKey;
        return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                let blob = new Blob([res.blob()]);
                let fileNm = data.fileName;
                saveAs(blob, fileNm);
                return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_FAIL, errorBody.message);
            }
            );
    }


    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_MULTI_DOWNLOAD)
    private downloadMultiProdAttachments(data: { requisitionId: string, attachmentsList: Array<any>, seqId: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        data.attachmentsList.forEach(element => {
            let APIURL = environment.productAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + element.objectKey;
            return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
                (res: Response) => {
                    let blob = new Blob([res.blob()]);
                    let fileNm = element.fileName;
                    saveAs(blob, fileNm);
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_FAIL, errorBody.message);
                });
        }
        );

        return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_EDIT)
    private editAttachments(data: { requisitionId: string, fileType: string, attachmentsList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let arrObjectKeys: Array<String> = new Array<String>();
        for(let i = 0; i < data.attachmentsList.length; i++) {
            arrObjectKeys.push(data.attachmentsList[i].objectKey);
        }
        let body = {objectKeys: arrObjectKeys};
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/update" + "?fileType=" + data.fileType;
        this.http.put(APIURL, body, options).toPromise().then(
            (res: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL, "File(s) could not be attached");
        });
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_MULTI_DELETE)
    private prodDeleteMultiAttachments(data: { requisitionId: string, attachmentsList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        data.attachmentsList.forEach(element => {
            let APIURL = environment.productAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + element.objectKey + "&userId=" + userId;
            this.http.delete(APIURL, options).toPromise().then(
                (res: Response) => {
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_FAIL, {});
                }
                );
            return resultingEvent;
        })
        return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.DELETE_REQ)
    private deleteRequisition(reqId: string): Event<any> | Promise<Event<any>> {
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let url: string = environment.deleteRequisitionURL.concat(reqId);

        return this.http.delete(url, options).toPromise()
            .then((response: Response) => {
                //we do mapping here to return the response of tm information
                let respBody = response.json();
                return new Event<any>(ModelChangeUpdateEvents.DELETE_REQ_SUCCESS, {});
            }, (err: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.DELETE_REQ_FAIL, err);
            }).catch(this.handleError);
    }

    /* For Market Role Manager Search Bar */
    @ActionSubscriber(ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH)
    private getDivisionsForRoleSearch(data: any): Event<any> | Promise<Event<any>> {
        const limit = data.limit;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;

        return this.http.get(environment.getDivisionsURL, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                if (response) {
                    const responseDivisions = response.divisionList;
                    const divisions = new Array<Division>();
                    responseDivisions.forEach((row) => {
                        const division = new Division();
                        division.city = row.city;
                        division.divisionCode = row.divisionCode;
                        division.divisionName = row.divisionName;
                        division.divisionNumber = row.divisionNumber;
                        division.region = row.region;
                        division.state = row.state;
                        division.status = row.status;
                        divisions.push(division);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS, divisions);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL, response);
                }
            })
            .catch((err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL, { 'data': false });
            });
    }
    /* For getting the approvers in a market */
    @ActionSubscriber(ActionEvents.GET_APPROVERS_FOR_MARKET)
    private getRolesForMarket(data: string): Event<any> | Promise<Event<any>> {
        const divNbr = data['divisionNumber'] || '';
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        const url: string = environment.marketRoleManagerURL.concat('?division=' + divNbr).concat('&applicationID=1');

        return this.http.get(url, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                const approvers = response.approver || [];
                const formattedResponse = [];
                if (response.allOOO === 'false') {
                    approvers.forEach((row) => {
                        const approver = new Approver();
                        approver.action = row.action ? row.action : '';
                        approver.applicationId = row.applicationId;
                        approver.designatedId = row.designatedId;
                        approver.division = row.division;
                        approver.email = row.email;
                        approver.firstName = row.firstName;
                        approver.lastName = row.lastName;
                        approver.level = row.level;
                        approver.outofOffice = row.outofOffice;
                        approver.returnDate = row.returnDate;
                        approver.userId = row.userId;
                        approver.roleId = row.roleId;
                        approver.roleName = Role.getRoleName(approver.roleId);
                        approver.messages = [];
                        row.messages.forEach((message) => {
                            const approverMessage = new Message();
                            approverMessage.type = message.type;
                            approverMessage.desc = message.desc;
                            approver.messages.push(message);
                        });
                        approver.valid = row.messages.length === 0 ? 'true' : 'false'
                        formattedResponse.push(approver);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_SUCCESS,
                        { 'data': true, 'approvers': formattedResponse });
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_SUCCESS,
                        { 'data': true, 'approvers': [] });
                }
            })
            .catch((err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_FAIL, { 'data': false });
            });
    }

    // Validate Approvers for Market
    @ActionSubscriber(ActionEvents.VALIDATE_APPROVERS)
    private validateApprovers(data: any): Event<any> | Promise<Event<any>> {
        const isSave = data.isSave || false;
        const rolesForDisplay = data.rolesForDisplay;
        const approversToSave = data.approversToSave;
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });

        return this.http.post(environment.validateApproversURL, data.body, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                const approvers = response.approver;
                const formattedResponse = [];
                if (response) {
                    if (response['allOOO'] === null) {
                        approvers.forEach((row) => {
                            const approver = new Approver();
                            approver.action = row.action;
                            approver.applicationId = row.applicationId;
                            approver.designatedId = row.designatedId;
                            approver.division = row.division;
                            approver.email = row.email;
                            approver.firstName = row.firstName;
                            approver.lastName = row.lastName;
                            approver.level = row.level;
                            approver.outofOffice = row.outofOffice;
                            approver.returnDate = row.returnDate;
                            approver.userId = row.userId;
                            approver.roleId = row.roleId;
                            approver.roleName = Role.getRoleName(approver.roleId);
                            approver.messages = [];
                            row.messages.forEach((message) => {
                                const approverMessage = new Message();
                                approverMessage.type = message.type;
                                approverMessage.desc = message.desc;
                                approver.messages.push(message);
                            });
                            approver.valid = approver.messages.length === 0 ? 'true' : 'false';
                            formattedResponse.push(approver);
                        });

                        // update rolesForDisplay
                        rolesForDisplay.forEach((role, i) => {
                            role.levels.forEach((level, j) => {
                                level.forEach((approver, k) => {
                                    const validatedApprover = Approver.findInArray(formattedResponse, 'roleId', approver.roleId, 'level', approver.level, 'userId', approver.userId);
                                    if (validatedApprover.length > 0) {
                                        approver.firstName = validatedApprover[0].firstName;
                                        approver.lastName = validatedApprover[0].lastName;
                                        approver.email = validatedApprover[0].email;
                                        approver.messages = validatedApprover[0].messages;
                                    }
                                })

                            })
                        });

                        return new Event<any>(ModelChangeUpdateEvents.VALIDATE_APPROVERS_SUCCESS,
                            { 'rolesForDisplay': rolesForDisplay, 'isSave': isSave }
                        );
                    } else {
                        return new Event<any>(ModelChangeUpdateEvents.VALIDATE_APPROVERS_FAIL, { 'data': false });
                    }
                }
            })
            .catch((err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.VALIDATE_APPROVERS_FAIL, { 'data': false });
            });
    }

    // Delete Approver for Market
    @ActionSubscriber(ActionEvents.TRIM_EMPTY_LEVELS)
    private trimEmptyLevels(data): Event<any> {

        let approvers = data.approvers;
        let rolesForDisplay = [];
        const roles = new RolesForDisplay();
        // Instantiate new roles for display array
        rolesForDisplay = roles.getRoles();
        // Group approver response by Role
        let formattedData = RolesForDisplay.groupBy(approvers, 'roleId');
        // Format the Data for Display
        formattedData = RolesForDisplay.formatDataForDisplay(formattedData);
        // Replace rolesForDisplay with actual approver values if they exist
        const matches = formattedData.filter((o1) => {
            return rolesForDisplay.some((o2) => {
                return o1['roleId'] === o2['roleId'];
            });
        });

        matches.forEach((row) => {
            const index = rolesForDisplay.findIndex(x => x.roleId === row.roleId);
            rolesForDisplay[index] = row;
        });

        rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = data.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });

        return new Event<any>(ModelChangeUpdateEvents.TRIM_EMPTY_LEVELS_SUCCESS, { 'rolesForDisplay': rolesForDisplay });
    }

    @ActionSubscriber(ActionEvents.NORMALIZE_LEVELS)
    private normalizeLevels(data): Event<any> {
        const rolesForDisplay = data.rolesForDisplay;
        const isSave = data.isSave || false;
        // Update approver object level attribute to match the actual levelId
        rolesForDisplay.forEach((role, i) => {
            role.levels.forEach((level, j) => {
                level.forEach((approver, k) => {
                    approver.level = (j + 1).toString();
                });
            });
        });
        if (isSave) {
            return new Event<any>(ModelChangeUpdateEvents.NORMALIZE_LEVELS_SUCCESS, {
                'rolesForDisplay': rolesForDisplay
            });
        } else {
            return new Event<any>(ModelChangeUpdateEvents.NORMALIZE_LEVELS_SUCCESS_NO_SAVE, {
                'rolesForDisplay': rolesForDisplay
            });
        }

    }

    // Save Approvers for Market
    @ActionSubscriber(ActionEvents.SAVE_APPROVERS_DELETE)
    private saveApproversDelete(request): Event<any> | Promise<Event<any>> {
        const body = request.body || '';
        const rolesForDisplay = request.rolesForDisplay;
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.marketRoleManagerURL, body, options)
            .toPromise()
            .then((res: Response) => {
                const responseBody = res.json();
                return new Event<any>(ModelChangeUpdateEvents.SAVE_APPROVERS_DELETE_SUCCESS, { 'response': responseBody, 'rolesForDisplay': rolesForDisplay });
            })
            .catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.SAVE_APPROVERS_ADD)
    private saveApproversAdd(request): Event<any> | Promise<Event<any>> {
        const body = request.body || '';
        const rolesForDisplay = request.rolesForDisplay;
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.marketRoleManagerURL, body, options)
            .toPromise()
            .then((res: Response) => {
                const responseBody = res.json();
                return new Event<any>(ModelChangeUpdateEvents.SAVE_APPROVERS_ADD_SUCCESS, { 'response': responseBody, 'rolesForDisplay': rolesForDisplay });
            })
            .catch(this.handleError);
    }

    // Add Approver to Role in Level
    @ActionSubscriber(ActionEvents.ADD_APPROVER)
    private addApprover(data): Event<any> {
        
        const rolesForDisplay = data.rolesForDisplay;
        const roleIndex = data.roleIndex;
        const approverToAdd = data.approverToAdd;
        const roleId = data.approverToAdd.roleId;
        const levelId = (data.approverToAdd.level - 1);
        const idx = Approver.findIndex(rolesForDisplay[roleIndex].levels[levelId], 'userId', approverToAdd.userId);

        if (idx < 0 ) {
            rolesForDisplay[roleIndex].levels[levelId].push(approverToAdd);
            return new Event<any>(ModelChangeUpdateEvents.ADD_APPROVER_SUCCESS, {
                'rolesForDisplay': rolesForDisplay,
                'approver': approverToAdd
            });
        } else {
            return new Event<any>(ModelChangeUpdateEvents.ADD_APPROVER_FAIL, {
                'rolesForDisplay': rolesForDisplay,
                'approver': approverToAdd
            });
        }
    }

    // Add Approver Level To Role
    @ActionSubscriber(ActionEvents.ADD_LEVEL_TO_ROLE)
    private addApproverLevel(data): Event<any> {
        const rolesForDisplay = data.rolesForDisplay;
        const roleIndex = data.roleIndex;
        rolesForDisplay[roleIndex].levels.push([]);
        return new Event<any>(ModelChangeUpdateEvents.ADD_LEVEL_TO_ROLE_SUCCESS, {
            'rolesForDisplay': rolesForDisplay
        });
    }

    // Delete Approver for Market
    @ActionSubscriber(ActionEvents.DELETE_APPROVER)
    private deleteApprover(data): Event<any> {
        const rolesForDisplay = data.rolesForDisplay;
        const roleIndex = data.roleIndex;
        const levelIndex = data.levelIndex;
        const approverIndex = data.approverIndex;
        const approver = rolesForDisplay[roleIndex].levels[levelIndex][approverIndex];
        rolesForDisplay[roleIndex].levels[levelIndex].splice(approverIndex, 1);
        return new Event<any>(ModelChangeUpdateEvents.DELETE_APPROVER_SUCCESS, { 'rolesForDisplay': rolesForDisplay, 'approver': approver });
    }

    // Delete Approver for Market
    @ActionSubscriber(ActionEvents.DELETE_LEVEL_FROM_ROLE)
    private deleteApproverLevel(data): Event<any> {
        const rolesForDisplay = data.rolesForDisplay;
        const roleIndex = data.roleIndex;
        const levelIndex = data.levelIndex;
        const levels = rolesForDisplay[roleIndex].levels;
        const approversToDelete = new Array<Approver>();
        const approversToAdd = new Array<Approver>();

        for (let i = levels.length - 1; i > levelIndex; i--) {
            levels[i].forEach((approver: Approver, j) => {
                const approverToDelete = new Approver();
                approverToDelete.action = 'Remove';
                approverToDelete.division = approver.division
                approverToDelete.email = approver.email;
                approverToDelete.firstName = approver.firstName;
                approverToDelete.lastName = approver.lastName;
                approverToDelete.level = approver.level;
                approverToDelete.messages = approver.messages;
                approverToDelete.outofOffice = approver.outofOffice;
                approverToDelete.returnDate = approver.returnDate;
                approverToDelete.roleID = approver.roleID || approver.roleId;
                approverToDelete.roleId = approver.roleId;
                approverToDelete.roleName = approver.roleName;
                approverToDelete.userId = approver.userId;
                approverToDelete.valid = approver.valid;
                approversToDelete.push(approverToDelete);

                const approverToAdd = new Approver();
                approverToAdd.action = 'Add';
                approverToAdd.division = approver.division
                approverToAdd.email = approver.email;
                approverToAdd.firstName = approver.firstName;
                approverToAdd.lastName = approver.lastName;
                approverToAdd.level = i.toString();
                approverToAdd.messages = approver.messages;
                approverToAdd.outofOffice = approver.outofOffice;
                approverToAdd.returnDate = approver.returnDate;
                approverToAdd.roleID = approver.roleID || approver.roleId;
                approverToAdd.roleId = approver.roleId;
                approverToAdd.roleName = approver.roleName;
                approverToAdd.userId = approver.userId;
                approverToAdd.valid = approver.valid;
                approverToAdd.flag = true;

                approversToAdd.push(approverToAdd);
            });
        }

        levels[levelIndex].forEach((approver) => {

            const approverToDelete = new Approver();
            approverToDelete.action = 'Remove';
            approverToDelete.division = approver.division
            approverToDelete.email = approver.email;
            approverToDelete.firstName = approver.firstName;
            approverToDelete.lastName = approver.lastName;
            approverToDelete.level = approver.level;
            approverToDelete.messages = approver.messages;
            approverToDelete.outofOffice = approver.outofOffice;
            approverToDelete.returnDate = approver.returnDate;
            approverToDelete.roleID = approver.roleID || approver.roleId;
            approverToDelete.roleId = approver.roleId;
            approverToDelete.roleName = approver.roleName;
            approverToDelete.userId = approver.userId;
            approverToDelete.valid = approver.valid;

            approversToDelete.push(approverToDelete);
        });
        rolesForDisplay[roleIndex].levels.splice(levelIndex, 1);

        return new Event<any>(ModelChangeUpdateEvents.DELETE_LEVEL_FROM_ROLE_SUCCESS, {
            'rolesForDisplay': rolesForDisplay,
            'approversToAdd': approversToAdd,
            'approversToDelete': approversToDelete,
        });
    }


    @ActionSubscriber(ActionEvents.GENERATE_PDF)
    private generatePdf(data: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let APIURL = environment.generatePdf;
        let reqId = data.requisition.requisitionNumber; //get reqId from data object
        let fileName = "SODS-ReqId" + reqId + ".pdf";
        return this.http.post(APIURL, data, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                let blob = new Blob([res.blob()]);
                saveAs(blob, fileName);
                return new Event<any>(ModelChangeUpdateEvents.PDF_GENERATE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.PDF_GENERATE_FAIL, {});
            }
        );
    }

    @ActionSubscriber(ActionEvents.EXPORT_EXCEL)
    private exportExcel(data: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        //let options = new RequestOptions({ headers: headers });
        let APIURL = environment.generateExcel;
        let jsonResponse = JSON.parse(localStorage.getItem('user'));
        let user = JSON.parse(jsonResponse._body);
        let networkId = user.userId;
        return this.http.post(APIURL + "?networkId=" + networkId, null, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                let blob = new Blob([res.blob()]);
                saveAs(blob, "ExportToExcel.xlsx");
                return new Event<any>(ModelChangeUpdateEvents.EXPORT_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.EXPORT_FAIL, {});
            }
            );
    }

    //for task inbox
    @ActionSubscriber(ActionEvents.GET_TASK)
    private getInboxTasks(networkId: string): Event<any> | Promise<Event<any>> {
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        const url: string = environment.getInboxTaskURL.concat(networkId);
        let taskList: Task[] = [];
        return this.http.get(url, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();                
                if (response) {
                    //map the response to task object
                    console.log("All tasks: " + JSON.stringify(response));
                    response.tasks.map(item => {
                        return {
                            taskId: item.taskID,
                            taskType: item.taskType,
                            reqId: item.reqID,
                            custNumber: item.custNumber,
                            custName: item.custName,
                            deptId: item.deptID,
                            commentsFlag: item.commentsFlag,
                            attachmentsFlag: item.attachmentsFlag,
                            actionRequired: item.actionRequired,
                            createdDate: item.createdDate,
                            lastUpdateDate: item.lastUpdateDate,
                            division: item.division

                        }
                    }).forEach(item => taskList.push(item));

                    return new Event<any>(ModelChangeUpdateEvents.GET_TASK_SUCCESS, taskList);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.GET_TASK_FAIL, "fail get task");
                }

            })
            .catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_COMMENT_INBOX)
    private retrieveCommentsforInbox(reqId: string) {
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        const url: string = environment.retrieveCommentforInboxURL.concat(reqId);
        let commentList: Array<Comment> = [];
        return this.http.get(url, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                
                if (response) {
                    response.map(item => {
                        return {
                            commentsText: item.commentsText,
                            timestamp: item.timestamp,
                            networkId: item.networkId,
                            name: item.name,
                        }
                    }).forEach(item => commentList.push(item));
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_SUCCESS, commentList);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_FAIL, "fail retrieve comments");
                }

            })
            .catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.GET_SEARCH_USER)
    private searchUser(query: any): Event<any> | Promise<Event<any>> {        
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        let res = query.query.split(",");
        //check res[0] and res[1]
        if (res[0] !== undefined && res[0] !== "" && res[1] !== undefined && res[1] !== "") {
            return this.http.get(environment.searchUser + '?firstName=' + res[1] + '&&lastName=' + res[0], options)
                .toPromise()
                .then((res: Response) => {
                    const response = res.json();
                    if (response) {
                        return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS, response);
                    } else {
                        return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_FAIL, response);
                    }
                })
        } else if ((res[0] === "" || res[0] === undefined) && res[1] !== "") {
            return this.http.get(environment.searchUser + '?firstName=' + res[1], options)
                .toPromise()
                .then((res: Response) => {
                    const response = res.json();
                    if (response) {
                        return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS, response);
                    } else {
                        return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_FAIL, response);
                    }
                })
        } else if ((res[1] === "" || res[1] === undefined) && res[0] !== "") {
            return this.http.get(environment.searchUser + '?lastName=' + res[0], options)
                .toPromise()
                .then((res: Response) => {
                    const response = res.json();
                    if (response) {
                        return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS, response);
                    } else {
                        return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_FAIL, response);
                    }
                })
        } else {
            return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_FAIL, "error");
        }

        // return this.http.get(environment.searchUser+'?firstName='+query.query, options)
        //     .toPromise()
        //     .then((res: Response) => {
        //         const response = res.json();
        //         if (response) {
        //             return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_SUCCESS, response);
        //         } else {
        //             return new Event<any>(ModelChangeUpdateEvents.GET_SEARCH_USER_FAIL, response);
        //         }
        //     })
    }

    @ActionSubscriber(ActionEvents.GET_OUT_OF_OFFICE_STATUS)
    private getOutofOffice(networkId: any): Event<any> | Promise<Event<any>> {
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        return this.http.get(environment.outoffOffice + '' + networkId, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                if (response) {
                    return new Event<any>(ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_SUCCESS, response);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_FAIL, response);
                }
            })
    }
    
    @ActionSubscriber(ActionEvents.GET_REQ_DETAILS_BY_ID)
    private getReqDetailsById(data: any): Event<any> | Promise<Event<any>> {
        const id = data.reqId;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        return this.http.get(environment.getReqDetailsURL + id, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                if (response) {
                    console.log('getReqDetailsForApprovers Response---->', response); //Testing for sods-exp-api
                    let reqDetails = ResponseMapper.mapRequisitionDetails(response);
                    // let reqDetails = ResponseMapper.mockRequisitionDetails(response);
                    return new Event<any>(ModelChangeUpdateEvents.GET_REQ_DETAILS_BY_ID_SUCCESS, reqDetails);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.GET_REQ_DETAILS_BY_ID_FAIL, response);
                }
            })
            .catch((err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_FAIL, { 'data': 'Failed to get requisition details' });
            });
    }

    @ActionSubscriber(ActionEvents.SET_OUT_OF_OFFICE_STATUS)
    private setOfficeOut(data: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let body = JSON.stringify(RequestMapper.mapSetOutofOffice(data));
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append("Content-Type", 'application/json');
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.outoffOffice, body, options)
            .toPromise()
            .then((res: Response) => {
                let responseBody = res.json();
                //base on the result send event
                if (responseBody.status !== "Success") {
                    return new Event<any>(ModelChangeUpdateEvents.SET_OUT_OF_OFFICE_STATUS_FAIL, responseBody.statusDescription);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.SET_OUT_OF_OFFICE_STATUS_SUCCESS, responseBody);
                }
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.SET_OUT_OF_OFFICE_STATUS_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.UN_SET_OUT_OF_OFFICE_STATUS)
    private unsetOfficeOut(data: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let body = JSON.stringify(RequestMapper.mapUnsetOutofOffice(data));
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append("Content-Type", 'application/json');
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.unSetOutoffOffice, body, options)
            .toPromise()
            .then((res: Response) => {
                let responseBody = res.json();             
                if (responseBody.status !== "Success") {
                    return new Event<any>(ModelChangeUpdateEvents.UN_SET_OUT_OF_OFFICE_STATUS_FAIL, responseBody.statusDescription);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.UN_SET_OUT_OF_OFFICE_STATUS_SUCCESS, responseBody);
                }
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.UN_SET_OUT_OF_OFFICE_STATUS_FAIL, errorMessage);
            });
    }

    /* For Approvers Components */
    @ActionSubscriber(ActionEvents.GET_REQ_DETAILS_FOR_APPROVALS)
    private getReqDetailsForApprovers(data: any): Event<any> | Promise<Event<any>> {
        const taskId = data.taskId;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        return this.http.get(environment.getTaskDetailsURL + taskId, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                if (response) {
                    console.log('getReqDetailsForApprovers Response---->', response); //Testing for sods-exp-api
                    let reqDetails = ResponseMapper.mapRequisitionDetails(response);
                    // let reqDetails = ResponseMapper.mockRequisitionDetails(response);
                    return new Event<any>(ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_SUCCESS, reqDetails);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_FAIL, response);
                }
            })
            .catch((err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_FAIL, { 'data': 'Failed to get requisition details' });
            });
    }

    @ActionSubscriber(ActionEvents.COMPLETE_TASK)
    private completeTask(request): Event<any> | Promise<Event<any>> {
        const body = request.body || '';
        const taskType = request.taskType || '';
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.completeTask, body, options)
            .toPromise()
            .then((res: Response) => {
                const responseBody = res.json();
                if(responseBody.code === 4) {
                    return new Event<any>(ModelChangeUpdateEvents.COMPLETE_TASK_SUCCESS, { 'response': responseBody, 'taskType': taskType });
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.COMPLETE_TASK_FAIL, { 'response': responseBody, 'taskType': taskType });
                }
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.COMPLETE_TASK_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.ACCEPT_TASK)
    private acceptTask(request): Event<any> | Promise<Event<any>> {
        const body = request.body || '';
        const taskType = request.taskType || '';
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.acceptTask, body, options)
            .toPromise()
            .then((res: Response) => {
                const responseBody = res.json();
                if(responseBody.code === 4) {
                    return new Event<any>(ModelChangeUpdateEvents.ACCEPT_TASK_SUCCESS, { 'response': responseBody, 'taskType': taskType });
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.ACCEPT_TASK_FAIL, { 'response': responseBody, 'taskType': taskType });
                }
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.ACCEPT_TASK_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.RELEASE_TASK)
    private releaseTask(request): Event<any> | Promise<Event<any>> {
        const body = request.body || '';
        const taskType = request.taskType || '';
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.releaseTask, body, options)
            .toPromise()
            .then((res: Response) => {
                const responseBody = res.json();
                if(responseBody.code === 4) {
                    return new Event<any>(ModelChangeUpdateEvents.RELEASE_TASK_SUCCESS, { 'response': responseBody, 'taskType': taskType });
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.RELEASE_TASK_FAIL, { 'response': responseBody, 'taskType': taskType });
                }
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.RELEASE_TASK_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.VALIDATE_PRODUCTS)
    private validateProducts(data: { productNbrs: Array<any>, div: string }): Event<any> | Promise<Event<any>> {
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });
        let body = {productRequest: {productNbrs:data.productNbrs}};
        let url: string = '';
        url = environment.validateProductsURL.concat('div=' + data.div);
        return this.http.post(url, body, options).toPromise()
            .then((response: Response) => {
                let res = response.json();
                let resultProduct = ResponseMapper.mapValidatedProducts(res);  
                return new Event<any>(ModelChangeUpdateEvents.VALIDATE_PRODUCTS_SUCCESS, resultProduct);
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.VALIDATE_PRODUCTS_FAIL, 'Product is invalid. Please check the product number or product type');
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.VALIDATE_PO)
    private validatePO(data: {requisitionId: string, vendorNumber: string, buyerNumber: string, poNumber: string}): Event<any> | Promise<Event<any>>{
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let body = {requisitionId:data.requisitionId, vendorNumber: data.vendorNumber, buyerNumber: data.requisitionId, poNumber:data.poNumber};
        let url: string = '';
        url = environment.validatePOURL;
        return this.http.post(url, body, options).toPromise()
            .then((response: Response) => {
                let poResponse : POResponse = <POResponse> response.json();
                //let res = response.json();
                return new Event<any>(ModelChangeUpdateEvents.VALIDATE_PO_SUCCESS, poResponse);
            }, (err: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.VALIDATE_PO_FAIL, err);
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.TRANSFER_REQUISITION)
    private transferRequisition(request): Event<any> | Promise<Event<any>> {
        const body = request.body || '';
        const taskType = request.taskType || '';
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.transferRequisitionURL, body, options)
            .toPromise()
            .then((res: Response) => {
                const responseBody = res.json();
                if(responseBody.status === 'Success') {
                    return new Event<any>(ModelChangeUpdateEvents.TRANSFER_REQUISITION_SUCCESS, { 'reqId':request.body.reqId, 'forwardId':request.body.approverId[0], 'response': responseBody });
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.TRANSFER_REQUISITION_FAIL, { 'response': responseBody});
                }
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.TRANSFER_REQUISITION_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_VIRTUAL_VENDOR)
    private retrieveVirtualVendor(data:{vendorId: string, product: Product}): Event<any> | Promise<Event<any>> {
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        let url: string = environment.retrieveVirtualVendor.concat(data.vendorId);
        return this.http.get(url, options).toPromise()
        .then((response: Response) => {
            if (response === null || response === undefined){
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_VIRTUAL_VENDOR_FAIL, {});
            }
            else{
                let retrieveVirtualVendorRespone = new RetrieveVirtualVendorRespone();
                //do a mapper here
                retrieveVirtualVendorRespone.virtualVendorList = response.json();
                retrieveVirtualVendorRespone.product = data.product;
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_VIRTUAL_VENDOR_SUCCESS, retrieveVirtualVendorRespone);
            }

        }, (err: Error) => {
            return new Event<any>(ModelChangeUpdateEvents.RELEASE_TASK_FAIL, {});
        }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.SEARCH_REQUISITION)
    private searchRequisition(searchRequest: SearchRequest): Event<any> | Promise<Event<any>> {
        const body = {'search': searchRequest};
        const resultingEvent: Event<any> = null;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        return this.http.post(environment.searchRequisitionURL, body, options)
            .toPromise()
            .then((res: Response) => {
                //now need to do mapping here
                let searchRequisitions = new SearchRequisitions();
                searchRequisitions = <SearchRequisitions> res.json();
                return new Event<any>(ModelChangeUpdateEvents.SEARCH_REQUISITION_SUCCESS, searchRequisitions);
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.SEARCH_REQUISITION_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.SEARCH_EXPORT_EXCEL)
    private searchExportExcel(data: {searchResult: any, searchType: any}): Event<any> | Promise<Event<any>> {
        //Also pass in type of search and name XLSX depending on type of search
        let fileName = "";
        if(data.searchType !== null) {
            if(data.searchType = 'Custom Search') {
                fileName = "SODSSearchCustom.xlsx";
            }
            if(data.searchType = 'Open 30') {
                fileName = "SODSSearchOpen30.xlsx";
            }
            if(data.searchType = 'Open Requests') {
                fileName = "SODSSearchMyOpen.xlsx";
            }
        }
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let APIURL = environment.generateSearchExcel;
        let body = {searchResult: data.searchResult};
        return this.http.post(APIURL, body, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                let blob = new Blob([res.blob()]);
                saveAs(blob, fileName);
                return new Event<any>(ModelChangeUpdateEvents.SEARCH_EXPORT_EXCEL_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.SEARCH_EXPORT_EXCEL_FAIL, {});
            }
        );
    }
}