import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';

//import ng2-idle
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'; 
import { ModalModule } from 'ngx-modal';
import { MomentModule } from 'angular2-moment';

import { SharedModule } from './shared/shared.module';

//Import the service here
import { ActionDispatcherService, ModelPresenterService, EventTypeRegistryService, StateRepresentationRendererService } from 'usf-sam';

//Login Component
import { LoginComponent } from './democomponents/login/login.component';
import { LogOffComponent } from './democomponents/login/logoff.component';

//Header Component
import { HeaderComponent } from './democomponents/header/header.component'

//Routing
import { appRoutingProviders, routing } from './app.routes';
import { AuthGuard } from './democomponents/util/auth.guard';

//Register the SODSModelService
import { SodsModelService } from './demomodel/sodsmodel.service';
import { AuthenticationService } from './service/authentication.service';
import { FilenotfoundComponent } from './democomponents/login/filenotfound.component';
import { OutofofficeComponent } from './democomponents/outofoffice/outofoffice.component';

import {OutOfService} from './service/outoffice.service';
import { ApproverComponent } from './democomponents/approver/approver.component';

//Import the pagination module
import { NgxPaginationModule } from 'ngx-pagination';
import { DivisionsService } from './service/divisions.service';
import { SearchReqDetailsComponent } from './users/xd56026/documents/sodsworkspace5/app-aws-sods/app/src/app/democomponents/sodssearch/search-req-details/search-req-details.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LogOffComponent,
    FilenotfoundComponent,
    OutofofficeComponent,
    SearchReqDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    ModalModule,
    routing,
    BrowserAnimationsModule,
    MomentModule,
    NgIdleKeepaliveModule.forRoot(),
    SharedModule,
    NgxPaginationModule
  ],
  providers: [
    ActionDispatcherService, 
    ModelPresenterService, 
    SodsModelService,
    EventTypeRegistryService,
    StateRepresentationRendererService,
    AuthenticationService,
    OutOfService,
    DivisionsService,
    AuthGuard],
  bootstrap: [AppComponent]
})

export class AppModule { }