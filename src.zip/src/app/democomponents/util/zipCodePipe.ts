import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'zipCodePipe',
})
export class ZipCodePipe implements PipeTransform {
    transform(value: string) {
        if(value !== null) {
            return this.formatZipCode(value);
        }
    }

    formatZipCode(zipcode) {
        return zipcode.replace(/(\d{5})(\d{4})/, '$1-$2');
    }
}