import { Customer } from '../../model/customer';
import { Product, Vendor, ShipToDist, VndrDtlList } from '../../model/product';
import { TandemTM } from '../../model/tandemTM';
import { ReqDetails, TaskInboxCustomer, TaskInboxProduct } from '../../model/submitRequisition';

export class ResponseMapper {
    static requistionTypes: any = {
        'SODS-SO': 'Special Order',
        'SODS-DS': 'Direct Ship'
    };

    static shipMethodTypes: any = {
        'Next': 'Next',
        'Separate': 'Separate'
    };

    static mapCustomer(data: any): Customer {
        let customer: Customer = new Customer();
        customer.id = data.custNbr;
        customer.division = data.div;
        customer.name = data.custNm;
        customer.address1 = data.addr.addr1;
        customer.address2 = data.addr.addr2;
        customer.city = data.addr.cty;
        customer.state = data.addr.ste;
        customer.zip = data.addr.zip;
        customer.phone = data.phone.telNbr;
        customer.estimatedOrderAmt = '321.12';
        customer.confidenceCode = data.creditCd;
        customer.creditCheckStatus = 'true';
        customer.tmId = data.rte.tmId;
        customer.tmName = 'sodsus02, SharedAcct';
        customer.tmEmail = 'Shared.sodsus02@foodfite.com';
        customer.deptOptions = this.buildOptions(data.dept || []);
        customer.custType = data.custTyp;
        return customer;
    }

    static mapProduct(data: any): Product{
        let product: Product = new Product();
        let vendor : Vendor = new Vendor();
        product.vendor = vendor;
        product.description = data.desc;
        product.productId = data.prodNbr;
        product.mfrId = data.mfrProdNbr;
        product.distSts = data.distSts;
        product.label = data.label;
        product.priceUOM = data.priceUOM;
        product.packSize = data.slsPkSize;
        product.netWeight = data.netWght;
        product.salesUOM = data.slsUOM;
        product.catchWeightInd = data.catchWghtInd;
        if(data.primVndrDtl !== null && data.primVndrDtl !== undefined){
            product.vendor.vendorId = data.primVndrDtl.vndrNbr;
            product.vendor.vendorName = data.primVndrDtl.vndrNm;
            product.vendor.vendorLstPrc = data.primVndrDtl.vndrLstPrc;
            product.vendor.buyerNumber = data.primVndrDtl.byrNbr;
            product.vendor.buyerEmail = data.primVndrDtl.byrEmail;
            product.vendor.buyerName = data.primVndrDtl.byrNm;
            product.vendor.buyerNetworkId = data.primVndrDtl.byrUsrID;
        }
        product.prodCnt = data.prodCnt;
        //add converter
        product.convFctr = data.convFctr;
        product.ntnlSts = data.ntnlSts;
        product.prodAttchd = data.prodAttchd;
        if(data.prodAttchd == 'T'){
            product.attached = 'true';
        }else if(data.prodAttchd == 'F'){
            product.attached = 'false';
        }else{
            product.attached = data.prodAttchd;
        }
        product.class = data.pimClass;
        product.pimClass = data.pimClass;
        return product;
    }

    static mapValidatedProducts(data: any) {
        let productsList: Array<Product> = [];
        for(let i = 0; i < data.product.length; i++) {
            let entry = data.product[i];
            let product: Product = new Product();
            let vendor : Vendor = new Vendor();
            let vndrDtlLists : VndrDtlList = new VndrDtlList();
            product.vendor = vendor;
            product.description = entry.desc;
            product.vndrDtlList = Array<VndrDtlList>();
            product.productId = entry.prodNbr;
            product.mfrId = entry.mfrProdNbr;
            product.distSts = entry.distSts;
            product.label = entry.label;
            product.priceUOM = entry.priceUOM;
            product.packSize = entry.slsPkSize;
            product.netWeight = entry.netWght;
            product.salesUOM = entry.slsUOM;
            product.catchWeightInd = entry.catchWghtInd;
            if(entry.primVndrDtl !== undefined && entry.primVndrDtl !== null) {
                product.vendor.vendorId = entry.primVndrDtl.vndrNbr;
                product.vendor.vendorName = entry.primVndrDtl.vndrNm;
                product.vendor.vendorLstPrc = entry.primVndrDtl.vndrLstPrc;
                product.vendor.buyerNumber = entry.primVndrDtl.byrNbr;
                product.vendor.buyerEmail = entry.primVndrDtl.byrEmail;
                product.vendor.buyerName = entry.primVndrDtl.byrNm;
                product.vendor.buyerNetworkId = entry.primVndrDtl.byrUsrID;
            }
            if(entry.vndrDtlList !== undefined && entry.primVndrDtl !== null) {
                for(let j = 0; j < entry.vndrDtlList.length; j++) {
                    let newVndrDtl : VndrDtlList = new VndrDtlList();
                    newVndrDtl.byrEmail = entry.vndrDtlList[j].byrEmail;
                    newVndrDtl.byrNbr = entry.vndrDtlList[j].byrNbr;
                    newVndrDtl.byrNm = entry.vndrDtlList[j].byrNm;
                    newVndrDtl.byrUserID = entry.vndrDtlList[j].byrUserID;
                    newVndrDtl.primVndrNbr = entry.vndrDtlList[j].primVndrNbr;
                    newVndrDtl.vndrLstPrc = entry.vndrDtlList[j].vndrLstPrc;
                    newVndrDtl.vndrNbr = entry.vndrDtlList[j].vndrNbr;
                    newVndrDtl.vndrNm = entry.vndrDtlList[j].vndrNm;
                    product.vndrDtlList.push(newVndrDtl);
                }
            }
            product.prodCnt = entry.prodCnt;
            product.convFctr = entry.convFctr;
            product.ntnlSts = entry.ntnlSts;
            if(entry.prodAttchd === 'T'){
                product.prodAttchd = 'true';
                product.attached = 'true';
            }else{
                product.prodAttchd = 'false';
                product.attached = 'false';
            }
            product.class = entry.pimClass;
            product.pimClass = entry.pimClass;
            productsList.push(product);
        }
        return productsList;
    }

    static mapTMInfo(data: any): TandemTM{
        let tandemTM: TandemTM = new TandemTM();
        tandemTM.routeToDivision = data.routeToDivision;
        tandemTM.routeToDivisionCode = data.routeToDivisionCode;
        tandemTM.routeToDivisionSystem = data.routeToDivisionSystem;
        tandemTM.routeToDivisionTimezone = data.routeToDivisionTimezone;
        tandemTM.routeToDSMID = data.routeToDSMID;
        tandemTM.routeToFMID = data.routeToFMID;
        tandemTM.routeToRSMID = data.routeToRSMID;
        tandemTM.routeToVPID = data.routeToVPID;
        tandemTM.status = data.status;
        tandemTM.statusDescription = data.statusDescription;
        tandemTM.tmnetworkID = data.tmnetworkID;
        tandemTM.tmparentDivision = data.tmparentDivision;
        return tandemTM;
    }

    private static buildOptions(dept: any): string[] {
        let optionList: string[] = [];

        if(dept.length == 0){
            return ['00-NODEPT'];
        }
        
        for(let i = 0; i < dept.length; i++) {
            let entry = dept[i];
            let department = entry.dptNbr.concat('-'.concat(entry.dptNm));
            optionList.push(department);
        }
        return optionList;
    }

    static mapRequisitionDetails(response: ReqDetails): ReqDetails {
        const reqDetails: ReqDetails = new ReqDetails();

        reqDetails.draftTaskId = response.draftTaskId || '';
        reqDetails.overideSavedByID = response.overideSavedByID || '';
        reqDetails.overideSavedByName = response.overideSavedByName || '';
        reqDetails.taskId = response.taskId || '';
        reqDetails.taskName = response.taskName || '';
        reqDetails.taskStatus = response.taskStatus || '';
        reqDetails.responseStatus = response.responseStatus || '';
        reqDetails.assignedToCount = response.assignedToCount || '';
        reqDetails.assignedToList = response.assignedToList || [];
        reqDetails.acceptedByList = response.acceptedByList;

        // requisition
        reqDetails.requisition.comments = response.requisition.comments || [];        
        reqDetails.requisition.createdAt = response.requisition.createdAt || '';
        reqDetails.requisition.defaultCustomerPO = response.requisition.defaultCustomerPO || '';
        reqDetails.requisition.defaultShipMethod = this.shipMethodTypes[response.requisition.defaultShipMethod] || '';
        reqDetails.requisition.defaultSpecialInstructions = response.requisition.defaultSpecialInstructions || '';
        reqDetails.requisition.mainCustomerType = response.requisition.mainCustomerType || '';
        reqDetails.requisition.division = response.requisition.division || '';
        reqDetails.requisition.ETADate = response.requisition.ETADate || '';
        reqDetails.requisition.ETASelection = response.requisition.ETASelection || false;
        reqDetails.requisition.mainCustomerDept = response.requisition.mainCustomerDept || '';
        reqDetails.requisition.mainCustomerID = response.requisition.mainCustomerID || '';
        reqDetails.requisition.mainCustomerName = response.requisition.mainCustomerName || '';
        reqDetails.requisition.quoteNumber = response.requisition.quoteNumber || '';
        reqDetails.requisition.quotePrice = response.requisition.quotePrice || '';
        reqDetails.requisition.requisitionNumber = response.requisition.requisitionNumber || '';
        reqDetails.requisition.requisitionType = this.requistionTypes[response.requisition.requisitionType] || response.requisition.requisitionType;
        reqDetails.requisition.returnIfETANotMet = response.requisition.returnIfETANotMet || false;
        reqDetails.requisition.status = response.requisition.status || '';
        reqDetails.requisition.totalAmount = response.requisition.totalAmount || '';
        reqDetails.requisition.updatedAt = response.requisition.updatedAt || '';

        // requestor
        reqDetails.requestor.additionalEmail = response.requestor.additionalEmail || '';
        reqDetails.requestor.additionalPhone = response.requestor.additionalPhone || '';
        reqDetails.requestor.email = response.requestor.email || '';
        reqDetails.requestor.name = response.requestor.name || '';
        reqDetails.requestor.networkId = response.requestor.networkId || '';

        // territory manager
        reqDetails.territoryManager.additionalEmail = response.territoryManager.additionalEmail || '';
        reqDetails.territoryManager.additionalPhone = response.territoryManager.additionalPhone || '';
        reqDetails.territoryManager.email = response.territoryManager.email || '';
        reqDetails.territoryManager.name = response.territoryManager.name || '';
        reqDetails.territoryManager.networkId = response.territoryManager.networkId || '';

        // customers
        let customers: TaskInboxCustomer[] = new Array<TaskInboxCustomer>();
        response.customers.forEach((customer) => {
            customer.defaultShipMethod = this.shipMethodTypes[customer.defaultShipMethod];
            customers.push(customer);
        });
        reqDetails.customers = customers;

        // products
        let products: TaskInboxProduct[] = new Array<TaskInboxProduct>();
        response.products.forEach((product: TaskInboxProduct) => {
            product.shipTodistribution[0].shipMethod = this.shipMethodTypes[product.shipTodistribution[0].shipMethod];
            if (!product.returned) {
                product.returned = false;
            }
            products.push(product);
        });
        reqDetails.products = products;
        reqDetails.auditLogs = response.auditLogs;
        return reqDetails;
    }

}