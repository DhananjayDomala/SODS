import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TaskInboxProduct } from '../../../model/submitRequisition';

@Component({
  selector: 'app-approver-ship-to',
  templateUrl: './approver-ship-to.component.html',
  styleUrls: ['./approver-ship-to.component.css']
})
export class ApproverShipToComponent implements OnInit {
  @Input() count: string;
  @Input() reqDetails;
  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();
  public data: any;
  isCollapsed: boolean;

  constructor() { }

  ngOnInit() {
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }
  get shipmentCount() {
        return (this.reqDetails[0].customers).length 
    }

}