import { RouterModule } from '@angular/router';
import { MarketrolemanagerComponent } from './marketrolemanager/marketrolemanager.component';
import { AuthGuard } from '../util/auth.guard';
import { SuperuserComponent } from './superuser/superuser.component';
import { AdministrationComponent } from 'app/democomponents/administration/administration.component';

export const administrationRoutes = [
    { path: '', component: MarketrolemanagerComponent, canActivate: [AuthGuard] },
    { path: 'superUser', component: SuperuserComponent , canActivate: [AuthGuard] }
];

export const routing = RouterModule.forChild(administrationRoutes);