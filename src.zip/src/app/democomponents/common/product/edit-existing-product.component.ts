import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "../../../events/action-events";
import { Customer } from '../../../model/customer';
import { Product, Vendor } from '../../../model/product';
import { Comment} from '../../../model/comment';
import { Attachment } from '../../../model/attachment';
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";
import { CalendarComponent } from "app/democomponents/common/calendar/calendar.component";

@Component({
  selector: 'sods-edit-existing-product',
  templateUrl: './edit-existing-product.component.html',
  styleUrls: ['./edit-existing-product.component.css']
})
export class EditExistingProductComponent extends BaseComponent implements OnInit {

    counter = 1;
    calendar_counter = 1;
    changeMonthFlag = false;
    searchTypeOptions: string[];
    errMsg: string = "";
    selectedSearchType: string;
    readonly defaultSearchType: string = 'Product(USF)';
    div: string;
    public productNbr: string;
  
    public product: Product;
    public vendor: Vendor;
  
    public minDate: Date = new Date();
    public value: Date = new Date();
  
    //validation error handling
    public retrieveSuccess: boolean = false;
    public product_not_found_error: boolean = false;
    public duplicated_product_error: boolean = false;
    public sellPrice_number_error: boolean = false;
    public handling_number_error: boolean = false;
    public qty_require_error: boolean = false;
    public qty_number_error: boolean = false;
    public zero_number_error: boolean = false;
    public date_selection_error: boolean = false;
    public error_msg: string = '';

    @ViewChild('ProdTypeDropdown') prodTypeDropdown: DropdownComponent;
    @ViewChild('sodsCalendar') sodsCalendar: CalendarComponent;
  
    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
      let mapping: any = [];        
      mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(data); }
      mapping[ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_SUCCESS] = (product: Product) => { this.renderProductFound(product); }
      mapping[ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL] = (error: any) => { this.renderProductNotFound(error);}
      super.registerStateChangeEvents(mapping);
    }
  
    ngOnInit() {
      this.searchTypeOptions = ['Product(USF)', 'Manufacturer Product'];
      this.product = new Product();
      this.product.vendor = new Vendor();
      this.product.eta = this.value;
      this.product.new = false;
      this.product.comments = new Array<Comment>();
      this.selectedSearchType = this.defaultSearchType;
    }
  
    onSearchTypeSelection($event){
      this.selectedSearchType = $event;
    }
  
    retrieveProduct(){
      this.errMsg = "";
      this.duplicated_product_error = false;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_PRODUCT_EDIT, {searchType: this.selectedSearchType, div: this.div, prodNbr: this.productNbr});
    this.actionDispatcherService.dispatch(event);
    }
  
    renderCustFound(data: Customer){
      this.div = data.division;
    }
    
    renderProductFound(product: Product){
      if (Number(product.distSts) === 0) {
        this.errMsg = "Product is currently set to Normal status.";
      } else if (Number(product.distSts) === 2) {
        this.errMsg = "Product is currently set to Active, but Out of Stock status.";
      } else if (Number(product.distSts) === 3){
        this.errMsg = "Product is currently set to Temporary status.";
      } else if (Number(product.distSts) === 4) {
         this.errMsg = "Product is currently set to Seasonal status.";
      }  else if (Number(product.distSts) === 8) {
         this.errMsg = "Product is currently set to DWO status.";
      }  else if (Number(product.distSts) === 9) {
        this.errMsg = "Product is currently set to Discontinued status.";
      } else if(product.ntnlSts == 'I'){
        this.errMsg = 'Product is Inactive';
      } else if(product.ntnlSts !== 'A'){
        this.errMsg = "Product not attached at national level";
      } else if(product.prodAttchd == 'F'){
        this.errMsg = "Product is invalid";
      } else if(product.prodAttchd == 'I'){
        this.errMsg = "Not attached to division";
      } else {
      let seq = this.product.seq;
      this.product_not_found_error = false;
      this.product = product;
      this.product.seq = seq;
      this.product.new = false;
      this.product.comments = new Array<Comment>();
      this.product.attachments = new Array<Attachment>();
      this.product.eta = new Date();
      this.retrieveSuccess = true;
      this.product_not_found_error = false;
    }
    }
    renderProductNotFound(error: any){
      this.retrieveSuccess = false;
    this.product_not_found_error = true;
    this.error_msg = error;
    }
  
    onDateSelectionDone($event){
      this.product.eta = $event;
      this.date_selection_error = false;
    }
  
    onErrorHandler($event){
      this.date_selection_error = true;
      if($event !== 'error'){
        this.date_selection_error = false;
      }
    }
  
    checkSellPrice() {
      if(this.product.sellPrice === "" || this.product.sellPrice === null || this.product.sellPrice === undefined) {
          this.sellPrice_number_error = false;
          return;   
      }
      
      if(this.validateQuotePrice(this.product.sellPrice)) {
          this.sellPrice_number_error = false;            
          //checks for whole integers (ex. 32) and converts to 32.00
          if(this.product.sellPrice.indexOf('.') === -1 && !(this.product.sellPrice.charAt(0) === '.')){
            this.product.sellPrice = this.product.sellPrice.concat('.00');
          }
          //checks for .xx and converts to 0.xx
          if(this.product.sellPrice.charAt(0) === '.'){
            this.product.sellPrice = '0'.concat(this.product.sellPrice);
          }
      } else { 
          this.sellPrice_number_error = true;     
      } 
    }
  
    checkHandlingPrice(){
      if(this.product.handling === "" || this.product.handling === null || this.product.handling === undefined) {
        this.handling_number_error = false;
        return;   
    }
    
    if(this.validateQuotePrice(this.product.handling)) {
        this.handling_number_error = false;            
        //checks for whole integers (ex. 32) and converts to 32.00
        if(this.product.handling.indexOf('.') === -1 && !(this.product.handling.charAt(0) === '.')){
          this.product.handling = this.product.handling.concat('.00');
        }
        //checks for .xx and converts to 0.xx
        if(this.product.handling.charAt(0) === '.'){
          this.product.handling = '0'.concat(this.product.handling);
        }
      }else { 
          this.handling_number_error = true;     
      } 
    }
  
    validateQuotePrice(quote: string) : boolean {
      if(quote === null || quote === undefined || quote.trim() === ""){
        return true;
      }
      let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
      return QUOTE_REGEXP.test(quote);
    }
  
    checkNumberFormatforQty() {
      this.checkKeyupRequire_qty();
      if(this.validateNumber(this.product.qty)) {
        this.qty_number_error = false;
      } else { 
        this.qty_number_error = true; 
      }
      if(this.product.qty === '0'){
        this.zero_number_error = true;
      }else{
        this.zero_number_error = false;
      }
    }
  
    //Validate Number
    validateNumber(data: string){
      if(data === null || data === undefined || data.trim() === '') {
        this.qty_require_error = true;
        return true;
      }
      this.qty_require_error = false;
      let NUMBER_REGEXP = /^[0-9]{1,5}$/
      return NUMBER_REGEXP.test(data);
    }
  
    checkKeyupRequire_qty(){
      this.qty_require_error = 
      ((this.product.qty === null || this.product.qty === undefined || this.product.qty.trim() === "") ? true : false); 
    }
  

    controlClick(){
      if(this.changeMonthFlag){
        this.changeMonthFlag = false;
        return;
      }
      if(this.counter % 2 === 0 && this.prodTypeDropdown.isVisible){
        this.prodTypeDropdown.isVisible = false;
        this.counter ++;
      }else if(this.prodTypeDropdown.isVisible){
        this.counter ++;
      }else if(this.counter % 2 === 0 && !this.prodTypeDropdown.isVisible){
        this.counter ++;
      }
  
      if(this.sodsCalendar !== null && this.sodsCalendar !== undefined){
        if(this.calendar_counter  % 2 === 0 && this.sodsCalendar.child3.overlayVisible){
          this.sodsCalendar.child3.overlayVisible = false;
          this.calendar_counter  ++;
        }else if(this.sodsCalendar.child3.overlayVisible){
          this.calendar_counter  ++;
        }else if(this.calendar_counter  % 2 === 0 && !this.sodsCalendar.child3.overlayVisible){
          this.calendar_counter  ++;
        }
      }
    }
  
    changeMonth(){
      this.changeMonthFlag = true;
    }
}
