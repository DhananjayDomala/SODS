// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { BrowserModule } from '@angular/platform-browser';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { SharedModule } from './../../../shared/shared.module';
// import { AddNewProductComponent } from './add-new-product.component';
// import { SAMPLEProduct, SAMPLEVendor } from '../../../model/product';
// import { SAMPLECommentA} from '../../../model/comment';

// fdescribe('AddNewProductComponent', () => {
//   let component: AddNewProductComponent;
//   let fixture: ComponentFixture<AddNewProductComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [],
//       imports: [BrowserAnimationsModule, SharedModule]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AddNewProductComponent);
//     component = fixture.componentInstance;
//     component.actionDispatcherService.dispatch = () => {};
//     component.product = SAMPLEProduct;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should onProdTypeSelection', () => {
//     component.onProdTypeSelection('123');
//     expect(component.product.prodType).toBe('123');
//   });

//   it('should onDateSelectionDone', () => {
//     component.onDateSelectionDone('123');
//     expect(component.product.eta).toBe('123');
//   });

//   it('should onErrorHandler', () => {
//     component.onErrorHandler('error');
//     expect(component.date_selection_error).toBeTruthy();

//     component.onErrorHandler('errojkr');
//     expect(component.date_selection_error).toBeFalsy();
//   });

//   it('should checkSellPrice', () => {
//     component.product = SAMPLEProduct;
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);

//     component.product.sellPrice = '';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);

//     //validate quote
//     component.product.sellPrice = undefined;
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);


//     //validate quote
//     component.product.sellPrice = 'sdasdasd';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(true);

//     //validate quote
//     component.product.sellPrice = '1';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);
//     expect(component.product.sellPrice).toBe('1.00');

//     //validate quote
//     component.product.sellPrice = '.1';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);
//     expect(component.product.sellPrice).toBe('0.1');

//     // Validate null value
//     expect(component.validateQuotePrice(null)).toBe(true);

//   });

//   it('should checkNumberFormatforQty', () => {
//     component.product = SAMPLEProduct;
//     component.checkNumberFormatforQty();
//     expect(component.qty_require_error).toBe(true);
//     expect(component.qty_number_error).toBe(false);
    
//     //empty value
//     component.product.qty = 'asdasd';
//     component.checkNumberFormatforQty();
//     expect(component.qty_number_error).toBe(true);

//     //validate number
//     component.product.qty = '0';
//     component.checkNumberFormatforQty();
//     expect(component.zero_number_error).toBe(true);

//     //empty value
//     component.product.qty = ' ';
//     component.checkNumberFormatforQty();
//     expect(component.qty_require_error).toBe(true);
//   });

//   it('should checkProdDescRequire', () => {
//     component.product.description = 'fghffhg';
//     component.checkProdDescRequire();
//     expect(component.product_desc_require_error).toBeFalsy();

//     //Prod Desc 

//     //true case:
//     component.product.description = '';
//     component.checkProdDescRequire();
//     expect(component.product_desc_require_error).toBeTruthy();

//     //false case
//     component.product.description = 'Sample';
//     component.checkProdDescRequire();
//     expect(component.product_desc_require_error).toBeFalsy();

//     //required mfrid : true Case
//     component.product.mfrId = '';
//     component.checkKeyupRequire_mfrProd();
//     expect(component.mfr_product_require_error).toBeTruthy();

//     //required mfrid : false Case
//     component.product.mfrId = 'Sample';
//     component.checkKeyupRequire_mfrProd();
//     expect(component.mfr_product_require_error).toBeFalsy();


//   });

//   it('should addComment', () => {
//     component.comment =  SAMPLECommentA;
//     component.addComment();
//   });

//   it('should attachfile', () => {
//     localStorage.setItem('token', JSON.stringify({value: ''}));
//     component.inputEl.nativeElement = {files: {item: (index:any) => { return {name: '', type: ''}; }, length: 10}};
//     component.attachfile();
//   });

//   it('should getAttachmentDetails', () => {
//     component.getAttachmentDetails('12', '234');
//   });

//   it('should renderAttachmentDetails', () => {
//     component.renderAttachmentDetails([{fileName: ''}]);
//   });

//   it('should deleteAttachments', () => {
//     component.deleteAttachments('12', '234');
//     expect(component.actionCompleted).toBe(false);
//   });

//   it('should renderAttachmentDeleted', () => {
//     component.renderAttachmentDeleted();
//     expect(component.actionCompleted).toBe(true);
//   });

//   it('should renderError', () => {
//     component.renderError({statusText: 'error'});
//     expect(component.actionCompleted).toBe(true);
//     expect(component.errorMsg).toBe('error');
//   });

// });
