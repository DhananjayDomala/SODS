import { any } from 'codelyzer/util/function';
import {Component, OnInit, ViewChild, ViewEncapsulation, Input, AfterContentChecked} from '@angular/core'; 
import {BaseComponent} from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "../../../events/action-events";
import { Customer } from '../../../model/customer';
import { Modal, ModalModule } from 'ngx-modal';
import { AddShipToLocationComponent } from './add-shipToLocation.component';
import { EditShipToLocationComponent } from './edit-shipToLocation.component';

@Component({
    selector: 'so-shipToLocation',
    templateUrl: './shipToLocation.component.html',
    styleUrls: ['./shipToLocation.component.css'],
})

export class ShipToLocationComponent  extends BaseComponent implements OnInit, AfterContentChecked {

	//Attach Add Ship To Location Modal
    @ViewChild('AddShipToLocation')addShipToLocationModal: Modal;
    @ViewChild('EditShipToLocation')editShipToLocationModal: Modal;

    @ViewChild('removeLocation') removeLocationModal: Modal;

    @ViewChild('addShipToLocationComponent') addShipToLocationComponent: AddShipToLocationComponent;
    @ViewChild('editShipToLocationComponent') editShipToLocationComponent: EditShipToLocationComponent;


    public data: any = [];
    public selectedMarket: any;
    marketingOptions: any;
    delItem: any;
    editItem: any;
    isCollapsed: any = true;
    selectedReqType: any;
    hasDuplicate: any = false;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }

    ngOnInit(){
       let mapping: any = [];       
        mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(data); }
        mapping[ModelChangeUpdateEvents.CUST_NOT_FOUND] = (error: any) => { this.renderCustNotFound(); }
        mapping[ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_SUCCESS] = (data: Customer) => { this.renderCustFound(data); }
        mapping[ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_FAIL] = (error: any) => { this.renderCustNotFound(); }
        mapping[ModelChangeUpdateEvents.DEPARTMENT_CHANGE_SUCCESS] = (deptId: string) => { this.renderDeptChangeSuccess(deptId); }
         mapping[ModelChangeUpdateEvents.SHIPMENT_CHANGE_SUCCESS] = (data: {'shipMethod': string, 'customerPO': string, 'specialInstruct': string}) => { this.renderShipmentChangeSuccess(data); }
        super.registerStateChangeEvents(mapping);
    }

    ngAfterContentChecked() {        
    }

    renderCustFound(cust: Customer) {
        if (cust.confidenceCode === "01") {
            return false;
        }
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);

        this[this.getTypeOfAction()].error = false;    
        if (!this.addShipToLocationModal.isOpened && !this.editShipToLocationModal.isOpened) {
                if (this.data && this.data.length > 1) {
                    this.data[0] = this.getShipmentObject(cust, 1);
                } else {
                    this.data = [];
                    this.data.push(
                        this.getShipmentObject(cust, 1)             
                    );
                }
                
                //TODO: send an action dispacter to notify product component
                let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPTO_CHANGE, this.data);
                this.actionDispatcherService.dispatch(event);
        } else {

            const typeOfAction = this.getTypeOfAction();
            this[typeOfAction].id = cust.id;
            this[typeOfAction].dept = cust.dept;
            this[typeOfAction].name = cust.name;
            this[typeOfAction].address = this.formatAddress(cust.address1, cust.address2);
            this[typeOfAction].postalInfo = this.formatLocation(cust.city, cust.state, cust.zip);
            this[typeOfAction].city = cust.city;
            this[typeOfAction].state = cust.state;
            this[typeOfAction].zip = cust.zip;
            this[typeOfAction].phone = this.formatPhone(cust.phone);
            this[typeOfAction].estimatedOrderAmt = cust.estimatedOrderAmt;
            this[typeOfAction].confidenceCode = cust.confidenceCode;
            this[typeOfAction].deptOptions = cust.deptOptions;
            this[typeOfAction].defaultDept = cust.deptOptions[0];
            this[typeOfAction].selectedDept = cust.deptOptions[0];
            this[typeOfAction].defaultShip = "Next";
            this[typeOfAction].selectedShip = "Next";
            this[typeOfAction].division = cust.division;
            this[typeOfAction].dataloaded = true;
            this[typeOfAction].dataChanged = this.addShipToLocationModal.isOpened || this.editShipToLocationModal.isOpened;
            this[typeOfAction].address1 = cust.address1;
            this[typeOfAction].address2 = cust.address2;
            this[this.getTypeOfAction()].customerPo = '';
            this[this.getTypeOfAction()].specialInstruct = '';
            this[this.getTypeOfAction()].creditCheckStatus = cust.creditCheckStatus;
            
            
            if (this.editItem) {
                this.editItem.deptOptions = cust.deptOptions;
            }
        
            // this[this.getTypeOfAction()].divisionObj = this.marketOptions.find(({divisionNumber}) => { return divisionNumber == cust.division; })
            // this[this.getTypeOfAction()].errorHandle(false);
            // this[this.getTypeOfAction()].customerType = cust.custType;
        }
    }

    renderDeptChangeSuccess(deptId: string){
        if(this.data !== null && this.data.length > 0){
            this.data[0].department = deptId;
        }
        let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPTO_CHANGE, this.data);
        this.actionDispatcherService.dispatch(event);
    }

    hasDuplicateValues() {
        if (!this.data){
            return false;
        }
        const a = this.data.map((item) => {
            return item.department;
        });
        const uniqueArray = a.filter(function(item, pos) {
            return a.indexOf(item) == pos;
        });
        return !(this.data.length === uniqueArray.length);  
    }
    renderShipmentChangeSuccess(data: {'shipMethod': string, 'customerPO': string, 'specialInstruct': string}){
        //fix by O8N6026
        if(this.data !== null && this.data.length > 0){
            this.data[0].ship_method = data.shipMethod;
            this.data[0].customerPo = data.customerPO;
            this.data[0].specialInstruct = data.specialInstruct;
        }
        let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPTO_CHANGE, this.data);
        this.actionDispatcherService.dispatch(event);
    }

    getShipmentObject(cust:any, index?: any) {
        return {
                    customerNo: index || (this.data || {}).length + 1,
                    customer: cust.id,
                    department: cust.selectedDept || cust.deptOptions && cust.deptOptions[0] || '00-NODEPT',
                    customerName: cust.name,
                    ship_to_location: cust.address || this.formatAddress(cust.address1, cust.address2),
                    postalInfo: cust.postalInfo || this.formatLocation(cust.city, cust.state, cust.zip),
                    ship_method: cust.selectedShip || 'Next',
                    customerPo: cust.customerPo || '',
                    specialInstruct: cust.specialInstruct || '',
                    phone: cust.phone || '',
                    deptOptions: cust.deptOptions && cust.deptOptions.length !== 0 ? cust.deptOptions : ['00-NODEPT'],
                    address1:  cust.address1,
                    address2: cust.address2,
                    city: cust.city,
                    state: cust.state,
                    zip: cust.zip,
                    estimatedOrderAmt: cust.estimatedOrderAmt || '',
                    confidenceCode: cust.confidenceCode || '',
                    creditCheckStatus: cust.creditCheckStatus
                } 
    }

    getTypeOfAction() {
        return (this.addShipToLocationModal.isOpened) ? 'addShipToLocationComponent' : 'editShipToLocationComponent';
    }

    get shipmentCount() {
        return (this.data || []).length
    }

    formatLocation(cty: string, ste: string, zip: string): string { return (cty + ", " + ste + " " + zip); }

    formatPhone(phoneNbr: string): string {
        return ('(' + phoneNbr.substring(0, 3) + ')-' + phoneNbr.substring(3,6) + '-' + phoneNbr.substring(6));
    }

    formatAddress(addr1: string, addr2: string): string {
        if(addr2 == '' || addr2 == "" || addr2 == undefined) { 
            return addr1; 
        } else { 
            return (addr1 + '\n' + addr2); 
        }
    }

    renderCustNotFound() {
        this[this.getTypeOfAction()].error = true;    
    }

    openAddModal() {
        this.addShipToLocationModal.open();
        
    }

    onOpenAddModal() {
        if (this.editItem) {
            this[this.getTypeOfAction()].id = this.editItem.customer;
            this[this.getTypeOfAction()].defaultDept = this.editItem.department;
            this[this.getTypeOfAction()].defaultShip = this.editItem.ship_method;
            this[this.getTypeOfAction()].selectedDept = this.editItem.department;
            this[this.getTypeOfAction()].selectedShip = this.editItem.ship_method;
            this[this.getTypeOfAction()].customerPo = this.editItem.customerPo;
            this[this.getTypeOfAction()].specialInstruct = this.editItem.specialInstruct;
            this[this.getTypeOfAction()].dataloaded = true;
            this[this.getTypeOfAction()].address = this.editItem.ship_to_location;
            this[this.getTypeOfAction()].name = this.editItem.customerName;
            this[this.getTypeOfAction()].postalInfo = this.editItem.postalInfo;
            this[this.getTypeOfAction()].phone = this.editItem.phone;
            this[this.getTypeOfAction()].dataChanged = false;
            this[this.getTypeOfAction()].deptOptions = this.editItem.deptOptions; 
            this[this.getTypeOfAction()].city = this.editItem.city;
            this[this.getTypeOfAction()].state = this.editItem.state;
            this[this.getTypeOfAction()].zip = this.editItem.zip;
            this[this.getTypeOfAction()].estimatedOrderAmt = this.editItem.estimatedOrderAmt;
            this[this.getTypeOfAction()].confidenceCode = this.editItem.confidenceCode;
            this[this.getTypeOfAction()].creditCheckStatus = this.editItem.creditCheckStatus;

            this['editShipToLocationComponent'].customerNo = this.editItem.customerNo;
        }
    }

    resetAddModal() {
        if (this['addShipToLocationComponent']) {
            this['addShipToLocationComponent'].resetValues();
        }
        if (this['editShipToLocationComponent']) {
            this['editShipToLocationComponent'].resetValues();
        }

        
        
    }

    editShip(item: any) {
        this.editItem = Object.assign({}, item);
        this.editShipToLocationModal.open();
    }

    removeShip(item:any) {
        this.delItem = item;
       this.removeLocationModal.open();     
    }

    remove() {
        this.data.forEach((ship, index) => {
            if (this.delItem && ship.customerNo === this.delItem.customerNo) {
                this.data.splice(index, 1);
                this.data = this.data.map((item, index) => {
                      item.customerNo = index + 1;
                      return item;  
                });
                this.delItem = null;
                this.removeLocationModal.close();  
            }    
        });
        //TODO: send an action dispacter to notify product component
        let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPTO_CHANGE, this.data);
        this.actionDispatcherService.dispatch(event);
    }
    closeRemove() {
        this.removeLocationModal.close();
    }

    closeAddModal() {
        this.editItem = null;
        if (this.addShipToLocationModal.isOpened) {
            this.addShipToLocationModal.close();
        } else if (this.editShipToLocationModal.isOpened) {
            this.editShipToLocationModal.close();
        }
    	
    }

    onAdd() {
        if (this.editItem) {
            if (!this.dataHasDuplicateValue(this[this.getTypeOfAction()])) {
                this.data = this.data.map((item) => {
                    if(item.customerNo === this.editItem.customerNo) {
                        item.customer = this[this.getTypeOfAction()].id;
                        item.department = this[this.getTypeOfAction()].selectedDept;
                        item.ship_method = this[this.getTypeOfAction()].selectedShip;
                        item.customerPo = this[this.getTypeOfAction()].customerPo;
                        item.specialInstruct = this[this.getTypeOfAction()].specialInstruct;
                        item.customerName = this[this.getTypeOfAction()].name;
                        item.ship_to_location = this[this.getTypeOfAction()].address;
                        item.postalInfo = this[this.getTypeOfAction()].postalInfo;
                        item.state = this[this.getTypeOfAction()].state;
                        item.city = this[this.getTypeOfAction()].city;
                        item.zip = this[this.getTypeOfAction()].zip;
                        item.deptOptions = this[this.getTypeOfAction()].deptOptions;
                        item.address1 = this[this.getTypeOfAction()].address1;
                        item.address2 = this[this.getTypeOfAction()].address2;
                        item.estimatedOrderAmt = this[this.getTypeOfAction()].estimatedOrderAmt;
                        item.confidenceCode = this[this.getTypeOfAction()].confidenceCode;
                        item.creditCheckStatus = this[this.getTypeOfAction()].creditCheckStatus;
                    }
                    return item;
                });
                //TODO: send an action dispacter to notify product component
                let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPTO_CHANGE, this.data);
                this.actionDispatcherService.dispatch(event);
                this.editItem = null;
                this.editShipToLocationModal.close();
                this[this.getTypeOfAction()].dataloaded = false;
            }
            
        } else{
            if (!this.dataHasDuplicateValue(this.getShipmentObject(this[this.getTypeOfAction()]))) {
                this.data.push(this.getShipmentObject(this[this.getTypeOfAction()]));
                //TODO: send an action dispacter event to notify product component
                //print out the new ship to id
                let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPTO_CHANGE, this.data);
                this.actionDispatcherService.dispatch(event);
                this.editItem = null;
                this.addShipToLocationModal.close();
                this[this.getTypeOfAction()].dataloaded = false;
            }
            
        }
        
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);
    }

    dataHasDuplicateValue(item) {
        const itemsExist = this.data.filter((ship) => {
            return ship.department === item.selectedDept && ship.customerNo === item.customerNo;
        })
      const isAlreadyExist = this.data.find((ship) => {
          return (
              (ship.department === (item.department || item.selectedDept) &&
               ship.customer === (item.customer || item.id)) && 
               (!this.editItem || (this.editItem && 
                (ship.ship_method === (item.ship_method || item.selectedShip)
                 || itemsExist.length === 0))
          ))
      });
        this[this.getTypeOfAction()].duplicate = (isAlreadyExist) ? true: false
        return this[this.getTypeOfAction()].duplicate;
    }

    isDisabled() {
        return !(this[this.getTypeOfAction()] && this[this.getTypeOfAction()].dataChanged && !this[this.getTypeOfAction()].invalidId && (!this.editItem || this.editItem && !this.editShipToLocationComponent.idChanged))
    }
} 