import { Component, OnInit, Input, Output, OnChanges, SimpleChanges, EventEmitter, HostBinding,  HostListener, ElementRef } from '@angular/core';

@Component({
  selector: 'sods-market-dropdown',
  templateUrl: './market-dropdown.component.html',
  styleUrls: ['./market-dropdown.component.css']
})
export class MarketDropdownComponent implements OnInit, OnChanges  {

  isVisible: boolean = false;
  public selectedOptionObj: Object;
  @Input() selectedOption: string;
  @Input() options: any[];
  @Output() selectionDone = new EventEmitter();

  constructor(private el: ElementRef) { }

  ngOnInit() {
    if (this.options) {
        this.selectedOptionObj = this.options.find(({divisionNumber}) => { return divisionNumber == this.selectedOption; })
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
  }

  @HostListener('document:click', ['$event'])
    handleClick(ev: Event) {
        if (ev && !this.el.nativeElement.contains(ev.target)) {
            this.isVisible = false;
        }
    }

  @HostListener('window:keyup', ['$event']) 
    handleKeyup(event) {
        if (event.code === 'Tab') {
            this.isVisible = false;
        }
    } 

  toggleDropDown(){
      this.isVisible = !this.isVisible;
  }

  select(option: any){;
      this.isVisible = !this.isVisible;
      this.selectedOptionObj = option;
      this.selectedOption = option.divisionNumber;  
      this.selectionDone.emit(this.selectedOption);
  }

}
