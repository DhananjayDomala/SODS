import { Component, OnInit, OnChanges, SimpleChanges, Input, Output, EventEmitter, HostBinding, ViewEncapsulation, ViewChild } from '@angular/core';
import {AutoCompleteModule} from 'primeng/primeng';

@Component({
  selector: 'sods-autocomplete',
  templateUrl: './autoComplete.component.html',
  styleUrls: ['./autoComplete.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AutoCompleteComponent implements OnInit, OnChanges {

  isVisible: boolean = false;
  @Input() value: string;
  @Input() width: string;
  @Input() data: any[];
  @Input() error: boolean;
  @Output() searchEvent = new EventEmitter();
  @Output() searchData = new EventEmitter();
  @Output() errorEmitter = new EventEmitter();
  results: any[] = [];
  style = {
    width: ''
  };
  constructor() { }

  ngOnInit() {
    this.style.width = '' + this.width + 'px';
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.data) {
      this.data = changes.data.currentValue;
      if (this.searchEvent) {
        this.results = this.data;
      }
    }
  }

  search(event) {
      if (this.searchEvent) {
        this.searchEvent.emit(event.query);
      } else {
        this.results = [];
          for(let i = 0; i < this.data.length; i++) {
              let brand = this.data[i];
              if(brand.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
                  this.results.push(brand);
              }
          }
            //this.searchData.emit(event.query);
      }
        
    }
  
  selectItem(event) {
    this.searchData.emit(this.value);
  }  

}
