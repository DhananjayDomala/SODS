import { Component, OnInit, ViewChild, Output, Input } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { BaseComponent } from '../../base-component';
import { EditCustomerComponent } from './edit-customer.component'
import { DropdownComponent } from '../dropdown/dropdown.component'

@Component({
    selector: 'sods-customer-details',
    templateUrl: './customer-details.component.html',
    styleUrls: ['./customer-details.component.css']
})

export class CustomerDetailsComponent extends BaseComponent implements OnInit {
    @ViewChild('shipMethodDP') shipMethodDP: DropdownComponent;

    public selectedReqType: string;
    public selectedDept: string;
    public defaultDept: string;

    readonly defaultShip: string = 'Next';
    public selectedShip: string;
    private shipOptions: string[] = ['Next', 'Separate'];
    reqStatus = '';

    readonly defaultETA: string = 'Select Date';
    public value: Date = new Date();
    public minDate: Date = new Date();
    public maxDate: Date;
    public selectedETA: string = 'Select Date';
    public notMet: boolean = false;
    private etaOptions: string[] =
    ['Select Date', 'ASAP 3 Week Max', 'ASAP 4 Week Max', 'ASAP No Maximum', 'Custom Date'];

    public selectVisable = true;
    public calenderHidden = true;
    public shipElementsHidden = true;
    

    //validation
    public quoteValid = true;
    public quoteNumValid = true;
    public dateValid = true;
    public date_selection_error: boolean = false;

    // seq: string;
    maxIncidentDescriptionLength: any = 1000;
    id: string;
    division: string;
    dept: string;
    name: string;
    defaultShipMethod: string;
    address: string;
    postalInfo: string;
    phone: string;
    quotePrice: string;
    quoteNbr: string;
    comments: string;
    specialInstruct: string;
    customerPO: string;
    estimatedOrderAmt: string;
    confidenceCode: string;
    creditCheckStatus: string;
    marketOptions: any = [];
    deptOptions: any = [];
    divisionObj: Object;
    date: string;
    //Add customer type here
    customerType: string;

    //add this field for checking selectedMarket
    originMarket: string;

    @ViewChild('CustomerModal')
    updateModal: Modal;

    @ViewChild('overrideModal')
    overRideModal: Modal;

    @ViewChild('CustomerUpdate')
    editCustomer: EditCustomerComponent;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }

    ngOnInit() {
        try {
            this.populateMarketDropdown();
            this.selectedShip = this.defaultShip;
            this.selectedETA = this.defaultETA;
            this.editCustomer.error = true;
            this.minDate = new Date();
        } catch (err) {

        }

    }

    onDeptSelection($event) {
        this.selectedDept = $event;
        try {
            let event = this.actionDispatcherService.generateEvent(ActionEvents.DEPARTMENT_CHANGE, this.selectedDept);
            this.actionDispatcherService.dispatch(event);

            let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
            this.actionDispatcherService.dispatch(changeEvent);
        } catch (e) { }

    }

    onShipmentSelection($event) {
        this.selectedShip = $event;
        this.selectedShip = (Array.isArray($event)) ? 'Next' : $event;

        if (this.selectedShip === 'Next') {
            this.shipElementsHidden = true;
        } else {
            this.shipElementsHidden = false;
        }
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
        this.actionDispatcherService.dispatch(changeEvent);

        let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPMENT_CHANGE, { 'shipMethod': this.selectedShip, 'customerPO': this.customerPO, 'specialInstruct': this.specialInstruct });
        this.actionDispatcherService.dispatch(event);
    }

    changeShipmentMethod() {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.SHIPMENT_CHANGE, { 'shipMethod': this.selectedShip, 'customerPO': this.customerPO, 'specialInstruct': this.specialInstruct });
        this.actionDispatcherService.dispatch(event);

    }

    onETASelection($event) {
        this.selectedETA = $event;
        this.date_selection_error = false;

        if (this.selectedETA === 'Select Date' || this.selectedETA === 'ASAP No Maximum') {
            this.value = null;
        } else if (this.selectedETA !== 'Custom Date') {
            this.value = new Date();
        }

        const no_of_days_added = (this.selectedETA === 'ASAP 3 Week Max') ? 3 * 7 : (this.selectedETA === 'ASAP 4 Week Max') ? 4 * 7 : 0
        if (no_of_days_added && this.value) {
            this.value.setDate(this.value.getDate() + no_of_days_added)
        }

        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
        this.actionDispatcherService.dispatch(changeEvent);

        let event = this.actionDispatcherService.generateEvent(ActionEvents.CALENDAR_CHANGE, this.value);
        this.actionDispatcherService.dispatch(event);


    }

    onDateSelectionDone($event) {
        this.value = $event;
        this.selectedETA = 'Custom Date';
        this.date_selection_error = false;
        let event = this.actionDispatcherService.generateEvent(ActionEvents.CALENDAR_CHANGE, $event);
        this.actionDispatcherService.dispatch(event);

        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
        this.actionDispatcherService.dispatch(changeEvent);
    }

    customerCheckbox(e) {
        this.notMet = e.target.checked
    }

    onErrorHandler($event) {
        this.date_selection_error = true;
        if ($event !== 'error') {
            this.date_selection_error = false;
            this.selectedETA = 'Custom Date';
            let event = this.actionDispatcherService.generateEvent(ActionEvents.CALENDAR_CHANGE, $event);
            this.actionDispatcherService.dispatch(event);
        }
    }

    checkQuote() {
        if (this.quotePrice === "") {
            this.quoteValid = true;
            return;
        }

        if (this.validateQuotePrice(this.quotePrice)) {
            this.quoteValid = true;
            //checks for whole integers (ex. 32) and converts to 32.00
            if (this.quotePrice.indexOf('.') === -1 && !(this.quotePrice.charAt(0) === '.')){
                this.quotePrice = this.quotePrice.concat('.00');
            }
            //checks for .xx and converts to 0.xx
            if (this.quotePrice.charAt(0) === '.'){
                this.quotePrice = '0'.concat(this.quotePrice);
            }
        } else {
            this.quoteValid = false;
        }
    }


    checkQuoteNum() {
        if (this.quoteNbr === "") {
            this.quoteNumValid = false;
            return;
        } else {
            this.quoteNumValid = true;
        }

    }

    checkDate() {
        if (this.validateETA(this.date)) {
            this.dateValid = true;
        } else {
            this.dateValid = false;
        }
    }

    validateQuotePrice(quote: string): boolean {
        if (quote === null || quote === undefined || quote.trim() === ""){
            return true;
        }
        let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
        return QUOTE_REGEXP.test(quote);
    }

    validateETA(date: string): boolean {
        if (date === null || date === undefined || date.trim() === ""){
            return true;
        }
        let DATE_REGEXP =
            /^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d$/
        return DATE_REGEXP.test(date);
    }

    open() { this.updateModal.open(); }

    close() { this.updateModal.close(); }

    cancel() {
        this.updateModal.close();
        this.editCustomer.error = false;
        this.editCustomer.id = "";
    }

    update() {
        let changeEvent = this.actionDispatcherService.generateEvent(ActionEvents.REQ_CHANGE_EVT, '');
        this.actionDispatcherService.dispatch(changeEvent);
        if (this.originMarket != this.editCustomer.selectedMarket) {
            //refresh the page
            window.location.reload();
        } else {
            this.editCustomer.error = false;
            let event = this.actionDispatcherService.generateEvent('retrieveCustomer', {
                id: this.editCustomer.id.trim(), division: this.editCustomer.selectedMarket
            });
            this.actionDispatcherService.dispatch(event);
        }

    }

    //Populates user designated markets in drop-down
    private populateMarketDropdown() {
        let array = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).applicationMarkets;
        let marketOptions = [];

        array.forEach(element => {
            let dropdownValue = {}
            dropdownValue['distributionName'] = element.marketName;
            dropdownValue['divisionCode'] = element.marketCode;
            dropdownValue['divisionNumber'] = element.marketNum;
            marketOptions.push(dropdownValue);
        });
        this.editCustomer.marketOptions = marketOptions;
        this.editCustomer.selectedMarket = marketOptions[0];
        console.log('--', marketOptions);
    }

    errorHandle(status: Boolean) {
        if (status) {
            this.editCustomer.error = true;
        } else {
            this.editCustomer.error = false;
            this.updateModal.close();
        }
    }

    checkComment() {
        this.comments = this.comments.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    }

    closeOverride() {
        this.overRideModal.close();
    }

    openOverridePopup() {
        this.overRideModal.open();
    }




}