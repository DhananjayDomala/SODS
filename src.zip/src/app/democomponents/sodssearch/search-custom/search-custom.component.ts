import { Component, OnInit, ViewChild } from '@angular/core';
import { SearchResultComponent } from 'app/democomponents/sodssearch/search-share/search-result/search-result.component';
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam/dist/usf-sam";
import { ModelChangeUpdateEvents, ActionEvents } from "app/events/action-events";
import { BaseComponent } from 'app/democomponents/base-component';

@Component({
  selector: 'app-search-custom',
  templateUrl: './search-custom.component.html',
  styleUrls: ['./search-custom.component.css']
})

export class SearchCustomComponent extends BaseComponent implements OnInit {
  @ViewChild('searchResult') searchResultComponent: SearchResultComponent;

  constructor(readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService);
  }

  ngOnInit() {
  }

  changePageOption(event){
    this.searchResultComponent.config.itemsPerPage = parseInt(event);
  }

  changeSortByOption(event){
    this.searchResultComponent.sort(event);
  }

  changeAscendingOption(event){
    this.searchResultComponent.isAscending = event.isAscending;
    this.searchResultComponent.sort(event.selectedSortOption);
  }

  searchRequisition($event) {
    const requestBody = $event.body;
    this.loadingResult();

    // emit search event
    const searchRequisitions = this.actionDispatcherService.generateEvent(ActionEvents.SEARCH_REQUISITION, requestBody);
    this.actionDispatcherService.dispatch(searchRequisitions);
  }

  loadingResult(){
    this.searchResultComponent.loading = true;
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }

}
