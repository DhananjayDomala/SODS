import { Component, OnInit, Input } from '@angular/core';
import { BaseComponent } from "app/democomponents/base-component";
import { SearchRequisitions, SearchProduct } from "app/model/searchRequisition";
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam/dist/usf-sam";
import { ModelChangeUpdateEvents } from "app/events/action-events";

@Component({
  selector: 'app-search-result-product-so',
  templateUrl: './search-result-product-so.component.html',
  styleUrls: ['./search-result-product-so.component.css']
})
export class SearchResultProductSoComponent extends BaseComponent implements OnInit {

  @Input() products: Array<SearchProduct>;

  public searchRequisitions: SearchRequisitions;
  
    constructor(readonly actionDispatcherService: ActionDispatcherService,
      readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService); 
        const mapping: any = [];
        super.registerStateChangeEvents(mapping);
      }

  ngOnInit() {
  }

}
