import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchResultProductSoComponent } from './search-result-product-so.component';

describe('SearchResultProductSoComponent', () => {
  let component: SearchResultProductSoComponent;
  let fixture: ComponentFixture<SearchResultProductSoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchResultProductSoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchResultProductSoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
