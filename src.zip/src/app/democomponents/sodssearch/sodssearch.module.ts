import { HeaderComponent } from '../header/header.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from  '../../shared/shared.module';
import { RouterModule } from '@angular/router';

import { routing } from './sodssearch.routes';
import { SearchMyOpenRequestComponent } from './search-my-open-request/search-my-open-request.component';
import { SearchOlderRequestComponent } from './search-older-request/search-older-request.component';
import { SearchCustomComponent } from './search-custom/search-custom.component';
import { SearchNavComponent } from "app/democomponents/sodssearch/search-share/search-nav/search-nav.component";
import { SearchDesignateComponent } from "app/democomponents/sodssearch/search-share/search-designate/search-designate.component";
import { SearchResultComponent } from "app/democomponents/sodssearch/search-share/search-result/search-result.component";
import { SearchResultProductSoComponent } from './search-share/search-result/search-result-product/search-result-product-so/search-result-product-so.component';
import { OrderrByPipe } from "app/democomponents/util/orderby.pipe";
import { NgxPaginationModule } from "ngx-pagination/dist/ngx-pagination";
import { SearchCustomFilterComponent } from './search-share/search-custom-filter/search-custom-filter.component';
import { SearchReqDetailsComponent } from './search-req-details/search-req-details.component';
import { ReqDetailsComponent } from './search-req-details/req-details/req-details.component';
import { ProductsComponent } from './search-req-details/products/products.component';
import { AttachmentsComponent } from './search-req-details/attachments/attachments.component';
import { ShipToLocationsComponent } from './search-req-details/ship-to-locations/ship-to-locations.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    NgxPaginationModule,
    routing
  ],
  declarations: [
    SearchMyOpenRequestComponent,
    SearchOlderRequestComponent,
    SearchCustomComponent,
    SearchNavComponent,
    SearchDesignateComponent,
    SearchResultComponent,
    SearchResultProductSoComponent,
    SearchCustomFilterComponent,
    SearchReqDetailsComponent,
    ReqDetailsComponent,
    ProductsComponent,
    AttachmentsComponent,
    ShipToLocationsComponent
  ]
})
export class SodssearchModule { }
