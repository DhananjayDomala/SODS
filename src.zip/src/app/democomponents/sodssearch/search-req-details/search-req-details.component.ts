import { BREADCRUMBS } from 'app/democomponents/common/breadcrumb/breadcrumbs';
import { StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from 'app/democomponents/base-component';
import { SearchResultComponent } from "app/democomponents/sodssearch/search-share/search-result/search-result.component";
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-search-req-details',
  templateUrl: './search-req-details.component.html',
  styleUrls: ['./search-req-details.component.css']
})
export class SearchReqDetailsComponent extends BaseComponent implements OnInit {

  public breadcrumbs = {};
  constructor(readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
   }
  

  ngOnInit() {
    this.breadcrumbs = BREADCRUMBS["specialOrder"];
    console.log('inside details componentcf');
  }

}
