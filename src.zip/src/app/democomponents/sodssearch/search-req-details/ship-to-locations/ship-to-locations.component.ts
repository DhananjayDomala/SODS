import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ship-to-locations',
  templateUrl: './ship-to-locations.component.html',
  styleUrls: ['./ship-to-locations.component.css']
})
export class ShipToLocationsComponent implements OnInit {
  @Input() shipToLocations: any;

  public data: any = [];
  isCollapsed: any = true;
  

  constructor() { }

  ngOnInit() {
    this.data = this.shipToLocations;
  }

}
