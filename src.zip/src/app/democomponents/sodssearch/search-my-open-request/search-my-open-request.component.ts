import { Component, OnInit, ViewChild } from '@angular/core';
import { SearchResultComponent } from "app/democomponents/sodssearch/search-share/search-result/search-result.component";

@Component({
  selector: 'app-search-my-open-request',
  templateUrl: './search-my-open-request.component.html',
  styleUrls: ['./search-my-open-request.component.css']
})
export class SearchMyOpenRequestComponent implements OnInit {

  public requestOption: string = 'open';

  @ViewChild('searchResult') searchResultComponent: SearchResultComponent;

  constructor() { }

  ngOnInit() {
    console.log('Open Requests');
    this.searchResultComponent.searchType = 'Open Requests';
  }

  changePageOption(event){
    if(event === 'All'){
      this.searchResultComponent.config.itemsPerPage = this.searchResultComponent.searchRequisitions.length;
    }else{
      this.searchResultComponent.config.itemsPerPage = parseInt(event);
    }
  }

  changeSortByOption(event){
    this.searchResultComponent.sort(event);
  }

  changeAscendingOption(event){
    this.searchResultComponent.isAscending = event.isAscending;
    this.searchResultComponent.sort(event.selectedSortOption);
  }

  loadingResult(){
    this.searchResultComponent.loading = true;
  }
}
