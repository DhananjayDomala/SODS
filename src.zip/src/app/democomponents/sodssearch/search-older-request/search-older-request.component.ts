import { Component, OnInit, ViewChild } from '@angular/core';
import { SearchResultComponent } from "app/democomponents/sodssearch/search-share/search-result/search-result.component";

@Component({
  selector: 'app-search-older-request',
  templateUrl: './search-older-request.component.html',
  styleUrls: ['./search-older-request.component.css']
})
export class SearchOlderRequestComponent implements OnInit {

  public requestOption: string = 'old';

  @ViewChild('searchResult') searchResultComponent: SearchResultComponent;

  constructor() { }

  ngOnInit() {
    this.searchResultComponent.searchType = 'Open 30';
  }

  changePageOption(event){
    if(event === 'All'){
      this.searchResultComponent.config.itemsPerPage = this.searchResultComponent.searchRequisitions.length;
    }
    this.searchResultComponent.config.itemsPerPage = parseInt(event);
  }

  changeSortByOption(event){
    this.searchResultComponent.sort(event);
  }

  changeAscendingOption(event){
    this.searchResultComponent.isAscending = event.isAscending;
    this.searchResultComponent.sort(event.selectedSortOption);
  }

  loadingResult(){
    this.searchResultComponent.loading = true;
  }

}
