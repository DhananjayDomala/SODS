import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { RouterModule } from '@angular/router';
import { MarketrolemanagerComponent } from './marketrolemanager.component';

import { routing } from './marketrolemanager.routes';
import { MarketRoleSearchComponent } from './market-role-search/market-role-search.component';
import { ApproversByRoleComponent } from './approvers-by-role/approvers-by-role.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing
  ],
  declarations: [
    MarketrolemanagerComponent,
    MarketRoleSearchComponent,
    ApproversByRoleComponent
  ]


})
export class MarketrolemanagerModule { }
