// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  envName: 'dev',

  /* GET Request with no param checked*/
  getDivisionsURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/allDivisions', 
  //getDivisionsURL: 'https://sodsapi-dev.cloud.usfood.com/sods-marketrolemanager-api/v1/sods/allDivisions',

  /* GET with query param div and custNbr and Header checked*/
  customerInquiryURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/customer?', 
  //customerInquiryURL: 'https://sodsapi-dev.cloud.usfood.com/sods-cust-inquiry-api/v1/sods/customer?',

  /* POST req with reqId in path param checked*/
  draftReqIdURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/draftRequisitions/',
  //draftReqIdURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/draftRequisitions/',

  /* GET qwith networkID in path param checked*/
  getInboxTaskURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/inbox/',
  //getInboxTaskURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/SODSInbox/',

  /* GET with reqId in  path param checked*/
  retrieveCommentforInboxURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/inbox/comments/',
  //retrieveCommentforInboxURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/SODSInbox/comments/',
  
  /* GET with division in query param and POST with ManageRoles as json request checked*/
  marketRoleManagerURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/marketRoleManager', //GET and POST
  //marketRoleManagerURL: 'https://sodsapi-dev.cloud.usfood.com/sods-marketrolemanager-api/v1/sods/marketRoleManager',

  /* POST req with ValidateUserRolesRequest as json req checked*/
  // validateApproversURL: 'https://awldrsodas03.cloud.usfood.com/sods-experience-api/v1/validateUserRoles', //POST
  validateApproversURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/validateUserRoles', 
  //validateApproversURL: 'https://sodsapi-dev.cloud.usfood.com/sods-marketrolemanager-api/v1/sods/validateUserRoles',

  /* POST req with SetOutOfOfficeRequest as json req checked*/
  getTasksURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/outOfOfficeStatus',
  //getTasksURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/OutOfOfficeStatus',

  /* GET with networkID in path param checked*/
  outoffOffice: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/outOfOfficeStatus/',
  //outoffOffice: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/OutOfOfficeStatus/',

  /* POST req with UnsetOutOfOfficeRequest as json req checked*/
  unSetOutoffOffice: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/unsetOutOfOfficeStatus',
  //unSetOutoffOffice: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/unsetOutOfOfficeStatus',

  /* POST req with div in query param, header in Header and ProductResponseBody as json req checked*/
  productRetrivalURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/product?',
  //productRetrivalURL: 'https://sodsapi-dev.cloud.usfood.com/sods-product-lookup-api/v1/sods/product?',

  /* GET with no param checked* */
  generateReqIdURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/reqId',
  //generateReqIdURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisitionid-generation-api/v1/sods/requisitionid',

  /* GET with reqId in path param */
  getReqDetailsURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/requisitions/',
  //getReqDetailsURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/requisitions/',

  /* POST with reqId in path and SodsRequisition as json req checked */
  postReqIdURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/requisitions/',
  // postReqIdURL: 'http://localhost:8080/sods-experience-api/v1/requisitions/',
  //postReqIdURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/requisitions/',

  /* DELETE with reqId in path param */
  deleteRequisitionURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/requisitions/',
  //deleteRequisitionURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/requisitions',

  /* GET with query param firstName and lastName checked*/
  searchUser: ' https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/searchUser',
  //searchUser: ' https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/searchUser',

  /* GET with path param tmId checked* */
  retrieveUSFTMFromTandemIDURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/territoryManager',
  //retrieveUSFTMFromTandemIDURL: 'https://sodsapi-dev.cloud.usfood.com/sods-requisition-api/v1/sods/territoryManager',

  /* POST with header in Header and div in query param and ProductResponseBody as json req  checked* */
  validateProductsURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/validateProducts?',
  //validateProductsURL: 'https://awldrsodas03.cloud.usfood.com/sods-experience-api/v1/validateProducts?',

  /* POST with Token as json req checked* */ 
  tokenParserURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/usfUser',
  //tokenParserURL: 'https://sodsapi-dev.cloud.usfood.com/sods-jwt-parser-api/v1/sods/info',

  // {"username":"sodsus01","password":"Testuser01","requestType":"TOKEN"} checked*
  loginURL : 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/token',
  //loginURL : 'https://sodsapi-dev.cloud.usfood.com/security-api/login',
  
  retrieveUserURL: 'https://sodsapi-dev.cloud.usfood.com/retrieve-user-api/login',  

  requisitionAttachments: 'https://sodsapi-dev.cloud.usfood.com/sods-attachments-api/v1/sods/requisition',

  productAttachments: 'https://sodsapi-dev.cloud.usfood.com/sods-attachments-api/v1/sods/product',

  generatePdf: 'https://sodsapi-dev.cloud.usfood.com/sods-report-generator-api/v1/sods/generatePdf',

  generateExcel: 'https://sodsapi-dev.cloud.usfood.com/sods-report-generator-api/v1/sods/generateExcel',

  // completeTask: 'https://awldrsodas01.cloud.usfood.com/sods-requisition-api/v1/sods/completeTask',
  completeTask: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/completeTask',

  //getTaskDetailsURL: 'https://awldrsodas01.cloud.usfood.com/sods-requisition-api/v1/sods/task/',
  getTaskDetailsURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/task/',
  
  //acceptTask: 'https://awldrsodas01.cloud.usfood.com/sods-requisition-api/v1/sods/acceptTask',
  acceptTask: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/acceptTask',

  //releaseTask: 'https://awldrsodas01.cloud.usfood.com/sods-requisition-api/v1/sods/releaseTask',
  releaseTask: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/releaseTask',

  //validatePOURL: 'https://awldrsodas01.cloud.usfood.com/sods-requisition-api/v1/sods/validatePO',
  validatePOURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/validatePO',

  //retrieveVirtualVendor: 'https://awldrsodas01.cloud.usfood.com/sods-requisition-api/v1/sods/virtualVendor/'
  retrieveVirtualVendor: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/virtualVendor/',

  transferRequisitionURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/transferRequisition',
  // transferRequisitionURL: 'http://localhost:8080/sods-experience-api/v1/transferRequisition',

  searchRequisitionURL: 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/search',

  generateSearchExcel: 'https://sodsapi-dev.cloud.usfood.com/sods-report-generator-api/v1/sods/generateSearchExcel'

};