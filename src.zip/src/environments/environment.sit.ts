// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  envName: 'sit',

  getDivisionsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/allDivisions', 

  customerInquiryURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/customer?', 

  draftReqIdURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/draftRequisitions/',

  getInboxTaskURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/inbox/',

  retrieveCommentforInboxURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/inbox/comments/',
  
  marketRoleManagerURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/marketRoleManager',

  validateApproversURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/validateUserRoles', 

  getTasksURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/outOfOfficeStatus',

  outoffOffice: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/outOfOfficeStatus/',

  unSetOutoffOffice: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/unsetOutOfOfficeStatus',

  productRetrivalURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/product?',

  generateReqIdURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/reqId',

  getReqDetailsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/requisitions/',

  postReqIdURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/requisitions/',

  deleteRequisitionURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/requisitions/',

  searchUser: ' https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/searchUser',

  retrieveUSFTMFromTandemIDURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/territoryManager',

  validateProductsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/validateProducts?',

  tokenParserURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/usfUser',

  loginURL : 'https://sodsapi-dev.cloud.usfood.com/sods-experience-api/v1/token',
  
  retrieveUserURL: 'https://sodsapi-sit.cloud.usfood.com/retrieve-user-api/login',  

  requisitionAttachments: 'https://sodsapi-sit.cloud.usfood.com/sods-attachments-api/v1/sods/requisition',

  productAttachments: 'https://sodsapi-sit.cloud.usfood.com/sods-attachments-api/v1/sods/product',

  generatePdf: 'https://sodsapi-sit.cloud.usfood.com/sods-report-generator-api/v1/sods/generatePdf',

  generateExcel: 'https://sodsapi-sit.cloud.usfood.com/sods-report-generator-api/v1/sods/generateExcel',

  completeTask: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/completeTask',

  getTaskDetailsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/task/',

  acceptTask: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/acceptTask',

  releaseTask: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/releaseTask',

  validatePOURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/validatePO',

  retrieveVirtualVendor: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/virtualVendor/',

  transferRequisitionURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/transferRequisition',

  searchRequisitionURL: 'https://sodsapi-sit.cloud.usfood.com/sods-experience-api/v1/search',

  generateSearchExcel: 'https://sodsapi-sit.cloud.usfood.com/sods-report-generator-api/v1/sods/generateSearchExcel'

};