export const environment = {
  production: true,
  envName: 'prod',
  loginURL : 'http://localhost:8080/security-api/login',
  // tokenParserURL: 'http://localhost:8080/sods-jwt-parser-api/v1/sods/info'
};