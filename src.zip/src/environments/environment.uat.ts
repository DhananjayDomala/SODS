// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  envName: 'uat',
  loginURL : 'https://sodsapi-sit.cloud.usfood.com/security-api/login',
  tokenParserURL: 'https://sodsapi-sit.cloud.usfood.com/sods-jwt-parser-api/v1/sods/info',
  generateReqIdURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisitionid-generation-api/v1/sods/requisitionid',
  postReqIdURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/requisitions/',
  draftReqIdURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/draftRequisitions/',
  customerInquiryURL: 'https://sodsapi-sit.cloud.usfood.com/sods-cust-inquiry-api/v1/sods/customer?',
  getTasksURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/OutOfOfficeStatus',
  retrieveUserURL: 'https://sodsapi-sit.cloud.usfood.com/retrieve-user-api/login',
  productRetrivalURL: 'https://sodsapi-sit.cloud.usfood.com/sods-product-lookup-api/v1/sods/product?',
  requisitionAttachments: 'https://sodsapi-sit.cloud.usfood.com/sods-attachments-api/v1/sods/requisition',
  productAttachments: 'https://sodsapi-sit.cloud.usfood.com/sods-attachments-api/v1/sods/product',
  marketRoleManagerURL: 'https://sodsapi-sit.cloud.usfood.com/sods-marketrolemanager-api/v1/sods/marketRoleManager',
  retrieveUSFTMFromTandemIDURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/territoryManager',
  deleteRequisitionURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/requisitions',
  getDivisionsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-marketrolemanager-api/v1/sods/allDivisions',
  searchUser: ' https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/searchUser',
  outoffOffice: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/OutOfOfficeStatus/',
  unSetOutoffOffice: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/unsetOutOfOfficeStatus',
  generatePdf: 'https://sodsapi-sit.cloud.usfood.com/sods-report-generator-api/v1/sods/generatePdf',
  generateExcel: 'https://sodsapi-sit.cloud.usfood.com/sods-report-generator-api/v1/sods/generateExcel',
  generateSearchExcel: 'https://sodsapi-dev.cloud.usfood.com/sods-report-generator-api/v1/sods/generateSearchExcel',
  getInboxTaskURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/SODSInbox/',
  retrieveCommentforInboxURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/SODSInbox/comments/',
  validateApproversURL: 'https://sodsapi-sit.cloud.usfood.com/sods-marketrolemanager-api/v1/sods/validateUserRoles',
  getReqDetailsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/requisitions/',
  completeTask: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/completeTask',
  getTaskDetailsURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/task/',
  acceptTask: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/acceptTask',
  releaseTask: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/releaseTask',
  transferRequisitionURL: 'https://sodsapi-sit.cloud.usfood.com/sods-requisition-api/v1/sods/transferRequisition',
  searchRequisitionURL: 'https://awldrsodas03.cloud.usfood.com/sods-experience-api/v1/search'
};
