import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActionDispatcherService, ModelPresenterService } from 'usf-sam';
import { SodsModelService } from './demomodel/sodsmodel.service';

import { ActionEvents } from './events/action-events';

import { Modal, ModalModule } from 'ngx-modal';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from './service/authentication.service';
import { User } from 'app/model/user';
import { LoadingService } from './service/loading.service'
import { AlertSetting } from './democomponents/common/alert/alert.component';
import { ALERTS } from './democomponents/common/alert/alerts';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {

  title = 'SODS Demo!';

  showBusyIcon = false;
  showError = false;
  timeoutIn = 5000;
// For Alert Text Bar
    public showAlert = false;
    public alertType = '';
    public alertMessage = '';
    public alertSettings: AlertSetting[] = [{ 'alertType': '', 'alertMessage': '' }];

  constructor(readonly actionDispatcher: ActionDispatcherService, readonly modelPresenter: ModelPresenterService,
    readonly sodsmodel: SodsModelService, 
    private loadingService: LoadingService,
    public router: Router, private authService: AuthenticationService, private user: User, private activatedRoute: ActivatedRoute) {


  }
  
  showAlertMessage(alertType: string, alertText: string) {
        this.alertSettings = [];
        this.alertMessage = ALERTS[alertType][alertText];
        const alert: AlertSetting = { 'alertType': alertType, 'alertMessage': this.alertMessage };
        this.alertSettings.push(alert);
        this.showAlert = true;
        this.goTo('top');
    }

    goTo(location: string): void {
        window.location.hash = '';
        window.location.hash = location;
    }

  ngOnInit() {
    this.modelPresenter.registerEventsForModel(this.sodsmodel);

    this.loadingService.busy().subscribe((isBusy: any) => { 
      this.showBusyIcon = isBusy;
    });
    this.loadingService.error().subscribe((isError: any) => { 
      this.showAlertMessage('error', 'noSuperUserSelected');
    });
    
    // set roles
    const localUser = JSON.parse(JSON.parse(localStorage.getItem('user'))._body) || '';
    if (localUser) {
      const roles = localUser.userRoles || '';
      const applicationMarkets = localUser.applicationMarkets || [];
      const firstName = localUser.firstName || '';
      const lastName = localUser.lastName || '';
      const networkID = localUser.userId || '';
      this.user.setRoles(roles);
      this.user.setMarkets(applicationMarkets);
      this.user.setFirstName(firstName);
      this.user.setLastName(lastName);
      this.user.setNetworkID(networkID);
    }

   }

  isLoggined() {
    
  }
  

  isLoginPage(): boolean {
    return this.router.url === '/' || this.router.url === '/login' || this.router.url === '/#';
  }
}