import { BaseComponent } from 'app/democomponents/base-component';
import { Injectable } from '@angular/core';

@Injectable()
export class MockSamService {

    constructor() {
        
    }

    callAction(eventTypeName: string, data: any) {
        return "Success";
    }
}