import { Injectable } from '@angular/core';
import { Division } from '../model/division';

@Injectable()
export class DivisionsService {
    divisions: Division[];

    setDivisions(divisions: Array<Division>) {
        this.divisions = divisions;
    }

    getDivisions() {
        return this.divisions;
    }

    getMarketNameByDivisionNumber(divNum: string) {
        const marketName = this.divisions.filter(division =>
            division.divisionNumber.toString() === divNum
        );
        let market = this.toTypeCase(marketName[0].divisionName);
        return market;
    }

    toTypeCase(txt: string) {
        return txt[0].toUpperCase() + txt.slice(1).toLowerCase();
    }
}
