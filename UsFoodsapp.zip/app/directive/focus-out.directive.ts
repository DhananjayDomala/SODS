import { Directive, ElementRef, Renderer, HostListener, Input, ViewContainerRef, TemplateRef } from '@angular/core';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Directive({
  selector: '[appFocusOut]'
})
export class FocusOutDirective implements OnInit {
  @Input() comp: any;

  date = new Date();
  currentMonth = this.date.getMonth();

  constructor(private el: ElementRef, private renderer: Renderer) { }

  ngOnInit() {
  }

  @HostListener('focusout') focusOut() {
  
    setTimeout(() => {
      debugger
      // console.log('Current Month: '+ this.currentMonth);
      if (this.currentMonth === this.comp.currentMonth && this.date.getFullYear() === this.comp.currentYear) {
        if(this.comp.overlayVisible) {
          //this.comp.overlayVisible = false;
        } else {
          this.comp.isVisible = false;
        }
      }
    }, 300);
    
  }

  @HostListener('focus') focus() {
    setTimeout(() => {
      if(this.comp.overlayVisible) {
        this.comp.overlayVisible = true;
      } else {
        this.comp.isVisible = true;
      }

    }, 150);
  }
}
