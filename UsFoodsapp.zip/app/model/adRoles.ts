export const PRIVILEGES = {
    'divManager': ['USF-SODS-DIVMGR'],
    'superUser': ['USF-SODS-SUPERUSER'],
    'marketRoleManager': ['USF-SODS-DIVMGR'],
    'createRequisition': ['SODS-USER'],
    'sodsUser': ['SODS-USER']
};
