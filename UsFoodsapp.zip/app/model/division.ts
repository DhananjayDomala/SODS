export class Division{
    divisionNumber: string;
    divisionName: string;
    divisionCode: string;
    city: string;
    state: string;
    region: string;
    status: string;
}
