export class DivisionRole{
    applicationid: string;
    division: string;
    roleId: string;
    level: string;
    includePeopleSoftData: boolean;
    requisitionId: string;
}

export class DivisionUser{
    ApplicationId: string;
    division: string;
    roleId: string;
    level: string;
    networkID: string;
    firstName: string;
    lastName: string;
    email: string;
    outOfOffice: boolean;
    returnDate: string;
}

export const SAMPLEDivisionUserBuyer: DivisionUser = {
        ApplicationId: '1',
        division: '1104',
        roleId: 'BUYER',
        level: '1',
        networkID: 'sodsgu01',
        firstName: '',
        lastName: '',
        email: '',
        outOfOffice: false,
        returnDate: ''
}

export const SAMPLEDivisionUserCA: DivisionUser = {
        ApplicationId: '1',
        division: '1104',
        roleId: 'CA',
        level: '1',
        networkID: 'SODSCR01',
        firstName: '',
        lastName: '',
        email: '',
        outOfOffice: false,
        returnDate: ''
}