export class Comment{
    commentsText: string;
    timestamp: string;
    networkID: string;
    name: string;
    new?: boolean;
}

export const SAMPLECommentA: Comment = {
    commentsText: 'abcdlajflsjfladsjfalsdjfalsjfdlsajfladsjflasdjflasdjflasjdflasj',
    timestamp: '',
    networkID: 'test',
    name: 'Wen, Liang',
    new: true
}

export const SAMPLECommentB: Comment = {
    commentsText: 'sjfldsajfldasjfladsjflasdjflsadjlvmfaonvoaijeoincalmclajclasjfaposdjf',
    timestamp: '',
    networkID: 'test',
    name: 'Karthik, Balasubramanian',
    new: true
}

export const SAMPLECommentArr: Comment[] = [SAMPLECommentA, SAMPLECommentB];