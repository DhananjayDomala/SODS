export class UnsetOutOfOfficeContent{
    NetworkID: string;
}

export class UnsetOutOfOffice{
    unsetOoOrequest: UnsetOutOfOfficeContent;
}

export class SetOutOfOfficeContent{
    outOfOfficeUserID: string;
    returnDate:  string;
    designateID: string;
    superUserID: string;
    updatedByUserID: string;
}

export class SetOutOfOffice{
    setOoOrequest: SetOutOfOfficeContent;
}

