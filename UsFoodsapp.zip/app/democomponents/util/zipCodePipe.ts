import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'zipCodePipe',
})
export class ZipCodePipe implements PipeTransform {
    transform(value: string): string {
        if(value !== null) {
            return this.formatZipCode(value);
        }
        return '';
    }

    formatZipCode(zipcode): string {
        return zipcode.replace(/(\d{5})(\d{4})/, '$1-$2');
    }
}