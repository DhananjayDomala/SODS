import { MarketNameAndCode } from './../../../common/dropdown-multiselect/multiselect-dropdown';
import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, HostListener } from '@angular/core';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from '../../../common/dropdown-multiselect/multiselect-dropdown';


@Component({
  selector: 'app-market-role-search',
  templateUrl: './market-role-search.component.html',
  styleUrls: ['./market-role-search.component.css']
})

export class MarketRoleSearchComponent implements OnInit, AfterViewInit {
  @Input() markets: Object[];
  @Input() selectedMarket: string;
  @Input() selectedMarketNumber: string;
  @Input() marketOptions: string[];
  @Input() marketNameAndCode: MarketNameAndCode[];
  @Input() roleOptions: IMultiSelectOption[];
  @Input() selectedRoleOptions: number[];

  @Output('isValidDivNum')
  isValidDivNum: EventEmitter<any> = new EventEmitter<any>();

  @Output('search')
  search: EventEmitter<any> = new EventEmitter<any>();

  @Output('roleSelect')
  roleSelect: EventEmitter<any> = new EventEmitter<any>();

  public roles: string[];

  public validMarketNumber = true;

  results: string[] = [];
  public multiSelectSettings: IMultiSelectSettings = {
    pullRight: true,
    enableSearch: false,
    checkedStyle: 'checkboxes',
    selectionLimit: 0,
    closeOnSelect: false,
    showCheckAll: false,
    showUncheckAll: false,
    showToggleCheckAll: true,
    dynamicTitleMaxItems: 1,
    maxHeight: '190',
    width: '320'
  };

  public multiSelectTexts: IMultiSelectTexts = {
    checkAll: 'Check All',
    uncheckAll: 'Uncheck All',
    toggleCheckAll: 'All Roles',
    checked: 'Selected',
    checkedPlural: 'Selected',
    searchPlaceholder: 'Search...',
    defaultTitle: 'Select Roles',
    allSelected: 'All Roles'
  };

  showMarketNumDropdown = false;

  constructor() { }

  ngOnInit() {
    if (this.markets) {
      this.results = this.markets.map(x => x['divisionNumber'].toString());
    }
  }

  ngAfterViewInit() {
  }

  valueChanged(newValue) {
    this.selectedMarketNumber = newValue;
    this.onMarketNumTxtFieldBlur(newValue);
  }

  onMarketNumTxtFieldBlur(divNumber) {
    // see if divNumber is valid
    const divisionNum = divNumber.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    this.validMarketNumber = this.isValidDivisionNumber(divisionNum);
    this.isValidDivNum.emit(this.validMarketNumber);
    // if valid, update the markets dropdown menu
    if (this.validMarketNumber) {
      this.selectedMarketNumber = divNumber;
      const index = this.markets.findIndex(x => x['divisionNumber'].toString() === this.selectedMarketNumber);
      this.setSelectedDivisonNumber(index);
    }
  }

  onMarketSelection(market): void {

    this.selectedMarket = market.option;
    this.setSelectedDivisonNumber(market.index);
  }

  public onChangeRoleSelection(roles): void {
    // Function is called when user checks an option
    // Input:  array of the selected option array indexes. ex) [0,1,2,3]

    // Set the selected roles array
    this.selectedRoleOptions = roles;
    this.roleSelect.emit(roles);
  }

  setSelectedDivNumber(divisionNumber) {
    this.selectedMarketNumber = divisionNumber;
    this.showMarketNumDropdown = !this.showMarketNumDropdown;
    let index = this.findIndex(this.markets, 'divisionNumber', Number(divisionNumber));
    this.setSelectedDivisonNumber(index);
  }

  setSelectedDivisonNumber(index: number): void {
    const marketNumber = this.markets[index]['divisionNumber'] || '';
    this.selectedMarket = this.markets[index]['divisionName'] + ' (' + this.markets[index]['divisionNumber'] + ' - ' + this.markets[index]['divisionCode'] + ')';
    this.selectedMarketNumber = marketNumber;
    this.validMarketNumber = true;
  }

  isValidDivisionNumber(divNumber: string): boolean {
    return this.markets.some(market => market['divisionNumber'].toString() === divNumber);
  }

  onSearchBtnClick() {
    // Emit the Search Form Options to parent component
    // Output the selected division
    // Output the selected role
    let data: any = { 'market': this.selectedMarketNumber, 'selectedRoles': this.selectedRoleOptions };
    this.search.emit(data);
  }

  toggleDropDown($event: Event) {
    $event.preventDefault();
    $event.stopPropagation();
    this.showMarketNumDropdown = !this.showMarketNumDropdown;
  }

  findIndex(array, property, value) {
    return array.findIndex(x => x[property] === value);
  }

}
