import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketRoleSearchComponent } from './market-role-search.component';
import { AdministrationModule } from "app/democomponents/administration/administration.module";
import { User } from "app/model/user";
import { Division } from "app/model/division";

describe('MarketRoleSearchComponent', () => {
  let component: MarketRoleSearchComponent;
  let fixture: ComponentFixture<MarketRoleSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AdministrationModule],
      declarations: [ ],
      providers: [
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketRoleSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should on market selection successfully', ()=>{

    let markets = 
    [
      {
        "divisionNumber": 1104,
        "divisionName": "ALBANY",
        "divisionCode": 98,
        "city": "CLIFTON PARK",
        "state": "NY",
        "region": "Northeast",
        "status": "A"
      },
      {
        "divisionNumber": 1104,
        "divisionName": "CLEVELAND",
        "divisionCode": "3Z",
        "city": "CLEVELAND",
        "state": "OH",
        "region": "East",
        "status": "A"
      }
    ]
    component.markets = new Array<string>();
    component.markets[1] = JSON.stringify(markets[0]);
    let market = {option: '1104', index: 1};
    component.onMarketSelection(market);
  });

  it('should on market num text field blur successfully', ()=>{
    let divNumber = '2140';
    component.markets = [];
    component.markets[0] = {
      city:'CLIFTON PARK',
      divisionCode: '9B',
      divisionName: 'ALBANY',
      divisionNumber: '2140',
      region: 'Northeast',
      state:'NY',
      status:'A'
    };

    const mockCall = {
      isValidDivisionNumber: (divisionNum: string) => {
        return true;
      },
      setSelectedDivisonNumber:() => {

      }
    }
    spyOn(component, 'isValidDivisionNumber').and.callFake(mockCall.isValidDivisionNumber);
    component.onMarketNumTxtFieldBlur(divNumber);

  });
});
