import { CreateRequisitionComponent } from './../common/createRequisition/createRequisition.component';
import { CustomerComponent } from './../common/customer/customer.component';
import { Modal } from 'ngx-modal';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { SamService } from 'app/service/sam.service';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { SODSNewSoComponent } from './sodsnewso.component';
import { ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';
import { dateFormatPipe } from 'app/democomponents/util/dateFormatPipe';
import { SharedModule } from 'app/shared/shared.module';
import { User } from 'app/model/user';
import { Component, OnInit, OnChanges, ViewChild, ViewEncapsulation, AfterViewInit, AfterContentChecked, SimpleChanges, NO_ERRORS_SCHEMA } from "@angular/core";
import { DOMTestComponentRenderer } from '@angular/platform-browser-dynamic/testing/src/dom_test_component_renderer';
import { MockComponent } from 'mock-component';

fdescribe('Sodsnewso1Component', () => {
  let component: SODSNewSoComponent;
  let fixture: ComponentFixture<SODSNewSoComponent>;

  let actionDispatcher: ActionDispatcherService;
  let state: StateRepresentationRendererService;
  let route: ActivatedRoute;
  let router: Router;
  let user: User;

  const reqId = {
    requestId: "1234"
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        SODSNewSoComponent
      ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SamService,
        User,
        Modal,
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              queryParams: 
              {
                'taskId': '1234'
              }
            }
          }
        }
      ],
      imports: [
        RouterModule,
        SharedModule,
        RouterTestingModule
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SODSNewSoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.errorsQueue = [];
  });
  

  const mockFun = {
    dataObject: () => {
      let json = {
        "draftTaskId": "31828",
        "overideSavedByID": "",
        "overideSavedByName": "",
        "requisition": {
          "requisitionNumber": "31828",
          "requisitionType": "SODS-SO",
          "division": "1104",
          "status": "new",
          "createdAt": "2018-01-8 14:18:56",
          "updatedAt": "2018-01-8 14:18:56",
          "totalAmount": 100,
          "ETASelection": false,
          "ETADate": "2018-01-8 14:18:42",
          "returnIfETANotMet": false,
          "defaultShipMethod": "Next",
          "mainCustomerID": 60528643,
          "mainCustomerName": "DBL TREE CLEVE DT/LAKESD*",
          "mainCustomerDept": "10-FOOD",
          "mainCustomerType": "NA",
          "attachmentsCount": false
        },
        "requestor": {
          "name": "sodsus01, SharedAcct",
          "networkID": "sodsus01",
          "email": "SODSUser.Shared@usfoods.com",
          "additionalPhone": "",
          "additionalEmail": ""
        },
        "territoryManager": {
          "name": "sodsus02, SharedAcct",
          "networkID": "QFS6026",
          "email": "SODSUser.Shared@usfoods.com"
        },
        "customers": [
          {
            "seq": 1,
            "id": 60528643,
            "dept": "10-FOOD",
            "defaultShipMethod": "Next",
            "name": "DBL TREE CLEVE DT/LAKESD*",
            "address1": "1111 LAKESIDE AVENUE",
            "address2": "",
            "city": "CLEVELAND",
            "state": "OH",
            "zip": "441140000",
            "phone": "2162415100",
            "useOverrideShipto": false,
            "estimatedOrderAmt": "321.12",
            "confidenceCode": "09",
            "creditCheckStatus": "true"
          }
        ],
        "products": [
          {
            "isCollapse": true,
            "copyError": false,
            "vendor": null,
            "prodType": "Grocery",
            "new": true,
            "comments": [],
            "attachments": [],
            "seq": 1,
            "attachmentKey": 1,
            "description": "Eggs",
            "mfrId": "1234",
            "qty": "3",
            "attachCount": 0,
            "shipTodistribution": [
              {
                "departmentId": "10-FOOD",
                "customer": {
                  "id": 60528643,
                  "name": "DBL TREE CLEVE DT/LAKESD*",
                  "address1": "1111 LAKESIDE AVENUE",
                  "address2": "",
                  "zip": "441140000",
                  "city": "CLEVELAND",
                  "state": "OH",
                  "dept": "10-FOOD"
                },
                "shipMethod": "Next",
                "qty": "3",
                "disableInput": true,
                "customerId": 60528643
              }
            ],
            "requested": {
              "description": "Eggs",
              "vendor": "Amber",
              "mfrId": "1234",
              "type": "Grocery"
            },
            "type": "Grocery",
            "manufacturerId": "1234",
            "meetsETA": true
          }
        ],
        "auditLogs": [],
        "tasks": []
      }
    },
    requestId: () => {
      return "1234";
    },
    returnFakeData: () => {
      return "Success";
    },
    returnTrue: () => {
      return true;
    },
    returnEmptyArr: () => {
      return [];
    }
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /**
   * 1. Initialize
   * 2. Execute
   * 3. Validate
   */
  it('should be true if not null', () => {
    component.ifNotNull("4");
    expect(component.ifNotNull).toBeTruthy();
  });
  
  /*Test Cases for Error Handling */
  it('should push to errors queue', () => {
    let errors = "An error";
    component.pushToErrorsQueue(errors);
    expect(component.errorsQueue.length).toBeGreaterThan(0);
  });
  it('should reset errors queue', () => {
    let errors = "Some error";
    component.errorsQueue.push(errors);
    component.resetErrorsQueue();
    expect(component.errorsQueue.length).toEqual(0);
  });
  it('should check for errors', () => {
    spyOn(component, 'checkForValidationErrors').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'checkForQuoteErrors').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'checkForShipToErrors').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'checkForProductErrors').and.callFake(mockFun.returnFakeData);
    component.checkForErrors();
    expect(component.checkForValidationErrors).toHaveBeenCalled();
    expect(component.checkForQuoteErrors).toHaveBeenCalled();
    expect(component.checkForShipToErrors).toHaveBeenCalled();
    expect(component.checkForProductErrors).toHaveBeenCalled();
  });
  it('should check error queue if no errors exist', () => { 
    component.errorsQueue.length = 0;
    component.noCopyErrors = true;
    component.etaError = false;
    spyOn(component, 'setSubmitBody').and.callFake(mockFun.dataObject);
    spyOn(component, 'callSamService').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'setBusy').and.callFake(mockFun.returnTrue);
    component.checkErrorQueueOnSubmit();
    expect(component.setSubmitBody).toHaveBeenCalled();
    expect(component.callSamService).toHaveBeenCalled();
    expect(component.setBusy).toHaveBeenCalled();
  });
  it('should check error queue and scroll up if errors exist', () => {
    component.errorsQueue.length = 1;
    component.noCopyErrors = false;
    component.etaError = true;
    spyOn(component, 'scrollWindowUp').and.returnValue('0');
    component.checkErrorQueueOnSubmit();
    expect(component.scrollWindowUp).toHaveBeenCalled();
  });
  /* Test Cases for Button Actions */
  it('should submit request', () => {
    spyOn(component, 'resetErrorsQueue').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'checkForErrors').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'checkForCopyErrors').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'processErrorQueue').and.callFake(mockFun.returnFakeData);
    spyOn(component, 'checkErrorQueueOnSubmit').and.callFake(mockFun.returnFakeData);
    component.onSubmitRequest();
    expect(component.successPost).toEqual(false);
    expect(component.closeErrorPopup).toEqual(false);
    expect(component.currentAlert).toEqual([]);
    expect(component.resetErrorsQueue).toHaveBeenCalled();
    expect(component.checkForErrors).toHaveBeenCalled();
    expect(component.checkForCopyErrors).toHaveBeenCalled();
    expect(component.processErrorQueue).toHaveBeenCalled();
    expect(component.checkErrorQueueOnSubmit).toHaveBeenCalled();
  });
  it('should process error queue', () => {
    component.errorsQueue.push("First error message");
    component.errorsQueue.push("Second error message");
    component.processErrorQueue();
    expect(component.errorAlerts[0]).toContain({"alertType":"error","alertMessage":"First error message"});
    expect(component.errorAlerts[1]).toContain({"alertType":"error","alertMessage":"Second error message"});
  });
  /* Test Cases for Open/Close of Modals */
  it('should open cancel modal', () => {
    component.cancelModal = new Modal();
    spyOn(component.cancelModal, 'open').and.returnValue(true);
    component.onCancel();
    expect(component.cancelModal.open()).toHaveBeenCalled;
  }); 
  it('should open delete req modal', () => {
    component.deleteReqModal = new Modal();
    spyOn(component.deleteReqModal, 'open').and.returnValue(true);
    component.onDelete();
    expect(component.deleteReqModal.open()).toHaveBeenCalled;
  }); 
  it('should close delete requisition', () => {
    component.deleteReqModal = new Modal();
    spyOn(component.deleteReqModal, 'open').and.returnValue(true);
    component.closeDeleteRequisition();
    expect(component.deleteReqModal.open()).toHaveBeenCalled;
  });
  it('should close alert bar', () => {
    component.onCloseBar("item");
    expect(component.currentAlert).toContain("item");
  });
  it('should save draft', () => {
    spyOn(component, 'setBusy').and.returnValue(true);
    spyOn(component, 'setDraftBody').and.callFake(mockFun.dataObject);
    spyOn(component, 'callSamService').and.callFake(mockFun.returnFakeData);
    component.saveDraft();
    expect(component.setBusy).toHaveBeenCalled();
    expect(component.setDraftBody).toHaveBeenCalled();
    expect(component.callSamService).toHaveBeenCalled();
  });
  it('should set busy status', () => {
    spyOn(component, 'callSamService').and.callFake(mockFun.returnFakeData);
    component.setBusy(true);
    expect(component.callSamService).toHaveBeenCalled();
  });
  it('should scroll window up', () => {
    spyOn(window, 'scrollTo').and.returnValue('0');
    component.scrollWindowUp();
    expect(window.scrollTo).toHaveBeenCalled();
  });
  it('should on fail of post requisition', () => {
    spyOn(component, 'setBusy').and.returnValue(true);
    spyOn(component, 'resetErrorsQueue').and.returnValue(true);
    spyOn(component, 'ifNotNull').and.returnValue(false);
    spyOn(component, 'pushToErrorsQueue').and.callFake(mockFun.dataObject);
    spyOn(component, 'scrollWindowUp').and.returnValue('0');
    component.onPostFail({error: {_body: null}});
    expect(component.successPost).toBeFalsy();
    expect(component.resetErrorsQueue).toHaveBeenCalled();
    expect(component.setBusy).toHaveBeenCalled();
    expect(component.pushToErrorsQueue).toHaveBeenCalled();
    expect(component.scrollWindowUp).toHaveBeenCalled();
  });  
  it('should on fail of post draft', () => {
    spyOn(component, 'setBusy').and.returnValue(true);
    spyOn(component, 'closeWarning').and.returnValue(true);
    spyOn(component, 'resetErrorsQueue').and.returnValue(true);
    spyOn(component, 'ifNotNull').and.returnValue(false);
    spyOn(component, 'pushToErrorsQueue').and.callFake(mockFun.dataObject);
    spyOn(component, 'scrollWindowUp').and.returnValue('0');
    component.onDraftFail({error: {_body: null}});
    expect(component.successDraft).toBeFalsy();
    expect(component.setBusy).toHaveBeenCalled();
    expect(component.resetErrorsQueue).toHaveBeenCalled();
    expect(component.pushToErrorsQueue).toHaveBeenCalled();
    expect(component.scrollWindowUp).toHaveBeenCalled();
  });
});