import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import * as console from 'console';
import { OutofofficeComponent } from './outofoffice.component';
import { SharedModule } from './../../shared/shared.module';
import { RouterTestingModule } from "@angular/router/testing";
import { Event, ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "./../../events/action-events";
import {OutOfService} from '../../service/outoffice.service';
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { FormsModule } from '@angular/forms';
import { MockComponent } from "app/model/mock";
import { User } from "app/model/user";
import { Idle, NgIdleModule, IdleExpiry } from "@ng-idle/core";

describe('OutofofficeComponent', () => {
  let component: OutofofficeComponent;
  let fixture: ComponentFixture<OutofofficeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutofofficeComponent ],
      imports: [SharedModule, RouterTestingModule],
      providers:
      [
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        OutOfService,
        User,
        Idle,
        {provide: IdleExpiry, useClass: MockExpiry}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let store = {};
    const mockSAMCall = {
      getBasicInfo: () => {

      },
      getAttachmentDetails: () =>{

      },
      setBusyStatus: () =>{

      },
      getComments: () => {

      },
      getDivisions: () => {

      },
      completeTask: () => {

      },
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
    .and.callFake(mockSAMCall.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockSAMCall.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockSAMCall.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockSAMCall.clear);

    
    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': '', 
    userRoles: ['sample1', 'USF-SODS-SUPERUSER']})}));

    fixture = TestBed.createComponent(OutofofficeComponent);
    component = fixture.componentInstance;

    this.sendEvent = false;
    component.actionDispatcherService.dispatch = (ev: any) => {this.sendEvent = true};
    // component.actionDispatcherService.dispatch = () => {};
    
    spyOn(component, 'getBasicInfo').and.callFake(mockSAMCall.getBasicInfo);

    fixture.detectChanges();
  });

  fit('should create', () => {
    expect(component).toBeTruthy();
  });

  fit('should call onGetOutofOfficeSuccess', () => {
    spyOn(component, 'onForwardTaskTo').and.callThrough();
    const data = {
      outOfOffice: true,
      designateName: 'sample',
      returnDate: '2018-1-1'
    };
    
    component.onGetOutofOfficeSuccess(data);

    expect(component.selectedType).toEqual('outOfOffice');
    expect(component.forwardTask).toEqual('sample');
    expect(component.calendarSettings.value.getDate()).toEqual(1);
    expect(component.onForwardTaskTo).toHaveBeenCalled();

  });

  fit('should call onGetOutofOfficeSuccess : else case', () => {
    spyOn(component, 'onForwardTaskTo').and.callThrough();
    const data = {
      outOfOffice: false,
      designateName: 'sample',
      returnDate: ''
    };
    
    component.onGetOutofOfficeSuccess(data);

    expect(component.selectedType).toEqual('inOffice');
    expect(component.forwardTask).toEqual('sample');
    expect(component.calendarSettings.value.getDate()).toEqual(new Date().getDate());
    expect(component.onForwardTaskTo).toHaveBeenCalled();

  });

  fit('should call onGetOutofOfficeFail', () => {
    spyOn(component, 'onGetOutofOfficeFail').and.callThrough();
    component.onGetOutofOfficeFail({});

    expect(component.onGetOutofOfficeFail).toHaveBeenCalledWith({});

  });

  fit('should call renderTasksTo', () => {
    component.typeOfSearch = 'user';
    component.forwardTask = 'sample22';
    const data = {
      users: [{fullName: 'sample'}]
    }
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.renderTasksTo(data);

    expect(component.searchedUsers.length).toEqual(1);
    expect(component.results.length).toEqual(1);
    expect(component.setBusyStatus).toHaveBeenCalledWith(false);
    

  });

  fit('should call renderTasksTo : else', () => {
    component.typeOfSearch = 'usersample';
    component.forwardTask = 'sample';
    const data = {
      users: [{fullName: 'sample'}]
    }
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.renderTasksTo(data);

    expect(component.searchedforwardTaskUsers.length).toEqual(1);
    expect(component.forwardTaskUsers.length).toEqual(1);
    expect(component.setBusyStatus).toHaveBeenCalledWith(false);
  });

  fit('should call renderTasksToFail', () => {
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.renderTasksToFail({});

    expect(component.setBusyStatus).toHaveBeenCalledWith(false);

  });

  fit('should call getTasks', () => {
    spyOn(component, 'getTasks').and.callThrough();
    component.getTasks();

    expect(component.getTasks).toHaveBeenCalled();

  });

  fit('should call onSubmitSuccess', () => {
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.onSubmitSuccess({});
    expect(component.isUpdateSuccess).toBeTruthy();
    expect(component.setBusyStatus).toHaveBeenCalledWith(false);

  });

  fit('should call onSubmitFail', () => {
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.onSubmitFail({});
    expect(component.isUpdateError).toBeTruthy();
    expect(component.setBusyStatus).toHaveBeenCalledWith(false);

  });

  fit('should call submitOutofOffice: happyPath', () => {
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.submitOutofOffice();
    expect(component.setBusyStatus).toHaveBeenCalledWith(true);

  });

  fit('should call submitOutofOffice: 1', () => {
    component.user = '';
    component.selectedType = 'setOtherUser';
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.submitOutofOffice();
    expect(component.setBusyStatus).not.toHaveBeenCalledWith(true);

  });

  fit('should call submitOutofOffice: 2', () => {
    component.forwardTask = '';
    component.selectedType = 'outOfOffice';
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.submitOutofOffice();
    expect(component.setBusyStatus).not.toHaveBeenCalledWith(true);

  });

  fit('should call submitOutofOffice: 2', () => {
    component.isUpdateError = true;
    component.selectedType = 'outOfOffice';
    spyOn(component, 'setBusyStatus').and.callThrough();
    component.submitOutofOffice();
    expect(component.setBusyStatus).not.toHaveBeenCalledWith(true);

  });

  fit('should call showOutOfOffice', () => {
    component.showOutOfOffice();
    expect(component.isShow).toBeTruthy();

  });

  fit('should call onDateSelectionDone', () => {
    component.onDateSelectionDone({});
    expect(component.date_selection_error).toBeFalsy();
    expect(component.calendarSettings.error).toBeFalsy();

  });

  fit('should call onErrorHandler', () => {
    component.onErrorHandler();
    expect(component.date_selection_error).toBeTruthy();
    expect(component.calendarSettings.error).toBeTruthy();

  });

  fit('should call onChangeRadio', () => {
    component.onChangeRadio('val');
    expect(component.selectedType).toEqual('');

  });

  fit('should call onUserSlection', () => {
    component.onUserSlection({});
    expect(component.isUserError).toBeFalsy();

  });

  fit('should call onForwardTaskSelection', () => {
    component.onForwardTaskSelection({});
    expect(component.isForwardError).toBeFalsy();

  });

  fit('should call onUserSearch', () => {
    component.onUserSearch({});
    expect(component.typeOfSearch).toEqual('user');

  });
});

export class MockExpiry extends IdleExpiry {
  public lastDate: Date;
  public mockNow: Date;

  last(value?: Date): Date {
    if (value !== void 0) {
      this.lastDate = value;
    }

    return this.lastDate;
  }

  now(): Date {
    return this.mockNow || new Date();
  }
}


