import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ActionDispatcherService, StateRepresentationRendererService } from "usf-sam/dist/usf-sam";
import { BaseComponent } from "app/democomponents/base-component";
import { ModelChangeUpdateEvents, ActionEvents } from "app/events/action-events";
import { SearchRequest, Parameter, SearchRequisitions } from "app/model/searchRequisition";
import { SORTBYOPTIONS, PAGEOPTIONS, DEFAULTSORTBYOPTION, DEFAULTPAGEOPTION, VALUEMAP } from "app/democomponents/common/options/options";

@Component({
  selector: 'app-search-designate',
  templateUrl: './search-designate.component.html',
  styleUrls: ['./search-designate.component.css']
})
export class SearchDesignateComponent extends BaseComponent implements OnInit  {

  //sorting
  sortByOptions: string[];
  selectedSortByOption: string;
  defaultSortByOption: string;
  isAscending: boolean;

  //pagination
  pageOptions: string[];
  selectedPage: string;
  defaultPage: string;

  @Input() requestOption: string;
  @Output() changePageOption = new EventEmitter();
  @Output() changeSortByOption = new EventEmitter();
  @Output() changeAscendingOption = new EventEmitter();
  @Output() searchRequisition = new EventEmitter();

  constructor(readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService); 
      const mapping: any = [];
      super.registerStateChangeEvents(mapping);
    }

  ngOnInit() {
        //init the sort by dropdown
        this.initSortByDropDown();

        // Get the Requistion Details For Approvals
        let searchRequest : SearchRequest = new SearchRequest();
        let parameter_netword_id : Parameter = new Parameter();
        let parameter_not_draft : Parameter = new Parameter();
        let parameter_not_complete : Parameter = new Parameter();
        let parameter_not_complete_with_returns : Parameter = new Parameter();
        let parameter_older_than_thirty_days : Parameter = new Parameter();
        searchRequest.parameters = new Array<Parameter>();
        
        //for my open request and older than 30 days request
        if(this.requestOption === 'open' || this.requestOption === 'old'){
          //for network id
          parameter_netword_id.field = 'Network ID';
          parameter_netword_id.operator = '=';
          parameter_netword_id.value = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
          searchRequest.parameters.push(parameter_netword_id);

          //for not draft
          parameter_not_draft.field = 'Requisition Status';
          parameter_not_draft.operator = '!=';
          parameter_not_draft.value = 'Draft';
          searchRequest.parameters.push(parameter_not_draft);

          //for not complete
          parameter_not_complete.field = 'Requisition Status';
          parameter_not_complete.operator = '!=';
          parameter_not_complete.value = 'Complete';
          searchRequest.parameters.push(parameter_not_complete);

          //for not complete with return
          parameter_not_complete_with_returns.field = 'Requisition Status';
          parameter_not_complete_with_returns.operator = '!=';
          parameter_not_complete_with_returns.value = 'Complete with Returns';
          searchRequest.parameters.push(parameter_not_complete_with_returns);

          //for not include delete
          parameter_not_complete_with_returns.field = 'Requisition Status';
          parameter_not_complete_with_returns.operator = '!=';
          parameter_not_complete_with_returns.value = 'Delete';
          searchRequest.parameters.push(parameter_not_complete_with_returns);
        }

        //for older than 30 days request
        if(this.requestOption === 'old'){
          let dt = new Date();
          dt.setMonth(dt.getMonth() - 1);
          parameter_older_than_thirty_days.field = 'Requisition Date';
          parameter_older_than_thirty_days.operator = '<=';
          parameter_older_than_thirty_days.value = this.getDateFormat(dt);
          searchRequest.parameters.push(parameter_older_than_thirty_days);
        }
        
        searchRequest.networkID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        searchRequest.operand = 'AND';
        searchRequest.excludeComplete = 'Y';
        const searchRequisitions = this.actionDispatcherService.generateEvent(ActionEvents.SEARCH_REQUISITION,searchRequest);
        this.actionDispatcherService.dispatch(searchRequisitions);
        this.searchRequisition.emit();
  }

  onSortBySelection(event){
    //need to do mapping for the option and value
    this.selectedSortByOption = event;
    let sortByOption = VALUEMAP.SORTBY[event];
    this.changeSortByOption.emit(sortByOption);
  }

  onPageSelection(event){
    this.changePageOption.emit(event);
  }

  initSortByDropDown(){
    this.isAscending = false;
    this.defaultPage = DEFAULTPAGEOPTION;
    this.selectedSortByOption = DEFAULTSORTBYOPTION;
    this.defaultSortByOption = DEFAULTSORTBYOPTION;
    this.sortByOptions = SORTBYOPTIONS;
    this.pageOptions = PAGEOPTIONS;
  }

  changeAscending(){
    this.isAscending = !this.isAscending;
    let sortByOption = VALUEMAP.SORTBY[this.selectedSortByOption];
    this.changeAscendingOption.emit({isAscending: this.isAscending, selectedSortOption: sortByOption});
  }

  getDateFormat(date: Date) {
      let d = '';
      d += date.getFullYear();
      d += '-' + (((date.getMonth() + 1) <= 9) ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1));
      d += '-' + date.getDate();
      d += ' ' + ((date.getHours() <= 9) ? '0' + date.getHours() : date.getHours());
      d += ':' + ((date.getMinutes() <= 9) ? '0' + date.getMinutes() : date.getMinutes());
      d += ':' + ((date.getSeconds() <= 9) ? '0' + date.getSeconds() : date.getSeconds());
      return d;
  }
}
