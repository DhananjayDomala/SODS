import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMyOpenRequestComponent } from './search-my-open-request.component';

describe('SearchMyOpenRequestComponent', () => {
  let component: SearchMyOpenRequestComponent;
  let fixture: ComponentFixture<SearchMyOpenRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchMyOpenRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchMyOpenRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
