import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ApproverShipToComponent } from "app/democomponents/approver/approver-ship-to/approver-ship-to.component";
import { ApproverCreditAnalyistShipToComponent } from "app/democomponents/approver/approver-credit-analyst/approver-credit-analyst.component";
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { ReqDetails, TaskInboxCustomer } from "app/model/submitRequisition";


describe('ApproverCreditAnalyistShipToComponent', () => {
  let component: ApproverCreditAnalyistShipToComponent;
  let fixture: ComponentFixture<ApproverCreditAnalyistShipToComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [  ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverCreditAnalyistShipToComponent);
    component = fixture.componentInstance;
    component.reqDetails = new Array<ReqDetails>();
    component.reqDetails[0] = new ReqDetails();
    component.reqDetails[0].customers = new Array<TaskInboxCustomer>();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
