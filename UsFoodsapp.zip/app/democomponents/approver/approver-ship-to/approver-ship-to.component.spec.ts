import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverShipToComponent } from './approver-ship-to.component';
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { ReqDetails, TaskInboxCustomer } from "app/model/submitRequisition";

describe('ApproverShipToComponent', () => {
  let component: ApproverShipToComponent;
  let fixture: ComponentFixture<ApproverShipToComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [  ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverShipToComponent);
    component = fixture.componentInstance;
    component.reqDetails = new Array<ReqDetails>();
    component.reqDetails[0] = new ReqDetails();
    component.reqDetails[0].customers = new Array<TaskInboxCustomer>();
    component.isCollapsed = false;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.reqDetails = new Array<ReqDetails>();
    component.reqDetails[0] = new ReqDetails();
    component.reqDetails[0].customers = new Array<TaskInboxCustomer>();
    expect(component).toBeTruthy();
  });

});
