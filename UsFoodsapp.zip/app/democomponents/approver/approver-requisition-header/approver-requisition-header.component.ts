import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails, OverrideShipTo } from '../../../model/submitRequisition';
import { DivisionsService } from '../../../service/divisions.service';
import { Division } from '../../../model/division';
import { ProductCommentComponent } from '../../common/comment/product-comment/product-comment.component';
import { Comment } from '../../../model/comment';
import { DropdownComponent } from '../../common/dropdown/dropdown.component'
import { OverrideShipToComponent } from 'app/democomponents/common/customer/override-ship-to/override-ship-to.component';
import { String } from 'aws-sdk/clients/es';


@Component({
  selector: 'app-approver-requisition-header',
  templateUrl: './approver-requisition-header.component.html',
  styleUrls: ['./approver-requisition-header.component.css']
})
export class ApproverRequisitionHeaderComponent implements OnInit {

  @ViewChild('OverrideShipTo') overrideShipToComponent: OverrideShipToComponent;
  @ViewChild('Comments') commentsComponent: ProductCommentComponent;
  @ViewChild('sodsDropdown') sodsDropdown: DropdownComponent;
  @ViewChild('viewCommentsTest') viewMsgsToModal: Modal;
  @ViewChild('overrideModal') overrideModal: Modal;
  @ViewChild('viewAuditLogs') viewAuditModal: Modal;
  @ViewChild('editRequestType') editRequestType: Modal;
  @ViewChild('errorChangeReq') errorChangeReq: Modal;
  @ViewChild('areYouSure') areUsureModal: Modal;

  @Input() comments: Comment[];
  @Input() set collapsed(value: boolean) {this.isCollapsed = value;}
  @Input() set dropShip(value: boolean) {this.isDropShip = value;}
  @Input() set market(value: string) {this.marketNumber = value;}
  @Input() reqDetails: ReqDetails;
  @Output('showHide') showHide: EventEmitter<any> = new EventEmitter<any>();
  @Output('addComment') addComment: EventEmitter<any> = new EventEmitter<any>();
  @Output('onReqTypeUpdate') onReqTypeUpdate: EventEmitter<any> = new EventEmitter<any>();

  public requisitionType: string;
  readonly defaultReqType: string = 'Special Order'
  selectedReqType: string;
  taskName: string;
  marketNumber: string;
  overrideModalHeader: string;
  overrideButton: string;
  useOverrideShipto: boolean = false;
  isCollapsed: boolean;
  isDropShip: boolean;
  switchFromSOToDS:boolean = false;
  showOverrideInfo:boolean;
  public selectedIndex: number;
  maxIncidentDescriptionLength = 1000;
  maxSpecialInstructionLength = 100;
  data: any = [];
  audits: any = [];
  reqTypeOptions = [];
  requisitionDetails: ReqDetails;
  divisions: Division[];
  overrideShipToModel: OverrideShipTo;
  taskType: string;
  deepCopyComments: string;
  
  constructor(private divisionService: DivisionsService) { }

  ngOnInit() {
    this.requisitionDetails = this.reqDetails;
    this.requisitionType = this.reqDetails.requisition.requisitionType;
    this.reqTypeOptions = ['Special Order', 'Direct Ship'];
    this.divisions = this.divisionService.getDivisions();
    this.commentsComponent.comments = this.comments;
    this.overrideShipToModel = new OverrideShipTo();
    this.taskType = this.checkTaskNames(this.reqDetails.taskName);
    if(this.reqDetails.requisition.comments.length > 0) {
      if(this.reqDetails.requisition.comments[0].commentsText !== undefined) {
        this.deepCopyComments = this.getRequestorComment(this.reqDetails); // Object.assign({}, this.reqDetails.requisition.comments[0].commentsText);
      }
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.comments) {
      this.commentsComponent.comments = this.comments;
    }
    if (changes.reqDetails) {
      this.requisitionDetails = changes.reqDetails.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  getRequestorComment(reqDetails: ReqDetails) {
    let requestorId = this.reqDetails.requestor.networkID;
    let firstRequestorComment = null;
    for(let m = this.reqDetails.requisition.comments.length - 1; m >= 0; m--) {
      if(this.reqDetails.requisition.comments[m].networkID === requestorId) {
        firstRequestorComment = this.reqDetails.requisition.comments[m].commentsText;
        return firstRequestorComment;
      }
    }
  }

  openViewComments() {
    this.commentsComponent.newAddedCount = 0;
    if (!this.commentsComponent.comments) {
      return;
    }
    this.makeProductCommentsMultiLine(this.commentsComponent.comments);
    this.viewMsgsToModal.open();
  }

  isBuyer2(taskName: String) {
    if (taskName) {
      return taskName.startsWith('Enter PO Creation Method');
    } else {
      return false;
    }
  }

  makeProductCommentsMultiLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let commentArray = comment.commentsText.split(']');
        text += commentArray[0] + ']\n';
        text += commentArray[1];
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  makeProductCommentsOneLine(comments: Comment[]) {
    comments.forEach((comment: Comment, i) => {
      let text = '';
      if (comment.commentsText.indexOf('productNbr') >= 0) {
        let text = comment.commentsText.trim().replace(/\n/g, '');
        this.commentsComponent.comments[i].commentsText = text;
      }
    });
  }

  saveComment() {
    //validation first
    if (this.commentsComponent.commentErr === true) {
      return;
    }
    //if user does not hit add, just close it
    if (this.commentsComponent.newAddFlag === false) {
      
      this.viewMsgsToModal.close();
    } else {
      this.commentsComponent.newAddFlag = false;
      //save to comments array of requisition

      // will need to remove the empty text on the first element
      if (this.commentsComponent.comments[0].commentsText === '') {
        this.commentsComponent.comments.shift();
      }

      this.makeProductCommentsOneLine(this.commentsComponent.comments);

      this.addComment.emit({ 'comment': this.commentsComponent.comments[0] });
      this.viewMsgsToModal.close();
    }
  }

  openAuditLog() {
    if (!this.reqDetails.auditLogs.length) {
      return;
    }
    this.viewAuditModal.open();
  }

  // closeMsgModal() {
    
  //   this.viewMsgsToModal.close();
  // }

  closeMsgModal() {
    if (this.commentsComponent.newAddFlag === true) {
      //cancel without saving so clear out the first item of the comments array
      for (let i = 0; i < this.commentsComponent.newAddedCount; i++) {
        this.commentsComponent.comments.shift();
      }
      //reset the add flag
      this.commentsComponent.newAddFlag = false;
    }
    //clear error
    this.commentsComponent.commentErr = false;
    this.viewMsgsToModal.close();
  }  
  closeAuditModal() {
    this.viewAuditModal.close();
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

  openRType() {
    this.editRequestType.open();
    this.selectedReqType = this.requisitionType;
    this.setDropdownValues(this.requisitionType)

  }

  updateRType() {
    this.requisitionType = this.selectedReqType;
    this.reqDetails.requisition.requisitionType = this.selectedReqType;
    this.onReqTypeUpdate.emit(this.requisitionType);
    this.editRequestType.close();
  }

  closeModal() {

    if (this.requisitionDetails.customers.length > 1 && this.selectedReqType === 'Special Order') {
      this.revertChanges();
      this.editRequestType.close();
      this.errorChangeReq.open();
      return null;
    }

    if (this.selectedReqType === 'Special Order') {
      this.sodsDropdown.selectedOption = 'Direct Ship';
      this.requisitionDetails.requisition.defaultShipMethod = 'Separate'
      this.switchFromSOToDS = true;
      this.onReqTypeSelection('Direct Ship', true);
    } else {
      this.sodsDropdown.selectedOption = 'Special Order';
      this.requisitionDetails.requisition.defaultShipMethod = this.requisitionDetails.requisition.defaultShipMethod;
      this.onReqTypeSelection('Special Order', true);
    }
    this.updateRType();
    this.areUsureModal.close();
  }

  setDropdownValues(val: any) {
    this.sodsDropdown.selectedOption = val;
    this.onReqTypeSelection(val, true);

  }

  revertChanges() {
    this.sodsDropdown.selectedOption = this.selectedReqType;
    this.onReqTypeSelection(this.selectedReqType, true);
    this.editRequestType.open();
    this.areUsureModal.close();
  }

  onReqTypeSelection($event: any, fromCloseModal?: boolean) {
    if ($event !== this.selectedReqType && !fromCloseModal) {
      this.editRequestType.close();
      this.areUsureModal.open();
      return;
    }

    this.selectedReqType = $event;
  }


  closeRTypeModal() {
    this.editRequestType.close();
  }

  closeChangeReq() {
    this.errorChangeReq.close();
    this.closeRTypeModal();
  }

  onUseOverrideCheckBoxChange(value:boolean) {
    this.useOverrideShipto = value;

    if(this.useOverrideShipto == true) {
        this.openAddOverrideShipTo();
    }else if(this.useOverrideShipto == false){
        this.showOverrideInfo = false;
        this.clearOverrideFields();
    }
}

openAddOverrideShipTo() {
    if(this.useOverrideShipto) {
        this.resetOverrideErrors();
        this.clearOverrideFields();
        this.overrideModalHeader = "Add Override Ship-To";
        this.overrideButton = "Add";
        this.overrideModal.open();
    }
}

openEditOverrideShipTo() {
    this.overrideModalHeader = "Edit Override Ship-To";
    this.overrideButton = "Update";
    this.overrideModal.open();
}

closeOverrideShipTo() {
    if(this.overrideButton == "Add") {
        this.useOverrideShipto = false;
    }
    this.overrideModal.close();
}

resetOverrideErrors() {
    this.overrideShipToComponent.errors_exist = false;
    this.overrideShipToComponent.name_required_error = false;
    this.overrideShipToComponent.phone_required_error = false;
    this.overrideShipToComponent.address1_required_error = false;
    this.overrideShipToComponent.address2_required_error = false;
    this.overrideShipToComponent.city_required_error = false;
    this.overrideShipToComponent.state_required = false;
    this.overrideShipToComponent.zip_required_error = false;
    this.overrideShipToComponent.name_required = false;
    this.overrideShipToComponent.phone_required = false;
    this.overrideShipToComponent.address1_required = false;
    this.overrideShipToComponent.city_required = false;
    this.overrideShipToComponent.state_required = false;
    this.overrideShipToComponent.zip_required = false;
}

clearOverrideFields() {
    this.overrideShipToComponent.stateDropdown.selectedOption = "Select";
    this.overrideShipToComponent.overrideShipToModel.name = "";
    this.overrideShipToComponent.overrideShipToModel.phone = "";
    this.overrideShipToComponent.overrideShipToModel.city = "";
    this.overrideShipToComponent.overrideShipToModel.state = "";
    this.overrideShipToComponent.overrideShipToModel.zip = "";
    this.overrideShipToComponent.overrideShipToModel.address1 = "";
    this.overrideShipToComponent.overrideShipToModel.address2 = "";
}

setOverrideShipToFields() {
    this.overrideShipToComponent.checkRequiredAndValidMet();
    if(this.overrideShipToComponent.isValid == true) {
        this.useOverrideShipto = true;
        this.showOverrideInfo = true;
        this.overrideShipToModel.name = this.overrideShipToComponent.overrideShipToModel.name;
        this.overrideShipToModel.phone = this.overrideShipToComponent.overrideShipToModel.phone;
        this.overrideShipToModel.city = this.overrideShipToComponent.overrideShipToModel.city;
        this.overrideShipToModel.state = this.overrideShipToComponent.overrideShipToModel.state;
        this.overrideShipToModel.zip = this.overrideShipToComponent.overrideShipToModel.zip;
        this.overrideShipToModel.address1 = this.overrideShipToComponent.overrideShipToModel.address1;
        this.overrideShipToModel.address2 = this.overrideShipToComponent.overrideShipToModel.address2;
        this.mapOverrideForDetails();
        this.overrideModal.close();
    }
}

  mapOverrideForDetails() {
    if(this.useOverrideShipto == true) {
      this.reqDetails.customers[0].useOverrideShipto = true;
      this.reqDetails.customers[0].overrideShipto = {
        name: this.overrideShipToComponent.overrideShipToModel.name,
        phone: this.overrideShipToComponent.overrideShipToModel.phone,
        city: this.overrideShipToComponent.overrideShipToModel.city,
        state: this.overrideShipToComponent.overrideShipToModel.state,
        zip: this.overrideShipToComponent.overrideShipToModel.zip,
        address1: this.overrideShipToComponent.overrideShipToModel.address1,
        address2: this.overrideShipToComponent.overrideShipToModel.address2
      };
    }else{
      this.reqDetails.customers[0].useOverrideShipto = false;
    }
      
  }

  checkTaskNames(taskName: string) {
    if (taskName === null || taskName === undefined) {
      return "invalid";
    }
    const rules = {
      'Approve Requisition': 'approver',
      "Approve New Item": 'NIA',
      'Approve and Setup Products': 'catMgr',
      'Attach Products and Check Product Status': 'replSpcl',
      'Enter Cost': 'buyer1',
      'Enter PO Creation Method': 'buyer2',
      'Analyze Credit': 'creditAnalyst',
      'Enter PO Number': 'buyerPO',
      'Recalled': 'draft',
      'Draft': 'draft',
      'Returned': 'draft'
    };
    let returnValue = 'invalid';
    let keys = Object.keys(rules);
    keys.forEach((key) => {
      if (taskName.startsWith(key)) {
        returnValue = rules[key];
      }
    });
    return returnValue;
  }

}
