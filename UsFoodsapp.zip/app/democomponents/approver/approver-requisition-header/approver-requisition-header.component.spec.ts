import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverRequisitionHeaderComponent } from './approver-requisition-header.component';
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { DivisionsService } from "app/service/divisions.service";
import { User } from "app/model/user";
import { ReqDetails, TaskInboxCustomer, OverrideShipTo } from "app/model/submitRequisition";
import { Requisition } from "app/model/requisition";
import { Customer } from "app/model/customer";
import { Comment } from '../../../model/comment';
import { SimpleChanges } from "@angular/core/core";

describe('ApproverRequisitionHeaderComponent', () => {
  let component: ApproverRequisitionHeaderComponent;
  let fixture: ComponentFixture<ApproverRequisitionHeaderComponent>;

  beforeEach(async(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [ ],
      providers: [
        DivisionsService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverRequisitionHeaderComponent);
    component = fixture.componentInstance;
    let inputReqDetails: ReqDetails  = new ReqDetails();
    inputReqDetails.requisition.requisitionType = 'SODS-SO';
    inputReqDetails.requisition.requisitionNumber = '1234';
    inputReqDetails.requisition.status = 'returned';
    inputReqDetails.customers = new Array<TaskInboxCustomer>();
    inputReqDetails.customers[0] = {
      'seq': '1',
      'id': '1',
      'dept': 'string',
      'defaultShipMethod': 'string',
      'name': 'string',
      'address1': 'string',
      'city': 'string',
      'state': 'string',
      'zip': 'string',
      'phone': 'string',
      'estimatedOrderAmt': 'string',
      'confidenceCode': 'string',
      'creditCheckStatus': true,
      'useOverrideShipto': true,
      'overrideShipto': new OverrideShipTo()
    }
    component.reqDetails = inputReqDetails;
    spyOn(document, 'getElementById').and.returnValue(new Object());
    fixture.detectChanges();
    expect((<HTMLInputElement>document.getElementById("override-checkbox")).checked).toBeTruthy;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnChanges successfully', ()=>{
    let changes : SimpleChanges = {
    }
    component.ngOnChanges(changes);
    //TODO: we need to figure out a way to test ngOnChanges
  });

  it('should be able to make product comments one line', ()=>{
    let comments = new Array<Comment>();
    comments[0] = new Comment();
    comments[0].commentsText = '[productNbr: 1235] comment test';
    comments[0].name = 'Wen, Liang';
    comments[0].networkID = 'O8N6026';
    comments[0].timestamp = '12-01-2018';
    component.commentsComponent.comments = comments;
    component.makeProductCommentsOneLine(comments);
    expect(component.commentsComponent.comments[0].commentsText).toBe('[productNbr: 1235] comment test');
  });

  it('should be able to make product comments multiple lines', ()=>{
    let comments = new Array<Comment>();
    comments[0] = new Comment();
    comments[0].commentsText = '[productNbr: 1235]comment test';
    comments[0].name = 'Wen, Liang';
    comments[0].networkID = 'O8N6026';
    comments[0].timestamp = '12-01-2018';
    component.commentsComponent.comments = comments;
    component.makeProductCommentsMultiLine(comments);
    expect(component.commentsComponent.comments[0].commentsText).toBe('[productNbr: 1235]\ncomment test');
  });

  it('should close Msg modal successfully', ()=>{
    component.closeMsgModal();
    expect(component.viewMsgsToModal.isOpened).toBeFalsy;
  });

  it('should close Audit modal successfully', ()=>{
    component.closeAuditModal();
    expect(component.viewAuditModal.isOpened).toBeFalsy;
  });

  it('should open Rtype window successfully', ()=>{
    component.openRType();
    expect(component.editRequestType.isOpened).toBeTruthy;
  });

  it('should update Rtype successfully', ()=>{
    component.selectedReqType = 'SODS-SO';
    component.updateRType();
    expect(component.requisitionType).toBe('SODS-SO');
    expect(component.editRequestType.isOpened).toBeFalsy;
  });

  it('should close Rtype modal successfully', ()=>{
    component.closeRTypeModal();
    expect(component.editRequestType.isOpened).toBeFalsy;
  });

  it('should close change req modal successfully', ()=>{
    component.closeChangeReq();
    expect(component.errorChangeReq.isOpened).toBeFalsy;
  });
});
