import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverCategoryManagerProductComponent } from './approver-category-manager-product.component';
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { DivisionsService } from "app/service/divisions.service";
import { User } from "app/model/user";
import { ApproverModule } from "app/democomponents/approver/approver.module";
import { TaskInboxProduct, ReqDetails } from "app/model/submitRequisition";
import { Requisition } from "app/model/requisition";

describe('ApproverCategoryManagerProductComponent', () => {
  let component: ApproverCategoryManagerProductComponent;
  let fixture: ComponentFixture<ApproverCategoryManagerProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ApproverModule],
      declarations: [ ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        DivisionsService,
        User
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const mockSAMCall = {
      loadAttachmentDetails: () => {

      }
    }
    fixture = TestBed.createComponent(ApproverCategoryManagerProductComponent);
    component = fixture.componentInstance;
    component.products = new Array<TaskInboxProduct>();
    spyOn(component.viewProductsComponent, 'loadAttachmentDetails').and.callFake(mockSAMCall.loadAttachmentDetails);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
