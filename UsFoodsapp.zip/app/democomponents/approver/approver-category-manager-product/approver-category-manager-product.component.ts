import { ApproverViewProductAttachmentsComponent } from './../approver-attachment/approver-view-product-attachments/approver-view-product-attachments.component';
import { ModelChangeUpdateEvents, ActionEvents } from './../../../events/action-events';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from './../../base-component';
import { ProductAttachmentComponent } from './../../common/product/product-attachment.component';
import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { TaskInboxProduct } from '../../../model/submitRequisition';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails } from '../../../model/submitRequisition';
import { ProductCommentComponent } from "app/democomponents/common/comment/product-comment/product-comment.component";

@Component({
  selector: 'app-approver-category-manager-product',
  templateUrl: './approver-category-manager-product.component.html',
  styleUrls: ['./approver-category-manager-product.component.css']
})

export class ApproverCategoryManagerProductComponent extends BaseComponent implements OnInit {
  @ViewChild('viewComments') viewMsgsToModal: Modal;
  @ViewChild('viewProduct') viewProdModal: Modal;
  @ViewChild('ProductComments') productComments: ProductCommentComponent; 
  @ViewChild('ViewProductAttachment') viewProductsComponent: ApproverViewProductAttachmentsComponent;
  @ViewChild('ProductAttachmentModal') productAttachmentModal: Modal;

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set accepted(value: boolean) {
      this.isAccepted = value;
  }

  @Input() set validated(value: boolean) {
    this.isValidated = value;
  }

  @Input() set allReturned(value: boolean) {
    this.isAllReturned = value;
  }
  @Input() invalidProducts: number[];
  @Input() products: TaskInboxProduct[];
  @Input() reqDetails: ReqDetails;
  requistionDetails: ReqDetails;
  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();
  @Output('return')
  return: EventEmitter<any> = new EventEmitter<any>();
  @Output('returnAll')
  returnAll: EventEmitter<any> = new EventEmitter<any>();
  @Output('addComment')
  addComment: EventEmitter<any> = new EventEmitter<any>();
  @Output('updateProductNumber')
  updateProductNumber: EventEmitter<any> = new EventEmitter<any>();

  public attachmentsList:Array<any> = [];
  isCollapsed: boolean;
  comments: any[] = [];
  selectedIndex: any;
  productCommentAdded: boolean[] = new Array<boolean>();
  currentProd: any;
  isAllReturned: boolean;
  allChecked = false;
  isAccepted: boolean;
  isValidated: boolean;
  public reqNbr: string;
  public prod_nbr_errors_exist: boolean = false;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];

    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    this.products.forEach((product) => {
      this.productCommentAdded.push(false);
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes.allReturned) {
      this.allChecked = changes.allReturned.currentValue;
    }
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }

  openViewComments(comments, index, seq) {
    this.selectedIndex = index;
    this.comments = [...comments] || [];
    // if (!comments.length) {
    //   return;
    // }

    this.viewMsgsToModal.open();
    this.productComments.newAddedCount = 0;
    this.productComments.comments = this.comments;
    this.productComments.productSeq = seq;
  }

  openViewAttachments(seq) {
    this.viewProductsComponent.attachmentsList = [];
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, 
      {requisitionId: this.reqNbr, attachmentKey:seq});
    this.actionDispatcherService.dispatch(event);
    this.viewProductsComponent.seqId = seq;
    this.productAttachmentModal.open();
  }

  openProd(product) {
    this.currentProd = product;
    this.viewProdModal.open();
  }

  closeMsgModal() {
    if(this.productComments.newAddFlag === true){
      //cancel without saving so clear out the first item of the comments array
      for(let i = 0; i < this.productComments.newAddedCount; i++){
        this.productComments.comments.shift();
      }
      //reset the add flag
      this.productComments.newAddFlag = false;
    }
    //clear error
    this.productComments.commentErr = false;
    this.viewMsgsToModal.close();
  }

  isCommentAddedToProduct(productIndex: number) {
    return this.productCommentAdded[productIndex] === true;
  }

  //save Comment
  saveComment() {
    let newComment = false;
    //validation first
    if (this.productComments.commentErr === true) {
      return;
    }
    //if user does not hit add, just close it
    if (this.productComments.newAddFlag === false) {
      this.viewMsgsToModal.close();
    } else {
      this.productComments.newAddFlag = false;
      //save to comments array of product element
      this.products.forEach((product, index) => {
        if (product.seq === this.productComments.productSeq) {
          //will need to remove the empty text on the first element
          if (this.productComments.comments[0].commentsText === '') {
            this.productComments.comments.shift();
          }
          product.comments = this.productComments.comments;
          product.comments.forEach((comment)=>{
            if(comment.new === true){
              newComment = true;
            }
          });
          this.productCommentAdded[this.selectedIndex] = true;
          this.addComment.emit({'product': this.products[this.selectedIndex], 'newComment': newComment});
        }
      });
      this.viewMsgsToModal.close();
    }
  }


  closeProdModal() {
    this.viewProdModal.close();
  }

  toggleReturnAll() {
    this.allChecked = !this.allChecked;
    this.returnAll.emit({ 'products': this.products, 'returned': this.allChecked });
  }

  returnProduct(product: TaskInboxProduct) { 
    this.return.emit({ 'product': product });
    let productIndex = this.products.findIndex((x) => x.seq === product.seq);
    // check to see if comment exists for product
    if (this.products[productIndex].returned) {
      if (this.isCommentAddedToProduct(productIndex)) {
        return;
      } else {
        // Open a modal to add a new comment to the product
        this.openViewComments(product.comments, productIndex, product.seq);
      }
    }
  }

  isAllProductsReturned() {
    this.products.forEach((product: TaskInboxProduct) => {
    });
    return true;
  }

  handleProdNumBlur(productId, manufacturerId) {
    this.updateProductNumber.emit();
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter((obj) => {
      return obj[property] === value;
    });
  }

  cancelProductAttchment(){
    this.productAttachmentModal.close();
  }

  downloadAll(){
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_MULTI_DOWNLOAD, 
      {requisitionId: this.reqNbr, attachmentsList: this.viewProductsComponent.attachmentsList, 
        attachmentKey: this.viewProductsComponent.seqId });
    this.actionDispatcherService.dispatch(event);
  }

  isInvalid(index): boolean {
    let invalidIndex = 0;
    this.invalidProducts.forEach((invalid) => {
      if (index === invalid) {
        invalidIndex++;
      }
    });
    return invalidIndex > 0;
  }

  validateNumber(data: string, seq: string) {
    this.prod_nbr_errors_exist = false;
    if(this.validateNbr(data)) {
      for(let i = 0; i < this.products.length; i++) {
        if(this.products[i].seq === seq) {
          this.products[i].errorFlag = false;
          this.products[i].nbrError = false;
        }
      }
    }else{
      for(let i = 0; i < this.products.length; i++) {
        if(this.products[i].seq === seq) {
          this.prod_nbr_errors_exist = true;
          this.products[i].errorFlag = true;
          this.products[i].nbrError = true;
        }
      }
    }
  }

  validateNbr(data: string){
		if(data === null || data === undefined || data.trim() === "") {
      return false;
    }
		let NUMBER_REGEXP = /^\d+$/;
		return NUMBER_REGEXP.test(data);
  }

}
