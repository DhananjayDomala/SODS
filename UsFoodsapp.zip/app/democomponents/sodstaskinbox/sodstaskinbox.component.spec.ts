import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SodstaskinboxComponent } from './sodstaskinbox.component';
import { InboxCommentComponent } from "app/democomponents/sodstaskinbox/inbox-comment/inbox-comment.component";
import { ViewAttachmentsComponent } from "app/democomponents/sodstaskinbox/viewattachments.component";
import { routing } from "app/democomponents/sodstaskinbox/sodstaskinbox.routes";
import { SodstaskinboxModule } from "app/democomponents/sodstaskinbox/sodstaskinbox.module";
import { RouterTestingModule } from '@angular/router/testing';
import { ActionDispatcherService, ModelPresenterService, StateRepresentationRendererService, EventTypeRegistryService } from "usf-sam/dist/usf-sam";
import { SodsModelService } from "app/demomodel/sodsmodel.service";
import { AppModule } from "app/app.module";
import { SAMPLECommentArr } from "app/model/comment";
import { SAMPLETASKARR } from "app/model/task";
import { ActionEvents } from "app/events/action-events";
import { Idle, NgIdleModule, IdleExpiry } from "@ng-idle/core";
import { User } from "app/model/user";
import { LoadingService } from '../../service/loading.service'

describe('SodstaskinboxComponent', () => {
  let component: SodstaskinboxComponent;
  let fixture: ComponentFixture<SodstaskinboxComponent>;
  let sendEvent = false;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SodstaskinboxModule,
        RouterTestingModule,
      ],
      declarations: [ ],
      providers:
      [ 
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService,
        SodsModelService,
        Idle,
        LoadingService,
        User,
       {provide: IdleExpiry, useClass: MockExpiry}]
    })
    .compileComponents();
  }));

  beforeEach(() => {

    //mock the data
    //create a mock version of localStorage
    let store = {};
    const mockLocalStorage = {
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
    .and.callFake(mockLocalStorage.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockLocalStorage.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockLocalStorage.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockLocalStorage.clear);

    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': '', 
      applicationMarkets: [{marketName: 'sample', marketNum: 'sample', marketCode: 'sample'}]})}));
    fixture = TestBed.createComponent(SodstaskinboxComponent);
    component = fixture.componentInstance;
    this.sendEvent = false;
    component.actionDispatcherService.dispatch = (ev: any) => {this.sendEvent = true};
    fixture.detectChanges();
  });

  fit('should create component', () => {
    expect(component).toBeTruthy();
  });

  fit('should sort as asc order', () => {
    //init
    component.isDesc = true;
    component.column = '';
    component.direction = 0;
    //execute
    component.sort('taskId');
    //validate
    expect(component.isDesc).toBe(false);
    expect(component.column).toBe('taskId');
    expect(component.direction).toBe(-1);
  });

  fit('should sort as desc order', () => {
    //init
    component.isDesc = false;
    component.column = '';
    component.direction = 0;
    //execute
    component.sort('taskId');
    //validate
    expect(component.isDesc).toBe(true);
    expect(component.column).toBe('taskId');
    expect(component.direction).toBe(1);
  });

  fit('should initialize the comment list array successfully after calling the render function of get comments successfully', 
    () => {
      //init
      let commentsList = SAMPLECommentArr;
      //execute
      component.renderRetrieveCommentsSuccess(commentsList);
      //validate
      expect(component.inboxComments.comments).toBe(commentsList);
      expect(component.inboxCommentModel.isOpened).toBe(true);
    });

  fit('should close the inboxComment model after calling the close() method', () => {
    //init
    //no initialization needed here
    //execute
    component.closeComment();
    //validate
    expect(component.inboxCommentModel.isOpened).toBe(false);
  });

  fit('should open attachments model after calling the openViewAttachments model', () => {
    //init
    let reqId = 1234;
    //execute
    component.openViewAttachments(reqId);
    //validate
    expect(component.viewAttachmentsComponent.requisitionId).toBe(reqId);
    expect(component.viewAttachmentsModal.isOpened).toBe(true);
  });

  fit('should clean out attachment list and close attachment model after calling the closeAttachment model', ()=>{
    //execute
    component.cancelViewAttachments();
    //validate
    expect(component.viewAttachmentsComponent.requisitionId).toBeNull();
    expect(component.viewAttachmentsComponent.attachmentsList).toBeNull();
    expect(component.viewAttachmentsModal.isOpened).toBe(false);
  });

  fit('should initialize the task list and sort as desc order after calling the render task list method', ()=>{
    //init
    let taskList = SAMPLETASKARR;
    //execute
    component.renderTasksLoadedSuccess(taskList);
    //validate
    expect(component.taskList).toBe(taskList);
    expect(component.isDesc).toBe(false);
  });

  //TODO: I think we should have some logic to check if the event has registered successfully
  fit('should generate the event successfully', () => {
    //execute
    component.export();
    component.downloadAll();
    component.openComments("1234");
  });

  fit('should set the out of office successfully', ()=>{
    let data = {
      'outOfOffice': true,
      'designateName': 'test'
    }
    component.onGetOutofOfficeSuccess(data);
    expect(component.selectedType).toBe('outOfOffice');
    expect(component.forwardTask).toBe('test');
  });

  fit('should have the correct page selection', ()=>{
    let event = 'View All';
    component.taskList.length = 1;
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(component.taskList.length);
    event = 'View 50';
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(50);
    event = 'View 100';
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(100);

    event = 'View 500';
    component.onPageSelection(event);
    expect(component.config.itemsPerPage).toBe(10);
  });

  fit('on onPageChange', ()=>{
    component.onPageChange(100);
    expect(component.config.currentPage).toBe(100);
  });

  it('on moveToOutOfOffice', () => {
    spyOn(component, 'moveToOutOfOffice').and.callThrough();
    component.moveToOutOfOffice();
    expect(component.moveToOutOfOffice).toHaveBeenCalled();
  });

  it('on openTaskDetails', () => {
    spyOn(component, 'openTaskDetails').and.callThrough();
    component.openTaskDetails('');
    expect(component.openTaskDetails).toHaveBeenCalled();
  });

  it('on openTaskDetails : case 2', () => {
    spyOn(component, 'openTaskDetails').and.callThrough();
    component.openTaskDetails('Draft');
    expect(component.openTaskDetails).toHaveBeenCalled();

    component.openTaskDetails('Returned');
    expect(component.openTaskDetails).toHaveBeenCalled();

    component.openTaskDetails('Recalled');
    expect(component.openTaskDetails).toHaveBeenCalled();
  });

  it('on openReqDetails', () => {
    spyOn(component, 'openReqDetails').and.callThrough();
    component.openReqDetails('');
    expect(component.openReqDetails).toHaveBeenCalled();
  });
});

export class MockExpiry extends IdleExpiry {
  public lastDate: Date;
  public mockNow: Date;

  last(value?: Date): Date {
    if (value !== void 0) {
      this.lastDate = value;
    }

    return this.lastDate;
  }

  now(): Date {
    return this.mockNow || new Date();
  }
}