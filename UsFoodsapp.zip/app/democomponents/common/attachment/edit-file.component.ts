import { BaseComponent } from "./../../base-component";
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";
import { ObjectKey } from "./../../../model/objectKey";
import { ALERTS } from '../alert/alerts';
import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild
} from "@angular/core";
import {
  ModelChangeUpdateEvents,
  ActionEvents
} from "./../../../events/action-events";
import {
  ActionDispatcherService,
  StateRepresentationRendererService,
  Event
} from "usf-sam";
import {
  Http,
  Response,
  Headers,
  RequestOptions,
  ResponseContentType
} from "@angular/http";

@Component({
  selector: "app-edit-file",
  templateUrl: "./edit-file.component.html",
  styleUrls: ["./edit-file.component.css"]
})
export class EditFileComponent extends BaseComponent implements OnInit {
  objectKey: string;
  requisitionId: string;
  fileName: string;
  listOfFiles: Array<ObjectKey> = [];
  @Output() notify = new EventEmitter();
  fileTypeOptions: string[];
  readonly defaultFileType: string = "";
  selectFileType: string;
  otherSelected: boolean = false;
  otherFileType: string;
  public other_require_error: boolean = false;
  public invalid_format: boolean = false;
  public file_type_error: boolean = false;
  public valid_format_error: boolean = false;
  public error_on_upload: boolean = false;
  // For Alert Text Bar
  public showAlert = false;
  public alertType = '';
  public alertMessage = '';
  public alertSettings = [{ alertType: '', alertMessage: '' }];

  @ViewChild("fileTypeDropdown") fileTypeDropDown: DropdownComponent;
  originalFileType: string;

  constructor(
    private http: Http,
    readonly actionDispatcherService: ActionDispatcherService,
    readonly stateRepresentationRendererService: StateRepresentationRendererService
  ) {
    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL] = () => {
      this.renderError();
    };
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_EDIT_SUCCESS] = () => {
      this.closeModal();
    };
    mapping[ModelChangeUpdateEvents.REQ_ID_GENERATED_SUCCESS] = (
      reqId: string
    ) => {
      this.renderReqIdGenerated(reqId);
    };
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    this.fileTypeOptions = [
      "",
      "Signed Order",
      "Customer Quote",
      "Order Acknowledgement",
      "Vendor Acknowledgement",
      "Spec Sheets",
      "Other"
    ];
  }
  renderReqIdGenerated(reqId) {
    this.requisitionId = reqId;
  }

  onFileTypeSelection($event) {
    this.selectFileType = $event;
    //Reset other input validations & error checks
    this.other_require_error = false;
    this.invalid_format = false;
    this.valid_format_error = false;
    if (this.selectFileType === "Other") {
      this.otherSelected = true;
      this.file_type_error = false;
    } else if (this.selectFileType === "") {
      this.file_type_error = true;
      this.otherSelected = false;
    } else {
      this.otherFileType = "";
      this.otherSelected = false;
      this.file_type_error = false;
    }
  }

  save() {
    this.listOfFiles.push({
      objectKey: this.objectKey,
      fileName: this.fileName,
      requisitionId: this.requisitionId
    });
    if (this.selectFileType === "Other") {
      if (this.listOfFiles.length > 0) {
        let isValid = this.validate();
        if (!isValid) {
          this.invalid_format = false;
          this.valid_format_error = false;
          let event = this.actionDispatcherService.generateEvent(
            ActionEvents.REQ_ATTACHMENTS_EDIT,
            {
              requisitionId: this.requisitionId,
              fileType: this.otherFileType,
              attachmentsList: this.listOfFiles
            }
          );
          this.actionDispatcherService.dispatch(event);
        } else {
          this.other_require_error = false;
          this.invalid_format = true;
          this.valid_format_error = true;
        }
      }
    } else {
      if (this.selectFileType !== "Other") {
        if (this.selectFileType === "") {
          this.file_type_error =
            this.selectFileType === null ||
            this.selectFileType === undefined ||
            this.selectFileType.trim() === ""
              ? true
              : false;
        } else {
          let event = this.actionDispatcherService.generateEvent(
            ActionEvents.REQ_ATTACHMENTS_EDIT,
            {
              requisitionId: this.requisitionId,
              fileType: this.selectFileType,
              attachmentsList: this.listOfFiles
            }
          );
          this.actionDispatcherService.dispatch(event);
        }
      }
    }
  }

  cancel() {
    this.notify.emit("closeEditFileModal");
  }

  checkKeyupRequire_other() {
    this.other_require_error =
      this.otherFileType === null ||
      this.otherFileType === undefined ||
      this.otherFileType.trim() === ""
        ? true
        : false;
    this.invalid_format = false;
    this.valid_format_error = false;
  }

  validate() {
    return !/^[a-z0-9]+$/i.test(this.otherFileType.trim().replace(/\s/g, ""));
  }

  renderError() {
    this.error_on_upload = true;
    this.showAlert = true;
    this.showAlertMessage('error', 'attachmentNotSaved');
  }

  closeModal() {
    this.notify.emit("closeEditFileModal");
  }

  handleAlert(alertSettings: any) {
    // this.showAlert = false;
    this.alertSettings = alertSettings;
    this.showAlert = true;
  }

  showAlertMessage(alertType: string, alertText: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert = { alertType: alertType, alertMessage: this.alertMessage };
    this.alertSettings.push(alert);
    this.showAlert = true;
  }
}
