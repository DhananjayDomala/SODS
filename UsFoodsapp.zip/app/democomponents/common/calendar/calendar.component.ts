import { Component, OnInit, AfterViewInit, Input, Output, EventEmitter, HostBinding, ViewEncapsulation, ViewChild, HostListener, ElementRef, forwardRef } from '@angular/core';
import { CalendarModule, Calendar } from 'primeng/primeng';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

export interface USFCalendarSettings {
  value: Date;
  maxDate?: Date;
  minDate?: Date;
  width: string;
  smBtn?: boolean;
  error: boolean;
  inputStyleClass: string[];
  styleClass: string[];
  overlayVisible?: boolean;
}

@Component({
  selector: 'sods-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CalendarComponent implements OnInit, AfterViewInit {

  isVisible = false;
  @Input() settings: USFCalendarSettings;
  @Output() selectionDone = new EventEmitter();
  @Output() onMonthChange = new EventEmitter();
  @Output() errorEmitter = new EventEmitter();

  @ViewChild('child1')
  child1: Calendar;

  @ViewChild('child2')
  child2: Calendar;

  @ViewChild('child3')
  child3: Calendar;

  @ViewChild('child4')
  child4: Calendar;

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {

  }

  select() {
    this.selectionDone.emit(this.settings.value);
  }

  monthChange() {
    this.onMonthChange.emit();
  }

  close($event) {
  }


  checkDate() {
    
    if (this.checkFilled()) {
      this.errorEmitter.emit('');
      return;
    }

    if (this.hasError()) {
      this.errorEmitter.emit('error');
    }
  }

  private checkChild1Filled() {
    return (!this.settings.smBtn && !this.settings.error && !this.child1.filled) ? true : false;
  }

  private checkChild2Filled() {
    return (!this.settings.smBtn && this.settings.error && !this.child2.filled) ? true : false;
  }

  private checkChild3Filled() {
    return (this.settings.smBtn && !this.settings.error && !this.child3.filled) ? true : false
  }

  private checkChild4Filled() {
    return (this.settings.smBtn && this.settings.error && !this.child4.filled) ? true : false;
  }

  private checkFilled() {
    let child1Filled = this.checkChild1Filled();
    let child2Filled = this.checkChild2Filled();
    let child3Filled = this.checkChild3Filled();
    let child4Filled = this.checkChild4Filled();
    return (child1Filled || child2Filled || child3Filled || child4Filled) ? true : false;
  }

  private hasError() {
    return (this.settings.value === null || this.settings.value === undefined || this.settings.value < this.settings.minDate) ? true : false;
  }

}
