export const DEFAULTSORTBYOPTION = 'Requisition ID';
export const DEFAULTPAGEOPTION = '10';
export const SORTBYOPTIONS = [
    'Created By',
    'Customer Name',
    'Customer PO #',
    'Date Created',
    'Department',
    'Last Updated',
    'Requisition ID',
    'Requisition Status',
    'Requisition Type',
    'Seller'
];

export const PAGEOPTIONS = [
    '10',
    '50',
    '100'
];

export const VALUEMAP = {
    'SORTBY': {
        'Created By' : 'requestor',
        'Customer Name' : 'customerName',
        'Customer PO #' : 'customerPO',
        'Date Created' : 'requestedDate',
        'Department' : 'customerDept',
        'Last Updated' : 'lastUpdateDate',
        'Requisition ID' : 'reqID',
        'Requisition Status' : 'status',
        'Requisition Type' : 'reqType',
        'Seller' : 'seller'
    },

    'PRODUCTTYPE': {
        '01' : 'COP',
        '02' : 'COP',
        '03' : 'Grocery',
        '04' : 'COP',
        '05' : 'Grocery',
        '06' : 'Grocery',
        '07' : 'Produce',
        '08' : 'Grocery',
        '09' : 'Grocery',
        '10' : 'Grocery',
        '11' : 'Grocery',
        '12' : 'Non-Food',
        '13' : 'Non-Food',
        '14' : 'CES',
        '15' : 'Grocery',
        '16' : 'Non-Food',
        '17' : 'Non-Food',
        '18' : 'COP'
    },

    'SHIPMETHOD': {
        'N' : 'Next',
        'S' : 'Separate'
    }
}


// export const SEARCHBYOPTIONS = [
//     'Requisition ID',
//     'Requisition Type',
//     'Requisition Status',
//     'Division',
//     'Network ID',
//     'Requisition Date',
//     'Ship-To Customer Name',
//     'Ship-To Customer Number',
//     'Product #',
//     'Product Description',
//     'MFG Product #',
//     'Product Type',
//     'PO Date',
//     'Requested ETA',
//     'Actual ETA',
//     'Meets ETA',
//     'Customer PO #',
//     'PO Number',
//     'Sales Order Number',
//     'Sales Order Date',
//     'Delivery Date',
//     'Invoice Number',
//     'Invoice Date',
//     'Vendor Number',
//     'Vendor Name',
//     'Buyer Number',
//     'Quote Number'
// ];

export const OPERATOROPTIONS = {
    'Requisition ID': ['Equals'],
    'Requisition Type': ['Equals'],
    'Requisition Status': ['Equals'],
    'Ship-To Customer Name': ['Contains'],
    'Ship-To Customer Number': ['Equals'],
    'Customer PO #': ['Equals'],
    'Product #': ['Equals'],
    'Product Description': ['Contains'],
    'MFG Product #': ['Equals'],
    'Division': ['Equals'],
    'Product Type': ['Equals'],
    'PO Number': ['Equals'],
    'PO Date': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Network ID': ['Equals'],
    'Requisition Date': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Requested ETA': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Actual ETA': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Meets ETA': ['Equals'],
    'Sales Order Number': ['Equals'],
    'Sales Order Date': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Delivery Date': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Invoice Number': ['Equals'],
    'Invoice Date': ['Equals', 'Greater than', 'Less than', 'Greater than equal to', 'Less than equal to'],
    'Vendor Name': ['Contains'],
    'Vendor Number': ['Equals'],
    'Buyer Number': ['Equals'],
    'Quote Number': ['Equals']
};

export const VALUEOPTIONS = {
    // empty array is for input field
    // string array is for drop down options
    // date in string array is a flag to show calendar input field
    'Requisition ID': ['integer'],
    'Actual ETA': ['date'],
    'Buyer Number': ['integer'],
    'Customer PO #': ['string'],
    'Delivery Date': ['date'],
    'Division': ['string'],
    'Invoice Date': ['date'],
    'Invoice Number': ['integer'],
    'Meets ETA': ['yes', 'no'],
    'MFG Product #': ['string'],
    'Network ID': ['string'],
    'PO Date': ['date'],
    'PO Number': ['integer'],
    'Product #': ['integer'],
    'Product Description': ['string'],
    'Product Type': ['CES', 'COP', 'Grocery', 'Non-Food', 'Produce'],
    'Quote Number': ['string'],
    'Requisition Date': ['date'],
    'Requested ETA': ['date'],
    'Requisition Status': ['Draft', 'Recalled', 'Returned', 'Cancelled', 'Pending Product/Vendor Setup', 
        'Pending Credit Review', 'Pending Approval', 'Pending Buyer', 'Purchasing/Ordering/Shipping in Progress', 
        'Complete', 'Complete with Returns'],
    'Requisition Type': ['Special Order', 'Direct Ship Order'],
    'Sales Order Date': ['date'],
    'Sales Order Number': ['integer'],
    'Ship-To Customer Name': ['string'],
    'Ship-To Customer Number': ['integer'],
    'Vendor Name': ['string'],
    'Vendor Number': ['integer']
};
