import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolTipLabel } from './tooltip-label.component';

describe('ToolTipLabel', () => {
  let component: ToolTipLabel;
  let fixture: ComponentFixture<ToolTipLabel>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToolTipLabel ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolTipLabel);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
