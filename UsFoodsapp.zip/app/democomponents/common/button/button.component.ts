import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

export interface USFoodsButtonSettings {
  width: string;
  height: string;
  marginLeft: string;
  marginRight: string;
  text: string;
  css: string[];
}

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {

  disabled: boolean;

  @Input() settings: USFoodsButtonSettings;

  @Output('buttonClick')
  buttonClick: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
    this.disabled = false;
  }

  onButtonClick($event: any) {
    this.buttonClick.emit({'event': this.settings.text});
  }

}
