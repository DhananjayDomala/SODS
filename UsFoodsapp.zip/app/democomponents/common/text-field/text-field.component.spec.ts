import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TextFieldComponent } from './text-field.component';
import { Component, OnInit, Input, Output, EventEmitter, ViewChild, Directive, DebugElement } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidatorDirective } from 'app/directive/validator.directive';
import { By } from '@angular/platform-browser';

describe('TextFieldComponent', () => {
  let component: TextFieldComponent;
  let fixture: ComponentFixture<TextFieldComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [TextFieldComponent, ValidatorDirective]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('should create', () => {
    expect(component).toBeTruthy();
  });

  fit('should store and return input value', () => {
    const value = '12345';
    component.usfTextfieldSettings = {
      width: '290',
      height: '36',
      marginLeft: '5',
      marginRight: '0',
      required: true,
      valid: false,
      validationType: 'integer',
      errorText: 'Please enter a valid number.',
      value: 'abc',
      id: '',
      disabled: false
    };
    expect(component.writeValue(value)).toEqual('12345');
  });

  fit('should detect invalid input for integer only field.', () => {
    component.usfTextfieldSettings = {
      width: '290',
      height: '36',
      marginLeft: '5',
      marginRight: '0',
      required: true,
      valid: false,
      validationType: 'integer',
      errorText: 'Please enter a valid number.',
      value: 'abc',
      id: '',
      disabled: false
    };
    let input = fixture.debugElement.query(By.css('input'));
    let el = input.nativeElement;
    // el.value = 'abc';
    // el.dispatchEvent(new Event('input'));
    el.value = 'lsdkfjlsdkjflk';
    el.dispatchEvent(new Event('input'));
    const event = new KeyboardEvent("keyup");

    expect(component.onKeyUpEvent(event)).toBeTruthy();
    expect(component.inputTxtField.hasError('validator')).toBeTruthy();
    expect(component.inputTxtField.hasError('required')).toBeFalsy();
  });

  fit('should detect when no input for required field.', () => {
    component.usfTextfieldSettings = {
      width: '290',
      height: '36',
      marginLeft: '5',
      marginRight: '0',
      required: true,
      valid: false,
      validationType: 'integer',
      errorText: 'Please enter a valid number.',
      value: 'abc',
      id: '',
      disabled: false
    };
    component.inputTxtField.control.setValue('');
    const event = new KeyboardEvent("keyup");
    expect(component.onKeyUpEvent(event)).toBeTruthy();
    expect(component.inputTxtField.hasError('required')).toBeTruthy();
    expect(component.inputTxtField.hasError('validator')).toBeFalsy();
  });

  fit('should allow valid input for integer only field.', () => {
    component.inputTxtField.control.setValue('10238923');
    const event = new KeyboardEvent("keyup");
    expect(component.onKeyUpEvent(event)).toBeFalsy();
    expect(component.inputTxtField.hasError('required')).toBeFalsy();
    expect(component.inputTxtField.hasError('validator')).toBeFalsy();
  });

});
