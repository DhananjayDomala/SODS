import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidatorDirective } from 'app/directive/validator.directive';
import { TextFieldComponent } from 'app/democomponents/common/text-field/text-field.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [ValidatorDirective, TextFieldComponent],
  exports: [
      ValidatorDirective,
      TextFieldComponent
  ]
})
export class TextFieldModule { }
