import { Component, OnInit, OnChanges, Input, Output, EventEmitter, ViewEncapsulation, ViewChild, Renderer, ContentChildren } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormGroup, FormControl, NgModel, ControlValueAccessor, Validators, ValidatorFn, NG_VALIDATORS, Validator } from '@angular/forms';
import { Element } from '@angular/compiler';
import { ElementRef } from '@angular/core/src/linker/element_ref';
import { AfterViewChecked } from '@angular/core/src/metadata/lifecycle_hooks';

export interface TypeaheadSettings {
  required?: boolean;
  label?: string;
  selected: string;
  results: any[];
  scrollable: boolean;
  validationType: string;
  errorMessageTxt: string;
  validated?: boolean;
  valid: boolean;
  placeholderTxt: string;
  marginLeft?: string;
  marginRight?: string;
  tooltip?: boolean;
  css: string[];
}

@Component({
  selector: 'app-typeahead',
  templateUrl: './typeahead.component.html',
  styleUrls: ['./typeahead.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: TypeaheadComponent, multi: true }
  ],
  encapsulation: ViewEncapsulation.None
})

export class TypeaheadComponent implements OnInit, OnChanges, ControlValueAccessor, AfterViewChecked {
  @Input() settings: TypeaheadSettings;
  @Output() loadingEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() valueSelectEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() validate: EventEmitter<any> = new EventEmitter<any>();
  onChange;
  @ViewChild('inputTxtField') inputTxtField: NgModel;
  @ViewChild('input') input;

  constructor() { }

  ngOnInit() {
    
  }

  ngOnChanges(changes) {
    this.settings = changes.settings.currentValue;
  }
  
  ngAfterViewChecked() {

  }
  writeValue(value: string): string {
    
    return this.settings.selected;
  }

  registerOnChange(fn) {
    this.onChange = fn;
  }

  registerOnTouched(fn) { }

  typeaheadLoading($event) {
    this.loadingEvent.emit($event);
  }

  typeaheadOnSelect($event) {
    this.valueSelectEvent.emit($event);
  }

  onKeyUp($event) {
    this.settings.validated = true;
    if(this.settings.valid) {

      if (this.inputTxtField.hasError('required') || this.inputTxtField.hasError('validator')) {
        this.validate.emit({ 'valid': false });
      }
    }
    return this.inputTxtField.hasError('required') || this.inputTxtField.hasError('validator');
  }
}
