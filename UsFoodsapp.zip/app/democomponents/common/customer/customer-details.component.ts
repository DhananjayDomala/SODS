import { Router } from '@angular/router';
import { SamService } from 'app/service/sam.service';
import { USFCalendarSettings } from 'app/democomponents/common/calendar/calendar.component';
import { Component, OnInit, ViewChild, Output, Input } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { BaseComponent } from '../../base-component';
import { EditCustomerComponent } from './edit-customer.component'
import { DropdownComponent } from '../dropdown/dropdown.component'
import { OverrideShipToComponent } from 'app/democomponents/common/customer/override-ship-to/override-ship-to.component';
import { OverrideShipTo } from 'app/model/submitRequisition';

@Component({
    selector: 'sods-customer-details',
    templateUrl: './customer-details.component.html',
    styleUrls: ['./customer-details.component.css']
})

export class CustomerDetailsComponent extends BaseComponent implements OnInit {
    @ViewChild('shipMethodDP') shipMethodDP: DropdownComponent;

    public selectedReqType: string;
    public selectedDept: string;
    public defaultDept: string;

    readonly defaultShip: string = 'Next';
    public selectedShip: string;
    private shipOptions: string[] = ['Next', 'Separate'];
    reqStatus = '';

    readonly defaultETA: string = 'Select Date';
    public selectedETA: string = 'Select Date';
    public notMet: boolean = false;
    private etaOptions: string[] =
    ['Select Date', 'ASAP 3 Week Max', 'ASAP 4 Week Max', 'ASAP No Maximum', 'Custom Date'];

    public selectVisable = true;
    public calenderHidden = true;
    public shipElementsHidden = true;
    public useOverrideShipto: boolean = false;

    // For Calendar
    public calendarSettings: USFCalendarSettings = {
        value: new Date(),
        minDate: new Date(),
        // maxDate: new Date(),
        width: '255',
        smBtn: false,
        error: false,
        inputStyleClass: ['calendar-input-255'],
        styleClass: ['calendar-component']
    }

    //validation
    public quoteValid = true;
    public quoteNumValid = true;
    public dateValid = true;
    public date_selection_error = false;

    // seq: string;
    maxIncidentDescriptionLength = 1000;
    maxSpecialInstructionLength = 100;
    customerPOMaxLength = 20;
    id: string;
    division: string;
    dept: string;
    name: string;
    defaultShipMethod: string;
    address: string;
    postalInfo: string;
    phone: string;
    quotePrice: string;
    quoteNbr: string;
    comments: string;
    specialInstruct: string;
    customerPO: string;
    estimatedOrderAmt: string;
    confidenceCode: string;
    creditCheckStatus: string;
    marketOptions: any = [];
    deptOptions: any = [];
    divisionObj: Object;
    date: string;
    //Add customer type here
    customerType: string;
    public copyError: boolean = false;
    //add this field for checking selectedMarket
    originMarket: string;

    //Override Ship-To Modal
    overrideModalHeader: string;
    overrideButton: string;
    showOverrideInfo:boolean;

    @ViewChild('CustomerModal')
    updateModal: Modal;

    @ViewChild('overrideModal')
    overrideModal: Modal;

    @ViewChild('CustomerUpdate')
    editCustomer: EditCustomerComponent;

    @ViewChild('OverrideShipTo') 
    overrideShipToComponent: OverrideShipToComponent;

    overrideShipToModel: OverrideShipTo;


    constructor(private router: Router, private samService: SamService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }

    ngOnInit() {
        this.overrideShipToModel = new OverrideShipTo();
        try {
            this.populateMarketDropdown();
            this.selectedShip = this.defaultShip;
            this.selectedETA = this.defaultETA;
            this.editCustomer.error = true;
            this.calendarSettings.minDate = new Date();
            this.calendarSettings.value = null;
        } catch (err) {

        }

    }

    onDeptSelection($event) {
        this.selectedDept = $event;
        try {
            this.callSamService(ActionEvents.DEPARTMENT_CHANGE, this.selectedDept);
            this.callSamService(ActionEvents.REQ_CHANGE_EVT, '');
        } catch (e) { }

    }
    onShipmentSelection($event) {
        this.selectedShip = $event;
        this.selectedShip = (Array.isArray($event)) ? 'Next' : $event;
        if (this.selectedShip === 'Next') {
            this.shipElementsHidden = true;
        }else{
            this.shipElementsHidden = false;
        }
        this.callSamService(ActionEvents.REQ_CHANGE_EVT, '');
        this.callSamService(ActionEvents.SHIPMENT_CHANGE, 
            { 
                'shipMethod': this.selectedShip, 
                'customerPO': this.customerPO, 
                'specialInstruct': this.specialInstruct 
            });
    }

    changeShipmentMethod() {
        this.callSamService(ActionEvents.SHIPMENT_CHANGE, 
            { 'shipMethod': this.selectedShip, 'customerPO': this.customerPO, 'specialInstruct': this.specialInstruct });
    }

    onETASelection($event) {
        this.selectedETA = $event;
        this.date_selection_error = false;

        if (this.selectedETA === 'Select Date' || this.selectedETA === 'ASAP No Maximum' || this.selectedETA === 'Custom Date') {
            this.calendarSettings.value = null;
        } else if (this.selectedETA !== 'Custom Date') {
            this.calendarSettings.value = new Date();
        }

        const no_of_days_added = (this.selectedETA === 'ASAP 3 Week Max') ? 3 * 7 : (this.selectedETA === 'ASAP 4 Week Max') ? 4 * 7 : 0
        if (no_of_days_added && this.calendarSettings.value) {
            this.calendarSettings.value.setDate(this.calendarSettings.value.getDate() + no_of_days_added)
        }

        this.callSamService(ActionEvents.REQ_CHANGE_EVT, '');
        this.callSamService(ActionEvents.CALENDAR_CHANGE, this.calendarSettings.value);


    }

    onDateSelectionDone($event) {
        this.calendarSettings.value = $event;
        this.selectedETA = 'Custom Date';
        this.date_selection_error = false;
        this.callSamService(ActionEvents.CALENDAR_CHANGE, $event);
        this.callSamService(ActionEvents.REQ_CHANGE_EVT, '');
    }

    customerCheckbox(e) {
        this.notMet = e.target.checked
    }

    onErrorHandler($event) {
        this.date_selection_error = true;
        if ($event !== 'error') {
            this.date_selection_error = false;
            this.selectedETA = 'Custom Date';
            this.callSamService(ActionEvents.CALENDAR_CHANGE, $event);
        }
    }

    checkQuote() {
        if (this.quotePrice === "") {
            this.quoteValid = true;
            return;
        }

        if (this.validateQuotePrice(this.quotePrice)) {
            this.quoteValid = true;
            //checks for whole integers (ex. 32) and converts to 32.00
            if (this.quotePrice.indexOf('.') === -1 && !(this.quotePrice.charAt(0) === '.')){
                this.quotePrice = this.quotePrice.concat('.00');
            }
            //checks for .xx and converts to 0.xx
            if (this.quotePrice.charAt(0) === '.'){
                this.quotePrice = '0'.concat(this.quotePrice);
            }
        } else {
            this.quoteValid = false;
        }
    }


    checkQuoteNum() {
        if (this.quoteNbr === "") {
            this.quoteNumValid = false;
            return;
        } else {
            this.quoteNumValid = true;
        }

    }

    checkDate() {
        if (this.validateETA(this.date)) {
            this.dateValid = true;
        } else {
            this.dateValid = false;
        }
    }

    validateQuotePrice(quote: string): boolean {
        if (quote === null || quote === undefined || quote.toString().trim() === ""){
            return true;
        }
        let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
        return QUOTE_REGEXP.test(quote);
    }

    validateETA(date: string): boolean {
        if (date === null || date === undefined || date.toString().trim() === ""){
            return true;
        }
        let DATE_REGEXP =
            /^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d$/
        return DATE_REGEXP.test(date);
    }

    open() { 
        this.updateModal.open(); }

    close() { this.updateModal.close(); }

    cancel() {
        this.updateModal.close();
        this.editCustomer.error = false;
        this.editCustomer.id = "";
    }

    update() {
        this.setBusy(true); 
        this.callSamService(ActionEvents.REQ_CHANGE_EVT, '');
        if (this.originMarket !== this.editCustomer.selectedMarket) {
            this.router.navigate(['/sodsnew']);
            window.location.reload(); 
        } else {
            this.editCustomer.error = false;
            this.callSamService('retrieveCustomer', {id: this.editCustomer.id.trim(), division: this.editCustomer.selectedMarket});
        }
    }

    //Populates user designated markets in drop-down
    private populateMarketDropdown() {
        let array = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).applicationMarkets;
        let marketOptions = [];

        array.forEach(element => {
            let dropdownValue = {}
            dropdownValue['distributionName'] = element.marketName;
            dropdownValue['divisionCode'] = element.marketCode;
            dropdownValue['divisionNumber'] = element.marketNum;
            marketOptions.push(dropdownValue);
        });


        console.log('we are here....');

        this.editCustomer.marketOptions = marketOptions;
        this.editCustomer.selectedMarket = marketOptions[0];
    }

    errorHandle(status: Boolean) {
        if (status) {
            this.editCustomer.error = true;
        } else {
            this.editCustomer.error = false;
            this.updateModal.close();
        }
    }

    checkComment() {
        this.comments = this.comments.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    }


    onUseOverrideCheckBoxChange(value:boolean) {
        this.useOverrideShipto = value;

        if(this.useOverrideShipto == true) {
            this.openAddOverrideShipTo();
        }else if(this.useOverrideShipto == false){
            this.showOverrideInfo = false;
            this.clearOverrideFields();
        }
    }

    openAddOverrideShipTo() {
        if(this.useOverrideShipto) {
            this.resetOverrideErrors();
            this.clearOverrideFields();
            this.overrideModalHeader = "Add Override Ship-To";
            this.overrideButton = "Add";
            this.overrideModal.open();
        }
    }

    openEditOverrideShipTo() {
        this.overrideModalHeader = "Edit Override Ship-To";
        this.overrideButton = "Update";
        this.overrideModal.open();
    }

    closeOverrideShipTo() {
        if(this.overrideButton == "Add") {
            this.useOverrideShipto = false;
        }
        this.overrideModal.close();
    }

    resetOverrideErrors() {
        this.overrideShipToComponent.errors_exist = false;
        this.overrideShipToComponent.name_required_error = false;
        this.overrideShipToComponent.phone_required_error = false;
        this.overrideShipToComponent.address1_required_error = false;
        this.overrideShipToComponent.address2_required_error = false;
        this.overrideShipToComponent.city_required_error = false;
        this.overrideShipToComponent.state_required = false;
        this.overrideShipToComponent.zip_required_error = false;
        this.overrideShipToComponent.name_required = false;
        this.overrideShipToComponent.phone_required = false;
        this.overrideShipToComponent.address1_required = false;
        this.overrideShipToComponent.city_required = false;
        this.overrideShipToComponent.state_required = false;
        this.overrideShipToComponent.zip_required = false;
    }

    clearOverrideFields() {
        this.overrideShipToComponent.stateDropdown.selectedOption = "Select";
        this.overrideShipToComponent.overrideShipToModel.name = "";
        this.overrideShipToComponent.overrideShipToModel.phone = "";
        this.overrideShipToComponent.overrideShipToModel.city = "";
        this.overrideShipToComponent.overrideShipToModel.state = "";
        this.overrideShipToComponent.overrideShipToModel.zip = "";
        this.overrideShipToComponent.overrideShipToModel.address1 = "";
        this.overrideShipToComponent.overrideShipToModel.address2 = "";
    }

    setOverrideShipToFields() {
        this.overrideShipToComponent.checkRequiredAndValidMet();
        if(this.overrideShipToComponent.isValid == true) {
            this.useOverrideShipto = true;
            this.showOverrideInfo = true;
            this.overrideShipToModel.name = this.overrideShipToComponent.overrideShipToModel.name;
            this.overrideShipToModel.phone = this.overrideShipToComponent.overrideShipToModel.phone;
            this.overrideShipToModel.city = this.overrideShipToComponent.overrideShipToModel.city;
            this.overrideShipToModel.state = this.overrideShipToComponent.overrideShipToModel.state;
            this.overrideShipToModel.zip = this.overrideShipToComponent.overrideShipToModel.zip;
            this.overrideShipToModel.address1 = this.overrideShipToComponent.overrideShipToModel.address1;
            this.overrideShipToModel.address2 = this.overrideShipToComponent.overrideShipToModel.address2;
            this.overrideModal.close();
        }
    }

    callSamService(eventTypeName: string, data: any) {
        this.samService.callAction(eventTypeName, data);
    }
    setBusy(status: boolean) {
        this.callSamService(ActionEvents.SET_BUSY_STATUS, status);
    }

}