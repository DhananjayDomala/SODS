import { AlertSetting } from './../alert/alert.component';
import { CreateRequisitionComponent } from './../createRequisition/createRequisition.component';
import { any } from 'codelyzer/util/function';
import { ActionEvents, ModelChangeUpdateEvents } from './../../../events/action-events';
import { environment } from './../../../../environments/environment';
import { RequestOptions, Http, Response, Headers, ResponseContentType } from '@angular/http';
import { Component, OnInit, ViewChild, Output, Input, ElementRef, HostListener } from '@angular/core'; 
import { Modal, ModalModule } from 'ngx-modal';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from '../../base-component';
import { Product, Vendor } from '../../../model/product';
import { Comment} from '../../../model/comment';
import { Form } from '@angular/forms';
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";
import { CalendarComponent, USFCalendarSettings } from "app/democomponents/common/calendar/calendar.component";
import { USFDropdownMenuSettings, USFDropdownComponent } from 'app/democomponents/common/dropdown/usf-dropdown/dropdown.component';
import { ALERTS } from 'app/democomponents/common/alert/alerts';

@Component({
  selector: 'sods-add-new-product',
  templateUrl: './add-new-product.component.html',
  styleUrls: ['./add-new-product.component.css']
})
export class AddNewProductComponent extends BaseComponent implements OnInit {
  
  // For product type dropdown
  public prodTypeDropdownSettings: USFDropdownMenuSettings = {
    selectedOption: 'Grocery',
    options: [],
    smBtn: false,
    width: '240',
    height: 'auto',
    invalid: false
  };
  private selectedProdType: string;
  public defaultProdType: string = 'Grocery';
  public minDate: Date = new Date();
  public value: Date;
  
  counter = 1;
  calendar_counter = 1;
  changeMonthFlag = false;

  // for calendar
  public calendarSettings: USFCalendarSettings = {
    value: new Date(),
    minDate: new Date(),
    // maxDate: new Date(),
    width: '255',
    smBtn: false,
    error: false,
    inputStyleClass: ['calendar-input-240'],
    styleClass: ['calendar-component']
  }

  //Validation Error Handling
  public product_desc_require_error: boolean = false;
  public vendor_require_error: boolean = false;
  public mfr_product_require_error: boolean = false;
  public qty_require_error: boolean = false;
  public qty_number_error: boolean = false;
  public zero_number_error: boolean = false;
  public date_selection_error: boolean = false;

  public sellPrice_number_error: boolean = false;
  public textareaLength: number = 1000;
  
  //other fields
  public product: Product;
  public comment: Comment;
  maxIncidentDescriptionLength: any = 1000;
  //Product attachment
  public fileName: string = "";
  public fileType: string = "";
  public showIcon:boolean = true;
  public attachmentsList:Array<any> = [];
  actionCompleted:boolean = true;
  public actionFailed = false;
  statusText : string;
  public requisitionId: string;
  fileRef: ElementRef;
  objectKey: string;
  attachCount : number = 0;
  public filesFound : boolean;
  public errorOnUpload: boolean = false;
  @ViewChild('fileInput') inputEl: ElementRef;
  @ViewChild('ProdTypeDropdown') prodTypeDropdown: USFDropdownComponent;
  @ViewChild('sodsCalendar') sodsCalendar: CalendarComponent;
  disableUpload: boolean = false;
  public showAlert = false;
  showModalAlert = false;
  public alertType = "";
  public alertMessage = "";
  public alertSettings: AlertSetting[] = [{ alertType: "", alertMessage: "" }];
  // For Spinner
  loading = false;

  constructor(private http: Http, readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => {}
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_FAIL] = (error:any) => {this.renderError(error)}
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DELETE_SUCCESS] = () => {this.renderAttachmentDeleted()}
    mapping[ModelChangeUpdateEvents.REQ_ID_GENERATED_SUCCESS] = (reqId: string) => { this.renderReqIdGenerated(reqId); } 
    super.registerStateChangeEvents(mapping);
    
  }

  ngOnInit() {
    this.prodTypeDropdownSettings.options = ['Grocery', 'Produce', 'COP', 'Non-Food', 'CES'];
    this.calendarSettings.minDate = new Date();
    this.product = new Product();
    this.product.vendor = new Vendor();
    this.product.prodType = this.prodTypeDropdownSettings.selectedOption;
    this.product.new = true;
    this.comment = new Comment();
    this.product.comments = new Array<Comment>();
    this.attachmentsList = []; 
  }

  renderReqIdGenerated(reqId) {
    this.requisitionId = reqId;
  }

  onProdTypeSelection($event){
    this.product.prodType = $event;
  }

  onDateSelectionDone($event){
    this.product.eta = $event;
    this.date_selection_error = false;
    this.calendarSettings.error = false;
  }

  onErrorHandler($event){
    this.date_selection_error = true;
    this.calendarSettings.error = true;
    if ($event !== 'error') {
      this.date_selection_error = false;
      this.calendarSettings.error = false;
    }
  }

  checkNumberFormatforQty() {
    this.checkKeyupRequire_qty();
    if(this.validateNumber(this.product.qty)) {
      this.qty_number_error = false;
    } else { 
      this.qty_number_error = true; 
    }
    if(this.product.qty === '0'){
      this.zero_number_error = true;
    }else{
      this.zero_number_error = false;
    }
  }

  //Validate Number
  validateNumber(data: string){
		if(data === null || data === undefined || data.trim() === '') {
      this.qty_require_error = true;
      return true;
    }
    this.qty_require_error = false;
		let NUMBER_REGEXP = /^[0-9]{1,5}$/
		return NUMBER_REGEXP.test(data);
  }
  

  checkSellPrice() {
    if(this.product.sellPrice === "" || this.product.sellPrice === null || this.product.sellPrice === undefined) {
        this.sellPrice_number_error = false;
        return;   
    }
    
    if(this.validateQuotePrice(this.product.sellPrice)) {
        this.sellPrice_number_error = false;            
        //checks for whole integers (ex. 32) and converts to 32.00
        if(this.product.sellPrice.indexOf('.') === -1 && !(this.product.sellPrice.charAt(0) === '.')){
          this.product.sellPrice = this.product.sellPrice.concat('.00');
        }
        //checks for .xx and converts to 0.xx
        if(this.product.sellPrice.charAt(0) === '.'){
          this.product.sellPrice = '0'.concat(this.product.sellPrice);
        }
    } else { 
        this.sellPrice_number_error = true;     
    } 
  }

  validateQuotePrice(quote: string) : boolean {
    if(quote === null || quote === undefined || quote.trim() === ""){
      return true;
    }
    let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
    return QUOTE_REGEXP.test(quote);
  }

  checkProdDescRequire(){
    if(this.product.description === null || this.product.description === undefined || this.product.description.trim() === ""){
      this.product_desc_require_error = true;
    }else{
      this.product_desc_require_error = false;
    }
  }

  checkKeyupRequire_desc(){
    this.product.description = this.product.description.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    this.product_desc_require_error = 
    ((this.product.description === null || this.product.description === undefined || this.product.description.trim() === "") ? true : false);
  }

  checkKeyupRequire_mfrProd(){
    this.product.mfrId = this.product.mfrId.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    this.mfr_product_require_error = 
    ((this.product.mfrId === null || this.product.mfrId === undefined || this.product.mfrId.trim( )=== "") ? true : false);    
  }

  checkKeyupRequire_qty(){
    this.qty_require_error = 
    ((this.product.qty === null || this.product.qty === undefined || this.product.qty.trim() === "") ? true : false); 
  }

  addComment(){
    this.comment.commentsText = this.comment.commentsText.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    //this.comment.timestamp = this.getDateFormat(new Date());
    let now = new Date(); 
    let now_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),  now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
    this.comment.timestamp = this.getDateFormat(now_utc);
    this.comment.networkID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
    this.comment.name = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName;
  }

  attachfile() {
    this.showModalAlert = false;
    if(this.disableUpload) {
      this.showAlertMessage('error','99FileLimit','modal');
      this.showModalAlert = true;
      this.errorOnUpload = true;
    }else{
      if(this.attachmentsList.length + 1 > 99) {
        this.showAlertMessage('error','99FileLimit','modal');
        this.showModalAlert = true;
        this.errorOnUpload = true;
      }else{
          this.fileName = "";
          let inputEl: HTMLInputElement = this.inputEl.nativeElement;
          let fileCount: number = inputEl.files.length;
          let APIURL = environment.productAttachments +"/"+ this.requisitionId + "/upload?" + 
            "sequenceId=" + this.product.seq; //Put into environments.ts? Have multiple pointing at this API
          let token = JSON.parse(localStorage.getItem('token')).value; 
          let headers = new Headers();
          headers.append('Authorization', `Bearer ${token}`);
          let options = new RequestOptions({headers: headers});
          let fileName: string;
          let attachment = new FormData();
          this.errorOnUpload = false;
    
          if (fileCount > 0) {
              for (let i = 0; i < fileCount; i++) {
                attachment.append("attachment", inputEl.files.item(i));
                fileName = inputEl.files.item(i).name;
                for(let i = 0; i < this.attachmentsList.length; i++) {
                  if(this.attachmentsList[i].fileName.toLowerCase() == fileName.toLowerCase()) {
                    this.showAlertMessage('error','duplicateFileNames','modal');
                    this.showModalAlert = true;
                    this.errorOnUpload = true;
                  }
                }
              }
              if(!this.errorOnUpload) {
                return this.http.put(APIURL, attachment, options)
                    .toPromise().then((res: Response)=>{
                        let body = res.json();
                        inputEl.value = "";
                        this.attachmentsList.push({objectKey: body.objectKey, fileName : fileName });
                    }).catch(
                        (error: Response) => {
                           let errorBody = error.json();
                           this.errorOnUpload = true;
                           this.showCustomAlertMessage('error',errorBody.message,'modal');
                           this.showModalAlert = true;
                        } 
                    );
              } 
          } 
          this.inputEl.nativeElement.value = "";
          return;
        }
      }
  }

  deleteAttachments(requisitionId, objectKey) {
    this.errorOnUpload = false;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_DELETE, {requisitionId: this.requisitionId, objectKey: objectKey});
    this.actionDispatcherService.dispatch(event);
  }

  deleteElement(elem){
    let elementitem:HTMLElement = document.getElementById('attach'+elem);
    elementitem.parentNode.removeChild(elementitem);
    this.attachmentsList.splice(elem, 1);
  }

  renderAttachmentDeleted() {
  }

  renderError(error: any) {
    this.showCustomAlertMessage('error',error.statusText,'modal');
    this.showModalAlert = true;
    this.actionFailed = true;
  }

  checkPackSize(){
    this.product.packSize = this.product.packSize.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
  }

  checkLabel(){
    this.product.label = this.product.label.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
  }
  
  checkVendor(){
    this.product.vendor.vendorName = this.product.vendor.vendorName.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    this.vendor_require_error = 
    ((this.product.vendor.vendorName === null || this.product.vendor.vendorName === undefined || this.product.vendor.vendorName.trim() === "") ? true : false);
  }
  
  get attachmentCount(){
    return this.attachmentsList.length;
  }

  getDateFormat(date: Date) {
      let d = '';
      d += date.getFullYear();
      d += '-' + (((date.getMonth() + 1) <= 9) ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1));
      d += '-' + date.getDate();
      d += ' ' + ((date.getHours() <= 9) ? '0' + date.getHours() : date.getHours());
      d += ':' + ((date.getMinutes() <= 9) ? '0' + date.getMinutes() : date.getMinutes());
      d += ':' + ((date.getSeconds() <= 9) ? '0' + date.getSeconds() : date.getSeconds());
      return d;
  }

  controlClick(){
    if(this.changeMonthFlag){
      this.changeMonthFlag = false;
      return;
    }
    this.controlClickForDropdown();
    this.controlClickForCalendar();
  }

  controlClickForDropdown(){
    if(this.counter % 2 === 0 && this.prodTypeDropdown.isVisible){
      this.prodTypeDropdown.isVisible = false;
      this.counter ++;
    }else if(this.prodTypeDropdown.isVisible){
      this.counter ++;
    }else if(this.counter % 2 === 0 && !this.prodTypeDropdown.isVisible){
      this.counter ++;
    }
  }

controlClickForCalendar(){
    if(this.notNullAndUndefined(this.sodsCalendar)){
      if(this.calendar_counter % 2 === 0 && this.sodsCalendar.child1.overlayVisible){
        this.sodsCalendar.child1.overlayVisible = false;
        this.calendar_counter ++;
      }else if(this.sodsCalendar.child1.overlayVisible){
        this.calendar_counter ++;
      }else if(this.calendar_counter  % 2 === 0 && !this.sodsCalendar.child1.overlayVisible){
        this.calendar_counter ++;
      }
    }
  }

notNullAndUndefined(data: any){
    return(data !== null && data !== undefined) ? true : false;
  }

  changeMonth(){
    this.changeMonthFlag = true;
  }

  showAlertMessage(alertType: string, alertText: string, location: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert: AlertSetting = {
      alertType: alertType,
      alertMessage: this.alertMessage
    };
    this.alertSettings.push(alert);
    this.showAlert = location !== "modal" ? true : false;
    this.showModalAlert = location === "modal" ? true : false;
    this.loading = false;
}
  showCustomAlertMessage(alertType: string, alertText: string, location: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert: AlertSetting = {
      alertType: alertType,
      alertMessage: alertText
    };
    this.alertSettings.push(alert);
    this.showAlert = location !== "modal" ? true : false;
    this.showModalAlert = location === "modal" ? true : false;
    this.loading = false;
  }
  goTo(location: string): void {
    window.location.hash = "";
    window.location.hash = location;
  }

}
