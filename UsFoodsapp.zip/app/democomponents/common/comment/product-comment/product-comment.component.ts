import { Component, OnInit } from '@angular/core';
import { Comment, SAMPLECommentA, SAMPLECommentB } from '../../../../model/comment';

@Component({
  selector: 'sods-product-comment',
  templateUrl: './product-comment.component.html',
  styleUrls: ['./product-comment.component.css']
})
export class ProductCommentComponent implements OnInit {

  public comments: Array<Comment> = [];
  public newAddFlag: boolean = false;
  public productSeq: number;
  public newAddedCount: number = 0;
  isHide = false;

  private textareaLength: number = 1000;
  maxIncidentDescriptionLength: any = 1000;
  //validation for comment
  public commentErr : boolean = false;

  constructor() { }

  ngOnInit() {

  }

  addComment(){
    //check if the comment added previously is empty or not

    if(this.newAddedCount > 0) {
      if(this.comments[0]) {
        if(this.comments[0].commentsText === null || this.comments[0].commentsText === undefined || this.comments[0].commentsText.trim() === ''){
          this.commentErr = true;
        }
      }
    }
    if(!this.commentErr){
      this.newAddedCount += 1;
      this.comments.reverse();
      let newComment : Comment = new Comment();
      newComment.new = true;
      newComment.name = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName;
      let now = new Date(); 
      let now_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),  now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
      newComment.timestamp = this.getDateFormat(now_utc);
      newComment.networkID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
      newComment.commentsText = '';
      this.commentErr = false;
      this.newAddFlag = true;
      this.comments.push(newComment);
      this.comments.reverse();
    }
  }


  checkComment(comment: Comment){
    if(comment.commentsText === null || comment.commentsText === undefined || comment.commentsText.trim() === ''){
      this.commentErr = true;
    }else{
      comment.commentsText = comment.commentsText.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
      this.commentErr = false;
    }
  }

  autogrow(){
    let textArea = document.getElementById("area");       
    textArea.style.overflow = 'hidden';
    textArea.style.height = '50px';
    textArea.style.height = textArea.scrollHeight + 'px';
  }

  getDateFormat(date: Date) {
      let d = '';
      d += date.getFullYear();
      d += '-' + (((date.getMonth() + 1) <= 9) ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1));
      d += '-' + date.getDate();
      d += ' ' + ((date.getHours() <= 9) ? '0' + date.getHours() : date.getHours());
      d += ':' + ((date.getMinutes() <= 9) ? '0' + date.getMinutes() : date.getMinutes());
      d += ':' + ((date.getSeconds() <= 9) ? '0' + date.getSeconds() : date.getSeconds());
      return d;
  }
}
