import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductCommentComponent } from './product-comment.component';
import { SharedModule } from "app/shared/shared.module";
import { RouterTestingModule } from "@angular/router/testing";
import { SAMPLECommentA } from "app/model/comment";

describe('ProductCommentComponent', () => {
  let component: ProductCommentComponent;
  let fixture: ComponentFixture<ProductCommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule, RouterTestingModule],
      declarations: [ ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    let store = {};
    const mockSAMCall = {
      getRequisitionDetails: (key: string) => {

      },
      getAttachmentDetails: () =>{

      },
      getComments: () => {

      },
      getDivisions: () => {

      },
      completeTask: () => {

      },
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
    .and.callFake(mockSAMCall.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockSAMCall.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockSAMCall.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockSAMCall.clear);
    localStorage.setItem('user', JSON.stringify({_body: JSON.stringify({'userId': 1, 'email': '', 'phoneNumber': '', 
      applicationMarkets: [{marketName: 'sample', marketNum: 'sample', marketCode: 'sample'}]})}));
    fixture = TestBed.createComponent(ProductCommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add comment successfully', ()=>{
    component.commentErr = false;
    component.newAddedCount = 1;
    component.comments[0] = SAMPLECommentA;
    component.addComment();
    component.comments[0].commentsText = '';
    component.addComment();
  });

  it('should check comment successfully', ()=>{
    let comment = Object.assign({}, SAMPLECommentA);
    component.checkComment(comment);
    expect(component.commentErr).toBeFalsy;
    comment.commentsText = '';
    component.checkComment(comment);
    expect(component.commentErr).toBeTruthy;
  });

  it('should auto grow successfully', ()=>{
    //component.autogrow();
    //expect(document.getElementById("area").style.overflow).toBe('hidden');
  });

  it('should get the date with correct format', ()=>{
    let date = new Date('2018-01-3 16:59:46');
    expect(component.getDateFormat(date)).toBe('2018-01-3 16:59:46');
  });



});
