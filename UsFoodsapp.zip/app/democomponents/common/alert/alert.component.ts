import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ALERTS } from './alerts';

export interface AlertSetting {
  alertType: string;
  alertMessage: string;
}

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit, OnChanges{

  @Input() alertSettings: AlertSetting[];
  @Input() showErrorBar: boolean = false;
  @Input() showSuccessBar: boolean = false;
  @Input() fontSize: string;
  @Input() marginBottom: boolean;
  @Output() onCloseBar = new EventEmitter();

  message: string;
  alert: any[];
  hideErrorBar: boolean = false;
  hideSuccessBar: boolean = false;

  constructor() {
    
  }

  ngOnInit() {
    this.alert = this.alertSettings;
    this.message = ALERTS[this.alert[0].alertType][this.alert[0].alertMessage];
  }

  ngDoCheck() {

  }

  ngOnChanges(changes: SimpleChanges): void {
    this.hideErrorBar = false;
    this.hideSuccessBar = false;
  }

  closeSuccessBar() {
    this.hideSuccessBar = true;
  }
  closeErrorBar() {
    this.hideErrorBar = true;
    if (!this.onCloseBar) {
      return null;
    }
    this.onCloseBar.emit(this.alert);
  }
}
