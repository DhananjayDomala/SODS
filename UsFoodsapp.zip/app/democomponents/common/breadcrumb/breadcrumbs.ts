export const BREADCRUMBS = {
    'home': {
        'heading': 'SODS',
        'links': [
            {
                'href': '/taskInbox',
                'name': 'Home',
                'active': true
            }
        ]
    },
    'create-requisition': {
        'heading': 'Create Requisition',
        'links': [
            {
                'href': '/sodsnew',
                'name': 'Create Requisition',
                'active': true
            }
        ]
    },
    'market-role-manager': {
        'heading': 'Market Role Manager',
        'links': [
            {
                'href': '/marketrolemanager',
                'name': 'Market Role Manager',
                'active': true
            }
        ]
    },
    'approver':{
        'heading': 'Approver Screen',
        'links': [
            {
                'href': '/approver',
                'name': 'Approver',
                'active': true
            }
        ]
    },

    'search': {
        'heading': 'Sods Search',
        'links': [
            {
                'href': '/search',
                'name': 'Search',
                'active': true
            }
        ]
    },

    'outOfOffice': {
        'heading': 'Out Of Office',
        'links': [
            {
                'href': '/outOfOffice',
                'name': 'Out Of Office',
                'active': true
            }
        ]
    },

    'specialOrder': {
        'heading': 'Special Order',
        'links': [
            {
                'href': '/search',
                'name': 'Search',
                'active': false
            },
            {
                'href': '/request-details',
                'name': 'Special Order Requisition',
                'active': true
            }
        ]
    },
    'directOrder': {
        'heading': 'Direct Order',
        'links': [
            {
                'href': '/search',
                'name': 'Search',
                'active': false
            },
            {
                'href': '/request-details',
                'name': 'Direct Ship Requisition',
                'active': true
            }
        ]
    },
    'super-user': {
        'heading': 'Market Super User Maintenance',
        'links': [
            {
                'href': '/administration/superUser',
                'name': 'Market Role Manager',
                'active': true
            }
        ]
    }
};
