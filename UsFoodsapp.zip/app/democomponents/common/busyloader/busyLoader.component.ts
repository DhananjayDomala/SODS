import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-busy-loader',
  templateUrl: './busyLoader.component.html',
  styleUrls: ['./busyLoader.component.css']
})
export class BusyLoaderComponent implements OnInit {
  @Input() loading: boolean;
  @Input() marginTop;

  constructor() { }

  ngOnInit() {
  }

}
